//#region node_modules/.pnpm/livekit-client@2.19.2_@types+dom-mediacapture-record@1.0.22/node_modules/livekit-client/dist/livekit-client.esm.mjs
function e(e, t) {
	return t.forEach(function(t) {
		t && typeof t != "string" && !Array.isArray(t) && Object.keys(t).forEach(function(n) {
			if (n !== "default" && !(n in e)) {
				var r = Object.getOwnPropertyDescriptor(t, n);
				Object.defineProperty(e, n, r.get ? r : {
					enumerable: !0,
					get: function() {
						return t[n];
					}
				});
			}
		});
	}), Object.freeze(e);
}
var t = Object.defineProperty, n = (e, n, r) => n in e ? t(e, n, {
	enumerable: !0,
	configurable: !0,
	writable: !0,
	value: r
}) : e[n] = r, r = (e, t, r) => n(e, typeof t == "symbol" ? t : t + "", r), i = class {
	constructor() {
		r(this, "_locking"), r(this, "_locks"), this._locking = Promise.resolve(), this._locks = 0;
	}
	isLocked() {
		return this._locks > 0;
	}
	lock() {
		this._locks += 1;
		let e, t = new Promise((t) => e = () => {
			--this._locks, t();
		}), n = this._locking.then(() => e);
		return this._locking = this._locking.then(() => t), n;
	}
};
function a(e, t) {
	if (!e) throw Error(t);
}
var o = 34028234663852886e22, s = -34028234663852886e22, c = 4294967295, l = 2147483647, u = -2147483648;
function d(e) {
	if (typeof e != "number") throw Error("invalid int 32: " + typeof e);
	if (!Number.isInteger(e) || e > l || e < u) throw Error("invalid int 32: " + e);
}
function f(e) {
	if (typeof e != "number") throw Error("invalid uint 32: " + typeof e);
	if (!Number.isInteger(e) || e > c || e < 0) throw Error("invalid uint 32: " + e);
}
function ee(e) {
	if (typeof e != "number") throw Error("invalid float 32: " + typeof e);
	if (Number.isFinite(e) && (e > o || e < s)) throw Error("invalid float 32: " + e);
}
var te = Symbol("@bufbuild/protobuf/enum-type");
function ne(e) {
	let t = e[te];
	return a(t, "missing enum type on enum object"), t;
}
function re(e, t, n, r) {
	e[te] = ie(t, n.map((t) => ({
		no: t.no,
		name: t.name,
		localName: e[t.no]
	})));
}
function ie(e, t, n) {
	let r = Object.create(null), i = Object.create(null), a = [];
	for (let e of t) {
		let t = oe(e);
		a.push(t), r[e.name] = t, i[e.no] = t;
	}
	return {
		typeName: e,
		values: a,
		findName(e) {
			return r[e];
		},
		findNumber(e) {
			return i[e];
		}
	};
}
function ae(e, t, n) {
	let r = {};
	for (let e of t) {
		let t = oe(e);
		r[t.localName] = t.no, r[t.no] = t.localName;
	}
	return re(r, e, t), r;
}
function oe(e) {
	return "localName" in e ? e : Object.assign(Object.assign({}, e), { localName: e.name });
}
var se = class {
	equals(e) {
		return this.getType().runtime.util.equals(this.getType(), this, e);
	}
	clone() {
		return this.getType().runtime.util.clone(this);
	}
	fromBinary(e, t) {
		let n = this.getType().runtime.bin, r = n.makeReadOptions(t);
		return n.readMessage(this, r.readerFactory(e), e.byteLength, r), this;
	}
	fromJson(e, t) {
		let n = this.getType(), r = n.runtime.json, i = r.makeReadOptions(t);
		return r.readMessage(n, e, i, this), this;
	}
	fromJsonString(e, t) {
		let n;
		try {
			n = JSON.parse(e);
		} catch (e) {
			throw Error(`cannot decode ${this.getType().typeName} from JSON: ${e instanceof Error ? e.message : String(e)}`);
		}
		return this.fromJson(n, t);
	}
	toBinary(e) {
		let t = this.getType().runtime.bin, n = t.makeWriteOptions(e), r = n.writerFactory();
		return t.writeMessage(this, r, n), r.finish();
	}
	toJson(e) {
		let t = this.getType().runtime.json, n = t.makeWriteOptions(e);
		return t.writeMessage(this, n);
	}
	toJsonString(e) {
		let t = this.toJson(e);
		return JSON.stringify(t, null, e?.prettySpaces ?? 0);
	}
	toJSON() {
		return this.toJson({ emitDefaultValues: !0 });
	}
	getType() {
		return Object.getPrototypeOf(this).constructor;
	}
};
function ce(e, t, n, r) {
	let i = r?.localName ?? t.substring(t.lastIndexOf(".") + 1), a = { [i]: function(t) {
		e.util.initFields(this), e.util.initPartial(t, this);
	} }[i];
	return Object.setPrototypeOf(a.prototype, new se()), Object.assign(a, {
		runtime: e,
		typeName: t,
		fields: e.util.newFieldList(n),
		fromBinary(e, t) {
			return new a().fromBinary(e, t);
		},
		fromJson(e, t) {
			return new a().fromJson(e, t);
		},
		fromJsonString(e, t) {
			return new a().fromJsonString(e, t);
		},
		equals(t, n) {
			return e.util.equals(a, t, n);
		}
	}), a;
}
function le() {
	let e = 0, t = 0;
	for (let n = 0; n < 28; n += 7) {
		let r = this.buf[this.pos++];
		if (e |= (r & 127) << n, !(r & 128)) return this.assertBounds(), [e, t];
	}
	let n = this.buf[this.pos++];
	if (e |= (n & 15) << 28, t = (n & 112) >> 4, !(n & 128)) return this.assertBounds(), [e, t];
	for (let n = 3; n <= 31; n += 7) {
		let r = this.buf[this.pos++];
		if (t |= (r & 127) << n, !(r & 128)) return this.assertBounds(), [e, t];
	}
	throw Error("invalid varint");
}
function ue(e, t, n) {
	for (let r = 0; r < 28; r += 7) {
		let i = e >>> r, a = !(!(i >>> 7) && t == 0), o = (a ? i | 128 : i) & 255;
		if (n.push(o), !a) return;
	}
	let r = e >>> 28 & 15 | (t & 7) << 4, i = !!(t >> 3);
	if (n.push((i ? r | 128 : r) & 255), i) {
		for (let e = 3; e < 31; e += 7) {
			let r = t >>> e, i = !!(r >>> 7), a = (i ? r | 128 : r) & 255;
			if (n.push(a), !i) return;
		}
		n.push(t >>> 31 & 1);
	}
}
var de = 4294967296;
function fe(e) {
	let t = e[0] === "-";
	t && (e = e.slice(1));
	let n = 1e6, r = 0, i = 0;
	function a(t, a) {
		let o = Number(e.slice(t, a));
		i *= n, r = r * n + o, r >= de && (i += r / de | 0, r %= de);
	}
	return a(-24, -18), a(-18, -12), a(-12, -6), a(-6), t ? _e(r, i) : ge(r, i);
}
function pe(e, t) {
	let n = ge(e, t), r = n.hi & 2147483648;
	r && (n = _e(n.lo, n.hi));
	let i = me(n.lo, n.hi);
	return r ? "-" + i : i;
}
function me(e, t) {
	var n = he(e, t);
	if (e = n.lo, t = n.hi, t <= 2097151) return String(de * t + e);
	let r = e & 16777215, i = (e >>> 24 | t << 8) & 16777215, a = t >> 16 & 65535, o = r + i * 6777216 + a * 6710656, s = i + a * 8147497, c = a * 2, l = 1e7;
	return o >= l && (s += Math.floor(o / l), o %= l), s >= l && (c += Math.floor(s / l), s %= l), c.toString() + ve(s) + ve(o);
}
function he(e, t) {
	return {
		lo: e >>> 0,
		hi: t >>> 0
	};
}
function ge(e, t) {
	return {
		lo: e | 0,
		hi: t | 0
	};
}
function _e(e, t) {
	return t = ~t, e ? e = ~e + 1 : t += 1, ge(e, t);
}
var ve = (e) => {
	let t = String(e);
	return "0000000".slice(t.length) + t;
};
function ye(e, t) {
	if (e >= 0) {
		for (; e > 127;) t.push(e & 127 | 128), e >>>= 7;
		t.push(e);
	} else {
		for (let n = 0; n < 9; n++) t.push(e & 127 | 128), e >>= 7;
		t.push(1);
	}
}
function be() {
	let e = this.buf[this.pos++], t = e & 127;
	if (!(e & 128) || (e = this.buf[this.pos++], t |= (e & 127) << 7, !(e & 128)) || (e = this.buf[this.pos++], t |= (e & 127) << 14, !(e & 128)) || (e = this.buf[this.pos++], t |= (e & 127) << 21, !(e & 128))) return this.assertBounds(), t;
	e = this.buf[this.pos++], t |= (e & 15) << 28;
	for (let t = 5; e & 128 && t < 10; t++) e = this.buf[this.pos++];
	if (e & 128) throw Error("invalid varint");
	return this.assertBounds(), t >>> 0;
}
function xe() {
	let e = /* @__PURE__ */ new DataView(/* @__PURE__ */ new ArrayBuffer(8));
	if (typeof BigInt == "function" && typeof e.getBigInt64 == "function" && typeof e.getBigUint64 == "function" && typeof e.setBigInt64 == "function" && typeof e.setBigUint64 == "function" && (typeof process != "object" || typeof process.env != "object" || process.env.BUF_BIGINT_DISABLE !== "1")) {
		let t = BigInt("-9223372036854775808"), n = BigInt("9223372036854775807"), r = BigInt("0"), i = BigInt("18446744073709551615");
		return {
			zero: BigInt(0),
			supported: !0,
			parse(e) {
				let r = typeof e == "bigint" ? e : BigInt(e);
				if (r > n || r < t) throw Error(`int64 invalid: ${e}`);
				return r;
			},
			uParse(e) {
				let t = typeof e == "bigint" ? e : BigInt(e);
				if (t > i || t < r) throw Error(`uint64 invalid: ${e}`);
				return t;
			},
			enc(t) {
				return e.setBigInt64(0, this.parse(t), !0), {
					lo: e.getInt32(0, !0),
					hi: e.getInt32(4, !0)
				};
			},
			uEnc(t) {
				return e.setBigInt64(0, this.uParse(t), !0), {
					lo: e.getInt32(0, !0),
					hi: e.getInt32(4, !0)
				};
			},
			dec(t, n) {
				return e.setInt32(0, t, !0), e.setInt32(4, n, !0), e.getBigInt64(0, !0);
			},
			uDec(t, n) {
				return e.setInt32(0, t, !0), e.setInt32(4, n, !0), e.getBigUint64(0, !0);
			}
		};
	}
	let t = (e) => a(/^-?[0-9]+$/.test(e), `int64 invalid: ${e}`), n = (e) => a(/^[0-9]+$/.test(e), `uint64 invalid: ${e}`);
	return {
		zero: "0",
		supported: !1,
		parse(e) {
			return typeof e != "string" && (e = e.toString()), t(e), e;
		},
		uParse(e) {
			return typeof e != "string" && (e = e.toString()), n(e), e;
		},
		enc(e) {
			return typeof e != "string" && (e = e.toString()), t(e), fe(e);
		},
		uEnc(e) {
			return typeof e != "string" && (e = e.toString()), n(e), fe(e);
		},
		dec(e, t) {
			return pe(e, t);
		},
		uDec(e, t) {
			return me(e, t);
		}
	};
}
var p = xe(), m;
(function(e) {
	e[e.DOUBLE = 1] = "DOUBLE", e[e.FLOAT = 2] = "FLOAT", e[e.INT64 = 3] = "INT64", e[e.UINT64 = 4] = "UINT64", e[e.INT32 = 5] = "INT32", e[e.FIXED64 = 6] = "FIXED64", e[e.FIXED32 = 7] = "FIXED32", e[e.BOOL = 8] = "BOOL", e[e.STRING = 9] = "STRING", e[e.BYTES = 12] = "BYTES", e[e.UINT32 = 13] = "UINT32", e[e.SFIXED32 = 15] = "SFIXED32", e[e.SFIXED64 = 16] = "SFIXED64", e[e.SINT32 = 17] = "SINT32", e[e.SINT64 = 18] = "SINT64";
})(m ||= {});
var Se;
(function(e) {
	e[e.BIGINT = 0] = "BIGINT", e[e.STRING = 1] = "STRING";
})(Se ||= {});
function Ce(e, t, n) {
	if (t === n) return !0;
	if (e == m.BYTES) {
		if (!(t instanceof Uint8Array) || !(n instanceof Uint8Array) || t.length !== n.length) return !1;
		for (let e = 0; e < t.length; e++) if (t[e] !== n[e]) return !1;
		return !0;
	}
	switch (e) {
		case m.UINT64:
		case m.FIXED64:
		case m.INT64:
		case m.SFIXED64:
		case m.SINT64: return t == n;
	}
	return !1;
}
function we(e, t) {
	switch (e) {
		case m.BOOL: return !1;
		case m.UINT64:
		case m.FIXED64:
		case m.INT64:
		case m.SFIXED64:
		case m.SINT64: return t == 0 ? p.zero : "0";
		case m.DOUBLE:
		case m.FLOAT: return 0;
		case m.BYTES: return new Uint8Array();
		case m.STRING: return "";
		default: return 0;
	}
}
function Te(e, t) {
	switch (e) {
		case m.BOOL: return t === !1;
		case m.STRING: return t === "";
		case m.BYTES: return t instanceof Uint8Array && !t.byteLength;
		default: return t == 0;
	}
}
function Ee(e, t) {
	(t == null || t > e.length) && (t = e.length);
	for (var n = 0, r = Array(t); n < t; n++) r[n] = e[n];
	return r;
}
function De(e) {
	if (Array.isArray(e)) return e;
}
function h(e, t, n) {
	return (t = je(t)) in e ? Object.defineProperty(e, t, {
		value: n,
		enumerable: !0,
		configurable: !0,
		writable: !0
	}) : e[t] = n, e;
}
function Oe(e, t) {
	var n = e == null ? null : typeof Symbol < "u" && e[Symbol.iterator] || e["@@iterator"];
	if (n != null) {
		var r, i, a, o, s = [], c = !0, l = !1;
		try {
			if (a = (n = n.call(e)).next, t === 0) {
				if (Object(n) !== n) return;
				c = !1;
			} else for (; !(c = (r = a.call(n)).done) && (s.push(r.value), s.length !== t); c = !0);
		} catch (e) {
			l = !0, i = e;
		} finally {
			try {
				if (!c && n.return != null && (o = n.return(), Object(o) !== o)) return;
			} finally {
				if (l) throw i;
			}
		}
		return s;
	}
}
function ke() {
	throw TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function g(e, t) {
	return De(e) || Oe(e, t) || Me(e, t) || ke();
}
function Ae(e, t) {
	if (typeof e != "object" || !e) return e;
	var n = e[Symbol.toPrimitive];
	if (n !== void 0) {
		var r = n.call(e, t);
		if (typeof r != "object") return r;
		throw TypeError("@@toPrimitive must return a primitive value.");
	}
	return (t === "string" ? String : Number)(e);
}
function je(e) {
	var t = Ae(e, "string");
	return typeof t == "symbol" ? t : t + "";
}
function Me(e, t) {
	if (e) {
		if (typeof e == "string") return Ee(e, t);
		var n = {}.toString.call(e).slice(8, -1);
		return n === "Object" && e.constructor && (n = e.constructor.name), n === "Map" || n === "Set" ? Array.from(e) : n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? Ee(e, t) : void 0;
	}
}
var _;
(function(e) {
	e[e.Varint = 0] = "Varint", e[e.Bit64 = 1] = "Bit64", e[e.LengthDelimited = 2] = "LengthDelimited", e[e.StartGroup = 3] = "StartGroup", e[e.EndGroup = 4] = "EndGroup", e[e.Bit32 = 5] = "Bit32";
})(_ ||= {});
var Ne = class {
	constructor(e) {
		this.stack = [], this.textEncoder = e ?? new TextEncoder(), this.chunks = [], this.buf = [];
	}
	finish() {
		this.chunks.push(new Uint8Array(this.buf));
		let e = 0;
		for (let t = 0; t < this.chunks.length; t++) e += this.chunks[t].length;
		let t = new Uint8Array(e), n = 0;
		for (let e = 0; e < this.chunks.length; e++) t.set(this.chunks[e], n), n += this.chunks[e].length;
		return this.chunks = [], t;
	}
	fork() {
		return this.stack.push({
			chunks: this.chunks,
			buf: this.buf
		}), this.chunks = [], this.buf = [], this;
	}
	join() {
		let e = this.finish(), t = this.stack.pop();
		if (!t) throw Error("invalid state, fork stack empty");
		return this.chunks = t.chunks, this.buf = t.buf, this.uint32(e.byteLength), this.raw(e);
	}
	tag(e, t) {
		return this.uint32((e << 3 | t) >>> 0);
	}
	raw(e) {
		return this.buf.length && (this.chunks.push(new Uint8Array(this.buf)), this.buf = []), this.chunks.push(e), this;
	}
	uint32(e) {
		for (f(e); e > 127;) this.buf.push(e & 127 | 128), e >>>= 7;
		return this.buf.push(e), this;
	}
	int32(e) {
		return d(e), ye(e, this.buf), this;
	}
	bool(e) {
		return this.buf.push(+!!e), this;
	}
	bytes(e) {
		return this.uint32(e.byteLength), this.raw(e);
	}
	string(e) {
		let t = this.textEncoder.encode(e);
		return this.uint32(t.byteLength), this.raw(t);
	}
	float(e) {
		ee(e);
		let t = new Uint8Array(4);
		return new DataView(t.buffer).setFloat32(0, e, !0), this.raw(t);
	}
	double(e) {
		let t = new Uint8Array(8);
		return new DataView(t.buffer).setFloat64(0, e, !0), this.raw(t);
	}
	fixed32(e) {
		f(e);
		let t = new Uint8Array(4);
		return new DataView(t.buffer).setUint32(0, e, !0), this.raw(t);
	}
	sfixed32(e) {
		d(e);
		let t = new Uint8Array(4);
		return new DataView(t.buffer).setInt32(0, e, !0), this.raw(t);
	}
	sint32(e) {
		return d(e), e = (e << 1 ^ e >> 31) >>> 0, ye(e, this.buf), this;
	}
	sfixed64(e) {
		let t = new Uint8Array(8), n = new DataView(t.buffer), r = p.enc(e);
		return n.setInt32(0, r.lo, !0), n.setInt32(4, r.hi, !0), this.raw(t);
	}
	fixed64(e) {
		let t = new Uint8Array(8), n = new DataView(t.buffer), r = p.uEnc(e);
		return n.setInt32(0, r.lo, !0), n.setInt32(4, r.hi, !0), this.raw(t);
	}
	int64(e) {
		let t = p.enc(e);
		return ue(t.lo, t.hi, this.buf), this;
	}
	sint64(e) {
		let t = p.enc(e), n = t.hi >> 31;
		return ue(t.lo << 1 ^ n, (t.hi << 1 | t.lo >>> 31) ^ n, this.buf), this;
	}
	uint64(e) {
		let t = p.uEnc(e);
		return ue(t.lo, t.hi, this.buf), this;
	}
}, Pe = class {
	constructor(e, t) {
		this.varint64 = le, this.uint32 = be, this.buf = e, this.len = e.length, this.pos = 0, this.view = new DataView(e.buffer, e.byteOffset, e.byteLength), this.textDecoder = t ?? new TextDecoder();
	}
	tag() {
		let e = this.uint32(), t = e >>> 3, n = e & 7;
		if (t <= 0 || n < 0 || n > 5) throw Error("illegal tag: field no " + t + " wire type " + n);
		return [t, n];
	}
	skip(e, t) {
		let n = this.pos;
		switch (e) {
			case _.Varint:
				for (; this.buf[this.pos++] & 128;);
				break;
			case _.Bit64: this.pos += 4;
			case _.Bit32:
				this.pos += 4;
				break;
			case _.LengthDelimited:
				let n = this.uint32();
				this.pos += n;
				break;
			case _.StartGroup:
				for (;;) {
					let e = g(this.tag(), 2), n = e[0], r = e[1];
					if (r === _.EndGroup) {
						if (t !== void 0 && n !== t) throw Error("invalid end group tag");
						break;
					}
					this.skip(r, n);
				}
				break;
			default: throw Error("cant skip wire type " + e);
		}
		return this.assertBounds(), this.buf.subarray(n, this.pos);
	}
	assertBounds() {
		if (this.pos > this.len) throw RangeError("premature EOF");
	}
	int32() {
		return this.uint32() | 0;
	}
	sint32() {
		let e = this.uint32();
		return e >>> 1 ^ -(e & 1);
	}
	int64() {
		return p.dec(...this.varint64());
	}
	uint64() {
		return p.uDec(...this.varint64());
	}
	sint64() {
		let e = g(this.varint64(), 2), t = e[0], n = e[1], r = -(t & 1);
		return t = (t >>> 1 | (n & 1) << 31) ^ r, n = n >>> 1 ^ r, p.dec(t, n);
	}
	bool() {
		let e = g(this.varint64(), 2), t = e[0], n = e[1];
		return t !== 0 || n !== 0;
	}
	fixed32() {
		return this.view.getUint32((this.pos += 4) - 4, !0);
	}
	sfixed32() {
		return this.view.getInt32((this.pos += 4) - 4, !0);
	}
	fixed64() {
		return p.uDec(this.sfixed32(), this.sfixed32());
	}
	sfixed64() {
		return p.dec(this.sfixed32(), this.sfixed32());
	}
	float() {
		return this.view.getFloat32((this.pos += 4) - 4, !0);
	}
	double() {
		return this.view.getFloat64((this.pos += 8) - 8, !0);
	}
	bytes() {
		let e = this.uint32(), t = this.pos;
		return this.pos += e, this.assertBounds(), this.buf.subarray(t, t + e);
	}
	string() {
		return this.textDecoder.decode(this.bytes());
	}
};
function Fe(e, t, n, r) {
	let i;
	return {
		typeName: t,
		extendee: n,
		get field() {
			if (!i) {
				let n = typeof r == "function" ? r() : r;
				n.name = t.split(".").pop(), n.jsonName = `[${t}]`, i = e.util.newFieldList([n]).list()[0];
			}
			return i;
		},
		runtime: e
	};
}
function Ie(e) {
	let t = e.field.localName, n = Object.create(null);
	return n[t] = Le(e), [n, () => n[t]];
}
function Le(e) {
	let t = e.field;
	if (t.repeated) return [];
	if (t.default !== void 0) return t.default;
	switch (t.kind) {
		case "enum": return t.T.values[0].no;
		case "scalar": return we(t.T, t.L);
		case "message":
			let e = t.T, n = new e();
			return e.fieldWrapper ? e.fieldWrapper.unwrapField(n) : n;
		case "map": throw "map fields are not allowed to be extensions";
	}
}
function Re(e, t) {
	if (!t.repeated && (t.kind == "enum" || t.kind == "scalar")) {
		for (let n = e.length - 1; n >= 0; --n) if (e[n].no == t.no) return [e[n]];
		return [];
	}
	return e.filter((e) => e.no === t.no);
}
var ze = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".split(""), Be = [];
for (let e = 0; e < ze.length; e++) Be[ze[e].charCodeAt(0)] = e;
Be[45] = ze.indexOf("+"), Be[95] = ze.indexOf("/");
var Ve = {
	dec(e) {
		let t = e.length * 3 / 4;
		e[e.length - 2] == "=" ? t -= 2 : e[e.length - 1] == "=" && --t;
		let n = new Uint8Array(t), r = 0, i = 0, a, o = 0;
		for (let t = 0; t < e.length; t++) {
			if (a = Be[e.charCodeAt(t)], a === void 0) switch (e[t]) {
				case "=": i = 0;
				case "\n":
				case "\r":
				case "	":
				case " ": continue;
				default: throw Error("invalid base64 string.");
			}
			switch (i) {
				case 0:
					o = a, i = 1;
					break;
				case 1:
					n[r++] = o << 2 | (a & 48) >> 4, o = a, i = 2;
					break;
				case 2:
					n[r++] = (o & 15) << 4 | (a & 60) >> 2, o = a, i = 3;
					break;
				case 3:
					n[r++] = (o & 3) << 6 | a, i = 0;
					break;
			}
		}
		if (i == 1) throw Error("invalid base64 string.");
		return n.subarray(0, r);
	},
	enc(e) {
		let t = "", n = 0, r, i = 0;
		for (let a = 0; a < e.length; a++) switch (r = e[a], n) {
			case 0:
				t += ze[r >> 2], i = (r & 3) << 4, n = 1;
				break;
			case 1:
				t += ze[i | r >> 4], i = (r & 15) << 2, n = 2;
				break;
			case 2:
				t += ze[i | r >> 6], t += ze[r & 63], n = 0;
				break;
		}
		return n && (t += ze[i], t += "=", n == 1 && (t += "=")), t;
	}
};
function He(e, t, n) {
	Ge(t, e);
	let r = t.runtime.bin.makeReadOptions(n), i = Re(e.getType().runtime.bin.listUnknownFields(e), t.field), a = g(Ie(t), 2), o = a[0], s = a[1];
	for (let e of i) t.runtime.bin.readField(o, r.readerFactory(e.data), t.field, e.wireType, r);
	return s();
}
function Ue(e, t, n, r) {
	Ge(t, e);
	let i = t.runtime.bin.makeReadOptions(r), a = t.runtime.bin.makeWriteOptions(r);
	if (We(e, t)) {
		let n = e.getType().runtime.bin.listUnknownFields(e).filter((e) => e.no != t.field.no);
		e.getType().runtime.bin.discardUnknownFields(e);
		for (let t of n) e.getType().runtime.bin.onUnknownField(e, t.no, t.wireType, t.data);
	}
	let o = a.writerFactory(), s = t.field;
	!s.opt && !s.repeated && (s.kind == "enum" || s.kind == "scalar") && (s = Object.assign(Object.assign({}, t.field), { opt: !0 })), t.runtime.bin.writeField(s, n, o, a);
	let c = i.readerFactory(o.finish());
	for (; c.pos < c.len;) {
		let t = g(c.tag(), 2), n = t[0], r = t[1], i = c.skip(r, n);
		e.getType().runtime.bin.onUnknownField(e, n, r, i);
	}
}
function We(e, t) {
	let n = e.getType();
	return t.extendee.typeName === n.typeName && !!n.runtime.bin.listUnknownFields(e).find((e) => e.no == t.field.no);
}
function Ge(e, t) {
	a(e.extendee.typeName == t.getType().typeName, `extension ${e.typeName} can only be applied to message ${e.extendee.typeName}`);
}
function Ke(e, t) {
	let n = e.localName;
	if (e.repeated) return t[n].length > 0;
	if (e.oneof) return t[e.oneof.localName].case === n;
	switch (e.kind) {
		case "enum":
		case "scalar": return e.opt || e.req ? t[n] !== void 0 : e.kind == "enum" ? t[n] !== e.T.values[0].no : !Te(e.T, t[n]);
		case "message": return t[n] !== void 0;
		case "map": return Object.keys(t[n]).length > 0;
	}
}
function qe(e, t) {
	let n = e.localName, r = !e.opt && !e.req;
	if (e.repeated) t[n] = [];
	else if (e.oneof) t[e.oneof.localName] = { case: void 0 };
	else switch (e.kind) {
		case "map":
			t[n] = {};
			break;
		case "enum":
			t[n] = r ? e.T.values[0].no : void 0;
			break;
		case "scalar":
			t[n] = r ? we(e.T, e.L) : void 0;
			break;
		case "message":
			t[n] = void 0;
			break;
	}
}
function Je(e, t) {
	if (typeof e != "object" || !e || !Object.getOwnPropertyNames(se.prototype).every((t) => t in e && typeof e[t] == "function")) return !1;
	let n = e.getType();
	return n === null || typeof n != "function" || !("typeName" in n) || typeof n.typeName != "string" ? !1 : t === void 0 ? !0 : n.typeName == t.typeName;
}
function Ye(e, t) {
	return Je(t) || !e.fieldWrapper ? t : e.fieldWrapper.wrapField(t);
}
m.DOUBLE, m.FLOAT, m.INT64, m.UINT64, m.INT32, m.UINT32, m.BOOL, m.STRING, m.BYTES;
var Xe = { ignoreUnknownFields: !1 }, Ze = {
	emitDefaultValues: !1,
	enumAsInteger: !1,
	useProtoFieldName: !1,
	prettySpaces: 0
};
function Qe(e) {
	return e ? Object.assign(Object.assign({}, Xe), e) : Xe;
}
function $e(e) {
	return e ? Object.assign(Object.assign({}, Ze), e) : Ze;
}
var et = Symbol(), tt = Symbol();
function nt() {
	return {
		makeReadOptions: Qe,
		makeWriteOptions: $e,
		readMessage(e, t, n, r) {
			if (t == null || Array.isArray(t) || typeof t != "object") throw Error(`cannot decode message ${e.typeName} from JSON: ${rt(t)}`);
			r ??= new e();
			let i = /* @__PURE__ */ new Map(), a = n.typeRegistry;
			for (let s of Object.entries(t)) {
				var o = g(s, 2);
				let t = o[0], c = o[1], l = e.fields.findJsonName(t);
				if (l) {
					if (l.oneof) {
						if (c === null && l.kind == "scalar") continue;
						let n = i.get(l.oneof);
						if (n !== void 0) throw Error(`cannot decode message ${e.typeName} from JSON: multiple keys for oneof "${l.oneof.name}" present: "${n}", "${t}"`);
						i.set(l.oneof, t);
					}
					it(r, c, l, n, e);
				} else {
					let i = !1;
					if (a?.findExtension && t.startsWith("[") && t.endsWith("]")) {
						let o = a.findExtension(t.substring(1, t.length - 1));
						if (o && o.extendee.typeName == e.typeName) {
							i = !0;
							let e = g(Ie(o), 2), t = e[0], a = e[1];
							it(t, c, o.field, n, o), Ue(r, o, a(), n);
						}
					}
					if (!i && !n.ignoreUnknownFields) throw Error(`cannot decode message ${e.typeName} from JSON: key "${t}" is unknown`);
				}
			}
			return r;
		},
		writeMessage(e, t) {
			let n = e.getType(), r = {}, i;
			try {
				for (i of n.fields.byNumber()) {
					if (!Ke(i, e)) {
						if (i.req) throw "required field not set";
						if (!t.emitDefaultValues || !ct(i)) continue;
					}
					let n = i.oneof ? e[i.oneof.localName].value : e[i.localName], a = lt(i, n, t);
					a !== void 0 && (r[t.useProtoFieldName ? i.name : i.jsonName] = a);
				}
				let a = t.typeRegistry;
				if (a?.findExtensionFor) for (let i of n.runtime.bin.listUnknownFields(e)) {
					let o = a.findExtensionFor(n.typeName, i.no);
					if (o && We(e, o)) {
						let n = He(e, o, t), i = lt(o.field, n, t);
						i !== void 0 && (r[o.field.jsonName] = i);
					}
				}
			} catch (e) {
				let t = i ? `cannot encode field ${n.typeName}.${i.name} to JSON` : `cannot encode message ${n.typeName} to JSON`, r = e instanceof Error ? e.message : String(e);
				throw Error(t + (r.length > 0 ? `: ${r}` : ""));
			}
			return r;
		},
		readScalar(e, t, n) {
			return ot(e, t, n ?? Se.BIGINT, !0);
		},
		writeScalar(e, t, n) {
			if (t !== void 0 && (n || Te(e, t))) return dt(e, t);
		},
		debug: rt
	};
}
function rt(e) {
	if (e === null) return "null";
	switch (typeof e) {
		case "object": return Array.isArray(e) ? "array" : "object";
		case "string": return e.length > 100 ? "string" : `"${e.split("\"").join("\\\"")}"`;
		default: return String(e);
	}
}
function it(e, t, n, r, i) {
	let o = n.localName;
	if (n.repeated) {
		if (a(n.kind != "map"), t === null) return;
		if (!Array.isArray(t)) throw Error(`cannot decode field ${i.typeName}.${n.name} from JSON: ${rt(t)}`);
		let s = e[o];
		for (let e of t) {
			if (e === null) throw Error(`cannot decode field ${i.typeName}.${n.name} from JSON: ${rt(e)}`);
			switch (n.kind) {
				case "message":
					s.push(n.T.fromJson(e, r));
					break;
				case "enum":
					let t = st(n.T, e, r.ignoreUnknownFields, !0);
					t !== tt && s.push(t);
					break;
				case "scalar":
					try {
						s.push(ot(n.T, e, n.L, !0));
					} catch (t) {
						let r = `cannot decode field ${i.typeName}.${n.name} from JSON: ${rt(e)}`;
						throw t instanceof Error && t.message.length > 0 && (r += `: ${t.message}`), Error(r);
					}
					break;
			}
		}
	} else if (n.kind == "map") {
		if (t === null) return;
		if (typeof t != "object" || Array.isArray(t)) throw Error(`cannot decode field ${i.typeName}.${n.name} from JSON: ${rt(t)}`);
		let a = e[o];
		for (let e of Object.entries(t)) {
			var s = g(e, 2);
			let o = s[0], c = s[1];
			if (c === null) throw Error(`cannot decode field ${i.typeName}.${n.name} from JSON: map value null`);
			let l;
			try {
				l = at(n.K, o);
			} catch (e) {
				let r = `cannot decode map key for field ${i.typeName}.${n.name} from JSON: ${rt(t)}`;
				throw e instanceof Error && e.message.length > 0 && (r += `: ${e.message}`), Error(r);
			}
			switch (n.V.kind) {
				case "message":
					a[l] = n.V.T.fromJson(c, r);
					break;
				case "enum":
					let e = st(n.V.T, c, r.ignoreUnknownFields, !0);
					e !== tt && (a[l] = e);
					break;
				case "scalar":
					try {
						a[l] = ot(n.V.T, c, Se.BIGINT, !0);
					} catch (e) {
						let r = `cannot decode map value for field ${i.typeName}.${n.name} from JSON: ${rt(t)}`;
						throw e instanceof Error && e.message.length > 0 && (r += `: ${e.message}`), Error(r);
					}
					break;
			}
		}
	} else switch (n.oneof && (e = e[n.oneof.localName] = { case: o }, o = "value"), n.kind) {
		case "message":
			let a = n.T;
			if (t === null && a.typeName != "google.protobuf.Value") return;
			let s = e[o];
			Je(s) ? s.fromJson(t, r) : (e[o] = s = a.fromJson(t, r), a.fieldWrapper && !n.oneof && (e[o] = a.fieldWrapper.unwrapField(s)));
			break;
		case "enum":
			let c = st(n.T, t, r.ignoreUnknownFields, !1);
			switch (c) {
				case et:
					qe(n, e);
					break;
				case tt: break;
				default:
					e[o] = c;
					break;
			}
			break;
		case "scalar":
			try {
				let r = ot(n.T, t, n.L, !1);
				switch (r) {
					case et:
						qe(n, e);
						break;
					default:
						e[o] = r;
						break;
				}
			} catch (e) {
				let r = `cannot decode field ${i.typeName}.${n.name} from JSON: ${rt(t)}`;
				throw e instanceof Error && e.message.length > 0 && (r += `: ${e.message}`), Error(r);
			}
			break;
	}
}
function at(e, t) {
	if (e === m.BOOL) switch (t) {
		case "true":
			t = !0;
			break;
		case "false":
			t = !1;
			break;
	}
	return ot(e, t, Se.BIGINT, !0).toString();
}
function ot(e, t, n, r) {
	if (t === null) return r ? we(e, n) : et;
	switch (e) {
		case m.DOUBLE:
		case m.FLOAT:
			if (t === "NaN") return NaN;
			if (t === "Infinity") return Infinity;
			if (t === "-Infinity") return -Infinity;
			if (t === "" || typeof t == "string" && t.trim().length !== t.length || typeof t != "string" && typeof t != "number") break;
			let r = Number(t);
			if (Number.isNaN(r) || !Number.isFinite(r)) break;
			return e == m.FLOAT && ee(r), r;
		case m.INT32:
		case m.FIXED32:
		case m.SFIXED32:
		case m.SINT32:
		case m.UINT32:
			let i;
			if (typeof t == "number" ? i = t : typeof t == "string" && t.length > 0 && t.trim().length === t.length && (i = Number(t)), i === void 0) break;
			return e == m.UINT32 || e == m.FIXED32 ? f(i) : d(i), i;
		case m.INT64:
		case m.SFIXED64:
		case m.SINT64:
			if (typeof t != "number" && typeof t != "string") break;
			let a = p.parse(t);
			return n ? a.toString() : a;
		case m.FIXED64:
		case m.UINT64:
			if (typeof t != "number" && typeof t != "string") break;
			let o = p.uParse(t);
			return n ? o.toString() : o;
		case m.BOOL:
			if (typeof t != "boolean") break;
			return t;
		case m.STRING:
			if (typeof t != "string") break;
			return t;
		case m.BYTES:
			if (t === "") return new Uint8Array();
			if (typeof t != "string") break;
			return Ve.dec(t);
	}
	throw Error();
}
function st(e, t, n, r) {
	if (t === null) return e.typeName == "google.protobuf.NullValue" ? 0 : r ? e.values[0].no : et;
	switch (typeof t) {
		case "number":
			if (Number.isInteger(t)) return t;
			break;
		case "string":
			let r = e.findName(t);
			if (r !== void 0) return r.no;
			if (n) return tt;
			break;
	}
	throw Error(`cannot decode enum ${e.typeName} from JSON: ${rt(t)}`);
}
function ct(e) {
	return e.repeated || e.kind == "map" ? !0 : !(e.oneof || e.kind == "message" || e.opt || e.req);
}
function lt(e, t, n) {
	if (e.kind == "map") {
		a(typeof t == "object" && !!t);
		let s = {}, c = Object.entries(t);
		switch (e.V.kind) {
			case "scalar":
				for (let t of c) {
					var r = g(t, 2);
					let n = r[0], i = r[1];
					s[n.toString()] = dt(e.V.T, i);
				}
				break;
			case "message":
				for (let e of c) {
					var i = g(e, 2);
					let t = i[0], r = i[1];
					s[t.toString()] = r.toJson(n);
				}
				break;
			case "enum":
				let t = e.V.T;
				for (let e of c) {
					var o = g(e, 2);
					let r = o[0], i = o[1];
					s[r.toString()] = ut(t, i, n.enumAsInteger);
				}
				break;
		}
		return n.emitDefaultValues || c.length > 0 ? s : void 0;
	}
	if (e.repeated) {
		a(Array.isArray(t));
		let r = [];
		switch (e.kind) {
			case "scalar":
				for (let n = 0; n < t.length; n++) r.push(dt(e.T, t[n]));
				break;
			case "enum":
				for (let i = 0; i < t.length; i++) r.push(ut(e.T, t[i], n.enumAsInteger));
				break;
			case "message":
				for (let e = 0; e < t.length; e++) r.push(t[e].toJson(n));
				break;
		}
		return n.emitDefaultValues || r.length > 0 ? r : void 0;
	}
	switch (e.kind) {
		case "scalar": return dt(e.T, t);
		case "enum": return ut(e.T, t, n.enumAsInteger);
		case "message": return Ye(e.T, t).toJson(n);
	}
}
function ut(e, t, n) {
	return a(typeof t == "number"), e.typeName == "google.protobuf.NullValue" ? null : n ? t : e.findNumber(t)?.name ?? t;
}
function dt(e, t) {
	switch (e) {
		case m.INT32:
		case m.SFIXED32:
		case m.SINT32:
		case m.FIXED32:
		case m.UINT32: return a(typeof t == "number"), t;
		case m.FLOAT:
		case m.DOUBLE: return a(typeof t == "number"), Number.isNaN(t) ? "NaN" : t === Infinity ? "Infinity" : t === -Infinity ? "-Infinity" : t;
		case m.STRING: return a(typeof t == "string"), t;
		case m.BOOL: return a(typeof t == "boolean"), t;
		case m.UINT64:
		case m.FIXED64:
		case m.INT64:
		case m.SFIXED64:
		case m.SINT64: return a(typeof t == "bigint" || typeof t == "string" || typeof t == "number"), t.toString();
		case m.BYTES: return a(t instanceof Uint8Array), Ve.enc(t);
	}
}
var ft = Symbol("@bufbuild/protobuf/unknown-fields"), pt = {
	readUnknownFields: !0,
	readerFactory: (e) => new Pe(e)
}, mt = {
	writeUnknownFields: !0,
	writerFactory: () => new Ne()
};
function ht(e) {
	return e ? Object.assign(Object.assign({}, pt), e) : pt;
}
function gt(e) {
	return e ? Object.assign(Object.assign({}, mt), e) : mt;
}
function _t() {
	return {
		makeReadOptions: ht,
		makeWriteOptions: gt,
		listUnknownFields(e) {
			return e[ft] ?? [];
		},
		discardUnknownFields(e) {
			delete e[ft];
		},
		writeUnknownFields(e, t) {
			let n = e[ft];
			if (n) for (let e of n) t.tag(e.no, e.wireType).raw(e.data);
		},
		onUnknownField(e, t, n, r) {
			let i = e;
			Array.isArray(i[ft]) || (i[ft] = []), i[ft].push({
				no: t,
				wireType: n,
				data: r
			});
		},
		readMessage(e, t, n, r, i) {
			let a = e.getType(), o = i ? t.len : t.pos + n, s, c;
			for (; t.pos < o;) {
				var l = g(t.tag(), 2);
				if (s = l[0], c = l[1], i === !0 && c == _.EndGroup) break;
				let n = a.fields.find(s);
				if (!n) {
					let n = t.skip(c, s);
					r.readUnknownFields && this.onUnknownField(e, s, c, n);
					continue;
				}
				vt(e, t, n, c, r);
			}
			if (i && (c != _.EndGroup || s !== n)) throw Error("invalid end group tag");
		},
		readField: vt,
		writeMessage(e, t, n) {
			let r = e.getType();
			for (let i of r.fields.byNumber()) {
				if (!Ke(i, e)) {
					if (i.req) throw Error(`cannot encode field ${r.typeName}.${i.name} to binary: required field not set`);
					continue;
				}
				Ct(i, i.oneof ? e[i.oneof.localName].value : e[i.localName], t, n);
			}
			return n.writeUnknownFields && this.writeUnknownFields(e, t), t;
		},
		writeField(e, t, n, r) {
			t !== void 0 && Ct(e, t, n, r);
		}
	};
}
function vt(e, t, n, r, i) {
	let a = n.repeated, o = n.localName;
	switch (n.oneof && (e = e[n.oneof.localName], e.case != o && delete e.value, e.case = o, o = "value"), n.kind) {
		case "scalar":
		case "enum":
			let s = n.kind == "enum" ? m.INT32 : n.T, c = St;
			if (n.kind == "scalar" && n.L > 0 && (c = xt), a) {
				let n = e[o];
				if (r == _.LengthDelimited && s != m.STRING && s != m.BYTES) {
					let e = t.uint32() + t.pos;
					for (; t.pos < e;) n.push(c(t, s));
				} else n.push(c(t, s));
			} else e[o] = c(t, s);
			break;
		case "message":
			let l = n.T;
			a ? e[o].push(yt(t, new l(), i, n)) : Je(e[o]) ? yt(t, e[o], i, n) : (e[o] = yt(t, new l(), i, n), l.fieldWrapper && !n.oneof && !n.repeated && (e[o] = l.fieldWrapper.unwrapField(e[o])));
			break;
		case "map":
			let u = g(bt(n, t, i), 2), d = u[0], f = u[1];
			e[o][d] = f;
			break;
	}
}
function yt(e, t, n, r) {
	let i = t.getType().runtime.bin, a = r?.delimited;
	return i.readMessage(t, e, a ? r.no : e.uint32(), n, a), t;
}
function bt(e, t, n) {
	let r = t.uint32(), i = t.pos + r, a, o;
	for (; t.pos < i;) switch (g(t.tag(), 1)[0]) {
		case 1:
			a = St(t, e.K);
			break;
		case 2:
			switch (e.V.kind) {
				case "scalar":
					o = St(t, e.V.T);
					break;
				case "enum":
					o = t.int32();
					break;
				case "message":
					o = yt(t, new e.V.T(), n, void 0);
					break;
			}
			break;
	}
	if (a === void 0 && (a = we(e.K, Se.BIGINT)), typeof a != "string" && typeof a != "number" && (a = a.toString()), o === void 0) switch (e.V.kind) {
		case "scalar":
			o = we(e.V.T, Se.BIGINT);
			break;
		case "enum":
			o = e.V.T.values[0].no;
			break;
		case "message":
			o = new e.V.T();
			break;
	}
	return [a, o];
}
function xt(e, t) {
	let n = St(e, t);
	return typeof n == "bigint" ? n.toString() : n;
}
function St(e, t) {
	switch (t) {
		case m.STRING: return e.string();
		case m.BOOL: return e.bool();
		case m.DOUBLE: return e.double();
		case m.FLOAT: return e.float();
		case m.INT32: return e.int32();
		case m.INT64: return e.int64();
		case m.UINT64: return e.uint64();
		case m.FIXED64: return e.fixed64();
		case m.BYTES: return e.bytes();
		case m.FIXED32: return e.fixed32();
		case m.SFIXED32: return e.sfixed32();
		case m.SFIXED64: return e.sfixed64();
		case m.SINT64: return e.sint64();
		case m.UINT32: return e.uint32();
		case m.SINT32: return e.sint32();
	}
}
function Ct(e, t, n, r) {
	a(t !== void 0);
	let i = e.repeated;
	switch (e.kind) {
		case "scalar":
		case "enum":
			let s = e.kind == "enum" ? m.INT32 : e.T;
			if (i) if (a(Array.isArray(t)), e.packed) Dt(n, s, e.no, t);
			else for (let r of t) Et(n, s, e.no, r);
			else Et(n, s, e.no, t);
			break;
		case "message":
			if (i) {
				a(Array.isArray(t));
				for (let i of t) Tt(n, r, e, i);
			} else Tt(n, r, e, t);
			break;
		case "map":
			a(typeof t == "object" && !!t);
			for (let i of Object.entries(t)) {
				var o = g(i, 2);
				let t = o[0], a = o[1];
				wt(n, r, e, t, a);
			}
			break;
	}
}
function wt(e, t, n, r, i) {
	e.tag(n.no, _.LengthDelimited), e.fork();
	let o = r;
	switch (n.K) {
		case m.INT32:
		case m.FIXED32:
		case m.UINT32:
		case m.SFIXED32:
		case m.SINT32:
			o = Number.parseInt(r);
			break;
		case m.BOOL:
			a(r == "true" || r == "false"), o = r == "true";
			break;
	}
	switch (Et(e, n.K, 1, o), n.V.kind) {
		case "scalar":
			Et(e, n.V.T, 2, i);
			break;
		case "enum":
			Et(e, m.INT32, 2, i);
			break;
		case "message":
			a(i !== void 0), e.tag(2, _.LengthDelimited).bytes(i.toBinary(t));
			break;
	}
	e.join();
}
function Tt(e, t, n, r) {
	let i = Ye(n.T, r);
	n.delimited ? e.tag(n.no, _.StartGroup).raw(i.toBinary(t)).tag(n.no, _.EndGroup) : e.tag(n.no, _.LengthDelimited).bytes(i.toBinary(t));
}
function Et(e, t, n, r) {
	a(r !== void 0);
	let i = g(Ot(t), 2), o = i[0], s = i[1];
	e.tag(n, o)[s](r);
}
function Dt(e, t, n, r) {
	if (!r.length) return;
	e.tag(n, _.LengthDelimited).fork();
	let i = g(Ot(t), 2)[1];
	for (let t = 0; t < r.length; t++) e[i](r[t]);
	e.join();
}
function Ot(e) {
	let t = _.Varint;
	switch (e) {
		case m.BYTES:
		case m.STRING:
			t = _.LengthDelimited;
			break;
		case m.DOUBLE:
		case m.FIXED64:
		case m.SFIXED64:
			t = _.Bit64;
			break;
		case m.FIXED32:
		case m.SFIXED32:
		case m.FLOAT:
			t = _.Bit32;
			break;
	}
	let n = m[e].toLowerCase();
	return [t, n];
}
function kt() {
	return {
		setEnumType: re,
		initPartial(e, t) {
			if (e === void 0) return;
			let n = t.getType();
			for (let i of n.fields.byMember()) {
				let n = i.localName, a = t, o = e;
				if (o[n] != null) switch (i.kind) {
					case "oneof":
						let e = o[n].case;
						if (e === void 0) continue;
						let t = i.findField(e), s = o[n].value;
						t && t.kind == "message" && !Je(s, t.T) ? s = new t.T(s) : t && t.kind === "scalar" && t.T === m.BYTES && (s = jt(s)), a[n] = {
							case: e,
							value: s
						};
						break;
					case "scalar":
					case "enum":
						let c = o[n];
						i.T === m.BYTES && (c = i.repeated ? c.map(jt) : jt(c)), a[n] = c;
						break;
					case "map":
						switch (i.V.kind) {
							case "scalar":
							case "enum":
								if (i.V.T === m.BYTES) for (let e of Object.entries(o[n])) {
									var r = g(e, 2);
									let t = r[0], i = r[1];
									a[n][t] = jt(i);
								}
								else Object.assign(a[n], o[n]);
								break;
							case "message":
								let e = i.V.T;
								for (let t of Object.keys(o[n])) {
									let r = o[n][t];
									e.fieldWrapper || (r = new e(r)), a[n][t] = r;
								}
								break;
						}
						break;
					case "message":
						let l = i.T;
						if (i.repeated) a[n] = o[n].map((e) => Je(e, l) ? e : new l(e));
						else {
							let e = o[n];
							l.fieldWrapper ? l.typeName === "google.protobuf.BytesValue" ? a[n] = jt(e) : a[n] = e : a[n] = Je(e, l) ? e : new l(e);
						}
						break;
				}
			}
		},
		equals(e, t, n) {
			return t === n ? !0 : !t || !n ? !1 : e.fields.byMember().every((e) => {
				let r = t[e.localName], i = n[e.localName];
				if (e.repeated) {
					if (r.length !== i.length) return !1;
					switch (e.kind) {
						case "message": return r.every((t, n) => e.T.equals(t, i[n]));
						case "scalar": return r.every((t, n) => Ce(e.T, t, i[n]));
						case "enum": return r.every((e, t) => Ce(m.INT32, e, i[t]));
					}
					throw Error(`repeated cannot contain ${e.kind}`);
				}
				switch (e.kind) {
					case "message":
						let t = r, n = i;
						return e.T.fieldWrapper && (t !== void 0 && !Je(t) && (t = e.T.fieldWrapper.wrapField(t)), n !== void 0 && !Je(n) && (n = e.T.fieldWrapper.wrapField(n))), e.T.equals(t, n);
					case "enum": return Ce(m.INT32, r, i);
					case "scalar": return Ce(e.T, r, i);
					case "oneof":
						if (r.case !== i.case) return !1;
						let a = e.findField(r.case);
						if (a === void 0) return !0;
						switch (a.kind) {
							case "message": return a.T.equals(r.value, i.value);
							case "enum": return Ce(m.INT32, r.value, i.value);
							case "scalar": return Ce(a.T, r.value, i.value);
						}
						throw Error(`oneof cannot contain ${a.kind}`);
					case "map":
						let o = Object.keys(r).concat(Object.keys(i));
						switch (e.V.kind) {
							case "message":
								let t = e.V.T;
								return o.every((e) => t.equals(r[e], i[e]));
							case "enum": return o.every((e) => Ce(m.INT32, r[e], i[e]));
							case "scalar":
								let n = e.V.T;
								return o.every((e) => Ce(n, r[e], i[e]));
						}
						break;
				}
			});
		},
		clone(e) {
			let t = e.getType(), n = new t(), r = n;
			for (let n of t.fields.byMember()) {
				let t = e[n.localName], a;
				if (n.repeated) a = t.map(At);
				else if (n.kind == "map") {
					a = r[n.localName];
					for (let e of Object.entries(t)) {
						var i = g(e, 2);
						let t = i[0], n = i[1];
						a[t] = At(n);
					}
				} else a = n.kind == "oneof" ? n.findField(t.case) ? {
					case: t.case,
					value: At(t.value)
				} : { case: void 0 } : At(t);
				r[n.localName] = a;
			}
			for (let n of t.runtime.bin.listUnknownFields(e)) t.runtime.bin.onUnknownField(r, n.no, n.wireType, n.data);
			return n;
		}
	};
}
function At(e) {
	if (e === void 0) return e;
	if (Je(e)) return e.clone();
	if (e instanceof Uint8Array) {
		let t = new Uint8Array(e.byteLength);
		return t.set(e), t;
	}
	return e;
}
function jt(e) {
	return e instanceof Uint8Array ? e : new Uint8Array(e);
}
function Mt(e, t, n) {
	return {
		syntax: e,
		json: nt(),
		bin: _t(),
		util: Object.assign(Object.assign({}, kt()), {
			newFieldList: t,
			initFields: n
		}),
		makeMessageType(e, t, n) {
			return ce(this, e, t, n);
		},
		makeEnum: ae,
		makeEnumType: ie,
		getEnumType: ne,
		makeExtension(e, t, n) {
			return Fe(this, e, t, n);
		}
	};
}
var Nt = class {
	constructor(e, t) {
		this._fields = e, this._normalizer = t;
	}
	findJsonName(e) {
		if (!this.jsonNames) {
			let e = {};
			for (let t of this.list()) e[t.jsonName] = e[t.name] = t;
			this.jsonNames = e;
		}
		return this.jsonNames[e];
	}
	find(e) {
		if (!this.numbers) {
			let e = {};
			for (let t of this.list()) e[t.no] = t;
			this.numbers = e;
		}
		return this.numbers[e];
	}
	list() {
		return this.all ||= this._normalizer(this._fields), this.all;
	}
	byNumber() {
		return this.numbersAsc ||= this.list().concat().sort((e, t) => e.no - t.no), this.numbersAsc;
	}
	byMember() {
		if (!this.members) {
			this.members = [];
			let e = this.members, t;
			for (let n of this.list()) n.oneof ? n.oneof !== t && (t = n.oneof, e.push(t)) : e.push(n);
		}
		return this.members;
	}
};
function Pt(e, t) {
	let n = Lt(e);
	return t ? n : Ht(Vt(n));
}
function Ft(e) {
	return Pt(e, !1);
}
var It = Lt;
function Lt(e) {
	let t = !1, n = [];
	for (let r = 0; r < e.length; r++) {
		let i = e.charAt(r);
		switch (i) {
			case "_":
				t = !0;
				break;
			case "0":
			case "1":
			case "2":
			case "3":
			case "4":
			case "5":
			case "6":
			case "7":
			case "8":
			case "9":
				n.push(i), t = !1;
				break;
			default:
				t && (t = !1, i = i.toUpperCase()), n.push(i);
				break;
		}
	}
	return n.join("");
}
var Rt = new Set([
	"constructor",
	"toString",
	"toJSON",
	"valueOf"
]), zt = new Set([
	"getType",
	"clone",
	"equals",
	"fromBinary",
	"fromJson",
	"fromJsonString",
	"toBinary",
	"toJson",
	"toJsonString",
	"toObject"
]), Bt = (e) => `${e}\$`, Vt = (e) => zt.has(e) ? Bt(e) : e, Ht = (e) => Rt.has(e) ? Bt(e) : e, Ut = class {
	constructor(e) {
		this.kind = "oneof", this.repeated = !1, this.packed = !1, this.opt = !1, this.req = !1, this.default = void 0, this.fields = [], this.name = e, this.localName = Ft(e);
	}
	addField(e) {
		a(e.oneof === this, `field ${e.name} not one of ${this.name}`), this.fields.push(e);
	}
	findField(e) {
		if (!this._lookup) {
			this._lookup = Object.create(null);
			for (let e = 0; e < this.fields.length; e++) this._lookup[this.fields[e].localName] = this.fields[e];
		}
		return this._lookup[e];
	}
};
function Wt(e, t) {
	let n = [], r;
	for (let t of typeof e == "function" ? e() : e) {
		let e = t;
		if (e.localName = Pt(t.name, t.oneof !== void 0), e.jsonName = t.jsonName ?? It(t.name), e.repeated = t.repeated ?? !1, t.kind == "scalar" && (e.L = t.L ?? Se.BIGINT), e.delimited = t.delimited ?? !1, e.req = t.req ?? !1, e.opt = t.opt ?? !1, t.packed === void 0 && (e.packed = t.kind == "enum" || t.kind == "scalar" && t.T != m.BYTES && t.T != m.STRING), t.oneof !== void 0) {
			let n = typeof t.oneof == "string" ? t.oneof : t.oneof.name;
			(!r || r.name != n) && (r = new Ut(n)), e.oneof = r, r.addField(e);
		}
		n.push(e);
	}
	return n;
}
var v = Mt("proto3", (e) => new Nt(e, (e) => Wt(e)), (e) => {
	for (let t of e.getType().fields.byMember()) {
		if (t.opt) continue;
		let n = t.localName, r = e;
		if (t.repeated) {
			r[n] = [];
			continue;
		}
		switch (t.kind) {
			case "oneof":
				r[n] = { case: void 0 };
				break;
			case "enum":
				r[n] = 0;
				break;
			case "map":
				r[n] = {};
				break;
			case "scalar":
				r[n] = we(t.T, t.L);
				break;
		}
	}
}), Gt = class e extends se {
	constructor(e) {
		super(), this.seconds = p.zero, this.nanos = 0, v.util.initPartial(e, this);
	}
	fromJson(e, t) {
		if (typeof e != "string") throw Error(`cannot decode google.protobuf.Timestamp from JSON: ${v.json.debug(e)}`);
		let n = e.match(/^([0-9]{4})-([0-9]{2})-([0-9]{2})T([0-9]{2}):([0-9]{2}):([0-9]{2})(?:Z|\.([0-9]{3,9})Z|([+-][0-9][0-9]:[0-9][0-9]))$/);
		if (!n) throw Error("cannot decode google.protobuf.Timestamp from JSON: invalid RFC 3339 string");
		let r = Date.parse(n[1] + "-" + n[2] + "-" + n[3] + "T" + n[4] + ":" + n[5] + ":" + n[6] + (n[8] ? n[8] : "Z"));
		if (Number.isNaN(r)) throw Error("cannot decode google.protobuf.Timestamp from JSON: invalid RFC 3339 string");
		if (r < Date.parse("0001-01-01T00:00:00Z") || r > Date.parse("9999-12-31T23:59:59Z")) throw Error("cannot decode message google.protobuf.Timestamp from JSON: must be from 0001-01-01T00:00:00Z to 9999-12-31T23:59:59Z inclusive");
		return this.seconds = p.parse(r / 1e3), this.nanos = 0, n[7] && (this.nanos = parseInt("1" + n[7] + "0".repeat(9 - n[7].length)) - 1e9), this;
	}
	toJson(e) {
		let t = Number(this.seconds) * 1e3;
		if (t < Date.parse("0001-01-01T00:00:00Z") || t > Date.parse("9999-12-31T23:59:59Z")) throw Error("cannot encode google.protobuf.Timestamp to JSON: must be from 0001-01-01T00:00:00Z to 9999-12-31T23:59:59Z inclusive");
		if (this.nanos < 0) throw Error("cannot encode google.protobuf.Timestamp to JSON: nanos must not be negative");
		let n = "Z";
		if (this.nanos > 0) {
			let e = (this.nanos + 1e9).toString().substring(1);
			n = e.substring(3) === "000000" ? "." + e.substring(0, 3) + "Z" : e.substring(6) === "000" ? "." + e.substring(0, 6) + "Z" : "." + e + "Z";
		}
		return new Date(t).toISOString().replace(".000Z", n);
	}
	toDate() {
		return new Date(Number(this.seconds) * 1e3 + Math.ceil(this.nanos / 1e6));
	}
	static now() {
		return e.fromDate(/* @__PURE__ */ new Date());
	}
	static fromDate(t) {
		let n = t.getTime();
		return new e({
			seconds: p.parse(Math.floor(n / 1e3)),
			nanos: n % 1e3 * 1e6
		});
	}
	static fromBinary(t, n) {
		return new e().fromBinary(t, n);
	}
	static fromJson(t, n) {
		return new e().fromJson(t, n);
	}
	static fromJsonString(t, n) {
		return new e().fromJsonString(t, n);
	}
	static equals(t, n) {
		return v.util.equals(e, t, n);
	}
};
Gt.runtime = v, Gt.typeName = "google.protobuf.Timestamp", Gt.fields = v.util.newFieldList(() => [{
	no: 1,
	name: "seconds",
	kind: "scalar",
	T: 3
}, {
	no: 2,
	name: "nanos",
	kind: "scalar",
	T: 5
}]);
var Kt = /* @__PURE__ */ v.makeMessageType("livekit.MetricsBatch", () => [
	{
		no: 1,
		name: "timestamp_ms",
		kind: "scalar",
		T: 3
	},
	{
		no: 2,
		name: "normalized_timestamp",
		kind: "message",
		T: Gt
	},
	{
		no: 3,
		name: "str_data",
		kind: "scalar",
		T: 9,
		repeated: !0
	},
	{
		no: 4,
		name: "time_series",
		kind: "message",
		T: qt,
		repeated: !0
	},
	{
		no: 5,
		name: "events",
		kind: "message",
		T: Yt,
		repeated: !0
	}
]), qt = /* @__PURE__ */ v.makeMessageType("livekit.TimeSeriesMetric", () => [
	{
		no: 1,
		name: "label",
		kind: "scalar",
		T: 13
	},
	{
		no: 2,
		name: "participant_identity",
		kind: "scalar",
		T: 13
	},
	{
		no: 3,
		name: "track_sid",
		kind: "scalar",
		T: 13
	},
	{
		no: 4,
		name: "samples",
		kind: "message",
		T: Jt,
		repeated: !0
	},
	{
		no: 5,
		name: "rid",
		kind: "scalar",
		T: 13
	}
]), Jt = /* @__PURE__ */ v.makeMessageType("livekit.MetricSample", () => [
	{
		no: 1,
		name: "timestamp_ms",
		kind: "scalar",
		T: 3
	},
	{
		no: 2,
		name: "normalized_timestamp",
		kind: "message",
		T: Gt
	},
	{
		no: 3,
		name: "value",
		kind: "scalar",
		T: 2
	}
]), Yt = /* @__PURE__ */ v.makeMessageType("livekit.EventMetric", () => [
	{
		no: 1,
		name: "label",
		kind: "scalar",
		T: 13
	},
	{
		no: 2,
		name: "participant_identity",
		kind: "scalar",
		T: 13
	},
	{
		no: 3,
		name: "track_sid",
		kind: "scalar",
		T: 13
	},
	{
		no: 4,
		name: "start_timestamp_ms",
		kind: "scalar",
		T: 3
	},
	{
		no: 5,
		name: "end_timestamp_ms",
		kind: "scalar",
		T: 3,
		opt: !0
	},
	{
		no: 6,
		name: "normalized_start_timestamp",
		kind: "message",
		T: Gt
	},
	{
		no: 7,
		name: "normalized_end_timestamp",
		kind: "message",
		T: Gt,
		opt: !0
	},
	{
		no: 8,
		name: "metadata",
		kind: "scalar",
		T: 9
	},
	{
		no: 9,
		name: "rid",
		kind: "scalar",
		T: 13
	}
]), Xt = /* @__PURE__ */ v.makeEnum("livekit.BackupCodecPolicy", [
	{
		no: 0,
		name: "PREFER_REGRESSION"
	},
	{
		no: 1,
		name: "SIMULCAST"
	},
	{
		no: 2,
		name: "REGRESSION"
	}
]), Zt = /* @__PURE__ */ v.makeEnum("livekit.TrackType", [
	{
		no: 0,
		name: "AUDIO"
	},
	{
		no: 1,
		name: "VIDEO"
	},
	{
		no: 2,
		name: "DATA"
	}
]), y = /* @__PURE__ */ v.makeEnum("livekit.TrackSource", [
	{
		no: 0,
		name: "UNKNOWN"
	},
	{
		no: 1,
		name: "CAMERA"
	},
	{
		no: 2,
		name: "MICROPHONE"
	},
	{
		no: 3,
		name: "SCREEN_SHARE"
	},
	{
		no: 4,
		name: "SCREEN_SHARE_AUDIO"
	}
]), Qt = /* @__PURE__ */ v.makeEnum("livekit.VideoQuality", [
	{
		no: 0,
		name: "LOW"
	},
	{
		no: 1,
		name: "MEDIUM"
	},
	{
		no: 2,
		name: "HIGH"
	},
	{
		no: 3,
		name: "OFF"
	}
]), $t = /* @__PURE__ */ v.makeEnum("livekit.ConnectionQuality", [
	{
		no: 0,
		name: "POOR"
	},
	{
		no: 1,
		name: "GOOD"
	},
	{
		no: 2,
		name: "EXCELLENT"
	},
	{
		no: 3,
		name: "LOST"
	}
]), en = /* @__PURE__ */ v.makeEnum("livekit.ClientConfigSetting", [
	{
		no: 0,
		name: "UNSET"
	},
	{
		no: 1,
		name: "DISABLED"
	},
	{
		no: 2,
		name: "ENABLED"
	}
]), tn = /* @__PURE__ */ v.makeEnum("livekit.DisconnectReason", [
	{
		no: 0,
		name: "UNKNOWN_REASON"
	},
	{
		no: 1,
		name: "CLIENT_INITIATED"
	},
	{
		no: 2,
		name: "DUPLICATE_IDENTITY"
	},
	{
		no: 3,
		name: "SERVER_SHUTDOWN"
	},
	{
		no: 4,
		name: "PARTICIPANT_REMOVED"
	},
	{
		no: 5,
		name: "ROOM_DELETED"
	},
	{
		no: 6,
		name: "STATE_MISMATCH"
	},
	{
		no: 7,
		name: "JOIN_FAILURE"
	},
	{
		no: 8,
		name: "MIGRATION"
	},
	{
		no: 9,
		name: "SIGNAL_CLOSE"
	},
	{
		no: 10,
		name: "ROOM_CLOSED"
	},
	{
		no: 11,
		name: "USER_UNAVAILABLE"
	},
	{
		no: 12,
		name: "USER_REJECTED"
	},
	{
		no: 13,
		name: "SIP_TRUNK_FAILURE"
	},
	{
		no: 14,
		name: "CONNECTION_TIMEOUT"
	},
	{
		no: 15,
		name: "MEDIA_FAILURE"
	},
	{
		no: 16,
		name: "AGENT_ERROR"
	}
]), nn = /* @__PURE__ */ v.makeEnum("livekit.ReconnectReason", [
	{
		no: 0,
		name: "RR_UNKNOWN"
	},
	{
		no: 1,
		name: "RR_SIGNAL_DISCONNECTED"
	},
	{
		no: 2,
		name: "RR_PUBLISHER_FAILED"
	},
	{
		no: 3,
		name: "RR_SUBSCRIBER_FAILED"
	},
	{
		no: 4,
		name: "RR_SWITCH_CANDIDATE"
	}
]), rn = /* @__PURE__ */ v.makeEnum("livekit.SubscriptionError", [
	{
		no: 0,
		name: "SE_UNKNOWN"
	},
	{
		no: 1,
		name: "SE_CODEC_UNSUPPORTED"
	},
	{
		no: 2,
		name: "SE_TRACK_NOTFOUND"
	}
]), b = /* @__PURE__ */ v.makeEnum("livekit.AudioTrackFeature", [
	{
		no: 0,
		name: "TF_STEREO"
	},
	{
		no: 1,
		name: "TF_NO_DTX"
	},
	{
		no: 2,
		name: "TF_AUTO_GAIN_CONTROL"
	},
	{
		no: 3,
		name: "TF_ECHO_CANCELLATION"
	},
	{
		no: 4,
		name: "TF_NOISE_SUPPRESSION"
	},
	{
		no: 5,
		name: "TF_ENHANCED_NOISE_CANCELLATION"
	},
	{
		no: 6,
		name: "TF_PRECONNECT_BUFFER"
	}
]), an = /* @__PURE__ */ v.makeEnum("livekit.PacketTrailerFeature", [{
	no: 0,
	name: "PTF_USER_TIMESTAMP"
}, {
	no: 1,
	name: "PTF_FRAME_ID"
}]), on = /* @__PURE__ */ v.makeMessageType("livekit.Room", () => [
	{
		no: 1,
		name: "sid",
		kind: "scalar",
		T: 9
	},
	{
		no: 2,
		name: "name",
		kind: "scalar",
		T: 9
	},
	{
		no: 3,
		name: "empty_timeout",
		kind: "scalar",
		T: 13
	},
	{
		no: 14,
		name: "departure_timeout",
		kind: "scalar",
		T: 13
	},
	{
		no: 4,
		name: "max_participants",
		kind: "scalar",
		T: 13
	},
	{
		no: 5,
		name: "creation_time",
		kind: "scalar",
		T: 3
	},
	{
		no: 15,
		name: "creation_time_ms",
		kind: "scalar",
		T: 3
	},
	{
		no: 6,
		name: "turn_password",
		kind: "scalar",
		T: 9
	},
	{
		no: 7,
		name: "enabled_codecs",
		kind: "message",
		T: sn,
		repeated: !0
	},
	{
		no: 8,
		name: "metadata",
		kind: "scalar",
		T: 9
	},
	{
		no: 9,
		name: "num_participants",
		kind: "scalar",
		T: 13
	},
	{
		no: 11,
		name: "num_publishers",
		kind: "scalar",
		T: 13
	},
	{
		no: 10,
		name: "active_recording",
		kind: "scalar",
		T: 8
	},
	{
		no: 13,
		name: "version",
		kind: "message",
		T: Hn
	}
]), sn = /* @__PURE__ */ v.makeMessageType("livekit.Codec", () => [{
	no: 1,
	name: "mime",
	kind: "scalar",
	T: 9
}, {
	no: 2,
	name: "fmtp_line",
	kind: "scalar",
	T: 9
}]), cn = /* @__PURE__ */ v.makeMessageType("livekit.ParticipantPermission", () => [
	{
		no: 1,
		name: "can_subscribe",
		kind: "scalar",
		T: 8
	},
	{
		no: 2,
		name: "can_publish",
		kind: "scalar",
		T: 8
	},
	{
		no: 3,
		name: "can_publish_data",
		kind: "scalar",
		T: 8
	},
	{
		no: 9,
		name: "can_publish_sources",
		kind: "enum",
		T: v.getEnumType(y),
		repeated: !0
	},
	{
		no: 7,
		name: "hidden",
		kind: "scalar",
		T: 8
	},
	{
		no: 8,
		name: "recorder",
		kind: "scalar",
		T: 8
	},
	{
		no: 10,
		name: "can_update_metadata",
		kind: "scalar",
		T: 8
	},
	{
		no: 11,
		name: "agent",
		kind: "scalar",
		T: 8
	},
	{
		no: 12,
		name: "can_subscribe_metrics",
		kind: "scalar",
		T: 8
	},
	{
		no: 13,
		name: "can_manage_agent_session",
		kind: "scalar",
		T: 8
	}
]), ln = /* @__PURE__ */ v.makeMessageType("livekit.ParticipantInfo", () => [
	{
		no: 1,
		name: "sid",
		kind: "scalar",
		T: 9
	},
	{
		no: 2,
		name: "identity",
		kind: "scalar",
		T: 9
	},
	{
		no: 3,
		name: "state",
		kind: "enum",
		T: v.getEnumType(un)
	},
	{
		no: 4,
		name: "tracks",
		kind: "message",
		T: mn,
		repeated: !0
	},
	{
		no: 5,
		name: "metadata",
		kind: "scalar",
		T: 9
	},
	{
		no: 6,
		name: "joined_at",
		kind: "scalar",
		T: 3
	},
	{
		no: 17,
		name: "joined_at_ms",
		kind: "scalar",
		T: 3
	},
	{
		no: 9,
		name: "name",
		kind: "scalar",
		T: 9
	},
	{
		no: 10,
		name: "version",
		kind: "scalar",
		T: 13
	},
	{
		no: 11,
		name: "permission",
		kind: "message",
		T: cn
	},
	{
		no: 12,
		name: "region",
		kind: "scalar",
		T: 9
	},
	{
		no: 13,
		name: "is_publisher",
		kind: "scalar",
		T: 8
	},
	{
		no: 14,
		name: "kind",
		kind: "enum",
		T: v.getEnumType(dn)
	},
	{
		no: 15,
		name: "attributes",
		kind: "map",
		K: 9,
		V: {
			kind: "scalar",
			T: 9
		}
	},
	{
		no: 16,
		name: "disconnect_reason",
		kind: "enum",
		T: v.getEnumType(tn)
	},
	{
		no: 18,
		name: "kind_details",
		kind: "enum",
		T: v.getEnumType(fn),
		repeated: !0
	},
	{
		no: 19,
		name: "data_tracks",
		kind: "message",
		T: hn,
		repeated: !0
	},
	{
		no: 20,
		name: "client_protocol",
		kind: "scalar",
		T: 5
	}
]), un = /* @__PURE__ */ v.makeEnum("livekit.ParticipantInfo.State", [
	{
		no: 0,
		name: "JOINING"
	},
	{
		no: 1,
		name: "JOINED"
	},
	{
		no: 2,
		name: "ACTIVE"
	},
	{
		no: 3,
		name: "DISCONNECTED"
	}
]), dn = /* @__PURE__ */ v.makeEnum("livekit.ParticipantInfo.Kind", [
	{
		no: 0,
		name: "STANDARD"
	},
	{
		no: 1,
		name: "INGRESS"
	},
	{
		no: 2,
		name: "EGRESS"
	},
	{
		no: 3,
		name: "SIP"
	},
	{
		no: 4,
		name: "AGENT"
	},
	{
		no: 7,
		name: "CONNECTOR"
	},
	{
		no: 8,
		name: "BRIDGE"
	}
]), fn = /* @__PURE__ */ v.makeEnum("livekit.ParticipantInfo.KindDetail", [
	{
		no: 0,
		name: "CLOUD_AGENT"
	},
	{
		no: 1,
		name: "FORWARDED"
	},
	{
		no: 2,
		name: "CONNECTOR_WHATSAPP"
	},
	{
		no: 3,
		name: "CONNECTOR_TWILIO"
	},
	{
		no: 4,
		name: "BRIDGE_RTSP"
	}
]), x = /* @__PURE__ */ v.makeEnum("livekit.Encryption.Type", [
	{
		no: 0,
		name: "NONE"
	},
	{
		no: 1,
		name: "GCM"
	},
	{
		no: 2,
		name: "CUSTOM"
	}
]), pn = /* @__PURE__ */ v.makeMessageType("livekit.SimulcastCodecInfo", () => [
	{
		no: 1,
		name: "mime_type",
		kind: "scalar",
		T: 9
	},
	{
		no: 2,
		name: "mid",
		kind: "scalar",
		T: 9
	},
	{
		no: 3,
		name: "cid",
		kind: "scalar",
		T: 9
	},
	{
		no: 4,
		name: "layers",
		kind: "message",
		T: _n,
		repeated: !0
	},
	{
		no: 5,
		name: "video_layer_mode",
		kind: "enum",
		T: v.getEnumType(vn)
	},
	{
		no: 6,
		name: "sdp_cid",
		kind: "scalar",
		T: 9
	}
]), mn = /* @__PURE__ */ v.makeMessageType("livekit.TrackInfo", () => [
	{
		no: 1,
		name: "sid",
		kind: "scalar",
		T: 9
	},
	{
		no: 2,
		name: "type",
		kind: "enum",
		T: v.getEnumType(Zt)
	},
	{
		no: 3,
		name: "name",
		kind: "scalar",
		T: 9
	},
	{
		no: 4,
		name: "muted",
		kind: "scalar",
		T: 8
	},
	{
		no: 5,
		name: "width",
		kind: "scalar",
		T: 13
	},
	{
		no: 6,
		name: "height",
		kind: "scalar",
		T: 13
	},
	{
		no: 7,
		name: "simulcast",
		kind: "scalar",
		T: 8
	},
	{
		no: 8,
		name: "disable_dtx",
		kind: "scalar",
		T: 8
	},
	{
		no: 9,
		name: "source",
		kind: "enum",
		T: v.getEnumType(y)
	},
	{
		no: 10,
		name: "layers",
		kind: "message",
		T: _n,
		repeated: !0
	},
	{
		no: 11,
		name: "mime_type",
		kind: "scalar",
		T: 9
	},
	{
		no: 12,
		name: "mid",
		kind: "scalar",
		T: 9
	},
	{
		no: 13,
		name: "codecs",
		kind: "message",
		T: pn,
		repeated: !0
	},
	{
		no: 14,
		name: "stereo",
		kind: "scalar",
		T: 8
	},
	{
		no: 15,
		name: "disable_red",
		kind: "scalar",
		T: 8
	},
	{
		no: 16,
		name: "encryption",
		kind: "enum",
		T: v.getEnumType(x)
	},
	{
		no: 17,
		name: "stream",
		kind: "scalar",
		T: 9
	},
	{
		no: 18,
		name: "version",
		kind: "message",
		T: Hn
	},
	{
		no: 19,
		name: "audio_features",
		kind: "enum",
		T: v.getEnumType(b),
		repeated: !0
	},
	{
		no: 20,
		name: "backup_codec_policy",
		kind: "enum",
		T: v.getEnumType(Xt)
	},
	{
		no: 21,
		name: "packet_trailer_features",
		kind: "enum",
		T: v.getEnumType(an),
		repeated: !0
	}
]), hn = /* @__PURE__ */ v.makeMessageType("livekit.DataTrackInfo", () => [
	{
		no: 1,
		name: "pub_handle",
		kind: "scalar",
		T: 13
	},
	{
		no: 2,
		name: "sid",
		kind: "scalar",
		T: 9
	},
	{
		no: 3,
		name: "name",
		kind: "scalar",
		T: 9
	},
	{
		no: 4,
		name: "encryption",
		kind: "enum",
		T: v.getEnumType(x)
	}
]), gn = /* @__PURE__ */ v.makeMessageType("livekit.DataTrackSubscriptionOptions", () => [{
	no: 1,
	name: "target_fps",
	kind: "scalar",
	T: 13,
	opt: !0
}]), _n = /* @__PURE__ */ v.makeMessageType("livekit.VideoLayer", () => [
	{
		no: 1,
		name: "quality",
		kind: "enum",
		T: v.getEnumType(Qt)
	},
	{
		no: 2,
		name: "width",
		kind: "scalar",
		T: 13
	},
	{
		no: 3,
		name: "height",
		kind: "scalar",
		T: 13
	},
	{
		no: 4,
		name: "bitrate",
		kind: "scalar",
		T: 13
	},
	{
		no: 5,
		name: "ssrc",
		kind: "scalar",
		T: 13
	},
	{
		no: 6,
		name: "spatial_layer",
		kind: "scalar",
		T: 5
	},
	{
		no: 7,
		name: "rid",
		kind: "scalar",
		T: 9
	},
	{
		no: 8,
		name: "repair_ssrc",
		kind: "scalar",
		T: 13
	}
]), vn = /* @__PURE__ */ v.makeEnum("livekit.VideoLayer.Mode", [
	{
		no: 0,
		name: "MODE_UNUSED"
	},
	{
		no: 1,
		name: "ONE_SPATIAL_LAYER_PER_STREAM"
	},
	{
		no: 2,
		name: "MULTIPLE_SPATIAL_LAYERS_PER_STREAM"
	},
	{
		no: 3,
		name: "ONE_SPATIAL_LAYER_PER_STREAM_INCOMPLETE_RTCP_SR"
	}
]), S = /* @__PURE__ */ v.makeMessageType("livekit.DataPacket", () => [
	{
		no: 1,
		name: "kind",
		kind: "enum",
		T: v.getEnumType(yn)
	},
	{
		no: 4,
		name: "participant_identity",
		kind: "scalar",
		T: 9
	},
	{
		no: 5,
		name: "destination_identities",
		kind: "scalar",
		T: 9,
		repeated: !0
	},
	{
		no: 2,
		name: "user",
		kind: "message",
		T: wn,
		oneof: "value"
	},
	{
		no: 3,
		name: "speaker",
		kind: "message",
		T: Sn,
		oneof: "value"
	},
	{
		no: 6,
		name: "sip_dtmf",
		kind: "message",
		T: Tn,
		oneof: "value"
	},
	{
		no: 7,
		name: "transcription",
		kind: "message",
		T: En,
		oneof: "value"
	},
	{
		no: 8,
		name: "metrics",
		kind: "message",
		T: Kt,
		oneof: "value"
	},
	{
		no: 9,
		name: "chat_message",
		kind: "message",
		T: On,
		oneof: "value"
	},
	{
		no: 10,
		name: "rpc_request",
		kind: "message",
		T: kn,
		oneof: "value"
	},
	{
		no: 11,
		name: "rpc_ack",
		kind: "message",
		T: An,
		oneof: "value"
	},
	{
		no: 12,
		name: "rpc_response",
		kind: "message",
		T: jn,
		oneof: "value"
	},
	{
		no: 13,
		name: "stream_header",
		kind: "message",
		T: Kn,
		oneof: "value"
	},
	{
		no: 14,
		name: "stream_chunk",
		kind: "message",
		T: qn,
		oneof: "value"
	},
	{
		no: 15,
		name: "stream_trailer",
		kind: "message",
		T: Jn,
		oneof: "value"
	},
	{
		no: 18,
		name: "encrypted_packet",
		kind: "message",
		T: bn,
		oneof: "value"
	},
	{
		no: 16,
		name: "sequence",
		kind: "scalar",
		T: 13
	},
	{
		no: 17,
		name: "participant_sid",
		kind: "scalar",
		T: 9
	}
]), yn = /* @__PURE__ */ v.makeEnum("livekit.DataPacket.Kind", [{
	no: 0,
	name: "RELIABLE"
}, {
	no: 1,
	name: "LOSSY"
}]), bn = /* @__PURE__ */ v.makeMessageType("livekit.EncryptedPacket", () => [
	{
		no: 1,
		name: "encryption_type",
		kind: "enum",
		T: v.getEnumType(x)
	},
	{
		no: 2,
		name: "iv",
		kind: "scalar",
		T: 12
	},
	{
		no: 3,
		name: "key_index",
		kind: "scalar",
		T: 13
	},
	{
		no: 4,
		name: "encrypted_value",
		kind: "scalar",
		T: 12
	}
]), xn = /* @__PURE__ */ v.makeMessageType("livekit.EncryptedPacketPayload", () => [
	{
		no: 1,
		name: "user",
		kind: "message",
		T: wn,
		oneof: "value"
	},
	{
		no: 3,
		name: "chat_message",
		kind: "message",
		T: On,
		oneof: "value"
	},
	{
		no: 4,
		name: "rpc_request",
		kind: "message",
		T: kn,
		oneof: "value"
	},
	{
		no: 5,
		name: "rpc_ack",
		kind: "message",
		T: An,
		oneof: "value"
	},
	{
		no: 6,
		name: "rpc_response",
		kind: "message",
		T: jn,
		oneof: "value"
	},
	{
		no: 7,
		name: "stream_header",
		kind: "message",
		T: Kn,
		oneof: "value"
	},
	{
		no: 8,
		name: "stream_chunk",
		kind: "message",
		T: qn,
		oneof: "value"
	},
	{
		no: 9,
		name: "stream_trailer",
		kind: "message",
		T: Jn,
		oneof: "value"
	}
]), Sn = /* @__PURE__ */ v.makeMessageType("livekit.ActiveSpeakerUpdate", () => [{
	no: 1,
	name: "speakers",
	kind: "message",
	T: Cn,
	repeated: !0
}]), Cn = /* @__PURE__ */ v.makeMessageType("livekit.SpeakerInfo", () => [
	{
		no: 1,
		name: "sid",
		kind: "scalar",
		T: 9
	},
	{
		no: 2,
		name: "level",
		kind: "scalar",
		T: 2
	},
	{
		no: 3,
		name: "active",
		kind: "scalar",
		T: 8
	}
]), wn = /* @__PURE__ */ v.makeMessageType("livekit.UserPacket", () => [
	{
		no: 1,
		name: "participant_sid",
		kind: "scalar",
		T: 9
	},
	{
		no: 5,
		name: "participant_identity",
		kind: "scalar",
		T: 9
	},
	{
		no: 2,
		name: "payload",
		kind: "scalar",
		T: 12
	},
	{
		no: 3,
		name: "destination_sids",
		kind: "scalar",
		T: 9,
		repeated: !0
	},
	{
		no: 6,
		name: "destination_identities",
		kind: "scalar",
		T: 9,
		repeated: !0
	},
	{
		no: 4,
		name: "topic",
		kind: "scalar",
		T: 9,
		opt: !0
	},
	{
		no: 8,
		name: "id",
		kind: "scalar",
		T: 9,
		opt: !0
	},
	{
		no: 9,
		name: "start_time",
		kind: "scalar",
		T: 4,
		opt: !0
	},
	{
		no: 10,
		name: "end_time",
		kind: "scalar",
		T: 4,
		opt: !0
	},
	{
		no: 11,
		name: "nonce",
		kind: "scalar",
		T: 12
	}
]), Tn = /* @__PURE__ */ v.makeMessageType("livekit.SipDTMF", () => [{
	no: 3,
	name: "code",
	kind: "scalar",
	T: 13
}, {
	no: 4,
	name: "digit",
	kind: "scalar",
	T: 9
}]), En = /* @__PURE__ */ v.makeMessageType("livekit.Transcription", () => [
	{
		no: 2,
		name: "transcribed_participant_identity",
		kind: "scalar",
		T: 9
	},
	{
		no: 3,
		name: "track_id",
		kind: "scalar",
		T: 9
	},
	{
		no: 4,
		name: "segments",
		kind: "message",
		T: Dn,
		repeated: !0
	}
]), Dn = /* @__PURE__ */ v.makeMessageType("livekit.TranscriptionSegment", () => [
	{
		no: 1,
		name: "id",
		kind: "scalar",
		T: 9
	},
	{
		no: 2,
		name: "text",
		kind: "scalar",
		T: 9
	},
	{
		no: 3,
		name: "start_time",
		kind: "scalar",
		T: 4
	},
	{
		no: 4,
		name: "end_time",
		kind: "scalar",
		T: 4
	},
	{
		no: 5,
		name: "final",
		kind: "scalar",
		T: 8
	},
	{
		no: 6,
		name: "language",
		kind: "scalar",
		T: 9
	}
]), On = /* @__PURE__ */ v.makeMessageType("livekit.ChatMessage", () => [
	{
		no: 1,
		name: "id",
		kind: "scalar",
		T: 9
	},
	{
		no: 2,
		name: "timestamp",
		kind: "scalar",
		T: 3
	},
	{
		no: 3,
		name: "edit_timestamp",
		kind: "scalar",
		T: 3,
		opt: !0
	},
	{
		no: 4,
		name: "message",
		kind: "scalar",
		T: 9
	},
	{
		no: 5,
		name: "deleted",
		kind: "scalar",
		T: 8
	},
	{
		no: 6,
		name: "generated",
		kind: "scalar",
		T: 8
	}
]), kn = /* @__PURE__ */ v.makeMessageType("livekit.RpcRequest", () => [
	{
		no: 1,
		name: "id",
		kind: "scalar",
		T: 9
	},
	{
		no: 2,
		name: "method",
		kind: "scalar",
		T: 9
	},
	{
		no: 3,
		name: "payload",
		kind: "scalar",
		T: 9
	},
	{
		no: 4,
		name: "response_timeout_ms",
		kind: "scalar",
		T: 13
	},
	{
		no: 5,
		name: "version",
		kind: "scalar",
		T: 13
	},
	{
		no: 6,
		name: "compressed_payload",
		kind: "scalar",
		T: 12
	}
]), An = /* @__PURE__ */ v.makeMessageType("livekit.RpcAck", () => [{
	no: 1,
	name: "request_id",
	kind: "scalar",
	T: 9
}]), jn = /* @__PURE__ */ v.makeMessageType("livekit.RpcResponse", () => [
	{
		no: 1,
		name: "request_id",
		kind: "scalar",
		T: 9
	},
	{
		no: 2,
		name: "payload",
		kind: "scalar",
		T: 9,
		oneof: "value"
	},
	{
		no: 3,
		name: "error",
		kind: "message",
		T: Mn,
		oneof: "value"
	},
	{
		no: 4,
		name: "compressed_payload",
		kind: "scalar",
		T: 12,
		oneof: "value"
	}
]), Mn = /* @__PURE__ */ v.makeMessageType("livekit.RpcError", () => [
	{
		no: 1,
		name: "code",
		kind: "scalar",
		T: 13
	},
	{
		no: 2,
		name: "message",
		kind: "scalar",
		T: 9
	},
	{
		no: 3,
		name: "data",
		kind: "scalar",
		T: 9
	}
]), Nn = /* @__PURE__ */ v.makeMessageType("livekit.ParticipantTracks", () => [{
	no: 1,
	name: "participant_sid",
	kind: "scalar",
	T: 9
}, {
	no: 2,
	name: "track_sids",
	kind: "scalar",
	T: 9,
	repeated: !0
}]), Pn = /* @__PURE__ */ v.makeMessageType("livekit.ServerInfo", () => [
	{
		no: 1,
		name: "edition",
		kind: "enum",
		T: v.getEnumType(Fn)
	},
	{
		no: 2,
		name: "version",
		kind: "scalar",
		T: 9
	},
	{
		no: 3,
		name: "protocol",
		kind: "scalar",
		T: 5
	},
	{
		no: 4,
		name: "region",
		kind: "scalar",
		T: 9
	},
	{
		no: 5,
		name: "node_id",
		kind: "scalar",
		T: 9
	},
	{
		no: 6,
		name: "debug_info",
		kind: "scalar",
		T: 9
	},
	{
		no: 7,
		name: "agent_protocol",
		kind: "scalar",
		T: 5
	}
]), Fn = /* @__PURE__ */ v.makeEnum("livekit.ServerInfo.Edition", [{
	no: 0,
	name: "Standard"
}, {
	no: 1,
	name: "Cloud"
}]), In = /* @__PURE__ */ v.makeMessageType("livekit.ClientInfo", () => [
	{
		no: 1,
		name: "sdk",
		kind: "enum",
		T: v.getEnumType(Ln)
	},
	{
		no: 2,
		name: "version",
		kind: "scalar",
		T: 9
	},
	{
		no: 3,
		name: "protocol",
		kind: "scalar",
		T: 5
	},
	{
		no: 4,
		name: "os",
		kind: "scalar",
		T: 9
	},
	{
		no: 5,
		name: "os_version",
		kind: "scalar",
		T: 9
	},
	{
		no: 6,
		name: "device_model",
		kind: "scalar",
		T: 9
	},
	{
		no: 7,
		name: "browser",
		kind: "scalar",
		T: 9
	},
	{
		no: 8,
		name: "browser_version",
		kind: "scalar",
		T: 9
	},
	{
		no: 9,
		name: "address",
		kind: "scalar",
		T: 9
	},
	{
		no: 10,
		name: "network",
		kind: "scalar",
		T: 9
	},
	{
		no: 11,
		name: "other_sdks",
		kind: "scalar",
		T: 9
	},
	{
		no: 12,
		name: "client_protocol",
		kind: "scalar",
		T: 5
	},
	{
		no: 13,
		name: "capabilities",
		kind: "enum",
		T: v.getEnumType(Rn),
		repeated: !0
	}
]), Ln = /* @__PURE__ */ v.makeEnum("livekit.ClientInfo.SDK", [
	{
		no: 0,
		name: "UNKNOWN"
	},
	{
		no: 1,
		name: "JS"
	},
	{
		no: 2,
		name: "SWIFT"
	},
	{
		no: 3,
		name: "ANDROID"
	},
	{
		no: 4,
		name: "FLUTTER"
	},
	{
		no: 5,
		name: "GO"
	},
	{
		no: 6,
		name: "UNITY"
	},
	{
		no: 7,
		name: "REACT_NATIVE"
	},
	{
		no: 8,
		name: "RUST"
	},
	{
		no: 9,
		name: "PYTHON"
	},
	{
		no: 10,
		name: "CPP"
	},
	{
		no: 11,
		name: "UNITY_WEB"
	},
	{
		no: 12,
		name: "NODE"
	},
	{
		no: 13,
		name: "UNREAL"
	},
	{
		no: 14,
		name: "ESP32"
	}
]), Rn = /* @__PURE__ */ v.makeEnum("livekit.ClientInfo.Capability", [{
	no: 0,
	name: "CAP_UNUSED"
}, {
	no: 1,
	name: "CAP_PACKET_TRAILER"
}]), zn = /* @__PURE__ */ v.makeMessageType("livekit.ClientConfiguration", () => [
	{
		no: 1,
		name: "video",
		kind: "message",
		T: Bn
	},
	{
		no: 2,
		name: "screen",
		kind: "message",
		T: Bn
	},
	{
		no: 3,
		name: "resume_connection",
		kind: "enum",
		T: v.getEnumType(en)
	},
	{
		no: 4,
		name: "disabled_codecs",
		kind: "message",
		T: Vn
	},
	{
		no: 5,
		name: "force_relay",
		kind: "enum",
		T: v.getEnumType(en)
	}
]), Bn = /* @__PURE__ */ v.makeMessageType("livekit.VideoConfiguration", () => [{
	no: 1,
	name: "hardware_encoder",
	kind: "enum",
	T: v.getEnumType(en)
}]), Vn = /* @__PURE__ */ v.makeMessageType("livekit.DisabledCodecs", () => [{
	no: 1,
	name: "codecs",
	kind: "message",
	T: sn,
	repeated: !0
}, {
	no: 2,
	name: "publish",
	kind: "message",
	T: sn,
	repeated: !0
}]), Hn = /* @__PURE__ */ v.makeMessageType("livekit.TimedVersion", () => [{
	no: 1,
	name: "unix_micro",
	kind: "scalar",
	T: 3
}, {
	no: 2,
	name: "ticks",
	kind: "scalar",
	T: 5
}]), Un = /* @__PURE__ */ v.makeEnum("livekit.DataStream.OperationType", [
	{
		no: 0,
		name: "CREATE"
	},
	{
		no: 1,
		name: "UPDATE"
	},
	{
		no: 2,
		name: "DELETE"
	},
	{
		no: 3,
		name: "REACTION"
	}
]), Wn = /* @__PURE__ */ v.makeMessageType("livekit.DataStream.TextHeader", () => [
	{
		no: 1,
		name: "operation_type",
		kind: "enum",
		T: v.getEnumType(Un)
	},
	{
		no: 2,
		name: "version",
		kind: "scalar",
		T: 5
	},
	{
		no: 3,
		name: "reply_to_stream_id",
		kind: "scalar",
		T: 9
	},
	{
		no: 4,
		name: "attached_stream_ids",
		kind: "scalar",
		T: 9,
		repeated: !0
	},
	{
		no: 5,
		name: "generated",
		kind: "scalar",
		T: 8
	}
], { localName: "DataStream_TextHeader" }), Gn = /* @__PURE__ */ v.makeMessageType("livekit.DataStream.ByteHeader", () => [{
	no: 1,
	name: "name",
	kind: "scalar",
	T: 9
}], { localName: "DataStream_ByteHeader" }), Kn = /* @__PURE__ */ v.makeMessageType("livekit.DataStream.Header", () => [
	{
		no: 1,
		name: "stream_id",
		kind: "scalar",
		T: 9
	},
	{
		no: 2,
		name: "timestamp",
		kind: "scalar",
		T: 3
	},
	{
		no: 3,
		name: "topic",
		kind: "scalar",
		T: 9
	},
	{
		no: 4,
		name: "mime_type",
		kind: "scalar",
		T: 9
	},
	{
		no: 5,
		name: "total_length",
		kind: "scalar",
		T: 4,
		opt: !0
	},
	{
		no: 7,
		name: "encryption_type",
		kind: "enum",
		T: v.getEnumType(x)
	},
	{
		no: 8,
		name: "attributes",
		kind: "map",
		K: 9,
		V: {
			kind: "scalar",
			T: 9
		}
	},
	{
		no: 9,
		name: "text_header",
		kind: "message",
		T: Wn,
		oneof: "content_header"
	},
	{
		no: 10,
		name: "byte_header",
		kind: "message",
		T: Gn,
		oneof: "content_header"
	}
], { localName: "DataStream_Header" }), qn = /* @__PURE__ */ v.makeMessageType("livekit.DataStream.Chunk", () => [
	{
		no: 1,
		name: "stream_id",
		kind: "scalar",
		T: 9
	},
	{
		no: 2,
		name: "chunk_index",
		kind: "scalar",
		T: 4
	},
	{
		no: 3,
		name: "content",
		kind: "scalar",
		T: 12
	},
	{
		no: 4,
		name: "version",
		kind: "scalar",
		T: 5
	},
	{
		no: 5,
		name: "iv",
		kind: "scalar",
		T: 12,
		opt: !0
	}
], { localName: "DataStream_Chunk" }), Jn = /* @__PURE__ */ v.makeMessageType("livekit.DataStream.Trailer", () => [
	{
		no: 1,
		name: "stream_id",
		kind: "scalar",
		T: 9
	},
	{
		no: 2,
		name: "reason",
		kind: "scalar",
		T: 9
	},
	{
		no: 3,
		name: "attributes",
		kind: "map",
		K: 9,
		V: {
			kind: "scalar",
			T: 9
		}
	}
], { localName: "DataStream_Trailer" }), Yn = /* @__PURE__ */ v.makeMessageType("livekit.SubscribedAudioCodec", () => [{
	no: 1,
	name: "codec",
	kind: "scalar",
	T: 9
}, {
	no: 2,
	name: "enabled",
	kind: "scalar",
	T: 8
}]), Xn = /* @__PURE__ */ v.makeEnum("livekit.SignalTarget", [{
	no: 0,
	name: "PUBLISHER"
}, {
	no: 1,
	name: "SUBSCRIBER"
}]), Zn = /* @__PURE__ */ v.makeEnum("livekit.StreamState", [{
	no: 0,
	name: "ACTIVE"
}, {
	no: 1,
	name: "PAUSED"
}]), Qn = /* @__PURE__ */ v.makeEnum("livekit.CandidateProtocol", [
	{
		no: 0,
		name: "UDP"
	},
	{
		no: 1,
		name: "TCP"
	},
	{
		no: 2,
		name: "TLS"
	}
]), $n = /* @__PURE__ */ v.makeMessageType("livekit.SignalRequest", () => [
	{
		no: 1,
		name: "offer",
		kind: "message",
		T: hr,
		oneof: "message"
	},
	{
		no: 2,
		name: "answer",
		kind: "message",
		T: hr,
		oneof: "message"
	},
	{
		no: 3,
		name: "trickle",
		kind: "message",
		T: lr,
		oneof: "message"
	},
	{
		no: 4,
		name: "add_track",
		kind: "message",
		T: nr,
		oneof: "message"
	},
	{
		no: 5,
		name: "mute",
		kind: "message",
		T: ur,
		oneof: "message"
	},
	{
		no: 6,
		name: "subscription",
		kind: "message",
		T: _r,
		oneof: "message"
	},
	{
		no: 7,
		name: "track_setting",
		kind: "message",
		T: br,
		oneof: "message"
	},
	{
		no: 8,
		name: "leave",
		kind: "message",
		T: Cr,
		oneof: "message"
	},
	{
		no: 10,
		name: "update_layers",
		kind: "message",
		T: Tr,
		oneof: "message"
	},
	{
		no: 11,
		name: "subscription_permission",
		kind: "message",
		T: zr,
		oneof: "message"
	},
	{
		no: 12,
		name: "sync_state",
		kind: "message",
		T: Hr,
		oneof: "message"
	},
	{
		no: 13,
		name: "simulate",
		kind: "message",
		T: Gr,
		oneof: "message"
	},
	{
		no: 14,
		name: "ping",
		kind: "scalar",
		T: 3,
		oneof: "message"
	},
	{
		no: 15,
		name: "update_metadata",
		kind: "message",
		T: Er,
		oneof: "message"
	},
	{
		no: 16,
		name: "ping_req",
		kind: "message",
		T: Kr,
		oneof: "message"
	},
	{
		no: 17,
		name: "update_audio_track",
		kind: "message",
		T: xr,
		oneof: "message"
	},
	{
		no: 18,
		name: "update_video_track",
		kind: "message",
		T: Sr,
		oneof: "message"
	},
	{
		no: 19,
		name: "publish_data_track_request",
		kind: "message",
		T: rr,
		oneof: "message"
	},
	{
		no: 20,
		name: "unpublish_data_track_request",
		kind: "message",
		T: ar,
		oneof: "message"
	},
	{
		no: 21,
		name: "update_data_subscription",
		kind: "message",
		T: vr,
		oneof: "message"
	}
]), er = /* @__PURE__ */ v.makeMessageType("livekit.SignalResponse", () => [
	{
		no: 1,
		name: "join",
		kind: "message",
		T: dr,
		oneof: "message"
	},
	{
		no: 2,
		name: "answer",
		kind: "message",
		T: hr,
		oneof: "message"
	},
	{
		no: 3,
		name: "offer",
		kind: "message",
		T: hr,
		oneof: "message"
	},
	{
		no: 4,
		name: "trickle",
		kind: "message",
		T: lr,
		oneof: "message"
	},
	{
		no: 5,
		name: "update",
		kind: "message",
		T: gr,
		oneof: "message"
	},
	{
		no: 6,
		name: "track_published",
		kind: "message",
		T: pr,
		oneof: "message"
	},
	{
		no: 8,
		name: "leave",
		kind: "message",
		T: Cr,
		oneof: "message"
	},
	{
		no: 9,
		name: "mute",
		kind: "message",
		T: ur,
		oneof: "message"
	},
	{
		no: 10,
		name: "speakers_changed",
		kind: "message",
		T: Or,
		oneof: "message"
	},
	{
		no: 11,
		name: "room_update",
		kind: "message",
		T: kr,
		oneof: "message"
	},
	{
		no: 12,
		name: "connection_quality",
		kind: "message",
		T: jr,
		oneof: "message"
	},
	{
		no: 13,
		name: "stream_state_update",
		kind: "message",
		T: Nr,
		oneof: "message"
	},
	{
		no: 14,
		name: "subscribed_quality_update",
		kind: "message",
		T: Ir,
		oneof: "message"
	},
	{
		no: 15,
		name: "subscription_permission_update",
		kind: "message",
		T: Br,
		oneof: "message"
	},
	{
		no: 16,
		name: "refresh_token",
		kind: "scalar",
		T: 9,
		oneof: "message"
	},
	{
		no: 17,
		name: "track_unpublished",
		kind: "message",
		T: mr,
		oneof: "message"
	},
	{
		no: 18,
		name: "pong",
		kind: "scalar",
		T: 3,
		oneof: "message"
	},
	{
		no: 19,
		name: "reconnect",
		kind: "message",
		T: fr,
		oneof: "message"
	},
	{
		no: 20,
		name: "pong_resp",
		kind: "message",
		T: qr,
		oneof: "message"
	},
	{
		no: 21,
		name: "subscription_response",
		kind: "message",
		T: Xr,
		oneof: "message"
	},
	{
		no: 22,
		name: "request_response",
		kind: "message",
		T: Zr,
		oneof: "message"
	},
	{
		no: 23,
		name: "track_subscribed",
		kind: "message",
		T: $r,
		oneof: "message"
	},
	{
		no: 24,
		name: "room_moved",
		kind: "message",
		T: Vr,
		oneof: "message"
	},
	{
		no: 25,
		name: "media_sections_requirement",
		kind: "message",
		T: ii,
		oneof: "message"
	},
	{
		no: 26,
		name: "subscribed_audio_codec_update",
		kind: "message",
		T: Lr,
		oneof: "message"
	},
	{
		no: 27,
		name: "publish_data_track_response",
		kind: "message",
		T: ir,
		oneof: "message"
	},
	{
		no: 28,
		name: "unpublish_data_track_response",
		kind: "message",
		T: or,
		oneof: "message"
	},
	{
		no: 29,
		name: "data_track_subscriber_handles",
		kind: "message",
		T: sr,
		oneof: "message"
	}
]), tr = /* @__PURE__ */ v.makeMessageType("livekit.SimulcastCodec", () => [
	{
		no: 1,
		name: "codec",
		kind: "scalar",
		T: 9
	},
	{
		no: 2,
		name: "cid",
		kind: "scalar",
		T: 9
	},
	{
		no: 4,
		name: "layers",
		kind: "message",
		T: _n,
		repeated: !0
	},
	{
		no: 5,
		name: "video_layer_mode",
		kind: "enum",
		T: v.getEnumType(vn)
	}
]), nr = /* @__PURE__ */ v.makeMessageType("livekit.AddTrackRequest", () => [
	{
		no: 1,
		name: "cid",
		kind: "scalar",
		T: 9
	},
	{
		no: 2,
		name: "name",
		kind: "scalar",
		T: 9
	},
	{
		no: 3,
		name: "type",
		kind: "enum",
		T: v.getEnumType(Zt)
	},
	{
		no: 4,
		name: "width",
		kind: "scalar",
		T: 13
	},
	{
		no: 5,
		name: "height",
		kind: "scalar",
		T: 13
	},
	{
		no: 6,
		name: "muted",
		kind: "scalar",
		T: 8
	},
	{
		no: 7,
		name: "disable_dtx",
		kind: "scalar",
		T: 8
	},
	{
		no: 8,
		name: "source",
		kind: "enum",
		T: v.getEnumType(y)
	},
	{
		no: 9,
		name: "layers",
		kind: "message",
		T: _n,
		repeated: !0
	},
	{
		no: 10,
		name: "simulcast_codecs",
		kind: "message",
		T: tr,
		repeated: !0
	},
	{
		no: 11,
		name: "sid",
		kind: "scalar",
		T: 9
	},
	{
		no: 12,
		name: "stereo",
		kind: "scalar",
		T: 8
	},
	{
		no: 13,
		name: "disable_red",
		kind: "scalar",
		T: 8
	},
	{
		no: 14,
		name: "encryption",
		kind: "enum",
		T: v.getEnumType(x)
	},
	{
		no: 15,
		name: "stream",
		kind: "scalar",
		T: 9
	},
	{
		no: 16,
		name: "backup_codec_policy",
		kind: "enum",
		T: v.getEnumType(Xt)
	},
	{
		no: 17,
		name: "audio_features",
		kind: "enum",
		T: v.getEnumType(b),
		repeated: !0
	},
	{
		no: 18,
		name: "packet_trailer_features",
		kind: "enum",
		T: v.getEnumType(an),
		repeated: !0
	}
]), rr = /* @__PURE__ */ v.makeMessageType("livekit.PublishDataTrackRequest", () => [
	{
		no: 1,
		name: "pub_handle",
		kind: "scalar",
		T: 13
	},
	{
		no: 2,
		name: "name",
		kind: "scalar",
		T: 9
	},
	{
		no: 3,
		name: "encryption",
		kind: "enum",
		T: v.getEnumType(x)
	}
]), ir = /* @__PURE__ */ v.makeMessageType("livekit.PublishDataTrackResponse", () => [{
	no: 1,
	name: "info",
	kind: "message",
	T: hn
}]), ar = /* @__PURE__ */ v.makeMessageType("livekit.UnpublishDataTrackRequest", () => [{
	no: 1,
	name: "pub_handle",
	kind: "scalar",
	T: 13
}]), or = /* @__PURE__ */ v.makeMessageType("livekit.UnpublishDataTrackResponse", () => [{
	no: 1,
	name: "info",
	kind: "message",
	T: hn
}]), sr = /* @__PURE__ */ v.makeMessageType("livekit.DataTrackSubscriberHandles", () => [{
	no: 1,
	name: "sub_handles",
	kind: "map",
	K: 13,
	V: {
		kind: "message",
		T: cr
	}
}]), cr = /* @__PURE__ */ v.makeMessageType("livekit.DataTrackSubscriberHandles.PublishedDataTrack", () => [
	{
		no: 1,
		name: "publisher_identity",
		kind: "scalar",
		T: 9
	},
	{
		no: 2,
		name: "publisher_sid",
		kind: "scalar",
		T: 9
	},
	{
		no: 3,
		name: "track_sid",
		kind: "scalar",
		T: 9
	}
], { localName: "DataTrackSubscriberHandles_PublishedDataTrack" }), lr = /* @__PURE__ */ v.makeMessageType("livekit.TrickleRequest", () => [
	{
		no: 1,
		name: "candidateInit",
		kind: "scalar",
		T: 9
	},
	{
		no: 2,
		name: "target",
		kind: "enum",
		T: v.getEnumType(Xn)
	},
	{
		no: 3,
		name: "final",
		kind: "scalar",
		T: 8
	}
]), ur = /* @__PURE__ */ v.makeMessageType("livekit.MuteTrackRequest", () => [{
	no: 1,
	name: "sid",
	kind: "scalar",
	T: 9
}, {
	no: 2,
	name: "muted",
	kind: "scalar",
	T: 8
}]), dr = /* @__PURE__ */ v.makeMessageType("livekit.JoinResponse", () => [
	{
		no: 1,
		name: "room",
		kind: "message",
		T: on
	},
	{
		no: 2,
		name: "participant",
		kind: "message",
		T: ln
	},
	{
		no: 3,
		name: "other_participants",
		kind: "message",
		T: ln,
		repeated: !0
	},
	{
		no: 4,
		name: "server_version",
		kind: "scalar",
		T: 9
	},
	{
		no: 5,
		name: "ice_servers",
		kind: "message",
		T: Dr,
		repeated: !0
	},
	{
		no: 6,
		name: "subscriber_primary",
		kind: "scalar",
		T: 8
	},
	{
		no: 7,
		name: "alternative_url",
		kind: "scalar",
		T: 9
	},
	{
		no: 8,
		name: "client_configuration",
		kind: "message",
		T: zn
	},
	{
		no: 9,
		name: "server_region",
		kind: "scalar",
		T: 9
	},
	{
		no: 10,
		name: "ping_timeout",
		kind: "scalar",
		T: 5
	},
	{
		no: 11,
		name: "ping_interval",
		kind: "scalar",
		T: 5
	},
	{
		no: 12,
		name: "server_info",
		kind: "message",
		T: Pn
	},
	{
		no: 13,
		name: "sif_trailer",
		kind: "scalar",
		T: 12
	},
	{
		no: 14,
		name: "enabled_publish_codecs",
		kind: "message",
		T: sn,
		repeated: !0
	},
	{
		no: 15,
		name: "fast_publish",
		kind: "scalar",
		T: 8
	}
]), fr = /* @__PURE__ */ v.makeMessageType("livekit.ReconnectResponse", () => [
	{
		no: 1,
		name: "ice_servers",
		kind: "message",
		T: Dr,
		repeated: !0
	},
	{
		no: 2,
		name: "client_configuration",
		kind: "message",
		T: zn
	},
	{
		no: 3,
		name: "server_info",
		kind: "message",
		T: Pn
	},
	{
		no: 4,
		name: "last_message_seq",
		kind: "scalar",
		T: 13
	}
]), pr = /* @__PURE__ */ v.makeMessageType("livekit.TrackPublishedResponse", () => [{
	no: 1,
	name: "cid",
	kind: "scalar",
	T: 9
}, {
	no: 2,
	name: "track",
	kind: "message",
	T: mn
}]), mr = /* @__PURE__ */ v.makeMessageType("livekit.TrackUnpublishedResponse", () => [{
	no: 1,
	name: "track_sid",
	kind: "scalar",
	T: 9
}]), hr = /* @__PURE__ */ v.makeMessageType("livekit.SessionDescription", () => [
	{
		no: 1,
		name: "type",
		kind: "scalar",
		T: 9
	},
	{
		no: 2,
		name: "sdp",
		kind: "scalar",
		T: 9
	},
	{
		no: 3,
		name: "id",
		kind: "scalar",
		T: 13
	},
	{
		no: 4,
		name: "mid_to_track_id",
		kind: "map",
		K: 9,
		V: {
			kind: "scalar",
			T: 9
		}
	}
]), gr = /* @__PURE__ */ v.makeMessageType("livekit.ParticipantUpdate", () => [{
	no: 1,
	name: "participants",
	kind: "message",
	T: ln,
	repeated: !0
}]), _r = /* @__PURE__ */ v.makeMessageType("livekit.UpdateSubscription", () => [
	{
		no: 1,
		name: "track_sids",
		kind: "scalar",
		T: 9,
		repeated: !0
	},
	{
		no: 2,
		name: "subscribe",
		kind: "scalar",
		T: 8
	},
	{
		no: 3,
		name: "participant_tracks",
		kind: "message",
		T: Nn,
		repeated: !0
	}
]), vr = /* @__PURE__ */ v.makeMessageType("livekit.UpdateDataSubscription", () => [{
	no: 1,
	name: "updates",
	kind: "message",
	T: yr,
	repeated: !0
}]), yr = /* @__PURE__ */ v.makeMessageType("livekit.UpdateDataSubscription.Update", () => [
	{
		no: 1,
		name: "track_sid",
		kind: "scalar",
		T: 9
	},
	{
		no: 2,
		name: "subscribe",
		kind: "scalar",
		T: 8
	},
	{
		no: 3,
		name: "options",
		kind: "message",
		T: gn
	}
], { localName: "UpdateDataSubscription_Update" }), br = /* @__PURE__ */ v.makeMessageType("livekit.UpdateTrackSettings", () => [
	{
		no: 1,
		name: "track_sids",
		kind: "scalar",
		T: 9,
		repeated: !0
	},
	{
		no: 3,
		name: "disabled",
		kind: "scalar",
		T: 8
	},
	{
		no: 4,
		name: "quality",
		kind: "enum",
		T: v.getEnumType(Qt)
	},
	{
		no: 5,
		name: "width",
		kind: "scalar",
		T: 13
	},
	{
		no: 6,
		name: "height",
		kind: "scalar",
		T: 13
	},
	{
		no: 7,
		name: "fps",
		kind: "scalar",
		T: 13
	},
	{
		no: 8,
		name: "priority",
		kind: "scalar",
		T: 13
	}
]), xr = /* @__PURE__ */ v.makeMessageType("livekit.UpdateLocalAudioTrack", () => [{
	no: 1,
	name: "track_sid",
	kind: "scalar",
	T: 9
}, {
	no: 2,
	name: "features",
	kind: "enum",
	T: v.getEnumType(b),
	repeated: !0
}]), Sr = /* @__PURE__ */ v.makeMessageType("livekit.UpdateLocalVideoTrack", () => [
	{
		no: 1,
		name: "track_sid",
		kind: "scalar",
		T: 9
	},
	{
		no: 2,
		name: "width",
		kind: "scalar",
		T: 13
	},
	{
		no: 3,
		name: "height",
		kind: "scalar",
		T: 13
	}
]), Cr = /* @__PURE__ */ v.makeMessageType("livekit.LeaveRequest", () => [
	{
		no: 1,
		name: "can_reconnect",
		kind: "scalar",
		T: 8
	},
	{
		no: 2,
		name: "reason",
		kind: "enum",
		T: v.getEnumType(tn)
	},
	{
		no: 3,
		name: "action",
		kind: "enum",
		T: v.getEnumType(wr)
	},
	{
		no: 4,
		name: "regions",
		kind: "message",
		T: Jr
	}
]), wr = /* @__PURE__ */ v.makeEnum("livekit.LeaveRequest.Action", [
	{
		no: 0,
		name: "DISCONNECT"
	},
	{
		no: 1,
		name: "RESUME"
	},
	{
		no: 2,
		name: "RECONNECT"
	}
]), Tr = /* @__PURE__ */ v.makeMessageType("livekit.UpdateVideoLayers", () => [{
	no: 1,
	name: "track_sid",
	kind: "scalar",
	T: 9
}, {
	no: 2,
	name: "layers",
	kind: "message",
	T: _n,
	repeated: !0
}]), Er = /* @__PURE__ */ v.makeMessageType("livekit.UpdateParticipantMetadata", () => [
	{
		no: 1,
		name: "metadata",
		kind: "scalar",
		T: 9
	},
	{
		no: 2,
		name: "name",
		kind: "scalar",
		T: 9
	},
	{
		no: 3,
		name: "attributes",
		kind: "map",
		K: 9,
		V: {
			kind: "scalar",
			T: 9
		}
	},
	{
		no: 4,
		name: "request_id",
		kind: "scalar",
		T: 13
	}
]), Dr = /* @__PURE__ */ v.makeMessageType("livekit.ICEServer", () => [
	{
		no: 1,
		name: "urls",
		kind: "scalar",
		T: 9,
		repeated: !0
	},
	{
		no: 2,
		name: "username",
		kind: "scalar",
		T: 9
	},
	{
		no: 3,
		name: "credential",
		kind: "scalar",
		T: 9
	}
]), Or = /* @__PURE__ */ v.makeMessageType("livekit.SpeakersChanged", () => [{
	no: 1,
	name: "speakers",
	kind: "message",
	T: Cn,
	repeated: !0
}]), kr = /* @__PURE__ */ v.makeMessageType("livekit.RoomUpdate", () => [{
	no: 1,
	name: "room",
	kind: "message",
	T: on
}]), Ar = /* @__PURE__ */ v.makeMessageType("livekit.ConnectionQualityInfo", () => [
	{
		no: 1,
		name: "participant_sid",
		kind: "scalar",
		T: 9
	},
	{
		no: 2,
		name: "quality",
		kind: "enum",
		T: v.getEnumType($t)
	},
	{
		no: 3,
		name: "score",
		kind: "scalar",
		T: 2
	}
]), jr = /* @__PURE__ */ v.makeMessageType("livekit.ConnectionQualityUpdate", () => [{
	no: 1,
	name: "updates",
	kind: "message",
	T: Ar,
	repeated: !0
}]), Mr = /* @__PURE__ */ v.makeMessageType("livekit.StreamStateInfo", () => [
	{
		no: 1,
		name: "participant_sid",
		kind: "scalar",
		T: 9
	},
	{
		no: 2,
		name: "track_sid",
		kind: "scalar",
		T: 9
	},
	{
		no: 3,
		name: "state",
		kind: "enum",
		T: v.getEnumType(Zn)
	}
]), Nr = /* @__PURE__ */ v.makeMessageType("livekit.StreamStateUpdate", () => [{
	no: 1,
	name: "stream_states",
	kind: "message",
	T: Mr,
	repeated: !0
}]), Pr = /* @__PURE__ */ v.makeMessageType("livekit.SubscribedQuality", () => [{
	no: 1,
	name: "quality",
	kind: "enum",
	T: v.getEnumType(Qt)
}, {
	no: 2,
	name: "enabled",
	kind: "scalar",
	T: 8
}]), Fr = /* @__PURE__ */ v.makeMessageType("livekit.SubscribedCodec", () => [{
	no: 1,
	name: "codec",
	kind: "scalar",
	T: 9
}, {
	no: 2,
	name: "qualities",
	kind: "message",
	T: Pr,
	repeated: !0
}]), Ir = /* @__PURE__ */ v.makeMessageType("livekit.SubscribedQualityUpdate", () => [
	{
		no: 1,
		name: "track_sid",
		kind: "scalar",
		T: 9
	},
	{
		no: 2,
		name: "subscribed_qualities",
		kind: "message",
		T: Pr,
		repeated: !0
	},
	{
		no: 3,
		name: "subscribed_codecs",
		kind: "message",
		T: Fr,
		repeated: !0
	}
]), Lr = /* @__PURE__ */ v.makeMessageType("livekit.SubscribedAudioCodecUpdate", () => [{
	no: 1,
	name: "track_sid",
	kind: "scalar",
	T: 9
}, {
	no: 2,
	name: "subscribed_audio_codecs",
	kind: "message",
	T: Yn,
	repeated: !0
}]), Rr = /* @__PURE__ */ v.makeMessageType("livekit.TrackPermission", () => [
	{
		no: 1,
		name: "participant_sid",
		kind: "scalar",
		T: 9
	},
	{
		no: 2,
		name: "all_tracks",
		kind: "scalar",
		T: 8
	},
	{
		no: 3,
		name: "track_sids",
		kind: "scalar",
		T: 9,
		repeated: !0
	},
	{
		no: 4,
		name: "participant_identity",
		kind: "scalar",
		T: 9
	}
]), zr = /* @__PURE__ */ v.makeMessageType("livekit.SubscriptionPermission", () => [{
	no: 1,
	name: "all_participants",
	kind: "scalar",
	T: 8
}, {
	no: 2,
	name: "track_permissions",
	kind: "message",
	T: Rr,
	repeated: !0
}]), Br = /* @__PURE__ */ v.makeMessageType("livekit.SubscriptionPermissionUpdate", () => [
	{
		no: 1,
		name: "participant_sid",
		kind: "scalar",
		T: 9
	},
	{
		no: 2,
		name: "track_sid",
		kind: "scalar",
		T: 9
	},
	{
		no: 3,
		name: "allowed",
		kind: "scalar",
		T: 8
	}
]), Vr = /* @__PURE__ */ v.makeMessageType("livekit.RoomMovedResponse", () => [
	{
		no: 1,
		name: "room",
		kind: "message",
		T: on
	},
	{
		no: 2,
		name: "token",
		kind: "scalar",
		T: 9
	},
	{
		no: 3,
		name: "participant",
		kind: "message",
		T: ln
	},
	{
		no: 4,
		name: "other_participants",
		kind: "message",
		T: ln,
		repeated: !0
	}
]), Hr = /* @__PURE__ */ v.makeMessageType("livekit.SyncState", () => [
	{
		no: 1,
		name: "answer",
		kind: "message",
		T: hr
	},
	{
		no: 2,
		name: "subscription",
		kind: "message",
		T: _r
	},
	{
		no: 3,
		name: "publish_tracks",
		kind: "message",
		T: pr,
		repeated: !0
	},
	{
		no: 4,
		name: "data_channels",
		kind: "message",
		T: Wr,
		repeated: !0
	},
	{
		no: 5,
		name: "offer",
		kind: "message",
		T: hr
	},
	{
		no: 6,
		name: "track_sids_disabled",
		kind: "scalar",
		T: 9,
		repeated: !0
	},
	{
		no: 7,
		name: "datachannel_receive_states",
		kind: "message",
		T: Ur,
		repeated: !0
	},
	{
		no: 8,
		name: "publish_data_tracks",
		kind: "message",
		T: ir,
		repeated: !0
	}
]), Ur = /* @__PURE__ */ v.makeMessageType("livekit.DataChannelReceiveState", () => [{
	no: 1,
	name: "publisher_sid",
	kind: "scalar",
	T: 9
}, {
	no: 2,
	name: "last_seq",
	kind: "scalar",
	T: 13
}]), Wr = /* @__PURE__ */ v.makeMessageType("livekit.DataChannelInfo", () => [
	{
		no: 1,
		name: "label",
		kind: "scalar",
		T: 9
	},
	{
		no: 2,
		name: "id",
		kind: "scalar",
		T: 13
	},
	{
		no: 3,
		name: "target",
		kind: "enum",
		T: v.getEnumType(Xn)
	}
]), Gr = /* @__PURE__ */ v.makeMessageType("livekit.SimulateScenario", () => [
	{
		no: 1,
		name: "speaker_update",
		kind: "scalar",
		T: 5,
		oneof: "scenario"
	},
	{
		no: 2,
		name: "node_failure",
		kind: "scalar",
		T: 8,
		oneof: "scenario"
	},
	{
		no: 3,
		name: "migration",
		kind: "scalar",
		T: 8,
		oneof: "scenario"
	},
	{
		no: 4,
		name: "server_leave",
		kind: "scalar",
		T: 8,
		oneof: "scenario"
	},
	{
		no: 5,
		name: "switch_candidate_protocol",
		kind: "enum",
		T: v.getEnumType(Qn),
		oneof: "scenario"
	},
	{
		no: 6,
		name: "subscriber_bandwidth",
		kind: "scalar",
		T: 3,
		oneof: "scenario"
	},
	{
		no: 7,
		name: "disconnect_signal_on_resume",
		kind: "scalar",
		T: 8,
		oneof: "scenario"
	},
	{
		no: 8,
		name: "disconnect_signal_on_resume_no_messages",
		kind: "scalar",
		T: 8,
		oneof: "scenario"
	},
	{
		no: 9,
		name: "leave_request_full_reconnect",
		kind: "scalar",
		T: 8,
		oneof: "scenario"
	}
]), Kr = /* @__PURE__ */ v.makeMessageType("livekit.Ping", () => [{
	no: 1,
	name: "timestamp",
	kind: "scalar",
	T: 3
}, {
	no: 2,
	name: "rtt",
	kind: "scalar",
	T: 3
}]), qr = /* @__PURE__ */ v.makeMessageType("livekit.Pong", () => [{
	no: 1,
	name: "last_ping_timestamp",
	kind: "scalar",
	T: 3
}, {
	no: 2,
	name: "timestamp",
	kind: "scalar",
	T: 3
}]), Jr = /* @__PURE__ */ v.makeMessageType("livekit.RegionSettings", () => [{
	no: 1,
	name: "regions",
	kind: "message",
	T: Yr,
	repeated: !0
}]), Yr = /* @__PURE__ */ v.makeMessageType("livekit.RegionInfo", () => [
	{
		no: 1,
		name: "region",
		kind: "scalar",
		T: 9
	},
	{
		no: 2,
		name: "url",
		kind: "scalar",
		T: 9
	},
	{
		no: 3,
		name: "distance",
		kind: "scalar",
		T: 3
	}
]), Xr = /* @__PURE__ */ v.makeMessageType("livekit.SubscriptionResponse", () => [{
	no: 1,
	name: "track_sid",
	kind: "scalar",
	T: 9
}, {
	no: 2,
	name: "err",
	kind: "enum",
	T: v.getEnumType(rn)
}]), Zr = /* @__PURE__ */ v.makeMessageType("livekit.RequestResponse", () => [
	{
		no: 1,
		name: "request_id",
		kind: "scalar",
		T: 13
	},
	{
		no: 2,
		name: "reason",
		kind: "enum",
		T: v.getEnumType(Qr)
	},
	{
		no: 3,
		name: "message",
		kind: "scalar",
		T: 9
	},
	{
		no: 4,
		name: "trickle",
		kind: "message",
		T: lr,
		oneof: "request"
	},
	{
		no: 5,
		name: "add_track",
		kind: "message",
		T: nr,
		oneof: "request"
	},
	{
		no: 6,
		name: "mute",
		kind: "message",
		T: ur,
		oneof: "request"
	},
	{
		no: 7,
		name: "update_metadata",
		kind: "message",
		T: Er,
		oneof: "request"
	},
	{
		no: 8,
		name: "update_audio_track",
		kind: "message",
		T: xr,
		oneof: "request"
	},
	{
		no: 9,
		name: "update_video_track",
		kind: "message",
		T: Sr,
		oneof: "request"
	},
	{
		no: 10,
		name: "publish_data_track",
		kind: "message",
		T: rr,
		oneof: "request"
	},
	{
		no: 11,
		name: "unpublish_data_track",
		kind: "message",
		T: ar,
		oneof: "request"
	}
]), Qr = /* @__PURE__ */ v.makeEnum("livekit.RequestResponse.Reason", [
	{
		no: 0,
		name: "OK"
	},
	{
		no: 1,
		name: "NOT_FOUND"
	},
	{
		no: 2,
		name: "NOT_ALLOWED"
	},
	{
		no: 3,
		name: "LIMIT_EXCEEDED"
	},
	{
		no: 4,
		name: "QUEUED"
	},
	{
		no: 5,
		name: "UNSUPPORTED_TYPE"
	},
	{
		no: 6,
		name: "UNCLASSIFIED_ERROR"
	},
	{
		no: 7,
		name: "INVALID_HANDLE"
	},
	{
		no: 8,
		name: "INVALID_NAME"
	},
	{
		no: 9,
		name: "DUPLICATE_HANDLE"
	},
	{
		no: 10,
		name: "DUPLICATE_NAME"
	}
]), $r = /* @__PURE__ */ v.makeMessageType("livekit.TrackSubscribed", () => [{
	no: 1,
	name: "track_sid",
	kind: "scalar",
	T: 9
}]), ei = /* @__PURE__ */ v.makeMessageType("livekit.ConnectionSettings", () => [
	{
		no: 1,
		name: "auto_subscribe",
		kind: "scalar",
		T: 8
	},
	{
		no: 2,
		name: "adaptive_stream",
		kind: "scalar",
		T: 8
	},
	{
		no: 3,
		name: "subscriber_allow_pause",
		kind: "scalar",
		T: 8,
		opt: !0
	},
	{
		no: 4,
		name: "disable_ice_lite",
		kind: "scalar",
		T: 8
	},
	{
		no: 5,
		name: "auto_subscribe_data_track",
		kind: "scalar",
		T: 8,
		opt: !0
	}
]), ti = /* @__PURE__ */ v.makeMessageType("livekit.JoinRequest", () => [
	{
		no: 1,
		name: "client_info",
		kind: "message",
		T: In
	},
	{
		no: 2,
		name: "connection_settings",
		kind: "message",
		T: ei
	},
	{
		no: 3,
		name: "metadata",
		kind: "scalar",
		T: 9
	},
	{
		no: 4,
		name: "participant_attributes",
		kind: "map",
		K: 9,
		V: {
			kind: "scalar",
			T: 9
		}
	},
	{
		no: 5,
		name: "add_track_requests",
		kind: "message",
		T: nr,
		repeated: !0
	},
	{
		no: 6,
		name: "publisher_offer",
		kind: "message",
		T: hr
	},
	{
		no: 7,
		name: "reconnect",
		kind: "scalar",
		T: 8
	},
	{
		no: 8,
		name: "reconnect_reason",
		kind: "enum",
		T: v.getEnumType(nn)
	},
	{
		no: 9,
		name: "participant_sid",
		kind: "scalar",
		T: 9
	},
	{
		no: 10,
		name: "sync_state",
		kind: "message",
		T: Hr
	}
]), ni = /* @__PURE__ */ v.makeMessageType("livekit.WrappedJoinRequest", () => [{
	no: 1,
	name: "compression",
	kind: "enum",
	T: v.getEnumType(ri)
}, {
	no: 2,
	name: "join_request",
	kind: "scalar",
	T: 12
}]), ri = /* @__PURE__ */ v.makeEnum("livekit.WrappedJoinRequest.Compression", [{
	no: 0,
	name: "NONE"
}, {
	no: 1,
	name: "GZIP"
}]), ii = /* @__PURE__ */ v.makeMessageType("livekit.MediaSectionsRequirement", () => [{
	no: 1,
	name: "num_audios",
	kind: "scalar",
	T: 13
}, {
	no: 2,
	name: "num_videos",
	kind: "scalar",
	T: 13
}]);
function ai(e) {
	return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default") ? e.default : e;
}
var oi = { exports: {} }, si = oi.exports, ci;
function li() {
	return ci ? oi.exports : (ci = 1, (function(e) {
		(function(t, n) {
			e.exports ? e.exports = n() : t.log = n();
		})(si, function() {
			var e = function() {}, t = "undefined", n = typeof window !== t && typeof window.navigator !== t && /Trident\/|MSIE /.test(window.navigator.userAgent), r = [
				"trace",
				"debug",
				"info",
				"warn",
				"error"
			], i = {}, a = null;
			function o(e, t) {
				var n = e[t];
				if (typeof n.bind == "function") return n.bind(e);
				try {
					return Function.prototype.bind.call(n, e);
				} catch {
					return function() {
						return Function.prototype.apply.apply(n, [e, arguments]);
					};
				}
			}
			function s() {
				console.log && (console.log.apply ? console.log.apply(console, arguments) : Function.prototype.apply.apply(console.log, [console, arguments])), console.trace && console.trace();
			}
			function c(r) {
				return r === "debug" && (r = "log"), typeof console === t ? !1 : r === "trace" && n ? s : console[r] === void 0 ? console.log === void 0 ? e : o(console, "log") : o(console, r);
			}
			function l() {
				for (var n = this.getLevel(), i = 0; i < r.length; i++) {
					var a = r[i];
					this[a] = i < n ? e : this.methodFactory(a, n, this.name);
				}
				if (this.log = this.debug, typeof console === t && n < this.levels.SILENT) return "No console available for logging";
			}
			function u(e) {
				return function() {
					typeof console !== t && (l.call(this), this[e].apply(this, arguments));
				};
			}
			function d(e, t, n) {
				return c(e) || u.apply(this, arguments);
			}
			function f(e, n) {
				var o = this, s, c, u, f = "loglevel";
				typeof e == "string" ? f += ":" + e : typeof e == "symbol" && (f = void 0);
				function ee(e) {
					var n = (r[e] || "silent").toUpperCase();
					if (!(typeof window === t || !f)) {
						try {
							window.localStorage[f] = n;
							return;
						} catch {}
						try {
							window.document.cookie = encodeURIComponent(f) + "=" + n + ";";
						} catch {}
					}
				}
				function te() {
					var e;
					if (!(typeof window === t || !f)) {
						try {
							e = window.localStorage[f];
						} catch {}
						if (typeof e === t) try {
							var n = window.document.cookie, r = encodeURIComponent(f), i = n.indexOf(r + "=");
							i !== -1 && (e = /^([^;]+)/.exec(n.slice(i + r.length + 1))[1]);
						} catch {}
						return o.levels[e] === void 0 && (e = void 0), e;
					}
				}
				function ne() {
					if (!(typeof window === t || !f)) {
						try {
							window.localStorage.removeItem(f);
						} catch {}
						try {
							window.document.cookie = encodeURIComponent(f) + "=; expires=Thu, 01 Jan 1970 00:00:00 UTC";
						} catch {}
					}
				}
				function re(e) {
					var t = e;
					if (typeof t == "string" && o.levels[t.toUpperCase()] !== void 0 && (t = o.levels[t.toUpperCase()]), typeof t == "number" && t >= 0 && t <= o.levels.SILENT) return t;
					throw TypeError("log.setLevel() called with invalid level: " + e);
				}
				o.name = e, o.levels = {
					TRACE: 0,
					DEBUG: 1,
					INFO: 2,
					WARN: 3,
					ERROR: 4,
					SILENT: 5
				}, o.methodFactory = n || d, o.getLevel = function() {
					return u ?? c ?? s;
				}, o.setLevel = function(e, t) {
					return u = re(e), t !== !1 && ee(u), l.call(o);
				}, o.setDefaultLevel = function(e) {
					c = re(e), te() || o.setLevel(e, !1);
				}, o.resetLevel = function() {
					u = null, ne(), l.call(o);
				}, o.enableAll = function(e) {
					o.setLevel(o.levels.TRACE, e);
				}, o.disableAll = function(e) {
					o.setLevel(o.levels.SILENT, e);
				}, o.rebuild = function() {
					if (a !== o && (s = re(a.getLevel())), l.call(o), a === o) for (var e in i) i[e].rebuild();
				}, s = re(a ? a.getLevel() : "WARN");
				var ie = te();
				ie != null && (u = re(ie)), l.call(o);
			}
			a = new f(), a.getLogger = function(e) {
				if (typeof e != "symbol" && typeof e != "string" || e === "") throw TypeError("You must supply a name when creating a logger.");
				var t = i[e];
				return t ||= i[e] = new f(e, a.methodFactory), t;
			};
			var ee = typeof window === t ? void 0 : window.log;
			return a.noConflict = function() {
				return typeof window !== t && window.log === a && (window.log = ee), a;
			}, a.getLoggers = function() {
				return i;
			}, a.default = a, a;
		});
	})(oi), oi.exports);
}
var ui = li(), di;
(function(e) {
	e[e.trace = 0] = "trace", e[e.debug = 1] = "debug", e[e.info = 2] = "info", e[e.warn = 3] = "warn", e[e.error = 4] = "error", e[e.silent = 5] = "silent";
})(di ||= {});
var C;
(function(e) {
	e.Default = "livekit", e.Room = "livekit-room", e.TokenSource = "livekit-token-source", e.Participant = "livekit-participant", e.Track = "livekit-track", e.Publication = "livekit-track-publication", e.Engine = "livekit-engine", e.Signal = "livekit-signal", e.PCManager = "livekit-pc-manager", e.PCTransport = "livekit-pc-transport", e.E2EE = "lk-e2ee", e.DataTracks = "livekit-data-tracks";
})(C ||= {});
var w = ui.getLogger(C.Default), fi = Object.values(C).map((e) => ui.getLogger(e));
w.setDefaultLevel(di.info);
function T(e, t) {
	let n = ui.getLogger(e);
	return n.setDefaultLevel(w.getLevel()), t ? pi(n, t) : n;
}
function pi(e, t) {
	let n = (n) => (r, i) => {
		let a = t(), o = a || i ? Object.assign(Object.assign({}, a), i) : void 0;
		e[n](r, o);
	}, r = Object.create(e);
	return r.trace = n("trace"), r.debug = n("debug"), r.info = n("info"), r.warn = n("warn"), r.error = n("error"), r;
}
function mi(e, t) {
	if (t) ui.getLogger(t).setLevel(e);
	else for (let t of fi) t.setLevel(e);
}
var hi = ui.getLogger(C.E2EE), gi = 7e3, _i = [
	0,
	300,
	4 * 300,
	9 * 300,
	16 * 300,
	gi,
	gi,
	gi,
	gi,
	gi
], vi = class {
	constructor(e) {
		this._retryDelays = e === void 0 ? _i : [...e];
	}
	nextRetryDelayInMs(e) {
		if (e.retryCount >= this._retryDelays.length) return null;
		let t = this._retryDelays[e.retryCount];
		return e.retryCount <= 1 ? t : t + Math.random() * 1e3;
	}
};
function yi(e, t) {
	var n = {};
	for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && t.indexOf(r) < 0 && (n[r] = e[r]);
	if (e != null && typeof Object.getOwnPropertySymbols == "function") for (var i = 0, r = Object.getOwnPropertySymbols(e); i < r.length; i++) t.indexOf(r[i]) < 0 && Object.prototype.propertyIsEnumerable.call(e, r[i]) && (n[r[i]] = e[r[i]]);
	return n;
}
function E(e, t, n, r) {
	function i(e) {
		return e instanceof n ? e : new n(function(t) {
			t(e);
		});
	}
	return new (n ||= Promise)(function(n, a) {
		function o(e) {
			try {
				c(r.next(e));
			} catch (e) {
				a(e);
			}
		}
		function s(e) {
			try {
				c(r.throw(e));
			} catch (e) {
				a(e);
			}
		}
		function c(e) {
			e.done ? n(e.value) : i(e.value).then(o, s);
		}
		c((r = r.apply(e, t || [])).next());
	});
}
function bi(e) {
	var t = typeof Symbol == "function" && Symbol.iterator, n = t && e[t], r = 0;
	if (n) return n.call(e);
	if (e && typeof e.length == "number") return { next: function() {
		return e && r >= e.length && (e = void 0), {
			value: e && e[r++],
			done: !e
		};
	} };
	throw TypeError(t ? "Object is not iterable." : "Symbol.iterator is not defined.");
}
function xi(e) {
	return this instanceof xi ? (this.v = e, this) : new xi(e);
}
function Si(e, t, n) {
	if (!Symbol.asyncIterator) throw TypeError("Symbol.asyncIterator is not defined.");
	var r = n.apply(e, t || []), i, a = [];
	return i = Object.create((typeof AsyncIterator == "function" ? AsyncIterator : Object).prototype), s("next"), s("throw"), s("return", o), i[Symbol.asyncIterator] = function() {
		return this;
	}, i;
	function o(e) {
		return function(t) {
			return Promise.resolve(t).then(e, d);
		};
	}
	function s(e, t) {
		r[e] && (i[e] = function(t) {
			return new Promise(function(n, r) {
				a.push([
					e,
					t,
					n,
					r
				]) > 1 || c(e, t);
			});
		}, t && (i[e] = t(i[e])));
	}
	function c(e, t) {
		try {
			l(r[e](t));
		} catch (e) {
			f(a[0][3], e);
		}
	}
	function l(e) {
		e.value instanceof xi ? Promise.resolve(e.value.v).then(u, d) : f(a[0][2], e);
	}
	function u(e) {
		c("next", e);
	}
	function d(e) {
		c("throw", e);
	}
	function f(e, t) {
		e(t), a.shift(), a.length && c(a[0][0], a[0][1]);
	}
}
function Ci(e) {
	var t, n;
	return t = {}, r("next"), r("throw", function(e) {
		throw e;
	}), r("return"), t[Symbol.iterator] = function() {
		return this;
	}, t;
	function r(r, i) {
		t[r] = e[r] ? function(t) {
			return (n = !n) ? {
				value: xi(e[r](t)),
				done: !1
			} : i ? i(t) : t;
		} : i;
	}
}
function wi(e) {
	if (!Symbol.asyncIterator) throw TypeError("Symbol.asyncIterator is not defined.");
	var t = e[Symbol.asyncIterator], n;
	return t ? t.call(e) : (e = typeof bi == "function" ? bi(e) : e[Symbol.iterator](), n = {}, r("next"), r("throw"), r("return"), n[Symbol.asyncIterator] = function() {
		return this;
	}, n);
	function r(t) {
		n[t] = e[t] && function(n) {
			return new Promise(function(r, a) {
				n = e[t](n), i(r, a, n.done, n.value);
			});
		};
	}
	function i(e, t, n, r) {
		Promise.resolve(r).then(function(t) {
			e({
				value: t,
				done: n
			});
		}, t);
	}
}
var Ti = { exports: {} }, Ei;
function Di() {
	if (Ei) return Ti.exports;
	Ei = 1;
	var e = typeof Reflect == "object" ? Reflect : null, t = e && typeof e.apply == "function" ? e.apply : function(e, t, n) {
		return Function.prototype.apply.call(e, t, n);
	}, n = e && typeof e.ownKeys == "function" ? e.ownKeys : Object.getOwnPropertySymbols ? function(e) {
		return Object.getOwnPropertyNames(e).concat(Object.getOwnPropertySymbols(e));
	} : function(e) {
		return Object.getOwnPropertyNames(e);
	};
	function r(e) {
		console && console.warn && console.warn(e);
	}
	var i = Number.isNaN || function(e) {
		return e !== e;
	};
	function a() {
		a.init.call(this);
	}
	Ti.exports = a, Ti.exports.once = ie, a.EventEmitter = a, a.prototype._events = void 0, a.prototype._eventsCount = 0, a.prototype._maxListeners = void 0;
	var o = 10;
	function s(e) {
		if (typeof e != "function") throw TypeError("The \"listener\" argument must be of type Function. Received type " + typeof e);
	}
	Object.defineProperty(a, "defaultMaxListeners", {
		enumerable: !0,
		get: function() {
			return o;
		},
		set: function(e) {
			if (typeof e != "number" || e < 0 || i(e)) throw RangeError("The value of \"defaultMaxListeners\" is out of range. It must be a non-negative number. Received " + e + ".");
			o = e;
		}
	}), a.init = function() {
		(this._events === void 0 || this._events === Object.getPrototypeOf(this)._events) && (this._events = Object.create(null), this._eventsCount = 0), this._maxListeners = this._maxListeners || void 0;
	}, a.prototype.setMaxListeners = function(e) {
		if (typeof e != "number" || e < 0 || i(e)) throw RangeError("The value of \"n\" is out of range. It must be a non-negative number. Received " + e + ".");
		return this._maxListeners = e, this;
	};
	function c(e) {
		return e._maxListeners === void 0 ? a.defaultMaxListeners : e._maxListeners;
	}
	a.prototype.getMaxListeners = function() {
		return c(this);
	}, a.prototype.emit = function(e) {
		for (var n = [], r = 1; r < arguments.length; r++) n.push(arguments[r]);
		var i = e === "error", a = this._events;
		if (a !== void 0) i &&= a.error === void 0;
		else if (!i) return !1;
		if (i) {
			var o;
			if (n.length > 0 && (o = n[0]), o instanceof Error) throw o;
			var s = /* @__PURE__ */ Error("Unhandled error." + (o ? " (" + o.message + ")" : ""));
			throw s.context = o, s;
		}
		var c = a[e];
		if (c === void 0) return !1;
		if (typeof c == "function") t(c, this, n);
		else for (var l = c.length, u = te(c, l), r = 0; r < l; ++r) t(u[r], this, n);
		return !0;
	};
	function l(e, t, n, i) {
		var a, o, l;
		if (s(n), o = e._events, o === void 0 ? (o = e._events = Object.create(null), e._eventsCount = 0) : (o.newListener !== void 0 && (e.emit("newListener", t, n.listener ? n.listener : n), o = e._events), l = o[t]), l === void 0) l = o[t] = n, ++e._eventsCount;
		else if (typeof l == "function" ? l = o[t] = i ? [n, l] : [l, n] : i ? l.unshift(n) : l.push(n), a = c(e), a > 0 && l.length > a && !l.warned) {
			l.warned = !0;
			var u = /* @__PURE__ */ Error("Possible EventEmitter memory leak detected. " + l.length + " " + String(t) + " listeners added. Use emitter.setMaxListeners() to increase limit");
			u.name = "MaxListenersExceededWarning", u.emitter = e, u.type = t, u.count = l.length, r(u);
		}
		return e;
	}
	a.prototype.addListener = function(e, t) {
		return l(this, e, t, !1);
	}, a.prototype.on = a.prototype.addListener, a.prototype.prependListener = function(e, t) {
		return l(this, e, t, !0);
	};
	function u() {
		if (!this.fired) return this.target.removeListener(this.type, this.wrapFn), this.fired = !0, arguments.length === 0 ? this.listener.call(this.target) : this.listener.apply(this.target, arguments);
	}
	function d(e, t, n) {
		var r = {
			fired: !1,
			wrapFn: void 0,
			target: e,
			type: t,
			listener: n
		}, i = u.bind(r);
		return i.listener = n, r.wrapFn = i, i;
	}
	a.prototype.once = function(e, t) {
		return s(t), this.on(e, d(this, e, t)), this;
	}, a.prototype.prependOnceListener = function(e, t) {
		return s(t), this.prependListener(e, d(this, e, t)), this;
	}, a.prototype.removeListener = function(e, t) {
		var n, r, i, a, o;
		if (s(t), r = this._events, r === void 0 || (n = r[e], n === void 0)) return this;
		if (n === t || n.listener === t) --this._eventsCount === 0 ? this._events = Object.create(null) : (delete r[e], r.removeListener && this.emit("removeListener", e, n.listener || t));
		else if (typeof n != "function") {
			for (i = -1, a = n.length - 1; a >= 0; a--) if (n[a] === t || n[a].listener === t) {
				o = n[a].listener, i = a;
				break;
			}
			if (i < 0) return this;
			i === 0 ? n.shift() : ne(n, i), n.length === 1 && (r[e] = n[0]), r.removeListener !== void 0 && this.emit("removeListener", e, o || t);
		}
		return this;
	}, a.prototype.off = a.prototype.removeListener, a.prototype.removeAllListeners = function(e) {
		var t, n = this._events, r;
		if (n === void 0) return this;
		if (n.removeListener === void 0) return arguments.length === 0 ? (this._events = Object.create(null), this._eventsCount = 0) : n[e] !== void 0 && (--this._eventsCount === 0 ? this._events = Object.create(null) : delete n[e]), this;
		if (arguments.length === 0) {
			var i = Object.keys(n), a;
			for (r = 0; r < i.length; ++r) a = i[r], a !== "removeListener" && this.removeAllListeners(a);
			return this.removeAllListeners("removeListener"), this._events = Object.create(null), this._eventsCount = 0, this;
		}
		if (t = n[e], typeof t == "function") this.removeListener(e, t);
		else if (t !== void 0) for (r = t.length - 1; r >= 0; r--) this.removeListener(e, t[r]);
		return this;
	};
	function f(e, t, n) {
		var r = e._events;
		if (r === void 0) return [];
		var i = r[t];
		return i === void 0 ? [] : typeof i == "function" ? n ? [i.listener || i] : [i] : n ? re(i) : te(i, i.length);
	}
	a.prototype.listeners = function(e) {
		return f(this, e, !0);
	}, a.prototype.rawListeners = function(e) {
		return f(this, e, !1);
	}, a.listenerCount = function(e, t) {
		return typeof e.listenerCount == "function" ? e.listenerCount(t) : ee.call(e, t);
	}, a.prototype.listenerCount = ee;
	function ee(e) {
		var t = this._events;
		if (t !== void 0) {
			var n = t[e];
			if (typeof n == "function") return 1;
			if (n !== void 0) return n.length;
		}
		return 0;
	}
	a.prototype.eventNames = function() {
		return this._eventsCount > 0 ? n(this._events) : [];
	};
	function te(e, t) {
		for (var n = Array(t), r = 0; r < t; ++r) n[r] = e[r];
		return n;
	}
	function ne(e, t) {
		for (; t + 1 < e.length; t++) e[t] = e[t + 1];
		e.pop();
	}
	function re(e) {
		for (var t = Array(e.length), n = 0; n < t.length; ++n) t[n] = e[n].listener || e[n];
		return t;
	}
	function ie(e, t) {
		return new Promise(function(n, r) {
			function i(n) {
				e.removeListener(t, a), r(n);
			}
			function a() {
				typeof e.removeListener == "function" && e.removeListener("error", i), n([].slice.call(arguments));
			}
			oe(e, t, a, { once: !0 }), t !== "error" && ae(e, i, { once: !0 });
		});
	}
	function ae(e, t, n) {
		typeof e.on == "function" && oe(e, "error", t, n);
	}
	function oe(e, t, n, r) {
		if (typeof e.on == "function") r.once ? e.once(t, n) : e.on(t, n);
		else if (typeof e.addEventListener == "function") e.addEventListener(t, function i(a) {
			r.once && e.removeEventListener(t, i), n(a);
		});
		else throw TypeError("The \"emitter\" argument must be of type EventEmitter. Received type " + typeof e);
	}
	return Ti.exports;
}
var Oi = Di(), ki = /*@__PURE__*/ ai(Oi), Ai = !0, ji = !0;
function Mi(e, t, n) {
	let r = e.match(t);
	return r && r.length >= n && parseFloat(r[n], 10);
}
function Ni(e, t, n) {
	if (!e.RTCPeerConnection) return;
	if (!Object.getOwnPropertyDescriptor(EventTarget.prototype, "addEventListener").writable) {
		Ii("Unable to polyfill events");
		return;
	}
	let r = e.RTCPeerConnection.prototype, i = r.addEventListener;
	r.addEventListener = function(e, r) {
		if (e !== t) return i.apply(this, arguments);
		let a = (e) => {
			let t = n(e);
			t && (r.handleEvent ? r.handleEvent(t) : r(t));
		};
		return this._eventMap = this._eventMap || {}, this._eventMap[t] || (this._eventMap[t] = /* @__PURE__ */ new Map()), this._eventMap[t].set(r, a), i.apply(this, [e, a]);
	};
	let a = r.removeEventListener;
	r.removeEventListener = function(e, n) {
		if (e !== t || !this._eventMap || !this._eventMap[t] || !this._eventMap[t].has(n)) return a.apply(this, arguments);
		let r = this._eventMap[t].get(n);
		return this._eventMap[t].delete(n), this._eventMap[t].size === 0 && delete this._eventMap[t], Object.keys(this._eventMap).length === 0 && delete this._eventMap, a.apply(this, [e, r]);
	}, Object.defineProperty(r, "on" + t, {
		get() {
			return this["_on" + t];
		},
		set(e) {
			this["_on" + t] && (this.removeEventListener(t, this["_on" + t]), delete this["_on" + t]), e && this.addEventListener(t, this["_on" + t] = e);
		},
		enumerable: !0,
		configurable: !0
	});
}
function Pi(e) {
	return typeof e == "boolean" ? (Ai = e, e ? "adapter.js logging disabled" : "adapter.js logging enabled") : /* @__PURE__ */ Error("Argument type: " + typeof e + ". Please use a boolean.");
}
function Fi(e) {
	return typeof e == "boolean" ? (ji = !e, "adapter.js deprecation warnings " + (e ? "disabled" : "enabled")) : /* @__PURE__ */ Error("Argument type: " + typeof e + ". Please use a boolean.");
}
function Ii() {
	if (typeof window == "object") {
		if (Ai) return;
		typeof console < "u" && typeof console.log == "function" && console.log.apply(console, arguments);
	}
}
function Li(e, t) {
	ji && console.warn(e + " is deprecated, please use " + t + " instead.");
}
function Ri(e) {
	let t = {
		browser: null,
		version: null
	};
	if (e === void 0 || !e.navigator || !e.navigator.userAgent) return t.browser = "Not a browser.", t;
	let n = e.navigator;
	if (n.userAgentData && n.userAgentData.brands) {
		let e = n.userAgentData.brands.find((e) => e.brand === "Chromium");
		if (e) return {
			browser: "chrome",
			version: parseInt(e.version, 10)
		};
	}
	if (n.mozGetUserMedia) t.browser = "firefox", t.version = parseInt(Mi(n.userAgent, /Firefox\/(\d+)\./, 1));
	else if (n.webkitGetUserMedia || e.isSecureContext === !1 && e.webkitRTCPeerConnection) t.browser = "chrome", t.version = parseInt(Mi(n.userAgent, /Chrom(e|ium)\/(\d+)\./, 2)) || null;
	else if (e.RTCPeerConnection && n.userAgent.match(/AppleWebKit\/(\d+)\./)) t.browser = "safari", t.version = parseInt(Mi(n.userAgent, /AppleWebKit\/(\d+)\./, 1)), t.supportsUnifiedPlan = e.RTCRtpTransceiver && "currentDirection" in e.RTCRtpTransceiver.prototype, t._safariVersion = Mi(n.userAgent, /Version\/(\d+(\.?\d+))/, 1);
	else return t.browser = "Not a supported browser.", t;
	return t;
}
function zi(e) {
	return Object.prototype.toString.call(e) === "[object Object]";
}
function Bi(e) {
	return zi(e) ? Object.keys(e).reduce(function(t, n) {
		let r = zi(e[n]), i = r ? Bi(e[n]) : e[n], a = r && !Object.keys(i).length;
		return i === void 0 || a ? t : Object.assign(t, { [n]: i });
	}, {}) : e;
}
function Vi(e, t, n) {
	!t || n.has(t.id) || (n.set(t.id, t), Object.keys(t).forEach((r) => {
		r.endsWith("Id") ? Vi(e, e.get(t[r]), n) : r.endsWith("Ids") && t[r].forEach((t) => {
			Vi(e, e.get(t), n);
		});
	}));
}
function Hi(e, t, n) {
	let r = n ? "outbound-rtp" : "inbound-rtp", i = /* @__PURE__ */ new Map();
	if (t === null) return i;
	let a = [];
	return e.forEach((e) => {
		e.type === "track" && e.trackIdentifier === t.id && a.push(e);
	}), a.forEach((t) => {
		e.forEach((n) => {
			n.type === r && n.trackId === t.id && Vi(e, n, i);
		});
	}), i;
}
var Ui = Ii;
function Wi(e, t) {
	let n = e && e.navigator;
	if (!n.mediaDevices) return;
	let r = function(e) {
		if (typeof e != "object" || e.mandatory || e.optional) return e;
		let t = {};
		return Object.keys(e).forEach((n) => {
			if (n === "require" || n === "advanced" || n === "mediaSource") return;
			let r = typeof e[n] == "object" ? e[n] : { ideal: e[n] };
			r.exact !== void 0 && typeof r.exact == "number" && (r.min = r.max = r.exact);
			let i = function(e, t) {
				return e ? e + t.charAt(0).toUpperCase() + t.slice(1) : t === "deviceId" ? "sourceId" : t;
			};
			if (r.ideal !== void 0) {
				t.optional = t.optional || [];
				let e = {};
				typeof r.ideal == "number" ? (e[i("min", n)] = r.ideal, t.optional.push(e), e = {}, e[i("max", n)] = r.ideal, t.optional.push(e)) : (e[i("", n)] = r.ideal, t.optional.push(e));
			}
			r.exact !== void 0 && typeof r.exact != "number" ? (t.mandatory = t.mandatory || {}, t.mandatory[i("", n)] = r.exact) : ["min", "max"].forEach((e) => {
				r[e] !== void 0 && (t.mandatory = t.mandatory || {}, t.mandatory[i(e, n)] = r[e]);
			});
		}), e.advanced && (t.optional = (t.optional || []).concat(e.advanced)), t;
	}, i = function(e, i) {
		if (t.version >= 61) return i(e);
		if (e = JSON.parse(JSON.stringify(e)), e && typeof e.audio == "object") {
			let t = function(e, t, n) {
				t in e && !(n in e) && (e[n] = e[t], delete e[t]);
			};
			e = JSON.parse(JSON.stringify(e)), t(e.audio, "autoGainControl", "googAutoGainControl"), t(e.audio, "noiseSuppression", "googNoiseSuppression"), e.audio = r(e.audio);
		}
		if (e && typeof e.video == "object") {
			let a = e.video.facingMode;
			a &&= typeof a == "object" ? a : { ideal: a };
			let o = t.version < 66;
			if (a && (a.exact === "user" || a.exact === "environment" || a.ideal === "user" || a.ideal === "environment") && !(n.mediaDevices.getSupportedConstraints && n.mediaDevices.getSupportedConstraints().facingMode && !o)) {
				delete e.video.facingMode;
				let t;
				if (a.exact === "environment" || a.ideal === "environment" ? t = ["back", "rear"] : (a.exact === "user" || a.ideal === "user") && (t = ["front"]), t) return n.mediaDevices.enumerateDevices().then((n) => {
					n = n.filter((e) => e.kind === "videoinput");
					let o = n.find((e) => t.some((t) => e.label.toLowerCase().includes(t)));
					return !o && n.length && t.includes("back") && (o = n[n.length - 1]), o && (e.video.deviceId = a.exact ? { exact: o.deviceId } : { ideal: o.deviceId }), e.video = r(e.video), Ui("chrome: " + JSON.stringify(e)), i(e);
				});
			}
			e.video = r(e.video);
		}
		return Ui("chrome: " + JSON.stringify(e)), i(e);
	}, a = function(e) {
		return t.version >= 64 ? e : {
			name: {
				PermissionDeniedError: "NotAllowedError",
				PermissionDismissedError: "NotAllowedError",
				InvalidStateError: "NotAllowedError",
				DevicesNotFoundError: "NotFoundError",
				ConstraintNotSatisfiedError: "OverconstrainedError",
				TrackStartError: "NotReadableError",
				MediaDeviceFailedDueToShutdown: "NotAllowedError",
				MediaDeviceKillSwitchOn: "NotAllowedError",
				TabCaptureError: "AbortError",
				ScreenCaptureError: "AbortError",
				DeviceCaptureError: "AbortError"
			}[e.name] || e.name,
			message: e.message,
			constraint: e.constraint || e.constraintName,
			toString() {
				return this.name + (this.message && ": ") + this.message;
			}
		};
	};
	if (n.getUserMedia = function(e, t, r) {
		i(e, (e) => {
			n.webkitGetUserMedia(e, t, (e) => {
				r && r(a(e));
			});
		});
	}.bind(n), n.mediaDevices.getUserMedia) {
		let e = n.mediaDevices.getUserMedia.bind(n.mediaDevices);
		n.mediaDevices.getUserMedia = function(t) {
			return i(t, (t) => e(t).then((e) => {
				if (t.audio && !e.getAudioTracks().length || t.video && !e.getVideoTracks().length) throw e.getTracks().forEach((e) => {
					e.stop();
				}), new DOMException("", "NotFoundError");
				return e;
			}, (e) => Promise.reject(a(e))));
		};
	}
}
function Gi(e) {
	e.MediaStream = e.MediaStream || e.webkitMediaStream;
}
function Ki(e, t) {
	if (!(t.version > 102)) if (typeof e == "object" && e.RTCPeerConnection && !("ontrack" in e.RTCPeerConnection.prototype)) {
		Object.defineProperty(e.RTCPeerConnection.prototype, "ontrack", {
			get() {
				return this._ontrack;
			},
			set(e) {
				this._ontrack && this.removeEventListener("track", this._ontrack), this.addEventListener("track", this._ontrack = e);
			},
			enumerable: !0,
			configurable: !0
		});
		let t = e.RTCPeerConnection.prototype.setRemoteDescription;
		e.RTCPeerConnection.prototype.setRemoteDescription = function() {
			return this._ontrackpoly || (this._ontrackpoly = (t) => {
				t.stream.addEventListener("addtrack", (n) => {
					let r;
					r = e.RTCPeerConnection.prototype.getReceivers ? this.getReceivers().find((e) => e.track && e.track.id === n.track.id) : { track: n.track };
					let i = new Event("track");
					i.track = n.track, i.receiver = r, i.transceiver = { receiver: r }, i.streams = [t.stream], this.dispatchEvent(i);
				}), t.stream.getTracks().forEach((n) => {
					let r;
					r = e.RTCPeerConnection.prototype.getReceivers ? this.getReceivers().find((e) => e.track && e.track.id === n.id) : { track: n };
					let i = new Event("track");
					i.track = n, i.receiver = r, i.transceiver = { receiver: r }, i.streams = [t.stream], this.dispatchEvent(i);
				});
			}, this.addEventListener("addstream", this._ontrackpoly)), t.apply(this, arguments);
		};
	} else Ni(e, "track", (e) => (e.transceiver || Object.defineProperty(e, "transceiver", { value: { receiver: e.receiver } }), e));
}
function qi(e) {
	if (typeof e == "object" && e.RTCPeerConnection && !("getSenders" in e.RTCPeerConnection.prototype) && "createDTMFSender" in e.RTCPeerConnection.prototype) {
		let t = function(e, t) {
			return {
				track: t,
				get dtmf() {
					return this._dtmf === void 0 && (t.kind === "audio" ? this._dtmf = e.createDTMFSender(t) : this._dtmf = null), this._dtmf;
				},
				_pc: e
			};
		};
		if (!e.RTCPeerConnection.prototype.getSenders) {
			e.RTCPeerConnection.prototype.getSenders = function() {
				return this._senders = this._senders || [], this._senders.slice();
			};
			let n = e.RTCPeerConnection.prototype.addTrack;
			e.RTCPeerConnection.prototype.addTrack = function(e, r) {
				let i = n.apply(this, arguments);
				return i || (i = t(this, e), this._senders.push(i)), i;
			};
			let r = e.RTCPeerConnection.prototype.removeTrack;
			e.RTCPeerConnection.prototype.removeTrack = function(e) {
				r.apply(this, arguments);
				let t = this._senders.indexOf(e);
				t !== -1 && this._senders.splice(t, 1);
			};
		}
		let n = e.RTCPeerConnection.prototype.addStream;
		e.RTCPeerConnection.prototype.addStream = function(e) {
			this._senders = this._senders || [], n.apply(this, [e]), e.getTracks().forEach((e) => {
				this._senders.push(t(this, e));
			});
		};
		let r = e.RTCPeerConnection.prototype.removeStream;
		e.RTCPeerConnection.prototype.removeStream = function(e) {
			this._senders = this._senders || [], r.apply(this, [e]), e.getTracks().forEach((e) => {
				let t = this._senders.find((t) => t.track === e);
				t && this._senders.splice(this._senders.indexOf(t), 1);
			});
		};
	} else if (typeof e == "object" && e.RTCPeerConnection && "getSenders" in e.RTCPeerConnection.prototype && "createDTMFSender" in e.RTCPeerConnection.prototype && e.RTCRtpSender && !("dtmf" in e.RTCRtpSender.prototype)) {
		let t = e.RTCPeerConnection.prototype.getSenders;
		e.RTCPeerConnection.prototype.getSenders = function() {
			let e = t.apply(this, []);
			return e.forEach((e) => e._pc = this), e;
		}, Object.defineProperty(e.RTCRtpSender.prototype, "dtmf", { get() {
			return this._dtmf === void 0 && (this.track.kind === "audio" ? this._dtmf = this._pc.createDTMFSender(this.track) : this._dtmf = null), this._dtmf;
		} });
	}
}
function Ji(e, t) {
	if (t.version >= 67 || !(typeof e == "object" && e.RTCPeerConnection && e.RTCRtpSender && e.RTCRtpReceiver)) return;
	if (!("getStats" in e.RTCRtpSender.prototype)) {
		let t = e.RTCPeerConnection.prototype.getSenders;
		t && (e.RTCPeerConnection.prototype.getSenders = function() {
			let e = t.apply(this, []);
			return e.forEach((e) => e._pc = this), e;
		});
		let n = e.RTCPeerConnection.prototype.addTrack;
		n && (e.RTCPeerConnection.prototype.addTrack = function() {
			let e = n.apply(this, arguments);
			return e._pc = this, e;
		}), e.RTCRtpSender.prototype.getStats = function() {
			let e = this;
			return this._pc.getStats().then((t) => Hi(t, e.track, !0));
		};
	}
	if (!("getStats" in e.RTCRtpReceiver.prototype)) {
		let t = e.RTCPeerConnection.prototype.getReceivers;
		t && (e.RTCPeerConnection.prototype.getReceivers = function() {
			let e = t.apply(this, []);
			return e.forEach((e) => e._pc = this), e;
		}), Ni(e, "track", (e) => (e.receiver._pc = e.srcElement, e)), e.RTCRtpReceiver.prototype.getStats = function() {
			let e = this;
			return this._pc.getStats().then((t) => Hi(t, e.track, !1));
		};
	}
	if (!("getStats" in e.RTCRtpSender.prototype && "getStats" in e.RTCRtpReceiver.prototype)) return;
	let n = e.RTCPeerConnection.prototype.getStats;
	e.RTCPeerConnection.prototype.getStats = function() {
		if (arguments.length > 0 && arguments[0] instanceof e.MediaStreamTrack) {
			let e = arguments[0], t, n, r;
			return this.getSenders().forEach((n) => {
				n.track === e && (t ? r = !0 : t = n);
			}), this.getReceivers().forEach((t) => (t.track === e && (n ? r = !0 : n = t), t.track === e)), r || t && n ? Promise.reject(new DOMException("There are more than one sender or receiver for the track.", "InvalidAccessError")) : t ? t.getStats() : n ? n.getStats() : Promise.reject(new DOMException("There is no sender or receiver for the track.", "InvalidAccessError"));
		}
		return n.apply(this, arguments);
	};
}
function Yi(e) {
	e.RTCPeerConnection.prototype.getLocalStreams = function() {
		return this._shimmedLocalStreams = this._shimmedLocalStreams || {}, Object.keys(this._shimmedLocalStreams).map((e) => this._shimmedLocalStreams[e][0]);
	};
	let t = e.RTCPeerConnection.prototype.addTrack;
	e.RTCPeerConnection.prototype.addTrack = function(e, n) {
		if (!n) return t.apply(this, arguments);
		this._shimmedLocalStreams = this._shimmedLocalStreams || {};
		let r = t.apply(this, arguments);
		return this._shimmedLocalStreams[n.id] ? this._shimmedLocalStreams[n.id].indexOf(r) === -1 && this._shimmedLocalStreams[n.id].push(r) : this._shimmedLocalStreams[n.id] = [n, r], r;
	};
	let n = e.RTCPeerConnection.prototype.addStream;
	e.RTCPeerConnection.prototype.addStream = function(e) {
		this._shimmedLocalStreams = this._shimmedLocalStreams || {}, e.getTracks().forEach((e) => {
			if (this.getSenders().find((t) => t.track === e)) throw new DOMException("Track already exists.", "InvalidAccessError");
		});
		let t = this.getSenders();
		n.apply(this, arguments);
		let r = this.getSenders().filter((e) => t.indexOf(e) === -1);
		this._shimmedLocalStreams[e.id] = [e].concat(r);
	};
	let r = e.RTCPeerConnection.prototype.removeStream;
	e.RTCPeerConnection.prototype.removeStream = function(e) {
		return this._shimmedLocalStreams = this._shimmedLocalStreams || {}, delete this._shimmedLocalStreams[e.id], r.apply(this, arguments);
	};
	let i = e.RTCPeerConnection.prototype.removeTrack;
	e.RTCPeerConnection.prototype.removeTrack = function(e) {
		return this._shimmedLocalStreams = this._shimmedLocalStreams || {}, e && Object.keys(this._shimmedLocalStreams).forEach((t) => {
			let n = this._shimmedLocalStreams[t].indexOf(e);
			n !== -1 && this._shimmedLocalStreams[t].splice(n, 1), this._shimmedLocalStreams[t].length === 1 && delete this._shimmedLocalStreams[t];
		}), i.apply(this, arguments);
	};
}
function Xi(e, t) {
	if (!e.RTCPeerConnection) return;
	if (e.RTCPeerConnection.prototype.addTrack && t.version >= 65) return Yi(e);
	let n = e.RTCPeerConnection.prototype.getLocalStreams;
	e.RTCPeerConnection.prototype.getLocalStreams = function() {
		let e = n.apply(this);
		return this._reverseStreams = this._reverseStreams || {}, e.map((e) => this._reverseStreams[e.id]);
	};
	let r = e.RTCPeerConnection.prototype.addStream;
	e.RTCPeerConnection.prototype.addStream = function(t) {
		if (this._streams = this._streams || {}, this._reverseStreams = this._reverseStreams || {}, t.getTracks().forEach((e) => {
			if (this.getSenders().find((t) => t.track === e)) throw new DOMException("Track already exists.", "InvalidAccessError");
		}), !this._reverseStreams[t.id]) {
			let n = new e.MediaStream(t.getTracks());
			this._streams[t.id] = n, this._reverseStreams[n.id] = t, t = n;
		}
		r.apply(this, [t]);
	};
	let i = e.RTCPeerConnection.prototype.removeStream;
	e.RTCPeerConnection.prototype.removeStream = function(e) {
		this._streams = this._streams || {}, this._reverseStreams = this._reverseStreams || {}, i.apply(this, [this._streams[e.id] || e]), delete this._reverseStreams[this._streams[e.id] ? this._streams[e.id].id : e.id], delete this._streams[e.id];
	}, e.RTCPeerConnection.prototype.addTrack = function(t, n) {
		if (this.signalingState === "closed") throw new DOMException("The RTCPeerConnection's signalingState is 'closed'.", "InvalidStateError");
		let r = [].slice.call(arguments, 1);
		if (r.length !== 1 || !r[0].getTracks().find((e) => e === t)) throw new DOMException("The adapter.js addTrack polyfill only supports a single  stream which is associated with the specified track.", "NotSupportedError");
		if (this.getSenders().find((e) => e.track === t)) throw new DOMException("Track already exists.", "InvalidAccessError");
		this._streams = this._streams || {}, this._reverseStreams = this._reverseStreams || {};
		let i = this._streams[n.id];
		if (i) i.addTrack(t), Promise.resolve().then(() => {
			this.dispatchEvent(new Event("negotiationneeded"));
		});
		else {
			let r = new e.MediaStream([t]);
			this._streams[n.id] = r, this._reverseStreams[r.id] = n, this.addStream(r);
		}
		return this.getSenders().find((e) => e.track === t);
	};
	function a(e, t) {
		let n = t.sdp;
		return Object.keys(e._reverseStreams || []).forEach((t) => {
			let r = e._reverseStreams[t], i = e._streams[r.id];
			n = n.replace(new RegExp(i.id, "g"), r.id);
		}), new RTCSessionDescription({
			type: t.type,
			sdp: n
		});
	}
	function o(e, t) {
		let n = t.sdp;
		return Object.keys(e._reverseStreams || []).forEach((t) => {
			let r = e._reverseStreams[t], i = e._streams[r.id];
			n = n.replace(new RegExp(r.id, "g"), i.id);
		}), new RTCSessionDescription({
			type: t.type,
			sdp: n
		});
	}
	["createOffer", "createAnswer"].forEach(function(t) {
		let n = e.RTCPeerConnection.prototype[t], r = { [t]() {
			let e = arguments;
			return arguments.length && typeof arguments[0] == "function" ? n.apply(this, [
				(t) => {
					let n = a(this, t);
					e[0].apply(null, [n]);
				},
				(t) => {
					e[1] && e[1].apply(null, t);
				},
				arguments[2]
			]) : n.apply(this, arguments).then((e) => a(this, e));
		} };
		e.RTCPeerConnection.prototype[t] = r[t];
	});
	let s = e.RTCPeerConnection.prototype.setLocalDescription;
	e.RTCPeerConnection.prototype.setLocalDescription = function() {
		return !arguments.length || !arguments[0].type || (arguments[0] = o(this, arguments[0])), s.apply(this, arguments);
	};
	let c = Object.getOwnPropertyDescriptor(e.RTCPeerConnection.prototype, "localDescription");
	Object.defineProperty(e.RTCPeerConnection.prototype, "localDescription", { get() {
		let e = c.get.apply(this);
		return e.type === "" ? e : a(this, e);
	} }), e.RTCPeerConnection.prototype.removeTrack = function(e) {
		if (this.signalingState === "closed") throw new DOMException("The RTCPeerConnection's signalingState is 'closed'.", "InvalidStateError");
		if (!e._pc) throw new DOMException("Argument 1 of RTCPeerConnection.removeTrack does not implement interface RTCRtpSender.", "TypeError");
		if (e._pc !== this) throw new DOMException("Sender was not created by this connection.", "InvalidAccessError");
		this._streams = this._streams || {};
		let t;
		Object.keys(this._streams).forEach((n) => {
			this._streams[n].getTracks().find((t) => e.track === t) && (t = this._streams[n]);
		}), t && (t.getTracks().length === 1 ? this.removeStream(this._reverseStreams[t.id]) : t.removeTrack(e.track), this.dispatchEvent(new Event("negotiationneeded")));
	};
}
function Zi(e, t) {
	!e.RTCPeerConnection && e.webkitRTCPeerConnection && (e.RTCPeerConnection = e.webkitRTCPeerConnection), e.RTCPeerConnection && t.version < 53 && [
		"setLocalDescription",
		"setRemoteDescription",
		"addIceCandidate"
	].forEach(function(t) {
		let n = e.RTCPeerConnection.prototype[t], r = { [t]() {
			return arguments[0] = new (t === "addIceCandidate" ? e.RTCIceCandidate : e.RTCSessionDescription)(arguments[0]), n.apply(this, arguments);
		} };
		e.RTCPeerConnection.prototype[t] = r[t];
	});
}
function Qi(e, t) {
	t.version > 102 || Ni(e, "negotiationneeded", (e) => {
		let n = e.target;
		if (!((t.version < 72 || n.getConfiguration && n.getConfiguration().sdpSemantics === "plan-b") && n.signalingState !== "stable")) return e;
	});
}
var $i = /*#__PURE__*/ Object.freeze({
	__proto__: null,
	fixNegotiationNeeded: Qi,
	shimAddTrackRemoveTrack: Xi,
	shimAddTrackRemoveTrackWithNative: Yi,
	shimGetSendersWithDtmf: qi,
	shimGetUserMedia: Wi,
	shimMediaStream: Gi,
	shimOnTrack: Ki,
	shimPeerConnection: Zi,
	shimSenderReceiverGetStats: Ji
});
function ea(e, t) {
	let n = e && e.navigator, r = e && e.MediaStreamTrack;
	if (n.getUserMedia = function(e, t, r) {
		Li("navigator.getUserMedia", "navigator.mediaDevices.getUserMedia"), n.mediaDevices.getUserMedia(e).then(t, r);
	}, !(t.version > 55 && "autoGainControl" in n.mediaDevices.getSupportedConstraints())) {
		let e = function(e, t, n) {
			t in e && !(n in e) && (e[n] = e[t], delete e[t]);
		}, t = n.mediaDevices.getUserMedia.bind(n.mediaDevices);
		if (n.mediaDevices.getUserMedia = function(n) {
			return typeof n == "object" && typeof n.audio == "object" && (n = JSON.parse(JSON.stringify(n)), e(n.audio, "autoGainControl", "mozAutoGainControl"), e(n.audio, "noiseSuppression", "mozNoiseSuppression")), t(n);
		}, r && r.prototype.getSettings) {
			let t = r.prototype.getSettings;
			r.prototype.getSettings = function() {
				let n = t.apply(this, arguments);
				return e(n, "mozAutoGainControl", "autoGainControl"), e(n, "mozNoiseSuppression", "noiseSuppression"), n;
			};
		}
		if (r && r.prototype.applyConstraints) {
			let t = r.prototype.applyConstraints;
			r.prototype.applyConstraints = function(n) {
				return this.kind === "audio" && typeof n == "object" && (n = JSON.parse(JSON.stringify(n)), e(n, "autoGainControl", "mozAutoGainControl"), e(n, "noiseSuppression", "mozNoiseSuppression")), t.apply(this, [n]);
			};
		}
	}
}
function ta(e, t) {
	e.navigator.mediaDevices && "getDisplayMedia" in e.navigator.mediaDevices || e.navigator.mediaDevices && (e.navigator.mediaDevices.getDisplayMedia = function(n) {
		if (!(n && n.video)) {
			let e = new DOMException("getDisplayMedia without video constraints is undefined");
			return e.name = "NotFoundError", e.code = 8, Promise.reject(e);
		}
		return n.video === !0 ? n.video = { mediaSource: t } : n.video.mediaSource = t, e.navigator.mediaDevices.getUserMedia(n);
	});
}
function na(e) {
	typeof e == "object" && e.RTCTrackEvent && "receiver" in e.RTCTrackEvent.prototype && !("transceiver" in e.RTCTrackEvent.prototype) && Object.defineProperty(e.RTCTrackEvent.prototype, "transceiver", { get() {
		return { receiver: this.receiver };
	} });
}
function ra(e, t) {
	typeof e != "object" || !(e.RTCPeerConnection || e.mozRTCPeerConnection) || (!e.RTCPeerConnection && e.mozRTCPeerConnection && (e.RTCPeerConnection = e.mozRTCPeerConnection), t.version < 53 && [
		"setLocalDescription",
		"setRemoteDescription",
		"addIceCandidate"
	].forEach(function(t) {
		let n = e.RTCPeerConnection.prototype[t], r = { [t]() {
			return arguments[0] = new (t === "addIceCandidate" ? e.RTCIceCandidate : e.RTCSessionDescription)(arguments[0]), n.apply(this, arguments);
		} };
		e.RTCPeerConnection.prototype[t] = r[t];
	}));
}
function ia(e, t) {
	if (typeof e != "object" || !(e.RTCPeerConnection || e.mozRTCPeerConnection) || t.version >= 151) return;
	let n = {
		inboundrtp: "inbound-rtp",
		outboundrtp: "outbound-rtp",
		candidatepair: "candidate-pair",
		localcandidate: "local-candidate",
		remotecandidate: "remote-candidate"
	}, r = e.RTCPeerConnection.prototype.getStats;
	e.RTCPeerConnection.prototype.getStats = function() {
		let e = Array.prototype.slice.call(arguments), i = e[0], a = e[1], o = e[2];
		return this.signalingState === "closed" ? Promise.resolve(/* @__PURE__ */ new Map()) : r.apply(this, [i || null]).then((e) => {
			if (t.version < 53 && !a) try {
				e.forEach((e) => {
					e.type = n[e.type] || e.type;
				});
			} catch (t) {
				if (t.name !== "TypeError") throw t;
				e.forEach((t, r) => {
					e.set(r, Object.assign({}, t, { type: n[t.type] || t.type }));
				});
			}
			return e;
		}).then(a, o);
	};
}
function aa(e) {
	if (!(typeof e == "object" && e.RTCPeerConnection && e.RTCRtpSender) || e.RTCRtpSender && "getStats" in e.RTCRtpSender.prototype) return;
	let t = e.RTCPeerConnection.prototype.getSenders;
	t && (e.RTCPeerConnection.prototype.getSenders = function() {
		let e = t.apply(this, []);
		return e.forEach((e) => e._pc = this), e;
	});
	let n = e.RTCPeerConnection.prototype.addTrack;
	n && (e.RTCPeerConnection.prototype.addTrack = function() {
		let e = n.apply(this, arguments);
		return e._pc = this, e;
	}), e.RTCRtpSender.prototype.getStats = function() {
		return this.track ? this._pc.getStats(this.track) : Promise.resolve(/* @__PURE__ */ new Map());
	};
}
function oa(e) {
	if (!(typeof e == "object" && e.RTCPeerConnection && e.RTCRtpSender) || e.RTCRtpSender && "getStats" in e.RTCRtpReceiver.prototype) return;
	let t = e.RTCPeerConnection.prototype.getReceivers;
	t && (e.RTCPeerConnection.prototype.getReceivers = function() {
		let e = t.apply(this, []);
		return e.forEach((e) => e._pc = this), e;
	}), Ni(e, "track", (e) => (e.receiver._pc = e.srcElement, e)), e.RTCRtpReceiver.prototype.getStats = function() {
		return this._pc.getStats(this.track);
	};
}
function sa(e) {
	!e.RTCPeerConnection || "removeStream" in e.RTCPeerConnection.prototype || (e.RTCPeerConnection.prototype.removeStream = function(e) {
		Li("removeStream", "removeTrack"), this.getSenders().forEach((t) => {
			t.track && e.getTracks().includes(t.track) && this.removeTrack(t);
		});
	});
}
function ca(e) {
	e.DataChannel && !e.RTCDataChannel && (e.RTCDataChannel = e.DataChannel);
}
function la(e) {
	if (!(typeof e == "object" && e.RTCPeerConnection)) return;
	let t = e.RTCPeerConnection.prototype.addTransceiver;
	t && (e.RTCPeerConnection.prototype.addTransceiver = function() {
		this.setParametersPromises = [];
		let e = arguments[1] && arguments[1].sendEncodings;
		e === void 0 && (e = []), e = [...e];
		let n = e.length > 0;
		n && e.forEach((e) => {
			if ("rid" in e && !/^[a-z0-9]{0,16}$/i.test(e.rid)) throw TypeError("Invalid RID value provided.");
			if ("scaleResolutionDownBy" in e && !(parseFloat(e.scaleResolutionDownBy) >= 1)) throw RangeError("scale_resolution_down_by must be >= 1.0");
			if ("maxFramerate" in e && !(parseFloat(e.maxFramerate) >= 0)) throw RangeError("max_framerate must be >= 0.0");
		});
		let r = t.apply(this, arguments);
		if (n) {
			let t = r.sender, n = t.getParameters();
			(!("encodings" in n) || n.encodings.length === 1 && Object.keys(n.encodings[0]).length === 0) && (n.encodings = e, t.sendEncodings = e, this.setParametersPromises.push(t.setParameters(n).then(() => {
				delete t.sendEncodings;
			}).catch(() => {
				delete t.sendEncodings;
			})));
		}
		return r;
	});
}
function ua(e) {
	if (!(typeof e == "object" && e.RTCRtpSender)) return;
	let t = e.RTCRtpSender.prototype.getParameters;
	t && (e.RTCRtpSender.prototype.getParameters = function() {
		let e = t.apply(this, arguments);
		return "encodings" in e || (e.encodings = [].concat(this.sendEncodings || [{}])), e;
	});
}
function da(e) {
	if (!(typeof e == "object" && e.RTCPeerConnection)) return;
	let t = e.RTCPeerConnection.prototype.createOffer;
	e.RTCPeerConnection.prototype.createOffer = function() {
		return this.setParametersPromises && this.setParametersPromises.length ? Promise.all(this.setParametersPromises).then(() => t.apply(this, arguments)).finally(() => {
			this.setParametersPromises = [];
		}) : t.apply(this, arguments);
	};
}
function fa(e) {
	if (!(typeof e == "object" && e.RTCPeerConnection)) return;
	let t = e.RTCPeerConnection.prototype.createAnswer;
	e.RTCPeerConnection.prototype.createAnswer = function() {
		return this.setParametersPromises && this.setParametersPromises.length ? Promise.all(this.setParametersPromises).then(() => t.apply(this, arguments)).finally(() => {
			this.setParametersPromises = [];
		}) : t.apply(this, arguments);
	};
}
var pa = /*#__PURE__*/ Object.freeze({
	__proto__: null,
	shimAddTransceiver: la,
	shimCreateAnswer: fa,
	shimCreateOffer: da,
	shimGetDisplayMedia: ta,
	shimGetParameters: ua,
	shimGetStats: ia,
	shimGetUserMedia: ea,
	shimOnTrack: na,
	shimPeerConnection: ra,
	shimRTCDataChannel: ca,
	shimReceiverGetStats: oa,
	shimRemoveStream: sa,
	shimSenderGetStats: aa
});
function ma(e) {
	if (!(typeof e != "object" || !e.RTCPeerConnection)) {
		if ("getLocalStreams" in e.RTCPeerConnection.prototype || (e.RTCPeerConnection.prototype.getLocalStreams = function() {
			return this._localStreams ||= [], this._localStreams;
		}), !("addStream" in e.RTCPeerConnection.prototype)) {
			let t = e.RTCPeerConnection.prototype.addTrack;
			e.RTCPeerConnection.prototype.addStream = function(e) {
				this._localStreams ||= [], this._localStreams.includes(e) || this._localStreams.push(e), e.getAudioTracks().forEach((n) => t.call(this, n, e)), e.getVideoTracks().forEach((n) => t.call(this, n, e));
			}, e.RTCPeerConnection.prototype.addTrack = function(e) {
				var n = [...arguments].slice(1);
				return n && n.forEach((e) => {
					this._localStreams ? this._localStreams.includes(e) || this._localStreams.push(e) : this._localStreams = [e];
				}), t.apply(this, arguments);
			};
		}
		"removeStream" in e.RTCPeerConnection.prototype || (e.RTCPeerConnection.prototype.removeStream = function(e) {
			this._localStreams ||= [];
			let t = this._localStreams.indexOf(e);
			if (t === -1) return;
			this._localStreams.splice(t, 1);
			let n = e.getTracks();
			this.getSenders().forEach((e) => {
				n.includes(e.track) && this.removeTrack(e);
			});
		});
	}
}
function ha(e) {
	if (!(typeof e != "object" || !e.RTCPeerConnection) && ("getRemoteStreams" in e.RTCPeerConnection.prototype || (e.RTCPeerConnection.prototype.getRemoteStreams = function() {
		return this._remoteStreams ? this._remoteStreams : [];
	}), !("onaddstream" in e.RTCPeerConnection.prototype))) {
		Object.defineProperty(e.RTCPeerConnection.prototype, "onaddstream", {
			get() {
				return this._onaddstream;
			},
			set(e) {
				this._onaddstream && (this.removeEventListener("addstream", this._onaddstream), this.removeEventListener("track", this._onaddstreampoly)), this.addEventListener("addstream", this._onaddstream = e), this.addEventListener("track", this._onaddstreampoly = (e) => {
					e.streams.forEach((e) => {
						if (this._remoteStreams ||= [], this._remoteStreams.includes(e)) return;
						this._remoteStreams.push(e);
						let t = new Event("addstream");
						t.stream = e, this.dispatchEvent(t);
					});
				});
			}
		});
		let t = e.RTCPeerConnection.prototype.setRemoteDescription;
		e.RTCPeerConnection.prototype.setRemoteDescription = function() {
			let e = this;
			return this._onaddstreampoly || this.addEventListener("track", this._onaddstreampoly = function(t) {
				t.streams.forEach((t) => {
					if (e._remoteStreams ||= [], e._remoteStreams.indexOf(t) >= 0) return;
					e._remoteStreams.push(t);
					let n = new Event("addstream");
					n.stream = t, e.dispatchEvent(n);
				});
			}), t.apply(e, arguments);
		};
	}
}
function ga(e) {
	if (typeof e != "object" || !e.RTCPeerConnection) return;
	let t = e.RTCPeerConnection.prototype, n = t.createOffer, r = t.createAnswer, i = t.setLocalDescription, a = t.setRemoteDescription, o = t.addIceCandidate;
	t.createOffer = function(e, t) {
		let r = arguments.length >= 2 ? arguments[2] : arguments[0], i = n.apply(this, [r]);
		return t ? (i.then(e, t), Promise.resolve()) : i;
	}, t.createAnswer = function(e, t) {
		let n = arguments.length >= 2 ? arguments[2] : arguments[0], i = r.apply(this, [n]);
		return t ? (i.then(e, t), Promise.resolve()) : i;
	};
	let s = function(e, t, n) {
		let r = i.apply(this, [e]);
		return n ? (r.then(t, n), Promise.resolve()) : r;
	};
	t.setLocalDescription = s, s = function(e, t, n) {
		let r = a.apply(this, [e]);
		return n ? (r.then(t, n), Promise.resolve()) : r;
	}, t.setRemoteDescription = s, s = function(e, t, n) {
		let r = o.apply(this, [e]);
		return n ? (r.then(t, n), Promise.resolve()) : r;
	}, t.addIceCandidate = s;
}
function _a(e) {
	let t = e && e.navigator;
	if (t.mediaDevices && t.mediaDevices.getUserMedia) {
		let e = t.mediaDevices, n = e.getUserMedia.bind(e);
		t.mediaDevices.getUserMedia = (e) => n(va(e));
	}
	!t.getUserMedia && t.mediaDevices && t.mediaDevices.getUserMedia && (t.getUserMedia = function(e, n, r) {
		t.mediaDevices.getUserMedia(e).then(n, r);
	}.bind(t));
}
function va(e) {
	return e && e.video !== void 0 ? Object.assign({}, e, { video: Bi(e.video) }) : e;
}
function ya(e) {
	if (!e.RTCPeerConnection) return;
	let t = e.RTCPeerConnection;
	e.RTCPeerConnection = function(e, n) {
		if (e && e.iceServers) {
			let t = [];
			for (let n = 0; n < e.iceServers.length; n++) {
				let r = e.iceServers[n];
				r.urls === void 0 && r.url ? (Li("RTCIceServer.url", "RTCIceServer.urls"), r = JSON.parse(JSON.stringify(r)), r.urls = r.url, delete r.url, t.push(r)) : t.push(e.iceServers[n]);
			}
			e.iceServers = t;
		}
		return new t(e, n);
	}, e.RTCPeerConnection.prototype = t.prototype, "generateCertificate" in t && Object.defineProperty(e.RTCPeerConnection, "generateCertificate", { get() {
		return t.generateCertificate;
	} });
}
function ba(e) {
	typeof e == "object" && e.RTCTrackEvent && "receiver" in e.RTCTrackEvent.prototype && !("transceiver" in e.RTCTrackEvent.prototype) && Object.defineProperty(e.RTCTrackEvent.prototype, "transceiver", { get() {
		return { receiver: this.receiver };
	} });
}
function xa(e) {
	let t = e.RTCPeerConnection.prototype.createOffer;
	e.RTCPeerConnection.prototype.createOffer = function(e) {
		if (e) {
			e.offerToReceiveAudio !== void 0 && (e.offerToReceiveAudio = !!e.offerToReceiveAudio);
			let t = this.getTransceivers().find((e) => e.receiver.track.kind === "audio");
			e.offerToReceiveAudio === !1 && t ? t.direction === "sendrecv" ? t.setDirection ? t.setDirection("sendonly") : t.direction = "sendonly" : t.direction === "recvonly" && (t.setDirection ? t.setDirection("inactive") : t.direction = "inactive") : e.offerToReceiveAudio === !0 && !t && this.addTransceiver("audio", { direction: "recvonly" }), e.offerToReceiveVideo !== void 0 && (e.offerToReceiveVideo = !!e.offerToReceiveVideo);
			let n = this.getTransceivers().find((e) => e.receiver.track.kind === "video");
			e.offerToReceiveVideo === !1 && n ? n.direction === "sendrecv" ? n.setDirection ? n.setDirection("sendonly") : n.direction = "sendonly" : n.direction === "recvonly" && (n.setDirection ? n.setDirection("inactive") : n.direction = "inactive") : e.offerToReceiveVideo === !0 && !n && this.addTransceiver("video", { direction: "recvonly" });
		}
		return t.apply(this, arguments);
	};
}
function Sa(e) {
	typeof e != "object" || e.AudioContext || (e.AudioContext = e.webkitAudioContext);
}
var Ca = /*#__PURE__*/ Object.freeze({
	__proto__: null,
	shimAudioContext: Sa,
	shimCallbacksAPI: ga,
	shimConstraints: va,
	shimCreateOfferLegacy: xa,
	shimGetUserMedia: _a,
	shimLocalStreamsAPI: ma,
	shimRTCIceServerUrls: ya,
	shimRemoteStreamsAPI: ha,
	shimTrackEventTransceiver: ba
}), wa = { exports: {} }, Ta;
function Ea() {
	return Ta ? wa.exports : (Ta = 1, (function(e) {
		let t = {};
		t.generateIdentifier = function() {
			return Math.random().toString(36).substring(2, 12);
		}, t.localCName = t.generateIdentifier(), t.splitLines = function(e) {
			return e.trim().split("\n").map((e) => e.trim());
		}, t.splitSections = function(e) {
			return e.split("\nm=").map((e, t) => (t > 0 ? "m=" + e : e).trim() + "\r\n");
		}, t.getDescription = function(e) {
			let n = t.splitSections(e);
			return n && n[0];
		}, t.getMediaSections = function(e) {
			let n = t.splitSections(e);
			return n.shift(), n;
		}, t.matchPrefix = function(e, n) {
			return t.splitLines(e).filter((e) => e.indexOf(n) === 0);
		}, t.parseCandidate = function(e) {
			let t;
			t = e.indexOf("a=candidate:") === 0 ? e.substring(12).split(" ") : e.substring(10).split(" ");
			let n = {
				foundation: t[0],
				component: {
					1: "rtp",
					2: "rtcp"
				}[t[1]] || t[1],
				protocol: t[2].toLowerCase(),
				priority: parseInt(t[3], 10),
				ip: t[4],
				address: t[4],
				port: parseInt(t[5], 10),
				type: t[7]
			};
			for (let e = 8; e < t.length; e += 2) switch (t[e]) {
				case "raddr":
					n.relatedAddress = t[e + 1];
					break;
				case "rport":
					n.relatedPort = parseInt(t[e + 1], 10);
					break;
				case "tcptype":
					n.tcpType = t[e + 1];
					break;
				case "ufrag":
					n.ufrag = t[e + 1], n.usernameFragment = t[e + 1];
					break;
				default:
					n[t[e]] === void 0 && (n[t[e]] = t[e + 1]);
					break;
			}
			return n;
		}, t.writeCandidate = function(e) {
			let t = [];
			t.push(e.foundation);
			let n = e.component;
			n === "rtp" ? t.push(1) : n === "rtcp" ? t.push(2) : t.push(n), t.push(e.protocol.toUpperCase()), t.push(e.priority), t.push(e.address || e.ip), t.push(e.port);
			let r = e.type;
			return t.push("typ"), t.push(r), r !== "host" && e.relatedAddress && e.relatedPort !== void 0 && (t.push("raddr"), t.push(e.relatedAddress), t.push("rport"), t.push(e.relatedPort)), e.tcpType && e.protocol.toLowerCase() === "tcp" && (t.push("tcptype"), t.push(e.tcpType)), (e.usernameFragment || e.ufrag) && (t.push("ufrag"), t.push(e.usernameFragment || e.ufrag)), "candidate:" + t.join(" ");
		}, t.parseIceOptions = function(e) {
			return e.substring(14).split(" ");
		}, t.parseRtpMap = function(e) {
			let t = e.substring(9).split(" "), n = { payloadType: parseInt(t.shift(), 10) };
			return t = t[0].split("/"), n.name = t[0], n.clockRate = parseInt(t[1], 10), n.channels = t.length === 3 ? parseInt(t[2], 10) : 1, n.numChannels = n.channels, n;
		}, t.writeRtpMap = function(e) {
			let t = e.payloadType;
			e.preferredPayloadType !== void 0 && (t = e.preferredPayloadType);
			let n = e.channels || e.numChannels || 1;
			return "a=rtpmap:" + t + " " + e.name + "/" + e.clockRate + (n === 1 ? "" : "/" + n) + "\r\n";
		}, t.parseExtmap = function(e) {
			let t = e.substring(9).split(" ");
			return {
				id: parseInt(t[0], 10),
				direction: t[0].indexOf("/") > 0 ? t[0].split("/")[1] : "sendrecv",
				uri: t[1],
				attributes: t.slice(2).join(" ")
			};
		}, t.writeExtmap = function(e) {
			return "a=extmap:" + (e.id || e.preferredId) + (e.direction && e.direction !== "sendrecv" ? "/" + e.direction : "") + " " + e.uri + (e.attributes ? " " + e.attributes : "") + "\r\n";
		}, t.parseFmtp = function(e) {
			let t = {}, n, r = e.substring(e.indexOf(" ") + 1).split(";");
			for (let e = 0; e < r.length; e++) n = r[e].trim().split("="), t[n[0].trim()] = n[1];
			return t;
		}, t.writeFmtp = function(e) {
			let t = "", n = e.payloadType;
			if (e.preferredPayloadType !== void 0 && (n = e.preferredPayloadType), e.parameters && Object.keys(e.parameters).length) {
				let r = [];
				Object.keys(e.parameters).forEach((t) => {
					e.parameters[t] === void 0 ? r.push(t) : r.push(t + "=" + e.parameters[t]);
				}), t += "a=fmtp:" + n + " " + r.join(";") + "\r\n";
			}
			return t;
		}, t.parseRtcpFb = function(e) {
			let t = e.substring(e.indexOf(" ") + 1).split(" ");
			return {
				type: t.shift(),
				parameter: t.join(" ")
			};
		}, t.writeRtcpFb = function(e) {
			let t = "", n = e.payloadType;
			return e.preferredPayloadType !== void 0 && (n = e.preferredPayloadType), e.rtcpFeedback && e.rtcpFeedback.length && e.rtcpFeedback.forEach((e) => {
				t += "a=rtcp-fb:" + n + " " + e.type + (e.parameter && e.parameter.length ? " " + e.parameter : "") + "\r\n";
			}), t;
		}, t.parseSsrcMedia = function(e) {
			let t = e.indexOf(" "), n = { ssrc: parseInt(e.substring(7, t), 10) }, r = e.indexOf(":", t);
			return r > -1 ? (n.attribute = e.substring(t + 1, r), n.value = e.substring(r + 1)) : n.attribute = e.substring(t + 1), n;
		}, t.parseSsrcGroup = function(e) {
			let t = e.substring(13).split(" ");
			return {
				semantics: t.shift(),
				ssrcs: t.map((e) => parseInt(e, 10))
			};
		}, t.getMid = function(e) {
			let n = t.matchPrefix(e, "a=mid:")[0];
			if (n) return n.substring(6);
		}, t.parseFingerprint = function(e) {
			let t = e.substring(14).split(" ");
			return {
				algorithm: t[0].toLowerCase(),
				value: t[1].toUpperCase()
			};
		}, t.getDtlsParameters = function(e, n) {
			return {
				role: "auto",
				fingerprints: t.matchPrefix(e + n, "a=fingerprint:").map(t.parseFingerprint)
			};
		}, t.writeDtlsParameters = function(e, t) {
			let n = "a=setup:" + t + "\r\n";
			return e.fingerprints.forEach((e) => {
				n += "a=fingerprint:" + e.algorithm + " " + e.value + "\r\n";
			}), n;
		}, t.parseCryptoLine = function(e) {
			let t = e.substring(9).split(" ");
			return {
				tag: parseInt(t[0], 10),
				cryptoSuite: t[1],
				keyParams: t[2],
				sessionParams: t.slice(3)
			};
		}, t.writeCryptoLine = function(e) {
			return "a=crypto:" + e.tag + " " + e.cryptoSuite + " " + (typeof e.keyParams == "object" ? t.writeCryptoKeyParams(e.keyParams) : e.keyParams) + (e.sessionParams ? " " + e.sessionParams.join(" ") : "") + "\r\n";
		}, t.parseCryptoKeyParams = function(e) {
			if (e.indexOf("inline:") !== 0) return null;
			let t = e.substring(7).split("|");
			return {
				keyMethod: "inline",
				keySalt: t[0],
				lifeTime: t[1],
				mkiValue: t[2] ? t[2].split(":")[0] : void 0,
				mkiLength: t[2] ? t[2].split(":")[1] : void 0
			};
		}, t.writeCryptoKeyParams = function(e) {
			return e.keyMethod + ":" + e.keySalt + (e.lifeTime ? "|" + e.lifeTime : "") + (e.mkiValue && e.mkiLength ? "|" + e.mkiValue + ":" + e.mkiLength : "");
		}, t.getCryptoParameters = function(e, n) {
			return t.matchPrefix(e + n, "a=crypto:").map(t.parseCryptoLine);
		}, t.getIceParameters = function(e, n) {
			let r = t.matchPrefix(e + n, "a=ice-ufrag:")[0], i = t.matchPrefix(e + n, "a=ice-pwd:")[0];
			return r && i ? {
				usernameFragment: r.substring(12),
				password: i.substring(10)
			} : null;
		}, t.writeIceParameters = function(e) {
			let t = "a=ice-ufrag:" + e.usernameFragment + "\r\na=ice-pwd:" + e.password + "\r\n";
			return e.iceLite && (t += "a=ice-lite\r\n"), t;
		}, t.parseRtpParameters = function(e) {
			let n = {
				codecs: [],
				headerExtensions: [],
				fecMechanisms: [],
				rtcp: []
			}, r = t.splitLines(e)[0].split(" ");
			n.profile = r[2];
			for (let i = 3; i < r.length; i++) {
				let a = r[i], o = t.matchPrefix(e, "a=rtpmap:" + a + " ")[0];
				if (o) {
					let r = t.parseRtpMap(o), i = t.matchPrefix(e, "a=fmtp:" + a + " ");
					switch (r.parameters = i.length ? t.parseFmtp(i[0]) : {}, r.rtcpFeedback = t.matchPrefix(e, "a=rtcp-fb:" + a + " ").map(t.parseRtcpFb), n.codecs.push(r), r.name.toUpperCase()) {
						case "RED":
						case "ULPFEC":
							n.fecMechanisms.push(r.name.toUpperCase());
							break;
					}
				}
			}
			t.matchPrefix(e, "a=extmap:").forEach((e) => {
				n.headerExtensions.push(t.parseExtmap(e));
			});
			let i = t.matchPrefix(e, "a=rtcp-fb:* ").map(t.parseRtcpFb);
			return n.codecs.forEach((e) => {
				i.forEach((t) => {
					e.rtcpFeedback.find((e) => e.type === t.type && e.parameter === t.parameter) || e.rtcpFeedback.push(t);
				});
			}), n;
		}, t.writeRtpDescription = function(e, n) {
			let r = "";
			r += "m=" + e + " ", r += n.codecs.length > 0 ? "9" : "0", r += " " + (n.profile || "UDP/TLS/RTP/SAVPF") + " ", r += n.codecs.map((e) => e.preferredPayloadType === void 0 ? e.payloadType : e.preferredPayloadType).join(" ") + "\r\n", r += "c=IN IP4 0.0.0.0\r\n", r += "a=rtcp:9 IN IP4 0.0.0.0\r\n", n.codecs.forEach((e) => {
				r += t.writeRtpMap(e), r += t.writeFmtp(e), r += t.writeRtcpFb(e);
			});
			let i = 0;
			return n.codecs.forEach((e) => {
				e.maxptime > i && (i = e.maxptime);
			}), i > 0 && (r += "a=maxptime:" + i + "\r\n"), n.headerExtensions && n.headerExtensions.forEach((e) => {
				r += t.writeExtmap(e);
			}), r;
		}, t.parseRtpEncodingParameters = function(e) {
			let n = [], r = t.parseRtpParameters(e), i = r.fecMechanisms.indexOf("RED") !== -1, a = r.fecMechanisms.indexOf("ULPFEC") !== -1, o = t.matchPrefix(e, "a=ssrc:").map((e) => t.parseSsrcMedia(e)).filter((e) => e.attribute === "cname"), s = o.length > 0 && o[0].ssrc, c, l = t.matchPrefix(e, "a=ssrc-group:FID").map((e) => e.substring(17).split(" ").map((e) => parseInt(e, 10)));
			l.length > 0 && l[0].length > 1 && l[0][0] === s && (c = l[0][1]), r.codecs.forEach((e) => {
				if (e.name.toUpperCase() === "RTX" && e.parameters.apt) {
					let t = {
						ssrc: s,
						codecPayloadType: parseInt(e.parameters.apt, 10)
					};
					s && c && (t.rtx = { ssrc: c }), n.push(t), i && (t = JSON.parse(JSON.stringify(t)), t.fec = {
						ssrc: s,
						mechanism: a ? "red+ulpfec" : "red"
					}, n.push(t));
				}
			}), n.length === 0 && s && n.push({ ssrc: s });
			let u = t.matchPrefix(e, "b=");
			return u.length && (u = u[0].indexOf("b=TIAS:") === 0 ? parseInt(u[0].substring(7), 10) : u[0].indexOf("b=AS:") === 0 ? parseInt(u[0].substring(5), 10) * 1e3 * .95 - 2e3 * 8 : void 0, n.forEach((e) => {
				e.maxBitrate = u;
			})), n;
		}, t.parseRtcpParameters = function(e) {
			let n = {}, r = t.matchPrefix(e, "a=ssrc:").map((e) => t.parseSsrcMedia(e)).filter((e) => e.attribute === "cname")[0];
			r && (n.cname = r.value, n.ssrc = r.ssrc);
			let i = t.matchPrefix(e, "a=rtcp-rsize");
			return n.reducedSize = i.length > 0, n.compound = i.length === 0, n.mux = t.matchPrefix(e, "a=rtcp-mux").length > 0, n;
		}, t.writeRtcpParameters = function(e) {
			let t = "";
			return e.reducedSize && (t += "a=rtcp-rsize\r\n"), e.mux && (t += "a=rtcp-mux\r\n"), e.ssrc !== void 0 && e.cname && (t += "a=ssrc:" + e.ssrc + " cname:" + e.cname + "\r\n"), t;
		}, t.parseMsid = function(e) {
			let n, r = t.matchPrefix(e, "a=msid:");
			if (r.length === 1) return n = r[0].substring(7).split(" "), {
				stream: n[0],
				track: n[1]
			};
			let i = t.matchPrefix(e, "a=ssrc:").map((e) => t.parseSsrcMedia(e)).filter((e) => e.attribute === "msid");
			if (i.length > 0) return n = i[0].value.split(" "), {
				stream: n[0],
				track: n[1]
			};
		}, t.parseSctpDescription = function(e) {
			let n = t.parseMLine(e), r = t.matchPrefix(e, "a=max-message-size:"), i;
			r.length > 0 && (i = parseInt(r[0].substring(19), 10)), isNaN(i) && (i = 65536);
			let a = t.matchPrefix(e, "a=sctp-port:");
			if (a.length > 0) return {
				port: parseInt(a[0].substring(12), 10),
				protocol: n.fmt,
				maxMessageSize: i
			};
			let o = t.matchPrefix(e, "a=sctpmap:");
			if (o.length > 0) {
				let e = o[0].substring(10).split(" ");
				return {
					port: parseInt(e[0], 10),
					protocol: e[1],
					maxMessageSize: i
				};
			}
		}, t.writeSctpDescription = function(e, t) {
			let n = [];
			return n = e.protocol === "DTLS/SCTP" ? [
				"m=" + e.kind + " 9 " + e.protocol + " " + t.port + "\r\n",
				"c=IN IP4 0.0.0.0\r\n",
				"a=sctpmap:" + t.port + " " + t.protocol + " 65535\r\n"
			] : [
				"m=" + e.kind + " 9 " + e.protocol + " " + t.protocol + "\r\n",
				"c=IN IP4 0.0.0.0\r\n",
				"a=sctp-port:" + t.port + "\r\n"
			], t.maxMessageSize !== void 0 && n.push("a=max-message-size:" + t.maxMessageSize + "\r\n"), n.join("");
		}, t.generateSessionId = function() {
			return Math.random().toString().substr(2, 22);
		}, t.writeSessionBoilerplate = function(e, n, r) {
			let i, a = n === void 0 ? 2 : n;
			return i = e || t.generateSessionId(), "v=0\r\no=" + (r || "thisisadapterortc") + " " + i + " " + a + " IN IP4 127.0.0.1\r\ns=-\r\nt=0 0\r\n";
		}, t.getDirection = function(e, n) {
			let r = t.splitLines(e);
			for (let e = 0; e < r.length; e++) switch (r[e]) {
				case "a=sendrecv":
				case "a=sendonly":
				case "a=recvonly":
				case "a=inactive": return r[e].substring(2);
			}
			return n ? t.getDirection(n) : "sendrecv";
		}, t.getKind = function(e) {
			return t.splitLines(e)[0].split(" ")[0].substring(2);
		}, t.isRejected = function(e) {
			return e.split(" ", 2)[1] === "0";
		}, t.parseMLine = function(e) {
			let n = t.splitLines(e)[0].substring(2).split(" ");
			return {
				kind: n[0],
				port: parseInt(n[1], 10),
				protocol: n[2],
				fmt: n.slice(3).join(" ")
			};
		}, t.parseOLine = function(e) {
			let n = t.matchPrefix(e, "o=")[0].substring(2).split(" ");
			return {
				username: n[0],
				sessionId: n[1],
				sessionVersion: parseInt(n[2], 10),
				netType: n[3],
				addressType: n[4],
				address: n[5]
			};
		}, t.isValidSDP = function(e) {
			if (typeof e != "string" || e.length === 0) return !1;
			let n = t.splitLines(e);
			for (let e = 0; e < n.length; e++) if (n[e].length < 2 || n[e].charAt(1) !== "=") return !1;
			return !0;
		}, e.exports = t;
	})(wa), wa.exports);
}
var Da = Ea(), Oa = /*@__PURE__*/ ai(Da), ka = /*#__PURE__*/ e({
	__proto__: null,
	default: Oa
}, [Da]);
function Aa(e) {
	if (!e.RTCIceCandidate || e.RTCIceCandidate && "foundation" in e.RTCIceCandidate.prototype) return;
	let t = e.RTCIceCandidate;
	e.RTCIceCandidate = function(e) {
		if (typeof e == "object" && e.candidate && e.candidate.indexOf("a=") === 0 && (e = JSON.parse(JSON.stringify(e)), e.candidate = e.candidate.substring(2)), e.candidate && e.candidate.length) {
			let n = new t(e), r = Oa.parseCandidate(e.candidate);
			for (let e in r) e in n || Object.defineProperty(n, e, { value: r[e] });
			return n.toJSON = function() {
				return {
					candidate: n.candidate,
					sdpMid: n.sdpMid,
					sdpMLineIndex: n.sdpMLineIndex,
					usernameFragment: n.usernameFragment
				};
			}, n;
		}
		return new t(e);
	}, e.RTCIceCandidate.prototype = t.prototype, Ni(e, "icecandidate", (t) => (t.candidate && Object.defineProperty(t, "candidate", {
		value: new e.RTCIceCandidate(t.candidate),
		writable: "false"
	}), t));
}
function ja(e) {
	!e.RTCIceCandidate || e.RTCIceCandidate && "relayProtocol" in e.RTCIceCandidate.prototype || Ni(e, "icecandidate", (e) => {
		if (e.candidate) {
			let t = Oa.parseCandidate(e.candidate.candidate);
			t.type === "relay" && (e.candidate.relayProtocol = {
				0: "tls",
				1: "tcp",
				2: "udp"
			}[t.priority >> 24]);
		}
		return e;
	});
}
function Ma(e, t) {
	if (!e.RTCPeerConnection) return;
	"sctp" in e.RTCPeerConnection.prototype || Object.defineProperty(e.RTCPeerConnection.prototype, "sctp", { get() {
		return this._sctp === void 0 ? null : this._sctp;
	} });
	let n = function(e) {
		if (!e || !e.sdp) return !1;
		let t = Oa.splitSections(e.sdp);
		return t.shift(), t.some((e) => {
			let t = Oa.parseMLine(e);
			return t && t.kind === "application" && t.protocol.indexOf("SCTP") !== -1;
		});
	}, r = function(e) {
		let t = e.sdp.match(/mozilla...THIS_IS_SDPARTA-(\d+)/);
		if (t === null || t.length < 2) return -1;
		let n = parseInt(t[1], 10);
		return n === n ? n : -1;
	}, i = function(e) {
		let n = 65536;
		return t.browser === "firefox" && (n = t.version < 57 ? e === -1 ? 16384 : 2147483637 : t.version < 60 ? t.version === 57 ? 65535 : 65536 : 2147483637), n;
	}, a = function(e, n) {
		let r = 65536;
		t.browser === "firefox" && t.version === 57 && (r = 65535);
		let i = Oa.matchPrefix(e.sdp, "a=max-message-size:");
		return i.length > 0 ? r = parseInt(i[0].substring(19), 10) : t.browser === "firefox" && n !== -1 && (r = 2147483637), r;
	}, o = e.RTCPeerConnection.prototype.setRemoteDescription;
	e.RTCPeerConnection.prototype.setRemoteDescription = function() {
		if (this._sctp = null, t.browser === "chrome" && t.version >= 76 && this.getConfiguration().sdpSemantics === "plan-b" && Object.defineProperty(this, "sctp", {
			get() {
				return this._sctp === void 0 ? null : this._sctp;
			},
			enumerable: !0,
			configurable: !0
		}), n(arguments[0])) {
			let e = r(arguments[0]), t = i(e), n = a(arguments[0], e), o;
			o = t === 0 && n === 0 ? Infinity : t === 0 || n === 0 ? Math.max(t, n) : Math.min(t, n);
			let s = {};
			Object.defineProperty(s, "maxMessageSize", { get() {
				return o;
			} }), this._sctp = s;
		}
		return o.apply(this, arguments);
	};
}
function Na(e, t) {
	if (!(e.RTCPeerConnection && "createDataChannel" in e.RTCPeerConnection.prototype) || t.browser === "chrome" && t.version > 149 || t.browser === "firefox" && t.version > 60) return;
	function n(e, t) {
		let n = e.send;
		e.send = function() {
			let r = arguments[0], i = r.length || r.size || r.byteLength;
			if (e.readyState === "open" && t.sctp && i > t.sctp.maxMessageSize) throw TypeError("Message too large (can send a maximum of " + t.sctp.maxMessageSize + " bytes)");
			return n.apply(e, arguments);
		};
	}
	let r = e.RTCPeerConnection.prototype.createDataChannel;
	e.RTCPeerConnection.prototype.createDataChannel = function() {
		let e = r.apply(this, arguments);
		return n(e, this), e;
	}, Ni(e, "datachannel", (e) => (n(e.channel, e.target), e));
}
function Pa(e) {
	if (!e.RTCPeerConnection || "connectionState" in e.RTCPeerConnection.prototype) return;
	let t = e.RTCPeerConnection.prototype;
	Object.defineProperty(t, "connectionState", {
		get() {
			return {
				completed: "connected",
				checking: "connecting"
			}[this.iceConnectionState] || this.iceConnectionState;
		},
		enumerable: !0,
		configurable: !0
	}), Object.defineProperty(t, "onconnectionstatechange", {
		get() {
			return this._onconnectionstatechange || null;
		},
		set(e) {
			this._onconnectionstatechange && (this.removeEventListener("connectionstatechange", this._onconnectionstatechange), delete this._onconnectionstatechange), e && this.addEventListener("connectionstatechange", this._onconnectionstatechange = e);
		},
		enumerable: !0,
		configurable: !0
	}), ["setLocalDescription", "setRemoteDescription"].forEach((e) => {
		let n = t[e];
		t[e] = function() {
			return this._connectionstatechangepoly || (this._connectionstatechangepoly = (e) => {
				let t = e.target;
				if (t._lastConnectionState !== t.connectionState) {
					t._lastConnectionState = t.connectionState;
					let n = new Event("connectionstatechange", e);
					t.dispatchEvent(n);
				}
				return e;
			}, this.addEventListener("iceconnectionstatechange", this._connectionstatechangepoly)), n.apply(this, arguments);
		};
	});
}
function Fa(e, t) {
	if (!e.RTCPeerConnection || t.browser === "chrome" && t.version >= 71 || t.browser === "safari" && t._safariVersion >= 13.1) return;
	let n = e.RTCPeerConnection.prototype.setRemoteDescription;
	e.RTCPeerConnection.prototype.setRemoteDescription = function(t) {
		if (t && t.sdp && t.sdp.indexOf("\na=extmap-allow-mixed") !== -1) {
			let n = t.sdp.split("\n").filter((e) => e.trim() !== "a=extmap-allow-mixed").join("\n");
			e.RTCSessionDescription && t instanceof e.RTCSessionDescription ? arguments[0] = new e.RTCSessionDescription({
				type: t.type,
				sdp: n
			}) : t.sdp = n;
		}
		return n.apply(this, arguments);
	};
}
function Ia(e, t) {
	if (!(e.RTCPeerConnection && e.RTCPeerConnection.prototype)) return;
	let n = e.RTCPeerConnection.prototype.addIceCandidate;
	!n || n.length === 0 || (e.RTCPeerConnection.prototype.addIceCandidate = function() {
		return arguments[0] ? (t.browser === "chrome" && t.version < 78 || t.browser === "firefox" && t.version < 68 || t.browser === "safari") && arguments[0] && arguments[0].candidate === "" ? Promise.resolve() : n.apply(this, arguments) : (arguments[1] && arguments[1].apply(null), Promise.resolve());
	});
}
function La(e, t) {
	if (!(e.RTCPeerConnection && e.RTCPeerConnection.prototype)) return;
	let n = e.RTCPeerConnection.prototype.setLocalDescription;
	!n || n.length === 0 || (e.RTCPeerConnection.prototype.setLocalDescription = function() {
		let e = arguments[0] || {};
		if (typeof e != "object" || e.type && e.sdp) return n.apply(this, arguments);
		if (e = {
			type: e.type,
			sdp: e.sdp
		}, !e.type) switch (this.signalingState) {
			case "stable":
			case "have-local-offer":
			case "have-remote-pranswer":
				e.type = "offer";
				break;
			default:
				e.type = "answer";
				break;
		}
		return e.sdp || e.type !== "offer" && e.type !== "answer" ? n.apply(this, [e]) : (e.type === "offer" ? this.createOffer : this.createAnswer).apply(this).then((e) => n.apply(this, [e]));
	});
}
var Ra = /*#__PURE__*/ Object.freeze({
	__proto__: null,
	removeExtmapAllowMixed: Fa,
	shimAddIceCandidateNullOrEmpty: Ia,
	shimConnectionState: Pa,
	shimMaxMessageSize: Ma,
	shimParameterlessSetLocalDescription: La,
	shimRTCIceCandidate: Aa,
	shimRTCIceCandidateRelayProtocol: ja,
	shimSendThrowTypeError: Na
});
function za() {
	let e = (arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {}).window, t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {
		shimChrome: !0,
		shimFirefox: !0,
		shimSafari: !0
	}, n = Ii, r = Ri(e), i = {
		browserDetails: r,
		commonShim: Ra,
		extractVersion: Mi,
		disableLog: Pi,
		disableWarnings: Fi,
		sdp: ka
	};
	switch (r.browser) {
		case "chrome":
			if (!$i || !Zi || !t.shimChrome) return n("Chrome shim is not included in this adapter release."), i;
			if (r.version === null) return n("Chrome shim can not determine version, not shimming."), i;
			n("adapter.js shimming chrome."), i.browserShim = $i, Ia(e, r), La(e), Wi(e, r), Gi(e), Zi(e, r), Ki(e, r), Xi(e, r), qi(e), Ji(e, r), Qi(e, r), Aa(e), ja(e), Pa(e), Ma(e, r), Na(e, r), Fa(e, r);
			break;
		case "firefox":
			if (!pa || !ra || !t.shimFirefox) return n("Firefox shim is not included in this adapter release."), i;
			n("adapter.js shimming firefox."), i.browserShim = pa, Ia(e, r), La(e), ea(e, r), ra(e, r), ia(e, r), na(e), sa(e), aa(e), oa(e), ca(e), la(e), ua(e), da(e), fa(e), Aa(e), Pa(e), Ma(e, r), Na(e, r);
			break;
		case "safari":
			if (!Ca || !t.shimSafari) return n("Safari shim is not included in this adapter release."), i;
			n("adapter.js shimming safari."), i.browserShim = Ca, Ia(e, r), La(e), ya(e), xa(e), ga(e), ma(e), ha(e), ba(e), _a(e), Sa(e), Aa(e), ja(e), Ma(e, r), Na(e, r), Fa(e, r);
			break;
		default:
			n("Unsupported browser!");
			break;
	}
	return i;
}
za({ window: typeof window > "u" ? void 0 : window });
var Ba, Va, D = class extends (Va = Promise) {
	constructor(e) {
		super(e);
	}
	catch(e) {
		return super.catch(e);
	}
	static reject(e) {
		return super.reject(e);
	}
	static all(e) {
		return super.all(e);
	}
	static race(e) {
		return super.race(e);
	}
};
Ba = D, D.resolve = (e) => Reflect.get(Va, "resolve", Ba).call(Ba, e);
var Ha = /version\/(\d+(\.?_?\d+)+)/i, Ua;
function O(e) {
	let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !0;
	if (e === void 0 && typeof navigator > "u") return;
	let n = (e ?? navigator.userAgent).toLowerCase();
	return (Ua === void 0 || t) && (Ua = Wa.find((e) => e.test.test(n))?.describe(n)), Ua;
}
var Wa = [
	{
		test: /firefox|iceweasel|fxios/i,
		describe(e) {
			return {
				name: "Firefox",
				version: Ga(/(?:firefox|iceweasel|fxios)[\s/](\d+(\.?_?\d+)+)/i, e),
				os: e.toLowerCase().includes("fxios") ? "iOS" : void 0,
				osVersion: Ka(e)
			};
		}
	},
	{
		test: /chrom|crios|crmo/i,
		describe(e) {
			return {
				name: "Chrome",
				version: Ga(/(?:chrome|chromium|crios|crmo)\/(\d+(\.?_?\d+)+)/i, e),
				os: e.toLowerCase().includes("crios") ? "iOS" : void 0,
				osVersion: Ka(e)
			};
		}
	},
	{
		test: /safari|applewebkit/i,
		describe(e) {
			return {
				name: "Safari",
				version: Ga(Ha, e),
				os: e.includes("mobile/") ? "iOS" : "macOS",
				osVersion: Ka(e)
			};
		}
	}
];
function Ga(e, t) {
	let n = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : 1, r = t.match(e);
	return r && r.length >= n && r[n] || "";
}
function Ka(e) {
	return e.includes("mac os") ? Ga(/\(.+?(\d+_\d+(:?_\d+)?)/, e, 1).replace(/_/g, ".") : void 0;
}
var qa = "2.19.2", Ja = class extends Error {
	constructor(e, t, n) {
		super(t || "an error has occurred"), this.name = "LiveKitError", this.code = e, n?.cause !== void 0 && (this.cause = n?.cause);
	}
}, Ya = class extends Ja {}, k;
(function(e) {
	e[e.NotAllowed = 0] = "NotAllowed", e[e.ServerUnreachable = 1] = "ServerUnreachable", e[e.InternalError = 2] = "InternalError", e[e.Cancelled = 3] = "Cancelled", e[e.LeaveRequest = 4] = "LeaveRequest", e[e.Timeout = 5] = "Timeout", e[e.WebSocket = 6] = "WebSocket", e[e.ServiceNotFound = 7] = "ServiceNotFound";
})(k ||= {});
var A = class e extends Ya {
	constructor(e, t, n, r) {
		super(1, e), this.name = "ConnectionError", this.status = n, this.reason = t, this.context = r, this.reasonName = k[t];
	}
	static notAllowed(t, n, r) {
		return new e(t, k.NotAllowed, n, r);
	}
	static timeout(t) {
		return new e(t, k.Timeout);
	}
	static leaveRequest(t, n) {
		return new e(t, k.LeaveRequest, void 0, n);
	}
	static internal(t, n) {
		return new e(t, k.InternalError, void 0, n);
	}
	static cancelled(t) {
		return new e(t, k.Cancelled);
	}
	static serverUnreachable(t, n) {
		return new e(t, k.ServerUnreachable, n);
	}
	static websocket(t, n, r) {
		return new e(t, k.WebSocket, n, r);
	}
	static serviceNotFound(t, n) {
		return new e(t, k.ServiceNotFound, void 0, n);
	}
}, Xa = class extends Ja {
	constructor(e) {
		super(21, e ?? "device is unsupported"), this.name = "DeviceUnsupportedError";
	}
}, Za = class extends Ja {
	constructor(e) {
		super(20, e ?? "track is invalid"), this.name = "TrackInvalidError";
	}
}, Qa = class extends Ja {
	constructor(e) {
		super(10, e ?? "unsupported server"), this.name = "UnsupportedServer";
	}
}, j = class extends Ja {
	constructor(e) {
		super(12, e ?? "unexpected connection state"), this.name = "UnexpectedConnectionState";
	}
}, $a = class extends Ja {
	constructor(e) {
		super(13, e ?? "unable to negotiate"), this.name = "NegotiationError";
	}
}, eo = class extends Ja {
	constructor(e, t) {
		super(15, e), this.name = "PublishTrackError", this.status = t;
	}
}, to = class extends Ya {
	constructor(e, t) {
		super(15, e), this.name = "SignalRequestError", this.reason = t, this.reasonName = typeof t == "string" ? t : Qr[t];
	}
}, M;
(function(e) {
	e[e.AlreadyOpened = 0] = "AlreadyOpened", e[e.AbnormalEnd = 1] = "AbnormalEnd", e[e.DecodeFailed = 2] = "DecodeFailed", e[e.LengthExceeded = 3] = "LengthExceeded", e[e.Incomplete = 4] = "Incomplete", e[e.HandlerAlreadyRegistered = 7] = "HandlerAlreadyRegistered", e[e.EncryptionTypeMismatch = 8] = "EncryptionTypeMismatch";
})(M ||= {});
var no = class extends Ya {
	constructor(e, t) {
		super(16, e), this.name = "DataStreamError", this.reason = t, this.reasonName = M[t];
	}
}, ro = class extends Ja {
	constructor(e) {
		super(18, e), this.name = "SignalReconnectError";
	}
}, io;
(function(e) {
	e.PermissionDenied = "PermissionDenied", e.NotFound = "NotFound", e.DeviceInUse = "DeviceInUse", e.Other = "Other";
})(io ||= {}), (function(e) {
	function t(t) {
		if (t && "name" in t) return t.name === "NotFoundError" || t.name === "DevicesNotFoundError" ? e.NotFound : t.name === "NotAllowedError" || t.name === "PermissionDeniedError" ? e.PermissionDenied : t.name === "NotReadableError" || t.name === "TrackStartError" ? e.DeviceInUse : e.Other;
	}
	e.getFailure = t;
})(io ||= {});
var N = class {};
N.setTimeout = function() {
	return setTimeout(...arguments);
}, N.setInterval = function() {
	return setInterval(...arguments);
}, N.clearTimeout = function() {
	return clearTimeout(...arguments);
}, N.clearInterval = function() {
	return clearInterval(...arguments);
};
var P;
(function(e) {
	e.Connected = "connected", e.Reconnecting = "reconnecting", e.SignalReconnecting = "signalReconnecting", e.Reconnected = "reconnected", e.Disconnected = "disconnected", e.ConnectionStateChanged = "connectionStateChanged", e.Moved = "moved", e.MediaDevicesChanged = "mediaDevicesChanged", e.ParticipantConnected = "participantConnected", e.ParticipantDisconnected = "participantDisconnected", e.TrackPublished = "trackPublished", e.TrackSubscribed = "trackSubscribed", e.TrackSubscriptionFailed = "trackSubscriptionFailed", e.TrackUnpublished = "trackUnpublished", e.TrackUnsubscribed = "trackUnsubscribed", e.TrackMuted = "trackMuted", e.TrackUnmuted = "trackUnmuted", e.LocalTrackPublished = "localTrackPublished", e.LocalTrackUnpublished = "localTrackUnpublished", e.LocalAudioSilenceDetected = "localAudioSilenceDetected", e.ActiveSpeakersChanged = "activeSpeakersChanged", e.ParticipantMetadataChanged = "participantMetadataChanged", e.ParticipantNameChanged = "participantNameChanged", e.ParticipantAttributesChanged = "participantAttributesChanged", e.ParticipantActive = "participantActive", e.RoomMetadataChanged = "roomMetadataChanged", e.DataReceived = "dataReceived", e.SipDTMFReceived = "sipDTMFReceived", e.TranscriptionReceived = "transcriptionReceived", e.ConnectionQualityChanged = "connectionQualityChanged", e.TrackStreamStateChanged = "trackStreamStateChanged", e.TrackSubscriptionPermissionChanged = "trackSubscriptionPermissionChanged", e.TrackSubscriptionStatusChanged = "trackSubscriptionStatusChanged", e.AudioPlaybackStatusChanged = "audioPlaybackChanged", e.VideoPlaybackStatusChanged = "videoPlaybackChanged", e.MediaDevicesError = "mediaDevicesError", e.ParticipantPermissionsChanged = "participantPermissionsChanged", e.SignalConnected = "signalConnected", e.RecordingStatusChanged = "recordingStatusChanged", e.ParticipantEncryptionStatusChanged = "participantEncryptionStatusChanged", e.EncryptionError = "encryptionError", e.DCBufferStatusChanged = "dcBufferStatusChanged", e.ActiveDeviceChanged = "activeDeviceChanged", e.ChatMessage = "chatMessage", e.LocalTrackSubscribed = "localTrackSubscribed", e.MetricsReceived = "metricsReceived", e.DataTrackPublished = "dataTrackPublished", e.DataTrackUnpublished = "dataTrackUnpublished", e.LocalDataTrackPublished = "localDataTrackPublished", e.LocalDataTrackUnpublished = "localDataTrackUnpublished";
})(P ||= {});
var F;
(function(e) {
	e.TrackPublished = "trackPublished", e.TrackSubscribed = "trackSubscribed", e.TrackSubscriptionFailed = "trackSubscriptionFailed", e.TrackUnpublished = "trackUnpublished", e.TrackUnsubscribed = "trackUnsubscribed", e.TrackMuted = "trackMuted", e.TrackUnmuted = "trackUnmuted", e.LocalTrackPublished = "localTrackPublished", e.LocalTrackUnpublished = "localTrackUnpublished", e.LocalTrackCpuConstrained = "localTrackCpuConstrained", e.LocalSenderCreated = "localSenderCreated", e.ParticipantMetadataChanged = "participantMetadataChanged", e.ParticipantNameChanged = "participantNameChanged", e.DataReceived = "dataReceived", e.SipDTMFReceived = "sipDTMFReceived", e.TranscriptionReceived = "transcriptionReceived", e.IsSpeakingChanged = "isSpeakingChanged", e.ConnectionQualityChanged = "connectionQualityChanged", e.TrackStreamStateChanged = "trackStreamStateChanged", e.TrackSubscriptionPermissionChanged = "trackSubscriptionPermissionChanged", e.TrackSubscriptionStatusChanged = "trackSubscriptionStatusChanged", e.TrackCpuConstrained = "trackCpuConstrained", e.MediaDevicesError = "mediaDevicesError", e.AudioStreamAcquired = "audioStreamAcquired", e.ParticipantPermissionsChanged = "participantPermissionsChanged", e.PCTrackAdded = "pcTrackAdded", e.AttributesChanged = "attributesChanged", e.LocalTrackSubscribed = "localTrackSubscribed", e.ChatMessage = "chatMessage", e.Active = "active";
})(F ||= {});
var I;
(function(e) {
	e.TransportsCreated = "transportsCreated", e.Connected = "connected", e.Disconnected = "disconnected", e.Resuming = "resuming", e.Resumed = "resumed", e.Restarting = "restarting", e.Restarted = "restarted", e.SignalResumed = "signalResumed", e.SignalRestarted = "signalRestarted", e.Closing = "closing", e.MediaTrackAdded = "mediaTrackAdded", e.ActiveSpeakersUpdate = "activeSpeakersUpdate", e.DataPacketReceived = "dataPacketReceived", e.RTPVideoMapUpdate = "rtpVideoMapUpdate", e.DCBufferStatusChanged = "dcBufferStatusChanged", e.ParticipantUpdate = "participantUpdate", e.RoomUpdate = "roomUpdate", e.SpeakersChanged = "speakersChanged", e.StreamStateChanged = "streamStateChanged", e.ConnectionQualityUpdate = "connectionQualityUpdate", e.SubscriptionError = "subscriptionError", e.SubscriptionPermissionUpdate = "subscriptionPermissionUpdate", e.RemoteMute = "remoteMute", e.SubscribedQualityUpdate = "subscribedQualityUpdate", e.LocalTrackUnpublished = "localTrackUnpublished", e.LocalTrackSubscribed = "localTrackSubscribed", e.Offline = "offline", e.SignalRequestResponse = "signalRequestResponse", e.SignalConnected = "signalConnected", e.RoomMoved = "roomMoved", e.PublishDataTrackResponse = "publishDataTrackResponse", e.UnPublishDataTrackResponse = "unPublishDataTrackResponse", e.DataTrackSubscriberHandles = "dataTrackSubscriberHandles", e.DataTrackPacketReceived = "dataTrackPacketReceived", e.Joined = "joined", e.TokenRefreshed = "tokenRefreshed", e.ServerRegionsReported = "serverRegionsReported";
})(I ||= {});
var L;
(function(e) {
	e.Message = "message", e.Muted = "muted", e.Unmuted = "unmuted", e.Restarted = "restarted", e.Ended = "ended", e.Subscribed = "subscribed", e.Unsubscribed = "unsubscribed", e.CpuConstrained = "cpuConstrained", e.UpdateSettings = "updateSettings", e.UpdateSubscription = "updateSubscription", e.AudioPlaybackStarted = "audioPlaybackStarted", e.AudioPlaybackFailed = "audioPlaybackFailed", e.AudioSilenceDetected = "audioSilenceDetected", e.VisibilityChanged = "visibilityChanged", e.VideoDimensionsChanged = "videoDimensionsChanged", e.VideoPlaybackStarted = "videoPlaybackStarted", e.VideoPlaybackFailed = "videoPlaybackFailed", e.ElementAttached = "elementAttached", e.ElementDetached = "elementDetached", e.UpstreamPaused = "upstreamPaused", e.UpstreamResumed = "upstreamResumed", e.SubscriptionPermissionChanged = "subscriptionPermissionChanged", e.SubscriptionStatusChanged = "subscriptionStatusChanged", e.SubscriptionFailed = "subscriptionFailed", e.TrackProcessorUpdate = "trackProcessorUpdate", e.AudioTrackFeatureUpdate = "audioTrackFeatureUpdate", e.TranscriptionReceived = "transcriptionReceived", e.TimeSyncUpdate = "timeSyncUpdate", e.PreConnectBufferFlushed = "preConnectBufferFlushed";
})(L ||= {});
function ao(e) {
	return e === void 0 ? e : typeof structuredClone == "function" ? typeof e == "object" && e ? structuredClone(Object.assign({}, e)) : structuredClone(e) : JSON.parse(JSON.stringify(e));
}
var R = class {
	constructor(e, t, n, r, i) {
		if (typeof e == "object") this.width = e.width, this.height = e.height, this.aspectRatio = e.aspectRatio, this.encoding = {
			maxBitrate: e.maxBitrate,
			maxFramerate: e.maxFramerate,
			priority: e.priority
		};
		else if (t !== void 0 && n !== void 0) this.width = e, this.height = t, this.aspectRatio = e / t, this.encoding = {
			maxBitrate: n,
			maxFramerate: r,
			priority: i
		};
		else throw TypeError("Unsupported options: provide at least width, height and maxBitrate");
	}
	get resolution() {
		return {
			width: this.width,
			height: this.height,
			frameRate: this.encoding.maxFramerate,
			aspectRatio: this.aspectRatio
		};
	}
}, oo = ["vp8", "h264"], so = [
	"vp8",
	"h264",
	"vp9",
	"av1",
	"h265"
];
function co(e) {
	return !!oo.find((t) => t === e);
}
var lo = co, uo;
(function(e) {
	e[e.PREFER_REGRESSION = 0] = "PREFER_REGRESSION", e[e.SIMULCAST = 1] = "SIMULCAST", e[e.REGRESSION = 2] = "REGRESSION";
})(uo ||= {});
var fo;
(function(e) {
	e.telephone = { maxBitrate: 12e3 }, e.speech = { maxBitrate: 24e3 }, e.music = { maxBitrate: 48e3 }, e.musicStereo = { maxBitrate: 64e3 }, e.musicHighQuality = { maxBitrate: 96e3 }, e.musicHighQualityStereo = { maxBitrate: 128e3 };
})(fo ||= {});
var po = {
	h90: new R(160, 90, 9e4, 20),
	h180: new R(320, 180, 16e4, 20),
	h216: new R(384, 216, 18e4, 20),
	h360: new R(640, 360, 45e4, 20),
	h540: new R(960, 540, 8e5, 25),
	h720: new R(1280, 720, 17e5, 30),
	h1080: new R(1920, 1080, 3e6, 30),
	h1440: new R(2560, 1440, 5e6, 30),
	h2160: new R(3840, 2160, 8e6, 30)
}, mo = {
	h120: new R(160, 120, 7e4, 20),
	h180: new R(240, 180, 125e3, 20),
	h240: new R(320, 240, 14e4, 20),
	h360: new R(480, 360, 33e4, 20),
	h480: new R(640, 480, 5e5, 20),
	h540: new R(720, 540, 6e5, 25),
	h720: new R(960, 720, 13e5, 30),
	h1080: new R(1440, 1080, 23e5, 30),
	h1440: new R(1920, 1440, 38e5, 30)
}, ho = {
	h360fps3: new R(640, 360, 2e5, 3, "medium"),
	h360fps15: new R(640, 360, 4e5, 15, "medium"),
	h720fps5: new R(1280, 720, 8e5, 5, "medium"),
	h720fps15: new R(1280, 720, 15e5, 15, "medium"),
	h720fps30: new R(1280, 720, 2e6, 30, "medium"),
	h1080fps15: new R(1920, 1080, 25e5, 15, "medium"),
	h1080fps30: new R(1920, 1080, 5e6, 30, "medium"),
	original: new R(0, 0, 7e6, 30, "medium")
};
function go(e, t, n) {
	var r, i;
	let a = Oo(e ?? {}), o = a.optionsWithoutProcessor, s = a.audioProcessor, c = a.videoProcessor, l = t?.processor, u = n?.processor, d = o ?? {};
	return d.audio === !0 && (d.audio = {}), d.video === !0 && (d.video = {}), d.audio && (_o(d.audio, t), (r = d.audio).deviceId ?? (r.deviceId = { ideal: "default" }), (s || l) && (d.audio.processor = s ?? l)), d.video && (_o(d.video, n), (i = d.video).deviceId ?? (i.deviceId = { ideal: "default" }), (c || u) && (d.video.processor = c ?? u)), d;
}
function _o(e, t) {
	return Object.keys(t).forEach((n) => {
		e[n] === void 0 && (e[n] = t[n]);
	}), e;
}
function vo(e) {
	var t, n;
	let r = {};
	if (e.video) if (typeof e.video == "object") {
		let n = {}, i = n, a = e.video;
		Object.keys(a).forEach((e) => {
			switch (e) {
				case "resolution":
					_o(i, a.resolution);
					break;
				default: i[e] = a[e];
			}
		}), r.video = n, (t = r.video).deviceId ?? (t.deviceId = { ideal: "default" });
	} else r.video = e.video ? { deviceId: { ideal: "default" } } : !1;
	else r.video = !1;
	return e.audio ? typeof e.audio == "object" ? (r.audio = e.audio, (n = r.audio).deviceId ?? (n.deviceId = { ideal: "default" })) : r.audio = { deviceId: { ideal: "default" } } : r.audio = !1, r;
}
function yo(e) {
	return E(this, arguments, void 0, function(e) {
		let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 200;
		return function* () {
			let n = bo();
			if (n) {
				let r = n.createAnalyser();
				r.fftSize = 2048;
				let i = r.frequencyBinCount, a = new Uint8Array(i);
				n.createMediaStreamSource(new MediaStream([e.mediaStreamTrack])).connect(r), yield V(t), r.getByteTimeDomainData(a);
				let o = a.some((e) => e !== 128 && e !== 0);
				return n.close(), !o;
			}
			return !1;
		}();
	});
}
function bo() {
	let e = typeof window < "u" && (window.AudioContext || window.webkitAudioContext);
	if (e) {
		let t = new e({ latencyHint: "interactive" });
		if (t.state === "suspended" && typeof window < "u" && window.document?.body) {
			let e = () => E(this, void 0, void 0, function* () {
				var n;
				try {
					t.state === "suspended" && (yield t.resume());
				} catch (e) {
					console.warn("Error trying to auto-resume audio context", e);
				} finally {
					(n = window.document.body) == null || n.removeEventListener("click", e);
				}
			});
			t.addEventListener("statechange", () => {
				var n;
				t.state === "closed" && ((n = window.document.body) == null || n.removeEventListener("click", e));
			}), window.document.body.addEventListener("click", e);
		}
		return t;
	}
}
function xo(e) {
	return e === "audioinput" ? B.Source.Microphone : e === "videoinput" ? B.Source.Camera : B.Source.Unknown;
}
function So(e) {
	if (e === B.Source.Microphone) return "audioinput";
	if (e === B.Source.Camera) return "videoinput";
}
function Co(e) {
	let t = e.video ?? !0;
	return e.resolution && e.resolution.width > 0 && e.resolution.height > 0 && (t = typeof t == "boolean" ? {} : t, t = Xo() ? Object.assign(Object.assign({}, t), {
		width: { max: e.resolution.width },
		height: { max: e.resolution.height },
		frameRate: e.resolution.frameRate
	}) : Object.assign(Object.assign({}, t), {
		width: { ideal: e.resolution.width },
		height: { ideal: e.resolution.height },
		frameRate: e.resolution.frameRate
	})), {
		audio: e.audio ?? !1,
		video: t,
		controller: e.controller,
		selfBrowserSurface: e.selfBrowserSurface,
		surfaceSwitching: e.surfaceSwitching,
		systemAudio: e.systemAudio,
		preferCurrentTab: e.preferCurrentTab
	};
}
function wo(e) {
	return e.split("/")[1].toLowerCase();
}
function To(e) {
	let t = [];
	return e.forEach((e) => {
		e.track !== void 0 && t.push(new pr({
			cid: e.track.mediaStreamID,
			track: e.trackInfo
		}));
	}), t;
}
function z(e) {
	return "mediaStreamTrack" in e ? {
		trackID: e.sid,
		source: e.source,
		muted: e.isMuted,
		enabled: e.mediaStreamTrack.enabled,
		kind: e.kind,
		streamID: e.mediaStreamID,
		streamTrackID: e.mediaStreamTrack.id
	} : {
		trackID: e.trackSid,
		enabled: e.isEnabled,
		muted: e.isMuted,
		trackInfo: Object.assign({
			mimeType: e.mimeType,
			name: e.trackName,
			encrypted: e.isEncrypted,
			kind: e.kind,
			source: e.source
		}, e.track ? z(e.track) : {})
	};
}
function Eo() {
	return typeof RTCRtpReceiver < "u" && typeof RTCRtpReceiver.prototype.getSynchronizationSources == "function";
}
function Do(e, t) {
	e === void 0 && (e = {}), t === void 0 && (t = {});
	let n = [...Object.keys(t), ...Object.keys(e)], r = {};
	for (let i of n) e[i] !== t[i] && (r[i] = t[i] ?? "");
	return r;
}
function Oo(e) {
	let t = Object.assign({}, e), n, r;
	return typeof t.audio == "object" && t.audio.processor && (n = t.audio.processor, t.audio = Object.assign(Object.assign({}, t.audio), { processor: void 0 })), typeof t.video == "object" && t.video.processor && (r = t.video.processor, t.video = Object.assign(Object.assign({}, t.video), { processor: void 0 })), {
		audioProcessor: n,
		videoProcessor: r,
		optionsWithoutProcessor: ao(t)
	};
}
function ko(e) {
	switch (e) {
		case y.CAMERA: return B.Source.Camera;
		case y.MICROPHONE: return B.Source.Microphone;
		case y.SCREEN_SHARE: return B.Source.ScreenShare;
		case y.SCREEN_SHARE_AUDIO: return B.Source.ScreenShareAudio;
		default: return B.Source.Unknown;
	}
}
function Ao(e, t) {
	return e.width * e.height < t.width * t.height;
}
function jo(e, t) {
	return e.layers?.find((e) => e.quality === t);
}
var Mo = 5e3, No = [], Po;
(function(e) {
	e[e.LOW = 0] = "LOW", e[e.MEDIUM = 1] = "MEDIUM", e[e.HIGH = 2] = "HIGH";
})(Po ||= {});
var B = class e extends Oi.EventEmitter {
	get streamState() {
		return this._streamState;
	}
	setStreamState(e) {
		this._streamState = e;
	}
	constructor(t, n) {
		let r = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
		super(), this.attachedElements = [], this.isMuted = !1, this._streamState = e.StreamState.Active, this.isInBackground = !1, this._currentBitrate = 0, this.log = w, this.appVisibilityChangedListener = () => {
			this.backgroundTimeout && clearTimeout(this.backgroundTimeout), document.visibilityState === "hidden" ? this.backgroundTimeout = setTimeout(() => this.handleAppVisibilityChanged(), Mo) : this.handleAppVisibilityChanged();
		}, this.log = T(r.loggerName ?? C.Track), this.loggerContextCb = r.loggerContextCb, this.setMaxListeners(100), this.kind = n, this._mediaStreamTrack = t, this._mediaStreamID = t.id, this.source = e.Source.Unknown;
	}
	get logContext() {
		return Object.assign(Object.assign({}, this.loggerContextCb?.call(this)), z(this));
	}
	get currentBitrate() {
		return this._currentBitrate;
	}
	get mediaStreamTrack() {
		return this._mediaStreamTrack;
	}
	get mediaStreamID() {
		return this._mediaStreamID;
	}
	attach(t) {
		let n = "audio";
		this.kind === e.Kind.Video && (n = "video"), this.attachedElements.length === 0 && this.kind === e.Kind.Video && this.addAppVisibilityListener(), t || (n === "audio" && (No.forEach((e) => {
			e.parentElement === null && !t && (t = e);
		}), t && No.splice(No.indexOf(t), 1)), t ||= document.createElement(n)), this.attachedElements.includes(t) || this.attachedElements.push(t), Fo(this.mediaStreamTrack, t);
		let r = t.srcObject.getTracks(), i = r.some((e) => e.kind === "audio");
		return t.play().then(() => {
			this.emit(i ? L.AudioPlaybackStarted : L.VideoPlaybackStarted);
		}).catch((e) => {
			e.name === "NotAllowedError" ? this.emit(i ? L.AudioPlaybackFailed : L.VideoPlaybackFailed, e) : e.name === "AbortError" ? w.debug(`${i ? "audio" : "video"} playback aborted, likely due to new play request`) : w.warn(`could not playback ${i ? "audio" : "video"}`, e), i && t && r.some((e) => e.kind === "video") && e.name === "NotAllowedError" && (t.muted = !0, t.play().catch(() => {}));
		}), this.emit(L.ElementAttached, t), t;
	}
	detach(e) {
		try {
			if (e) {
				Io(this.mediaStreamTrack, e);
				let t = this.attachedElements.indexOf(e);
				return t >= 0 && (this.attachedElements.splice(t, 1), this.recycleElement(e), this.emit(L.ElementDetached, e)), e;
			}
			let t = [];
			return this.attachedElements.forEach((e) => {
				Io(this.mediaStreamTrack, e), t.push(e), this.recycleElement(e), this.emit(L.ElementDetached, e);
			}), this.attachedElements = [], t;
		} finally {
			this.attachedElements.length === 0 && this.removeAppVisibilityListener();
		}
	}
	stop() {
		this.stopMonitor(), this._mediaStreamTrack.stop();
	}
	enable() {
		this._mediaStreamTrack.enabled = !0;
	}
	disable() {
		this._mediaStreamTrack.enabled = !1;
	}
	stopMonitor() {
		this.monitorInterval && clearInterval(this.monitorInterval), this.timeSyncHandle && cancelAnimationFrame(this.timeSyncHandle);
	}
	updateLoggerOptions(e) {
		e.loggerName && (this.log = T(e.loggerName)), e.loggerContextCb && (this.loggerContextCb = e.loggerContextCb);
	}
	recycleElement(e) {
		if (e instanceof HTMLAudioElement) {
			let t = !0;
			e.pause(), No.forEach((e) => {
				e.parentElement || (t = !1);
			}), t && No.push(e);
		}
	}
	handleAppVisibilityChanged() {
		return E(this, void 0, void 0, function* () {
			this.isInBackground = document.visibilityState === "hidden", !this.isInBackground && this.kind === e.Kind.Video && setTimeout(() => this.attachedElements.forEach((e) => e.play().catch(() => {})), 0);
		});
	}
	addAppVisibilityListener() {
		H() ? (this.isInBackground = document.visibilityState === "hidden", document.addEventListener("visibilitychange", this.appVisibilityChangedListener)) : this.isInBackground = !1;
	}
	removeAppVisibilityListener() {
		H() && document.removeEventListener("visibilitychange", this.appVisibilityChangedListener);
	}
};
function Fo(e, t) {
	let n;
	n = t.srcObject instanceof MediaStream ? t.srcObject : new MediaStream();
	let r;
	r = e.kind === "audio" ? n.getAudioTracks() : n.getVideoTracks(), r.includes(e) || (r.forEach((e) => {
		n.removeTrack(e);
	}), n.addTrack(e)), (!Xo() || !(t instanceof HTMLVideoElement)) && (t.autoplay = !0), t.muted = n.getAudioTracks().length === 0, t instanceof HTMLVideoElement && (t.playsInline = !0), t.srcObject !== n && (t.srcObject = n, (Xo() || qo()) && t instanceof HTMLVideoElement && setTimeout(() => {
		t.srcObject = n, t.play().catch(() => {});
	}, 0));
}
function Io(e, t) {
	if (t.srcObject instanceof MediaStream) {
		let n = t.srcObject;
		n.removeTrack(e), n.getTracks().length > 0 ? t.srcObject = n : t.srcObject = null;
	}
}
(function(e) {
	let t;
	(function(e) {
		e.Audio = "audio", e.Video = "video", e.Unknown = "unknown";
	})(t = e.Kind ||= {});
	let n;
	(function(e) {
		e.Camera = "camera", e.Microphone = "microphone", e.ScreenShare = "screen_share", e.ScreenShareAudio = "screen_share_audio", e.Unknown = "unknown";
	})(n = e.Source ||= {});
	let r;
	(function(e) {
		e.Active = "active", e.Paused = "paused", e.Unknown = "unknown";
	})(r = e.StreamState ||= {});
	function i(e) {
		switch (e) {
			case t.Audio: return Zt.AUDIO;
			case t.Video: return Zt.VIDEO;
			default: return Zt.DATA;
		}
	}
	e.kindToProto = i;
	function a(e) {
		switch (e) {
			case Zt.AUDIO: return t.Audio;
			case Zt.VIDEO: return t.Video;
			default: return t.Unknown;
		}
	}
	e.kindFromProto = a;
	function o(e) {
		switch (e) {
			case n.Camera: return y.CAMERA;
			case n.Microphone: return y.MICROPHONE;
			case n.ScreenShare: return y.SCREEN_SHARE;
			case n.ScreenShareAudio: return y.SCREEN_SHARE_AUDIO;
			default: return y.UNKNOWN;
		}
	}
	e.sourceToProto = o;
	function s(e) {
		switch (e) {
			case y.CAMERA: return n.Camera;
			case y.MICROPHONE: return n.Microphone;
			case y.SCREEN_SHARE: return n.ScreenShare;
			case y.SCREEN_SHARE_AUDIO: return n.ScreenShareAudio;
			default: return n.Unknown;
		}
	}
	e.sourceFromProto = s;
	function c(e) {
		switch (e) {
			case Zn.ACTIVE: return r.Active;
			case Zn.PAUSED: return r.Paused;
			default: return r.Unknown;
		}
	}
	e.streamStateFromProto = c;
})(B ||= {});
var Lo = "|", Ro = "https://aomediacodec.github.io/av1-rtp-spec/#dependency-descriptor-rtp-header-extension";
function zo(e) {
	let t = e.split(Lo);
	return t.length > 1 ? [t[0], e.substr(t[0].length + 1)] : [e, ""];
}
function V(e) {
	return new D((t) => N.setTimeout(t, e));
}
function Bo() {
	return "addTransceiver" in RTCPeerConnection.prototype;
}
function Vo() {
	return "addTrack" in RTCPeerConnection.prototype;
}
function Ho() {
	if (!("getCapabilities" in RTCRtpSender) || Xo() || qo()) return !1;
	let e = RTCRtpSender.getCapabilities("video"), t = !1;
	if (e) {
		for (let n of e.codecs) if (n.mimeType.toLowerCase() === "video/av1") {
			t = !0;
			break;
		}
	}
	return t;
}
function Uo() {
	if (!("getCapabilities" in RTCRtpSender) || qo()) return !1;
	if (Xo()) {
		let e = O();
		if (e?.version && cs(e.version, "16") < 0 || e?.os === "iOS" && e?.osVersion && cs(e.osVersion, "16") < 0) return !1;
	}
	let e = RTCRtpSender.getCapabilities("video"), t = !1;
	if (e) {
		for (let n of e.codecs) if (n.mimeType.toLowerCase() === "video/vp9") {
			t = !0;
			break;
		}
	}
	return t;
}
function Wo(e) {
	return e === "av1" || e === "vp9";
}
function Go(e) {
	return !document || Zo() ? !1 : (e ||= document.createElement("audio"), "setSinkId" in e);
}
function Ko() {
	return typeof RTCPeerConnection > "u" ? !1 : Bo() || Vo();
}
function qo() {
	return O()?.name === "Firefox";
}
function Jo() {
	let e = O();
	return !!e && e.name === "Chrome" && e.os !== "iOS";
}
function Yo() {
	return typeof window < "u" && window.RTCRtpScriptTransform !== void 0 && !Jo();
}
function Xo() {
	return O()?.name === "Safari";
}
function Zo() {
	let e = O();
	return e?.name === "Safari" || e?.os === "iOS";
}
function Qo() {
	let e = O();
	return e?.name === "Safari" && e.version.startsWith("17.") || e?.os === "iOS" && !!e?.osVersion && cs(e.osVersion, "17") >= 0;
}
function $o(e) {
	return e ||= O(), e?.name === "Safari" && cs(e.version, "18.3") > 0 || e?.os === "iOS" && !!e?.osVersion && cs(e.osVersion, "18.3") > 0;
}
function es() {
	return H() ? navigator.userAgentData?.mobile ?? /Tablet|iPad|Mobile|Android|BlackBerry/.test(navigator.userAgent) : !1;
}
function ts() {
	let e = O(), t = "17.2";
	if (e) return e.name !== "Safari" && e.os !== "iOS" || e.os === "iOS" && e.osVersion && cs(e.osVersion, t) >= 0 ? !0 : e.name === "Safari" && cs(e.version, t) >= 0;
}
function H() {
	return typeof document < "u";
}
function ns() {
	return navigator.product == "ReactNative";
}
function rs(e) {
	return e.hostname.endsWith(".livekit.cloud") || e.hostname.endsWith(".livekit.run");
}
function is(e) {
	return rs(e) ? e.hostname.split(".")[0] : null;
}
function as() {
	if (global && global.LiveKitReactNativeGlobal) return global.LiveKitReactNativeGlobal;
}
function os() {
	if (!ns()) return;
	let e = as();
	if (e) return e.platform;
}
function ss() {
	if (H()) return window.devicePixelRatio;
	if (ns()) {
		let e = as();
		if (e) return e.devicePixelRatio;
	}
	return 1;
}
function cs(e, t) {
	let n = e.split("."), r = t.split("."), i = Math.min(n.length, r.length);
	for (let e = 0; e < i; ++e) {
		let t = parseInt(n[e], 10), a = parseInt(r[e], 10);
		if (t > a) return 1;
		if (t < a) return -1;
		if (e === i - 1 && t === a) return 0;
	}
	return e === "" && t !== "" ? -1 : t === "" ? 1 : n.length == r.length ? 0 : n.length < r.length ? -1 : 1;
}
function ls(e) {
	for (let t of e) t.target.handleResize(t);
}
function us(e) {
	for (let t of e) t.target.handleVisibilityChanged(t);
}
var ds = null, fs = () => (ds ||= new ResizeObserver(ls), ds), ps = null, ms = () => (ps ||= new IntersectionObserver(us, {
	root: null,
	rootMargin: "0px"
}), ps);
function hs(e) {
	let t = new In({
		capabilities: e,
		sdk: Ln.JS,
		protocol: 17,
		clientProtocol: 1,
		version: qa
	});
	return ns() && (t.os = os() ?? ""), t;
}
function gs() {
	let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : 16, t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 16, n = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : !1, r = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : !1, i = document.createElement("canvas");
	i.width = e, i.height = t;
	let a = i.getContext("2d");
	a?.fillRect(0, 0, i.width, i.height), r && a && (a.beginPath(), a.arc(e / 2, t / 2, 50, 0, Math.PI * 2, !0), a.closePath(), a.fillStyle = "grey", a.fill());
	let o = g(i.captureStream().getTracks(), 1)[0];
	if (!o) throw Error("Could not get empty media stream video track");
	return o.enabled = n, o;
}
var _s;
function vs() {
	if (!_s) {
		let e = new AudioContext(), t = e.createOscillator(), n = e.createGain();
		n.gain.setValueAtTime(0, 0);
		let r = e.createMediaStreamDestination();
		if (t.connect(n), n.connect(r), t.start(), _s = g(r.stream.getAudioTracks(), 1)[0], !_s) throw Error("Could not get empty media stream audio track");
		_s.enabled = !1;
	}
	return _s.clone();
}
var U = class {
	get isResolved() {
		return this._isResolved;
	}
	constructor(e, t) {
		this._isResolved = !1, this.onFinally = t, this.promise = new Promise((t, n) => E(this, void 0, void 0, function* () {
			this.resolve = t, this.reject = n, e && (yield e(t, n));
		})).finally(() => {
			var e;
			this._isResolved = !0, (e = this.onFinally) == null || e.call(this);
		});
	}
};
function ys(e) {
	return so.includes(e);
}
function bs(e) {
	if (typeof e == "string" || typeof e == "number") return e;
	if (Array.isArray(e)) return e[0];
	if (e.exact !== void 0) return Array.isArray(e.exact) ? e.exact[0] : e.exact;
	if (e.ideal !== void 0) return Array.isArray(e.ideal) ? e.ideal[0] : e.ideal;
	throw Error("could not unwrap constraint");
}
function xs(e) {
	return e.startsWith("http") ? e.replace(/^(http)/, "ws") : e;
}
function Ss(e) {
	return e.startsWith("ws") ? e.replace(/^(ws)/, "http") : e;
}
function Cs(e, t) {
	return e.segments.map((e) => {
		let n = e.id, r = e.text, i = e.language, a = e.startTime, o = e.endTime, s = e.final, c = t.get(n) ?? Date.now(), l = Date.now();
		return s ? t.delete(n) : t.set(n, c), {
			id: n,
			text: r,
			startTime: Number.parseInt(a.toString()),
			endTime: Number.parseInt(o.toString()),
			final: s,
			language: i,
			firstReceivedTime: c,
			lastReceivedTime: l
		};
	});
}
function ws(e) {
	let t = e.id, n = e.timestamp, r = e.message, i = e.editTimestamp;
	return {
		id: t,
		timestamp: Number.parseInt(n.toString()),
		editTimestamp: i ? Number.parseInt(i.toString()) : void 0,
		message: r
	};
}
function Ts(e) {
	switch (e.reason) {
		case k.LeaveRequest: return e.context;
		case k.Cancelled: return tn.CLIENT_INITIATED;
		case k.NotAllowed: return tn.USER_REJECTED;
		case k.ServerUnreachable: return tn.JOIN_FAILURE;
		default: return tn.UNKNOWN_REASON;
	}
}
function Es(e) {
	return e === void 0 ? void 0 : Number(e);
}
function Ds(e) {
	return e === void 0 ? void 0 : BigInt(e);
}
function Os(e) {
	return !!e && !(e instanceof MediaStreamTrack) && e.isLocal;
}
function ks(e) {
	return !!e && e.kind == B.Kind.Audio;
}
function As(e) {
	return !!e && e.kind == B.Kind.Video;
}
function js(e) {
	return Os(e) && As(e);
}
function Ms(e) {
	return Os(e) && ks(e);
}
function Ns(e) {
	return !!e && !e.isLocal;
}
function Ps(e) {
	return !!e && !e.isLocal;
}
function Fs(e) {
	return Ns(e) && As(e);
}
function Is(e) {
	return e.isLocal;
}
function Ls(e, t) {
	let n = [], r = new TextEncoder().encode(e);
	for (; r.length > t;) {
		let e = t;
		for (; e > 0;) {
			let t = r[e];
			if (t !== void 0 && (t & 192) != 128) break;
			e--;
		}
		n.push(r.slice(0, e)), r = r.slice(e);
	}
	return r.length > 0 && n.push(r), n;
}
function Rs(e) {
	let t = e.get("Cache-Control");
	if (t) {
		let e = t.match(/(?:^|[,\s])max-age=(\d+)/)?.[1];
		if (e) return parseInt(e, 10);
	}
}
function zs() {
	return typeof CompressionStream < "u";
}
function Bs() {
	return zs() && !qo();
}
function Vs(e, t) {
	let n = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : !1, r = Hs(e, t);
	return n ? r : Gs(r, "v1");
}
function Hs(e, t) {
	let n = new URL(xs(e));
	return t.forEach((e, t) => {
		n.searchParams.set(t, e);
	}), Gs(n, "rtc");
}
function Us(e) {
	return Gs(new URL(Ss(e)), "validate");
}
function Ws(e) {
	return e.endsWith("/") ? e : `${e}/`;
}
function Gs(e, t) {
	return e.pathname = `${Ws(e.pathname)}${t}`, e;
}
function Ks(e) {
	if (typeof e == "string") return er.fromJson(JSON.parse(e), { ignoreUnknownFields: !0 });
	if (e instanceof ArrayBuffer) return er.fromBinary(new Uint8Array(e));
	throw Error(`could not decode websocket message: ${typeof e}`);
}
function qs(e) {
	let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "Unknown reason";
	if (!(e instanceof AbortSignal)) return t;
	let n = e.reason;
	switch (typeof n) {
		case "string": return n;
		case "object": return n instanceof Error ? n.message : t;
		default: return "toString" in n ? n.toString() : t;
	}
}
var Js = "lk_e2ee", Ys;
(function(e) {
	e.SetKey = "setKey", e.RatchetRequest = "ratchetRequest", e.KeyRatcheted = "keyRatcheted";
})(Ys ||= {});
var Xs;
(function(e) {
	e.KeyRatcheted = "keyRatcheted";
})(Xs ||= {});
var Zs;
(function(e) {
	e.ParticipantEncryptionStatusChanged = "participantEncryptionStatusChanged", e.EncryptionError = "encryptionError";
})(Zs ||= {});
var Qs;
(function(e) {
	e.Error = "cryptorError";
})(Qs ||= {});
function $s() {
	return tc() || ec();
}
function ec() {
	return typeof window < "u" && window.RTCRtpScriptTransform !== void 0;
}
function tc() {
	return typeof window < "u" && window.RTCRtpSender !== void 0 && window.RTCRtpSender.prototype.createEncodedStreams !== void 0;
}
function nc(e) {
	if (e.value?.case !== "sipDtmf" && e.value?.case !== "metrics" && e.value?.case !== "speaker" && e.value?.case !== "transcription" && e.value?.case !== "encryptedPacket") return new xn({ value: e.value });
}
Oi.EventEmitter;
var rc;
(function(e) {
	e[e.InvalidKey = 0] = "InvalidKey", e[e.MissingKey = 1] = "MissingKey", e[e.InternalError = 2] = "InternalError";
})(rc ||= {});
function ic() {
	return Yo();
}
function ac(e) {
	return !!e?.worker && (tc() || ic());
}
function oc(e) {
	return !!(e?.timestamp || e?.frameId);
}
function sc(e) {
	let t = [];
	return e?.timestamp && t.push(an.PTF_USER_TIMESTAMP), e?.frameId && t.push(an.PTF_FRAME_ID), t;
}
function cc(e) {
	if (!e || e.length === 0) return;
	let t = {};
	return e.includes(an.PTF_USER_TIMESTAMP) && (t.timestamp = !0), e.includes(an.PTF_FRAME_ID) && (t.frameId = !0), t.timestamp || t.frameId ? t : void 0;
}
function lc(e) {
	let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 50, n = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {}, r, i = n.isImmediate ?? !1, a = n.callback ?? !1, o = n.maxWait, s = Date.now(), c = [];
	function l() {
		if (o !== void 0) {
			let e = Date.now() - s;
			if (e + t >= o) return o - e;
		}
		return t;
	}
	let u = function() {
		var t = [...arguments];
		let n = this;
		return new Promise((o, u) => {
			let d = function() {
				if (r = void 0, s = Date.now(), !i) {
					let r = e.apply(n, t);
					a && a(r), c.forEach((e) => {
						let t = e.resolve;
						return t(r);
					}), c = [];
				}
			}, f = i && r === void 0;
			if (r !== void 0 && N.clearTimeout(r), r = N.setTimeout(d, l()), f) {
				let r = e.apply(n, t);
				return a && a(r), o(r);
			}
			c.push({
				resolve: o,
				reject: u
			});
		});
	};
	return u.cancel = function(e) {
		r !== void 0 && N.clearTimeout(r), c.forEach((t) => {
			let n = t.reject;
			return n(e);
		}), c = [];
	}, u;
}
var uc = 2e3;
function dc(e, t) {
	if (!t) return 0;
	let n, r;
	return "bytesReceived" in e ? (n = e.bytesReceived, r = t.bytesReceived) : "bytesSent" in e && (n = e.bytesSent, r = t.bytesSent), n === void 0 || r === void 0 || e.timestamp === void 0 || t.timestamp === void 0 ? 0 : (n - r) * 8 * 1e3 / (e.timestamp - t.timestamp);
}
var fc = class extends B {
	constructor(e, t, n, r, i) {
		super(e, n, i), this.sid = t, this.receiver = r;
	}
	get isLocal() {
		return !1;
	}
	setMuted(e) {
		this.isMuted !== e && (this.isMuted = e, this._mediaStreamTrack.enabled = !e, this.emit(e ? L.Muted : L.Unmuted, this));
	}
	setMediaStream(e) {
		this.mediaStream = e;
		let t = (n) => {
			n.track === this._mediaStreamTrack && (e.removeEventListener("removetrack", t), this.receiver && "playoutDelayHint" in this.receiver && (this.receiver.playoutDelayHint = void 0), this.receiver = void 0, this._currentBitrate = 0, this.emit(L.Ended, this));
		};
		e.addEventListener("removetrack", t);
	}
	start() {
		this.startMonitor(), super.enable();
	}
	stop() {
		this.stopMonitor(), super.disable();
	}
	getRTCStatsReport() {
		return E(this, void 0, void 0, function* () {
			if (this.receiver?.getStats) return yield this.receiver.getStats();
		});
	}
	setPlayoutDelay(e) {
		this.receiver ? "playoutDelayHint" in this.receiver ? this.receiver.playoutDelayHint = e : this.log.warn("Playout delay not supported in this browser") : this.log.warn("Cannot set playout delay, track already ended");
	}
	getPlayoutDelay() {
		if (this.receiver) {
			if ("playoutDelayHint" in this.receiver) return this.receiver.playoutDelayHint;
			this.log.warn("Playout delay not supported in this browser");
		} else this.log.warn("Cannot get playout delay, track already ended");
		return 0;
	}
	startMonitor() {
		this.monitorInterval ||= setInterval(() => this.monitorReceiver(), uc), Eo() && this.registerTimeSyncUpdate();
	}
	registerTimeSyncUpdate() {
		let e = () => {
			this.timeSyncHandle = requestAnimationFrame(() => e());
			let t = this.receiver?.getSynchronizationSources()[0];
			if (t) {
				let e = t.timestamp, n = t.rtpTimestamp;
				n && this.rtpTimestamp !== n && (this.emit(L.TimeSyncUpdate, {
					timestamp: e,
					rtpTimestamp: n
				}), this.rtpTimestamp = n);
			}
		};
		e();
	}
}, pc = 100, mc = class extends fc {
	constructor(e, t, n, r, i) {
		super(e, t, B.Kind.Video, n, i), this.elementInfos = [], this.monitorReceiver = () => E(this, void 0, void 0, function* () {
			if (!this.receiver) {
				this._currentBitrate = 0;
				return;
			}
			let e = yield this.getReceiverStats();
			e && this.prevStats && this.receiver && (this._currentBitrate = dc(e, this.prevStats)), this.prevStats = e;
		}), this.debouncedHandleResize = lc(() => {
			this.updateDimensions();
		}, pc), this.adaptiveStreamSettings = r;
	}
	get isAdaptiveStream() {
		return this.adaptiveStreamSettings !== void 0;
	}
	lookupFrameMetadata(e) {
		let t = e.rtpTimestamp;
		return this.packetTrailerExtractor?.lookupMetadata(t);
	}
	setStreamState(e) {
		super.setStreamState(e), this.log.debug("setStreamState", e), this.isAdaptiveStream && e === B.StreamState.Active && this.updateVisibility();
	}
	get mediaStreamTrack() {
		return this._mediaStreamTrack;
	}
	setMuted(e) {
		super.setMuted(e), this.attachedElements.forEach((t) => {
			e ? Io(this._mediaStreamTrack, t) : Fo(this._mediaStreamTrack, t);
		});
	}
	attach(e) {
		if (e ? super.attach(e) : e = super.attach(), this.adaptiveStreamSettings && this.elementInfos.find((t) => t.element === e) === void 0) {
			let t = new hc(e);
			this.observeElementInfo(t);
		}
		return e;
	}
	observeElementInfo(e) {
		this.adaptiveStreamSettings && this.elementInfos.find((t) => t === e) === void 0 ? (e.handleResize = () => {
			this.debouncedHandleResize();
		}, e.handleVisibilityChanged = () => {
			this.updateVisibility();
		}, this.elementInfos.push(e), e.observe(), this.debouncedHandleResize(), this.updateVisibility()) : this.log.warn("visibility resize observer not triggered", this.logContext);
	}
	stopObservingElementInfo(e) {
		if (!this.isAdaptiveStream) {
			this.log.warn("stopObservingElementInfo ignored", this.logContext);
			return;
		}
		let t = this.elementInfos.filter((t) => t === e);
		for (let e of t) e.stopObserving();
		this.elementInfos = this.elementInfos.filter((t) => t !== e), this.updateVisibility(), this.debouncedHandleResize();
	}
	detach(e) {
		if (e) return this.stopObservingElement(e), super.detach(e);
		let t = super.detach();
		for (let e of t) this.stopObservingElement(e);
		return t;
	}
	getDecoderImplementation() {
		return this.prevStats?.decoderImplementation;
	}
	getReceiverStats() {
		return E(this, void 0, void 0, function* () {
			if (!this.receiver || !this.receiver.getStats) return;
			let e = yield this.receiver.getStats(), t, n = "", r = /* @__PURE__ */ new Map();
			return e.forEach((e) => {
				e.type === "inbound-rtp" ? (n = e.codecId, t = {
					type: "video",
					streamId: e.id,
					framesDecoded: e.framesDecoded,
					framesDropped: e.framesDropped,
					framesReceived: e.framesReceived,
					packetsReceived: e.packetsReceived,
					packetsLost: e.packetsLost,
					frameWidth: e.frameWidth,
					frameHeight: e.frameHeight,
					pliCount: e.pliCount,
					firCount: e.firCount,
					nackCount: e.nackCount,
					jitter: e.jitter,
					timestamp: e.timestamp,
					bytesReceived: e.bytesReceived,
					decoderImplementation: e.decoderImplementation
				}) : e.type === "codec" && r.set(e.id, e);
			}), t && n !== "" && r.get(n) && (t.mimeType = r.get(n).mimeType), t;
		});
	}
	stopObservingElement(e) {
		let t = this.elementInfos.filter((t) => t.element === e);
		for (let e of t) this.stopObservingElementInfo(e);
	}
	handleAppVisibilityChanged() {
		let e = Object.create(null, { handleAppVisibilityChanged: { get: () => super.handleAppVisibilityChanged } });
		return E(this, void 0, void 0, function* () {
			yield e.handleAppVisibilityChanged.call(this), this.isAdaptiveStream && this.updateVisibility();
		});
	}
	updateVisibility(e) {
		let t = this.elementInfos.reduce((e, t) => Math.max(e, t.visibilityChangedAt || 0), 0), n = this.adaptiveStreamSettings?.pauseVideoInBackground ?? !0 ? this.isInBackground : !1, r = this.elementInfos.some((e) => e.pictureInPicture), i = this.elementInfos.some((e) => e.visible) && !n || r;
		if (!(this.lastVisible === i && !e)) {
			if (!i && Date.now() - t < pc) {
				N.setTimeout(() => {
					this.updateVisibility();
				}, pc);
				return;
			}
			this.lastVisible = i, this.emit(L.VisibilityChanged, i, this);
		}
	}
	updateDimensions() {
		let e = 0, t = 0, n = this.getPixelDensity();
		for (let r of this.elementInfos) {
			let i = r.width() * n, a = r.height() * n;
			i + a > e + t && (e = i, t = a);
		}
		this.lastDimensions?.width === e && this.lastDimensions?.height === t || (this.lastDimensions = {
			width: e,
			height: t
		}, this.emit(L.VideoDimensionsChanged, this.lastDimensions, this));
	}
	getPixelDensity() {
		let e = this.adaptiveStreamSettings?.pixelDensity;
		return e === "screen" ? ss() : e || (ss() > 2 ? 2 : 1);
	}
}, hc = class {
	get visible() {
		return this.isPiP || this.isIntersecting;
	}
	get pictureInPicture() {
		return this.isPiP;
	}
	constructor(e, t) {
		this.onVisibilityChanged = (e) => {
			var t;
			let n = e.target, r = e.isIntersecting;
			n === this.element && (this.isIntersecting = r, this.isPiP = gc(this.element), this.visibilityChangedAt = Date.now(), (t = this.handleVisibilityChanged) == null || t.call(this));
		}, this.onEnterPiP = () => {
			var e;
			(e = window.documentPictureInPicture?.window) == null || e.addEventListener("pagehide", this.onLeavePiP), queueMicrotask(() => {
				requestAnimationFrame(() => {
					var e;
					this.isPiP = gc(this.element), (e = this.handleVisibilityChanged) == null || e.call(this);
				});
			});
		}, this.onLeavePiP = () => {
			var e;
			this.isPiP = gc(this.element), (e = this.handleVisibilityChanged) == null || e.call(this);
		}, this.element = e, this.isIntersecting = t ?? _c(e), this.isPiP = H() && gc(e), this.visibilityChangedAt = 0;
	}
	width() {
		return this.element.clientWidth;
	}
	height() {
		return this.element.clientHeight;
	}
	observe() {
		var e, t;
		this.isIntersecting = _c(this.element), this.isPiP = gc(this.element), this.element.handleResize = () => {
			var e;
			(e = this.handleResize) == null || e.call(this);
		}, this.element.handleVisibilityChanged = this.onVisibilityChanged, ms().observe(this.element), fs().observe(this.element), this.element.addEventListener("enterpictureinpicture", this.onEnterPiP), this.element.addEventListener("leavepictureinpicture", this.onLeavePiP), (e = window.documentPictureInPicture) == null || e.addEventListener("enter", this.onEnterPiP), (t = window.documentPictureInPicture?.window) == null || t.addEventListener("pagehide", this.onLeavePiP);
	}
	stopObserving() {
		var e, t, n, r;
		(e = ms()) == null || e.unobserve(this.element), (t = fs()) == null || t.unobserve(this.element), this.element.removeEventListener("enterpictureinpicture", this.onEnterPiP), this.element.removeEventListener("leavepictureinpicture", this.onLeavePiP), (n = window.documentPictureInPicture) == null || n.removeEventListener("enter", this.onEnterPiP), (r = window.documentPictureInPicture?.window) == null || r.removeEventListener("pagehide", this.onLeavePiP);
	}
};
function gc(e) {
	return document.pictureInPictureElement === e ? !0 : window.documentPictureInPicture?.window ? _c(e, window.documentPictureInPicture?.window) : !1;
}
function _c(e, t) {
	let n = t || window, r = e.offsetTop, i = e.offsetLeft, a = e.offsetWidth, o = e.offsetHeight, s = e.hidden, c = getComputedStyle(e).display;
	for (; e.offsetParent;) e = e.offsetParent, r += e.offsetTop, i += e.offsetLeft;
	return r < n.pageYOffset + n.innerHeight && i < n.pageXOffset + n.innerWidth && r + o > n.pageYOffset && i + a > n.pageXOffset && !s && c !== "none";
}
var vc = class extends Oi.EventEmitter {
	constructor(e, t) {
		super(), this.decryptDataRequests = /* @__PURE__ */ new Map(), this.encryptDataRequests = /* @__PURE__ */ new Map(), this.onWorkerMessage = (e) => {
			let t = e.data, n = t.kind, r = t.data;
			switch (n) {
				case "error":
					if (w.error(r.error.message), r.uuid) {
						let e = this.decryptDataRequests.get(r.uuid);
						if (e?.reject) {
							e.reject(r.error);
							break;
						}
						let t = this.encryptDataRequests.get(r.uuid);
						if (t?.reject) {
							t.reject(r.error);
							break;
						}
					}
					this.emit(Zs.EncryptionError, r.error, r.participantIdentity);
					break;
				case "initAck":
					r.enabled && this.keyProvider.getKeys().forEach((e) => {
						this.postKey(e, !1);
					});
					break;
				case "enable":
					if (r.enabled && this.keyProvider.getKeys().forEach((e) => {
						this.postKey(e, !1);
					}), this.encryptionEnabled !== r.enabled && r.participantIdentity === this.room?.localParticipant.identity) this.emit(Zs.ParticipantEncryptionStatusChanged, r.enabled, this.room.localParticipant), this.encryptionEnabled = r.enabled;
					else if (r.participantIdentity) {
						let e = this.room?.getParticipantByIdentity(r.participantIdentity);
						if (!e) throw TypeError(`couldn't set encryption status, participant not found${r.participantIdentity}`);
						this.emit(Zs.ParticipantEncryptionStatusChanged, r.enabled, e);
					}
					break;
				case "ratchetKey":
					this.keyProvider.emit(Ys.KeyRatcheted, r.ratchetResult, r.participantIdentity, r.keyIndex);
					break;
				case "decryptDataResponse":
					let e = this.decryptDataRequests.get(r.uuid);
					e?.resolve && e.resolve(r);
					break;
				case "encryptDataResponse":
					let t = this.encryptDataRequests.get(r.uuid);
					t?.resolve && t.resolve(r);
					break;
				case "packetTrailerMetadata":
					this.handlePacketTrailerMetadata(r.trackId, r.rtpTimestamp, r.ssrc, r.metadata);
					break;
			}
		}, this.onWorkerError = (e) => {
			w.error("e2ee worker encountered an error:", { error: e.error }), this.emit(Zs.EncryptionError, e.error, void 0);
		}, this.keyProvider = e.keyProvider, this.worker = e.worker, this.encryptionEnabled = !1, this.dataChannelEncryptionEnabled = t;
	}
	get isEnabled() {
		return this.encryptionEnabled;
	}
	get isDataChannelEncryptionEnabled() {
		return this.isEnabled && this.dataChannelEncryptionEnabled;
	}
	setup(e) {
		if (!$s()) throw new Xa("tried to setup end-to-end encryption on an unsupported browser");
		if (w.info("setting up e2ee"), e !== this.room) {
			this.room = e, this.setupEventListeners(e, this.keyProvider);
			let t = {
				kind: "init",
				data: {
					keyProviderOptions: this.keyProvider.getOptions(),
					loglevel: hi.getLevel()
				}
			};
			this.worker && (w.info("initializing worker", { worker: this.worker }), this.worker.onmessage = this.onWorkerMessage, this.worker.onerror = this.onWorkerError, this.worker.postMessage(t));
		}
	}
	setParticipantCryptorEnabled(e, t) {
		w.debug(`set e2ee to ${e} for participant ${t}`), this.postEnable(e, t);
	}
	setSifTrailer(e) {
		!e || e.length === 0 ? w.warn("ignoring server sent trailer as it's empty") : this.postSifTrailer(e);
	}
	handlePacketTrailerMetadata(e, t, n, r) {
		if (this.room) {
			for (let i of [this.room.localParticipant, ...this.room.remoteParticipants.values()]) for (let a of i.trackPublications.values()) if (a.track && a.track.mediaStreamID === e && a.track instanceof mc && a.track.packetTrailerExtractor) {
				a.track.packetTrailerExtractor.storeMetadata(t, n, r);
				return;
			}
		}
	}
	setupEngine(e) {
		e.on(I.RTPVideoMapUpdate, (e) => {
			this.postRTPMap(e);
		});
	}
	setupEventListeners(e, t) {
		e.on(P.TrackPublished, (e, t) => this.setParticipantCryptorEnabled(e.trackInfo.encryption !== x.NONE, t.identity)), e.on(P.ConnectionStateChanged, (t) => {
			t === Q.Connected && e.remoteParticipants.forEach((e) => {
				e.trackPublications.forEach((t) => {
					this.setParticipantCryptorEnabled(t.trackInfo.encryption !== x.NONE, e.identity);
				});
			});
		}).on(P.TrackUnsubscribed, (e, t, n) => {
			var r;
			let i = {
				kind: "removeTransform",
				data: {
					participantIdentity: n.identity,
					trackId: e.mediaStreamID
				}
			};
			(r = this.worker) == null || r.postMessage(i);
		}).on(P.TrackSubscribed, (e, t, n) => {
			this.setupE2EEReceiver(e, n.identity, t.trackInfo);
		}).on(P.SignalConnected, () => {
			if (!this.room) throw TypeError("expected room to be present on signal connect");
			let e = t.getLatestManuallySetKeyIndex();
			t.getKeys().forEach((t) => {
				this.postKey(t, e === (t.keyIndex ?? 0));
			}), this.setParticipantCryptorEnabled(this.room.localParticipant.isE2EEEnabled, this.room.localParticipant.identity);
		}), e.localParticipant.on(F.LocalSenderCreated, (e, t) => E(this, void 0, void 0, function* () {
			this.setupE2EESender(t, e);
		})), e.localParticipant.on(F.LocalTrackPublished, (e) => {
			if (!As(e.track) || !Zo()) return;
			let t = {
				kind: "updateCodec",
				data: {
					trackId: e.track.mediaStreamID,
					codec: wo(e.trackInfo.codecs[0].mimeType),
					participantIdentity: this.room.localParticipant.identity,
					hasPacketTrailer: !1
				}
			};
			this.worker.postMessage(t);
		}), t.on(Ys.SetKey, (e, t) => this.postKey(e, t ?? !0)).on(Ys.RatchetRequest, (e, t) => this.postRatchetRequest(e, t));
	}
	encryptData(e) {
		return E(this, void 0, void 0, function* () {
			if (!this.worker) throw Error("could not encrypt data, worker is missing");
			let t = crypto.randomUUID(), n = {
				kind: "encryptDataRequest",
				data: {
					uuid: t,
					payload: e,
					participantIdentity: this.room.localParticipant.identity
				}
			}, r = new U();
			return r.onFinally = () => {
				this.encryptDataRequests.delete(t);
			}, this.encryptDataRequests.set(t, r), this.worker.postMessage(n), r.promise;
		});
	}
	handleEncryptedData(e, t, n, r) {
		if (!this.worker) throw Error("could not handle encrypted data, worker is missing");
		let i = crypto.randomUUID(), a = {
			kind: "decryptDataRequest",
			data: {
				uuid: i,
				payload: e,
				iv: t,
				participantIdentity: n,
				keyIndex: r
			}
		}, o = new U();
		return o.onFinally = () => {
			this.decryptDataRequests.delete(i);
		}, this.decryptDataRequests.set(i, o), this.worker.postMessage(a), o.promise;
	}
	postRatchetRequest(e, t) {
		if (!this.worker) throw Error("could not ratchet key, worker is missing");
		let n = {
			kind: "ratchetRequest",
			data: {
				participantIdentity: e,
				keyIndex: t
			}
		};
		this.worker.postMessage(n);
	}
	postKey(e, t) {
		let n = e.key, r = e.participantIdentity, i = e.keyIndex;
		if (!this.worker) throw Error("could not set key, worker is missing");
		let a = {
			kind: "setKey",
			data: {
				participantIdentity: r,
				isPublisher: r === this.room?.localParticipant.identity,
				key: n,
				keyIndex: i,
				updateCurrentKeyIndex: t
			}
		};
		this.worker.postMessage(a);
	}
	postEnable(e, t) {
		if (this.worker) {
			let n = {
				kind: "enable",
				data: {
					enabled: e,
					participantIdentity: t
				}
			};
			this.worker.postMessage(n);
		} else throw ReferenceError("failed to enable e2ee, worker is not ready");
	}
	postRTPMap(e) {
		if (!this.worker) throw TypeError("could not post rtp map, worker is missing");
		if (!this.room?.localParticipant.identity) throw TypeError("could not post rtp map, local participant identity is missing");
		let t = {
			kind: "setRTPMap",
			data: {
				map: e,
				participantIdentity: this.room.localParticipant.identity
			}
		};
		this.worker.postMessage(t);
	}
	postSifTrailer(e) {
		if (!this.worker) throw Error("could not post SIF trailer, worker is missing");
		let t = {
			kind: "setSifTrailer",
			data: { trailer: e }
		};
		this.worker.postMessage(t);
	}
	setupE2EEReceiver(e, t, n) {
		if (!e.receiver) return;
		if (!n?.mimeType || n.mimeType === "") throw TypeError("MimeType missing from trackInfo, cannot set up E2EE cryptor");
		let r = e.kind === "video" && !!n.packetTrailerFeatures && n.packetTrailerFeatures.length > 0;
		this.handleReceiver(e.receiver, e.mediaStreamID, t, e.kind === "video" ? wo(n.mimeType) : void 0, r);
	}
	setupE2EESender(e, t) {
		if (!Os(e) || !t) {
			t || w.warn("early return because sender is not ready");
			return;
		}
		this.handleSender(t, e.mediaStreamID, void 0, As(e) ? e.publishOptions?.packetTrailer : void 0);
	}
	handleReceiver(e, t, n, r, i) {
		return E(this, void 0, void 0, function* () {
			if (this.worker) {
				if (Yo()) {
					let a = {
						kind: "decode",
						participantIdentity: n,
						trackId: t,
						codec: r,
						hasPacketTrailer: i
					};
					e.transform = new RTCRtpScriptTransform(this.worker, a);
				} else {
					if (Js in e && r) {
						let e = {
							kind: "updateCodec",
							data: {
								trackId: t,
								codec: r,
								participantIdentity: n,
								hasPacketTrailer: i
							}
						};
						this.worker.postMessage(e);
						return;
					}
					let a = e.writableStream, o = e.readableStream;
					if (!a || !o) {
						let t = e.createEncodedStreams();
						e.writableStream = t.writable, a = t.writable, e.readableStream = t.readable, o = t.readable;
					}
					let s = {
						kind: "decode",
						data: {
							readableStream: o,
							writableStream: a,
							trackId: t,
							codec: r,
							participantIdentity: n,
							isReuse: Js in e,
							hasPacketTrailer: i
						}
					};
					this.worker.postMessage(s, [o, a]);
				}
				e[Js] = !0;
			}
		});
	}
	handleSender(e, t, n, r) {
		if (!(Js in e || !this.worker)) {
			if (!this.room?.localParticipant.identity || this.room.localParticipant.identity === "") throw TypeError("local identity needs to be known in order to set up encrypted sender");
			if (Yo()) {
				w.info("initialize script transform");
				let i = {
					kind: "encode",
					participantIdentity: this.room.localParticipant.identity,
					trackId: t,
					codec: n,
					hasPacketTrailer: oc(r),
					packetTrailer: r
				};
				e.transform = new RTCRtpScriptTransform(this.worker, i);
			} else {
				w.info("initialize encoded streams");
				let i = e.createEncodedStreams(), a = {
					kind: "encode",
					data: {
						readableStream: i.readable,
						writableStream: i.writable,
						codec: n,
						trackId: t,
						participantIdentity: this.room.localParticipant.identity,
						isReuse: !1,
						hasPacketTrailer: oc(r),
						packetTrailer: r
					}
				};
				this.worker.postMessage(a, [i.readable, i.writable]);
			}
			e[Js] = !0;
		}
	}
}, yc = 300, bc = class {
	constructor() {
		this.metadataMap = /* @__PURE__ */ new Map(), this.activeSsrc = 0;
	}
	storeMetadata(e, t, n) {
		for (this.activeSsrc !== 0 && this.activeSsrc !== t && this.metadataMap.clear(), this.activeSsrc = t; this.metadataMap.size >= yc;) {
			let e = this.metadataMap.keys().next().value;
			this.metadataMap.delete(e);
		}
		this.metadataMap.set(e, n);
	}
	lookupMetadata(e) {
		return this.metadataMap.get(e);
	}
	dispose() {
		this.metadataMap.clear(), this.activeSsrc = 0;
	}
}, xc = class {
	constructor(e) {
		this.extractors = /* @__PURE__ */ new Map(), this.workerPipelines = /* @__PURE__ */ new Map(), this.onWorkerMessage = (e) => {
			let t = e.data;
			if (t.kind === "metadata") {
				let e = this.extractors.get(t.data.trackId);
				e && e.storeMetadata(t.data.rtpTimestamp, t.data.ssrc, t.data.metadata);
			}
		}, this.onWorkerError = (e) => {
			w.error("packet trailer worker encountered an error:", { error: e.error });
		}, this.worker = e?.worker;
	}
	setup(e) {
		e !== this.room && (this.room = e, this.worker && (this.worker.onmessage = this.onWorkerMessage, this.worker.onerror = this.onWorkerError, this.worker.postMessage({ kind: "init" })), e.on(P.TrackSubscribed, (e, t, n) => {
			e.kind === "video" && this.setupReceiver(e, t.trackInfo);
		}).on(P.TrackUnsubscribed, (e) => {
			this.teardownTrack(e);
		}).on(P.Disconnected, () => {
			this.cleanup();
		}));
	}
	setupReceiver(e, t) {
		let n = e.receiver;
		if (!n) return;
		if (!(t?.packetTrailerFeatures && t.packetTrailerFeatures.length > 0)) {
			this.room?.hasE2EESetup || this.setupPassthroughReceiver(n, e.mediaStreamID);
			return;
		}
		if (!ac(this.worker ? { worker: this.worker } : void 0) && !this.room?.hasE2EESetup) {
			w.warn("packet trailer transform not supported; skipping extraction");
			return;
		}
		let r = new bc(), i = e.mediaStreamID;
		this.extractors.set(i, r), e.packetTrailerExtractor = r, !this.room?.hasE2EESetup && this.setupWorkerReceiver(n, i, !0);
	}
	setupPassthroughReceiver(e, t) {
		if (ic()) {
			"transform" in e && (e.transform = null);
			return;
		}
		if (this.worker && ac({ worker: this.worker }) && !this.workerPipelines.has(e)) {
			this.setupWorkerReceiver(e, t, !1);
			return;
		}
		this.worker && this.workerPipelines.has(e) && this.setupWorkerReceiver(e, t, !1);
	}
	setupWorkerReceiver(e, t) {
		let n = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : !0, r = this.worker;
		if (!r) return;
		if (ic()) {
			e.transform = new RTCRtpScriptTransform(r, {
				kind: "decode",
				trackId: t
			});
			return;
		}
		let i = this.workerPipelines.get(e);
		if (i) {
			let a = {
				kind: "updateTrackId",
				data: {
					oldTrackId: i,
					newTrackId: t,
					hasPacketTrailer: n
				}
			};
			r.postMessage(a), this.workerPipelines.set(e, t);
			return;
		}
		if (!("createEncodedStreams" in e)) {
			w.warn("createEncodedStreams not supported");
			return;
		}
		let a;
		try {
			a = e.createEncodedStreams();
		} catch (e) {
			w.warn("failed to create encoded streams", { error: e });
			return;
		}
		let o = {
			kind: "decode",
			data: {
				readableStream: a.readable,
				writableStream: a.writable,
				trackId: t,
				hasPacketTrailer: n
			}
		};
		r.postMessage(o, [a.readable, a.writable]), this.workerPipelines.set(e, t);
	}
	teardownTrack(e) {
		let t = e.mediaStreamID, n = this.extractors.get(t);
		n && (n.dispose(), this.extractors.delete(t)), e instanceof mc && (e.packetTrailerExtractor = void 0);
	}
	cleanup() {
		var e;
		for (let e of this.extractors.values()) e.dispose();
		this.extractors.clear(), this.workerPipelines.clear(), (e = this.worker) == null || e.terminate();
	}
}, Sc = 500, Cc = 15e3, wc = class e {
	constructor() {
		this.failedConnectionAttempts = /* @__PURE__ */ new Map(), this.backOffPromises = /* @__PURE__ */ new Map();
	}
	static getInstance() {
		return this._instance ||= new e(), this._instance;
	}
	addFailedConnectionAttempt(e) {
		let t = is(new URL(e));
		if (!t) return;
		let n = this.failedConnectionAttempts.get(t) ?? 0;
		this.failedConnectionAttempts.set(t, n + 1), this.backOffPromises.set(t, V(Math.min(Sc * 2 ** n, Cc)));
	}
	getBackOffPromise(e) {
		let t = new URL(e), n = t && is(t);
		return n && this.backOffPromises.get(n) || Promise.resolve();
	}
	resetFailedConnectionAttempts(e) {
		let t = new URL(e), n = t && is(t);
		n && (this.failedConnectionAttempts.set(n, 0), this.backOffPromises.set(n, Promise.resolve()));
	}
	resetAll() {
		this.backOffPromises.clear(), this.failedConnectionAttempts.clear();
	}
};
wc._instance = null;
var Tc = "default", Ec = class e {
	constructor() {
		this._previousDevices = [];
	}
	static getInstance() {
		return this.instance === void 0 && (this.instance = new e()), this.instance;
	}
	get previousDevices() {
		return this._previousDevices;
	}
	getDevices(t) {
		return E(this, arguments, void 0, function(t) {
			var n = this;
			let r = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !0;
			return function* () {
				if (e.userMediaPromiseMap?.size > 0) {
					w.debug("awaiting getUserMedia promise");
					try {
						t ? yield e.userMediaPromiseMap.get(t) : yield Promise.all(e.userMediaPromiseMap.values());
					} catch {
						w.warn("error waiting for media permissons");
					}
				}
				let i = yield navigator.mediaDevices.enumerateDevices();
				if (r && !(Xo() && n.hasDeviceInUse(t)) && (i.filter((e) => e.kind === t).length === 0 || i.some((e) => {
					let n = e.label === "", r = t ? e.kind === t : !0;
					return n && r;
				}))) {
					let e = {
						video: t !== "audioinput" && t !== "audiooutput",
						audio: t !== "videoinput" && { deviceId: { ideal: "default" } }
					}, n = yield navigator.mediaDevices.getUserMedia(e);
					i = yield navigator.mediaDevices.enumerateDevices(), n.getTracks().forEach((e) => {
						e.stop();
					});
				}
				return n._previousDevices = i, t && (i = i.filter((e) => e.kind === t)), i;
			}();
		});
	}
	normalizeDeviceId(e, t, n) {
		return E(this, void 0, void 0, function* () {
			if (t !== Tc) return t;
			let r = yield this.getDevices(e), i = r.find((e) => e.deviceId === Tc);
			if (!i) {
				w.warn("could not reliably determine default device");
				return;
			}
			let a = r.find((e) => e.deviceId !== Tc && e.groupId === (n ?? i.groupId));
			if (!a) {
				w.warn("could not reliably determine default device");
				return;
			}
			return a?.deviceId;
		});
	}
	hasDeviceInUse(t) {
		return t ? e.userMediaPromiseMap.has(t) : e.userMediaPromiseMap.size > 0;
	}
};
Ec.mediaDeviceKinds = [
	"audioinput",
	"audiooutput",
	"videoinput"
], Ec.userMediaPromiseMap = /* @__PURE__ */ new Map();
var Dc = 65535, Oc = 4294967295, kc = class e {
	static u16(t) {
		return new e(t, Dc);
	}
	static u32(t) {
		return new e(t, Oc);
	}
	constructor(e, t) {
		if (this.value = e, e < 0) throw Error("WrapAroundUnsignedInt: cannot faithfully represent an integer smaller than 0");
		if (t > 2 ** 53 - 1) throw Error("WrapAroundUnsignedInt: cannot faithfully represent an integer bigger than MAX_SAFE_INTEGER.");
		this.maxSize = t, this.clamp();
	}
	clamp() {
		for (; this.value > this.maxSize;) this.value -= this.maxSize + 1;
		for (; this.value < 0;) this.value += this.maxSize + 1;
	}
	clone() {
		return new e(this.value, this.maxSize);
	}
	update(e) {
		this.value = e(this.value), this.clamp();
	}
	increment() {
		let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : 1;
		this.update((t) => t + e);
	}
	decrement() {
		let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : 1;
		this.update((t) => t - e);
	}
	getThenIncrement() {
		let t = this.value;
		return this.increment(), new e(t, this.maxSize);
	}
	isBefore(e) {
		let t = this.value >>> 0, n = (e.value >>> 0) - t >>> 0;
		return n !== 0 && n < this.maxSize + 1;
	}
}, Ac = class e {
	static fromRtpTicks(t) {
		return new e(t, 9e4);
	}
	static rtpRandom() {
		let t = Math.round(Math.random() * Oc);
		return e.fromRtpTicks(t);
	}
	constructor(e, t) {
		this.timestamp = kc.u32(e), this.rateInHz = t;
	}
	asTicks() {
		return this.timestamp.value;
	}
	clone() {
		return new e(this.timestamp.value, this.rateInHz);
	}
	wrappingAdd(e) {
		this.timestamp.increment(e);
	}
	isBefore(e) {
		return this.timestamp.isBefore(e.timestamp);
	}
}, jc = class e {
	constructor(e, t, n) {
		this.epoch = t, this.base = n, this.previous = n.clone(), this.rateInHz = e;
	}
	static startingNow(t, n) {
		return new e(n, /* @__PURE__ */ new Date(), t);
	}
	static startingAtTime(t, n, r) {
		return new e(r, t, n);
	}
	static rtpStartingNow(t) {
		return e.startingNow(t, 9e4);
	}
	static rtpStartingAtTime(t, n) {
		return e.startingAtTime(t, n, 9e4);
	}
	now() {
		return this.at(/* @__PURE__ */ new Date());
	}
	at(t) {
		let n = t.getTime() - this.epoch.getTime(), r = e.durationInMsToTicks(n, this.rateInHz), i = this.base.clone();
		return i.wrappingAdd(r), i.isBefore(this.previous) && (i = this.previous), this.previous = i.clone(), i.clone();
	}
	static durationInMsToTicks(e, t) {
		let n = (e * 1e6 * t + 5e8) / 1e9;
		return Math.round(n);
	}
};
function Mc(e) {
	if (e instanceof DataView) return e;
	if (e instanceof ArrayBuffer) return new DataView(e);
	if (e instanceof Uint8Array) return new DataView(e.buffer, e.byteOffset, e.byteLength);
	throw Error(`Error coercing ${e} to DataView - input was not DataView, ArrayBuffer, or Uint8Array.`);
}
var Nc;
(function(e) {
	e[e.Reserved = 0] = "Reserved", e[e.TooLarge = 1] = "TooLarge";
})(Nc ||= {});
var Pc = class e extends Ya {
	constructor(e, t) {
		super(19, e), this.name = "DataTrackHandleError", this.reason = t, this.reasonName = Nc[t];
	}
	isReason(e) {
		return this.reason === e;
	}
	static tooLarge() {
		return new e("Value too large to be a valid track handle", Nc.TooLarge);
	}
	static reserved(t) {
		return new e(`0x${t.toString(16)} is a reserved value.`, Nc.Reserved);
	}
}, Fc = { fromNumber(e) {
	if (e === 0) throw Pc.reserved(e);
	if (e > Dc) throw Pc.tooLarge();
	return e;
} }, Ic = class {
	constructor() {
		this.value = 0;
	}
	get() {
		return this.value += 1, this.value > Dc ? null : this.value;
	}
	reset() {
		this.value = 0;
	}
}, Lc = {
	from(e) {
		return {
			sid: e.sid,
			pubHandle: e.pubHandle,
			name: e.name,
			usesE2ee: e.encryption !== x.NONE
		};
	},
	toProtobuf(e) {
		return new hn({
			sid: e.sid,
			pubHandle: e.pubHandle,
			name: e.name,
			encryption: e.usesE2ee ? x.GCM : x.NONE
		});
	}
}, Rc;
(function(e) {
	e[e.WAITING = 0] = "WAITING", e[e.RUNNING = 1] = "RUNNING", e[e.COMPLETED = 2] = "COMPLETED";
})(Rc ||= {});
var zc = class {
	constructor() {
		this.pendingTasks = /* @__PURE__ */ new Map(), this.taskMutex = new i(), this.nextTaskIndex = 0;
	}
	run(e) {
		return E(this, void 0, void 0, function* () {
			let t = {
				id: this.nextTaskIndex++,
				enqueuedAt: Date.now(),
				status: Rc.WAITING
			};
			this.pendingTasks.set(t.id, t);
			let n = yield this.taskMutex.lock();
			try {
				return t.executedAt = Date.now(), t.status = Rc.RUNNING, yield e();
			} finally {
				t.status = Rc.COMPLETED, this.pendingTasks.delete(t.id), n();
			}
		});
	}
	flush() {
		return E(this, void 0, void 0, function* () {
			return this.run(() => E(this, void 0, void 0, function* () {}));
		});
	}
	snapshot() {
		return Array.from(this.pendingTasks.values());
	}
}, Bc = class {
	get readyState() {
		return this.ws.readyState;
	}
	constructor(e) {
		let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
		if (t.signal?.aborted) throw new DOMException("This operation was aborted", "AbortError");
		this.url = e;
		let n = new WebSocket(e, t.protocols ?? []);
		n.binaryType = "arraybuffer", this.ws = n;
		let r = function() {
			let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {}, t = e.closeCode, r = e.reason;
			return n.close(t, r);
		};
		this.opened = new D((e, t) => {
			let i = () => {
				t(A.websocket("Encountered websocket error during connection establishment"));
			};
			n.onopen = () => {
				e({
					readable: new ReadableStream({
						start(e) {
							n.onmessage = (t) => {
								let n = t.data;
								return e.enqueue(n);
							}, n.onerror = (t) => e.error(t);
						},
						cancel: r
					}),
					writable: new WritableStream({
						write(e) {
							n.send(e);
						},
						abort() {
							n.close();
						},
						close: r
					}),
					protocol: n.protocol,
					extensions: n.extensions
				}), n.removeEventListener("error", i);
			}, n.addEventListener("error", i);
		}), this.closed = new D((e, t) => {
			let r = () => E(this, void 0, void 0, function* () {
				let r = new D((e) => {
					n.readyState !== WebSocket.CLOSED && n.addEventListener("close", (t) => {
						e(t);
					}, { once: !0 });
				}), i = yield D.race([V(250), r]);
				i ? e(i) : t(A.websocket("Encountered unspecified websocket error without a timely close event"));
			});
			n.onclose = (t) => {
				let i = t.code, a = t.reason;
				e({
					closeCode: i,
					reason: a
				}), n.removeEventListener("error", r);
			}, n.addEventListener("error", r);
		}), t.signal && (t.signal.onabort = () => n.close()), this.close = r;
	}
}, Vc = [
	"syncState",
	"trickle",
	"offer",
	"answer",
	"simulate",
	"leave"
];
function Hc(e) {
	let t = Vc.indexOf(e.case) >= 0;
	return w.trace("request allowed to bypass queue:", {
		canPass: t,
		req: e
	}), t;
}
var W;
(function(e) {
	e[e.CONNECTING = 0] = "CONNECTING", e[e.CONNECTED = 1] = "CONNECTED", e[e.RECONNECTING = 2] = "RECONNECTING", e[e.DISCONNECTING = 3] = "DISCONNECTING", e[e.DISCONNECTED = 4] = "DISCONNECTED";
})(W ||= {});
var Uc = 250, Wc = class {
	get currentState() {
		return this.state;
	}
	get isDisconnected() {
		return this.state === W.DISCONNECTING || this.state === W.DISCONNECTED;
	}
	get isEstablishingConnection() {
		return this.state === W.CONNECTING || this.state === W.RECONNECTING;
	}
	getNextRequestId() {
		return this._requestId += 1, this._requestId;
	}
	constructor() {
		let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : !1, t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
		this.rtt = 0, this.state = W.DISCONNECTED, this.log = w, this._requestId = 0, this.useV0SignalPath = !1, this.resetCallbacks = () => {
			this.onAnswer = void 0, this.onLeave = void 0, this.onLocalTrackPublished = void 0, this.onLocalTrackUnpublished = void 0, this.onNegotiateRequested = void 0, this.onOffer = void 0, this.onRemoteMuteChanged = void 0, this.onSubscribedQualityUpdate = void 0, this.onTokenRefresh = void 0, this.onTrickle = void 0, this.onClose = void 0, this.onMediaSectionsRequirement = void 0;
		}, this.loggerContextCb = t.loggerContextCb, this.log = T(t.loggerName ?? C.Signal, () => this.logContext), this.useJSON = e, this.requestQueue = new zc(), this.queuedRequests = [], this.closingLock = new i(), this.connectionLock = new i(), this.state = W.DISCONNECTED;
	}
	get logContext() {
		return this.loggerContextCb?.call(this) ?? {};
	}
	join(e, t, n, r) {
		return E(this, arguments, void 0, function(e, t, n, r) {
			var i = this;
			let a = arguments.length > 4 && arguments[4] !== void 0 ? arguments[4] : !1, o = arguments.length > 5 ? arguments[5] : void 0;
			return function* () {
				return i.state = W.CONNECTING, i.options = n, yield i.connect(e, t, n, r, a, o);
			}();
		});
	}
	reconnect(e, t, n, r) {
		return E(this, void 0, void 0, function* () {
			if (!this.options) {
				this.log.warn("attempted to reconnect without signal options being set, ignoring");
				return;
			}
			return this.state = W.RECONNECTING, this.clearPingInterval(), yield this.connect(e, t, Object.assign(Object.assign({}, this.options), {
				reconnect: !0,
				sid: n,
				reconnectReason: r
			}), void 0, this.useV0SignalPath);
		});
	}
	connect(e, t, n, r) {
		return E(this, arguments, void 0, function(e, t, n, r) {
			var i = this;
			let a = arguments.length > 4 && arguments[4] !== void 0 ? arguments[4] : !1, o = arguments.length > 5 ? arguments[5] : void 0;
			return function* () {
				let s = yield i.connectionLock.lock();
				i.connectOptions = n, i.useV0SignalPath = a;
				let c = hs(n.clientInfoCapabilities), l = Vs(e, a ? qc(t, c, n) : yield Jc(t, c, n, o), a).toString(), u = Us(l).toString();
				return new Promise((e, t) => E(i, void 0, void 0, function* () {
					try {
						let i = !1, a = (e) => E(this, void 0, void 0, function* () {
							if (i) return;
							i = !0;
							let n = qs(e instanceof Event ? e.currentTarget : e, "Abort handler called");
							this.streamWriter && !this.isDisconnected ? this.sendLeave().then(() => this.close(n)).catch((e) => {
								this.log.error(e), this.close();
							}) : this.close(), o(), t(A.cancelled(n));
						});
						r?.addEventListener("abort", a);
						let o = () => {
							clearTimeout(s), r?.removeEventListener("abort", a);
						}, s = setTimeout(() => {
							a(A.timeout("room connection has timed out (signal)"));
						}, n.websocketTimeout), c = (e, t) => {
							this.handleSignalConnected(e, s, t);
						}, d = new URL(l);
						d.searchParams.has("access_token") && d.searchParams.set("access_token", "<redacted>"), this.log.info(`signal connecting to ${d}`, {
							reconnect: n.reconnect,
							reconnectReason: n.reconnectReason
						}), this.ws && (yield this.close(!1)), this.ws = new Bc(l);
						try {
							this.ws.closed.then((e) => {
								this.isEstablishingConnection && t(A.internal(`Websocket got closed during a (re)connection attempt: ${e.reason}`)), e.closeCode !== 1e3 && (this.log.warn("websocket closed", {
									reason: e.reason,
									code: e.closeCode,
									wasClean: e.closeCode === 1e3,
									state: this.state
								}), this.state === W.CONNECTED && this.handleOnClose(e.reason ?? "Unexpected WS error"));
							}).catch((e) => {
								this.isEstablishingConnection && t(A.internal(`Websocket error during a (re)connection attempt: ${e}`));
							});
							let r = yield this.ws.opened.catch((e) => E(this, void 0, void 0, function* () {
								if (this.state !== W.CONNECTED) {
									this.state = W.DISCONNECTED, clearTimeout(s), t(yield this.handleConnectionError(e, u));
									return;
								}
								this.handleWSError(e), t(e);
							}));
							if (clearTimeout(s), !r) return;
							let i = r.readable.getReader();
							this.streamWriter = r.writable.getWriter();
							let a = yield i.read();
							if (i.releaseLock(), !a.value) throw A.internal("no message received as first message");
							let o = Ks(a.value), l = this.validateFirstMessage(o, n.reconnect ?? !1);
							if (!l.isValid) {
								t(l.error);
								return;
							}
							o.message?.case === "join" && (this.pingTimeoutDuration = o.message.value.pingTimeout, this.pingIntervalDuration = o.message.value.pingInterval, this.pingTimeoutDuration && this.pingTimeoutDuration > 0 && this.log.debug("ping config", {
								timeout: this.pingTimeoutDuration,
								interval: this.pingIntervalDuration
							}), this.onJoined && this.onJoined(o.message.value)), c(r, l.shouldProcessFirstMessage ? o : void 0), e(l.response);
						} catch (e) {
							t(e);
						} finally {
							o();
						}
					} finally {
						s();
					}
				}));
			}();
		});
	}
	startReadingLoop(e, t) {
		return E(this, void 0, void 0, function* () {
			for (t && this.handleSignalResponse(t);;) {
				this.signalLatency && (yield V(this.signalLatency));
				let t = yield e.read(), n = t.done, r = t.value;
				if (n) break;
				let i = Ks(r);
				this.handleSignalResponse(i);
			}
		});
	}
	close() {
		return E(this, arguments, void 0, function() {
			var e = this;
			let t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : !0, n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "Close method called on signal client";
			return function* () {
				if ([W.DISCONNECTING || W.DISCONNECTED].includes(e.state)) {
					e.log.debug("ignoring signal close as it's already in disconnecting state");
					return;
				}
				let r = yield e.closingLock.lock();
				try {
					if (e.clearPingInterval(), t && (e.state = W.DISCONNECTING), e.ws) {
						e.ws.close({
							closeCode: 1e3,
							reason: n
						});
						let t = e.ws.closed;
						e.ws = void 0, e.streamWriter = void 0, yield Promise.race([t, V(Uc)]);
					}
				} catch (t) {
					e.log.debug("websocket error while closing", { error: t });
				} finally {
					t && (e.state = W.DISCONNECTED), r();
				}
			}();
		});
	}
	sendOffer(e, t) {
		this.log.debug("sending offer", { offerSdp: e.sdp }), this.sendRequest({
			case: "offer",
			value: Kc(e, t)
		});
	}
	sendAnswer(e, t) {
		return this.log.debug("sending answer", { answerSdp: e.sdp }), this.sendRequest({
			case: "answer",
			value: Kc(e, t)
		});
	}
	sendIceCandidate(e, t) {
		return this.log.debug("sending ice candidate", { candidate: e }), this.sendRequest({
			case: "trickle",
			value: new lr({
				candidateInit: JSON.stringify(e),
				target: t
			})
		});
	}
	sendMuteTrack(e, t) {
		return this.sendRequest({
			case: "mute",
			value: new ur({
				sid: e,
				muted: t
			})
		});
	}
	sendAddTrack(e) {
		return this.sendRequest({
			case: "addTrack",
			value: e
		});
	}
	sendUpdateLocalMetadata(e, t) {
		return E(this, arguments, void 0, function(e, t) {
			var n = this;
			let r = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
			return function* () {
				let i = n.getNextRequestId();
				return yield n.sendRequest({
					case: "updateMetadata",
					value: new Er({
						requestId: i,
						metadata: e,
						name: t,
						attributes: r
					})
				}), i;
			}();
		});
	}
	sendUpdateTrackSettings(e) {
		this.sendRequest({
			case: "trackSetting",
			value: e
		});
	}
	sendUpdateSubscription(e) {
		return this.sendRequest({
			case: "subscription",
			value: e
		});
	}
	sendSyncState(e) {
		return this.sendRequest({
			case: "syncState",
			value: e
		});
	}
	sendUpdateVideoLayers(e, t) {
		return this.sendRequest({
			case: "updateLayers",
			value: new Tr({
				trackSid: e,
				layers: t
			})
		});
	}
	sendUpdateSubscriptionPermissions(e, t) {
		return this.sendRequest({
			case: "subscriptionPermission",
			value: new zr({
				allParticipants: e,
				trackPermissions: t
			})
		});
	}
	sendSimulateScenario(e) {
		return this.sendRequest({
			case: "simulate",
			value: e
		});
	}
	sendPing() {
		return Promise.all([this.sendRequest({
			case: "ping",
			value: p.parse(Date.now())
		}), this.sendRequest({
			case: "pingReq",
			value: new Kr({
				timestamp: p.parse(Date.now()),
				rtt: p.parse(this.rtt)
			})
		})]);
	}
	sendUpdateLocalAudioTrack(e, t) {
		return this.sendRequest({
			case: "updateAudioTrack",
			value: new xr({
				trackSid: e,
				features: t
			})
		});
	}
	sendLeave() {
		return this.sendRequest({
			case: "leave",
			value: new Cr({
				reason: tn.CLIENT_INITIATED,
				action: wr.DISCONNECT
			})
		});
	}
	sendPublishDataTrackRequest(e, t, n) {
		return this.sendRequest({
			case: "publishDataTrackRequest",
			value: new rr({
				pubHandle: e,
				name: t,
				encryption: n ? x.GCM : x.NONE
			})
		});
	}
	sendUnPublishDataTrackRequest(e) {
		return this.sendRequest({
			case: "unpublishDataTrackRequest",
			value: new ar({ pubHandle: e })
		});
	}
	sendUpdateDataSubscription(e, t) {
		return this.sendRequest({
			case: "updateDataSubscription",
			value: new vr({ updates: [new yr({
				trackSid: e,
				subscribe: t
			})] })
		});
	}
	sendRequest(e) {
		return E(this, arguments, void 0, function(e) {
			var t = this;
			let n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !1;
			return function* () {
				if (!n && !Hc(e) && t.state === W.RECONNECTING) {
					t.queuedRequests.push(() => E(t, void 0, void 0, function* () {
						yield this.sendRequest(e, !0);
					}));
					return;
				}
				if (n || (yield t.requestQueue.flush()), t.signalLatency && (yield V(t.signalLatency)), t.isDisconnected) {
					t.log.debug(`skipping signal request (type: ${e.case}) - SignalClient disconnected`);
					return;
				}
				if (!t.streamWriter) {
					t.log.error(`cannot send signal request before connected, type: ${e?.case}`);
					return;
				}
				let r = new $n({ message: e });
				try {
					t.useJSON ? yield t.streamWriter.write(r.toJsonString()) : yield t.streamWriter.write(r.toBinary().buffer);
				} catch (e) {
					t.log.error("error sending signal message", { error: e });
				}
			}();
		});
	}
	handleSignalResponse(e) {
		let t = e.message;
		if (t == null) {
			this.log.debug("received unsupported message");
			return;
		}
		let n = !1;
		if (t.case === "answer") {
			let e = Gc(t.value);
			this.onAnswer && this.onAnswer(e, t.value.id, t.value.midToTrackId);
		} else if (t.case === "offer") {
			let e = Gc(t.value);
			this.onOffer && this.onOffer(e, t.value.id, t.value.midToTrackId);
		} else if (t.case === "trickle") {
			let e = JSON.parse(t.value.candidateInit);
			this.onTrickle && this.onTrickle(e, t.value.target);
		} else t.case === "update" ? this.onParticipantUpdate && this.onParticipantUpdate(t.value.participants ?? []) : t.case === "trackPublished" ? this.onLocalTrackPublished && this.onLocalTrackPublished(t.value) : t.case === "speakersChanged" ? this.onSpeakersChanged && this.onSpeakersChanged(t.value.speakers ?? []) : t.case === "leave" ? this.onLeave && this.onLeave(t.value) : t.case === "mute" ? this.onRemoteMuteChanged && this.onRemoteMuteChanged(t.value.sid, t.value.muted) : t.case === "roomUpdate" ? this.onRoomUpdate && t.value.room && this.onRoomUpdate(t.value.room) : t.case === "connectionQuality" ? this.onConnectionQuality && this.onConnectionQuality(t.value) : t.case === "streamStateUpdate" ? this.onStreamStateUpdate && this.onStreamStateUpdate(t.value) : t.case === "subscribedQualityUpdate" ? this.onSubscribedQualityUpdate && this.onSubscribedQualityUpdate(t.value) : t.case === "subscriptionPermissionUpdate" ? this.onSubscriptionPermissionUpdate && this.onSubscriptionPermissionUpdate(t.value) : t.case === "refreshToken" ? this.onTokenRefresh && this.onTokenRefresh(t.value) : t.case === "trackUnpublished" ? this.onLocalTrackUnpublished && this.onLocalTrackUnpublished(t.value) : t.case === "subscriptionResponse" ? this.onSubscriptionError && this.onSubscriptionError(t.value) : t.case === "pong" || (t.case === "pongResp" ? (this.rtt = Date.now() - Number.parseInt(t.value.lastPingTimestamp.toString()), this.resetPingTimeout(), n = !0) : t.case === "requestResponse" ? this.onRequestResponse && this.onRequestResponse(t.value) : t.case === "trackSubscribed" ? this.onLocalTrackSubscribed && this.onLocalTrackSubscribed(t.value.trackSid) : t.case === "roomMoved" ? (this.onTokenRefresh && this.onTokenRefresh(t.value.token), this.onRoomMoved && this.onRoomMoved(t.value)) : t.case === "mediaSectionsRequirement" ? this.onMediaSectionsRequirement && this.onMediaSectionsRequirement(t.value) : t.case === "publishDataTrackResponse" ? this.onPublishDataTrackResponse && this.onPublishDataTrackResponse(t.value) : t.case === "unpublishDataTrackResponse" ? this.onUnPublishDataTrackResponse && this.onUnPublishDataTrackResponse(t.value) : t.case === "dataTrackSubscriberHandles" ? this.onDataTrackSubscriberHandles && this.onDataTrackSubscriberHandles(t.value) : this.log.debug("unsupported message", { msgCase: t.case }));
		n || this.resetPingTimeout();
	}
	setReconnected() {
		for (; this.queuedRequests.length > 0;) {
			let e = this.queuedRequests.shift();
			e && this.requestQueue.run(e);
		}
	}
	handleOnClose(e) {
		return E(this, void 0, void 0, function* () {
			if (this.state === W.DISCONNECTED) return;
			let t = this.onClose;
			yield this.close(void 0, e), this.log.info(`websocket connection closed: ${e}`, { reason: e }), t && t(e);
		});
	}
	handleWSError(e) {
		this.log.error("websocket error", { error: e });
	}
	resetPingTimeout() {
		if (this.clearPingTimeout(), !this.pingTimeoutDuration) {
			this.log.warn("ping timeout duration not set");
			return;
		}
		this.pingTimeout = N.setTimeout(() => {
			this.log.warn(`ping timeout triggered. last pong received at: ${(/* @__PURE__ */ new Date(Date.now() - this.pingTimeoutDuration * 1e3)).toUTCString()}`), this.handleOnClose("ping timeout");
		}, this.pingTimeoutDuration * 1e3);
	}
	clearPingTimeout() {
		this.pingTimeout && N.clearTimeout(this.pingTimeout);
	}
	startPingInterval() {
		if (this.clearPingInterval(), this.resetPingTimeout(), !this.pingIntervalDuration) {
			this.log.warn("ping interval duration not set");
			return;
		}
		this.log.debug("start ping interval"), this.pingInterval = N.setInterval(() => {
			this.sendPing();
		}, this.pingIntervalDuration * 1e3);
	}
	clearPingInterval() {
		this.log.debug("clearing ping interval"), this.clearPingTimeout(), this.pingInterval && N.clearInterval(this.pingInterval);
	}
	handleSignalConnected(e, t, n) {
		this.state = W.CONNECTED, this.log.info("signal connected"), clearTimeout(t), this.startPingInterval(), this.startReadingLoop(e.readable.getReader(), n);
	}
	validateFirstMessage(e, t) {
		return e.message?.case === "join" ? {
			isValid: !0,
			response: e.message.value
		} : this.state === W.RECONNECTING && e.message?.case !== "leave" ? e.message?.case === "reconnect" ? {
			isValid: !0,
			response: e.message.value
		} : (this.log.debug("declaring signal reconnected without reconnect response received"), {
			isValid: !0,
			response: void 0,
			shouldProcessFirstMessage: !0
		}) : this.isEstablishingConnection && e.message?.case === "leave" ? {
			isValid: !1,
			error: A.leaveRequest("Received leave request while trying to (re)connect", e.message.value.reason)
		} : t ? {
			isValid: !1,
			error: A.internal("Unexpected first message")
		} : {
			isValid: !1,
			error: A.internal(`did not receive join response, got ${e.message?.case} instead`)
		};
	}
	handleConnectionError(e, t) {
		return E(this, void 0, void 0, function* () {
			try {
				let n = yield fetch(t);
				switch (n.status) {
					case 404:
						let e = yield n.text();
						return e.includes("requested room does not exist") ? A.notAllowed(e, n.status) : A.serviceNotFound("v1 RTC path not found. Consider upgrading your LiveKit server version", "v0-rtc");
					case 401:
					case 403:
						let t = yield n.text();
						return A.notAllowed(t, n.status);
					default: break;
				}
				return e instanceof A ? e : A.internal(`Encountered unknown websocket error during connection: ${e}`, {
					status: n.status,
					statusText: n.statusText
				});
			} catch (e) {
				return e instanceof A ? e : A.serverUnreachable(e instanceof Error ? e.message : "server was not reachable");
			}
		});
	}
};
function Gc(e) {
	let t = {
		type: "offer",
		sdp: e.sdp
	};
	switch (e.type) {
		case "answer":
		case "offer":
		case "pranswer":
		case "rollback":
			t.type = e.type;
			break;
	}
	return t;
}
function Kc(e, t) {
	return new hr({
		sdp: e.sdp,
		type: e.type,
		id: t
	});
}
function qc(e, t, n) {
	let r = new URLSearchParams();
	return r.set("access_token", e), n.reconnect && (r.set("reconnect", "1"), n.sid && r.set("sid", n.sid)), r.set("auto_subscribe", n.autoSubscribe ? "1" : "0"), r.set("sdk", ns() ? "reactnative" : "js"), r.set("version", t.version), r.set("protocol", t.protocol.toString()), r.set("client_protocol", t.clientProtocol.toString()), t.deviceModel && r.set("device_model", t.deviceModel), t.os && r.set("os", t.os), t.osVersion && r.set("os_version", t.osVersion), t.browser && r.set("browser", t.browser), t.browserVersion && r.set("browser_version", t.browserVersion), n.adaptiveStream && r.set("adaptive_stream", "1"), n.reconnectReason && r.set("reconnect_reason", n.reconnectReason.toString()), navigator.connection?.type && r.set("network", navigator.connection.type), r;
}
function Jc(e, t, n, r) {
	return E(this, void 0, void 0, function* () {
		let i = new URLSearchParams();
		i.set("access_token", e);
		let a = new ti({
			clientInfo: t,
			connectionSettings: new ei({
				autoSubscribe: !!n.autoSubscribe,
				adaptiveStream: !!n.adaptiveStream
			}),
			reconnect: !!n.reconnect,
			participantSid: n.sid ? n.sid : void 0,
			publisherOffer: r
		});
		n.reconnectReason && (a.reconnectReason = n.reconnectReason);
		let o = a.toBinary(), s, c;
		if (zs()) {
			let e = new CompressionStream("gzip"), t = e.writable.getWriter();
			t.write(new Uint8Array(o)), t.close();
			let n = [], r = e.readable.getReader();
			for (;;) {
				let e = yield r.read(), t = e.done, i = e.value;
				if (t) break;
				n.push(i);
			}
			let i = n.reduce((e, t) => e + t.length, 0), a = new Uint8Array(i), l = 0;
			for (let e of n) a.set(e, l), l += e.length;
			s = a, c = ri.GZIP;
		} else s = o, c = ri.NONE;
		let l = new ni({
			joinRequest: s,
			compression: c
		}).toBinary();
		return i.set("join_request", ((e) => {
			let t = Array.from(e, (e) => String.fromCodePoint(e)).join("");
			return btoa(t);
		})(l).replace(/\+/g, "-").replace(/\//g, "_")), i;
	});
}
var Yc = class {
	constructor() {
		this.buffer = [], this._totalSize = 0;
	}
	push(e) {
		this.buffer.push(e), this._totalSize += e.data.byteLength;
	}
	pop() {
		let e = this.buffer.shift();
		return e && (this._totalSize -= e.data.byteLength), e;
	}
	getAll() {
		return this.buffer.slice();
	}
	popToSequence(e) {
		for (; this.buffer.length > 0 && this.buffer[0].sequence <= e;) this.pop();
	}
	alignBufferedAmount(e) {
		for (; this.buffer.length > 0;) {
			let t = this.buffer[0];
			if (this._totalSize - t.data.byteLength <= e) break;
			this.pop();
		}
	}
	get length() {
		return this.buffer.length;
	}
}, Xc = class {
	constructor(e) {
		this._map = /* @__PURE__ */ new Map(), this._lastCleanup = 0, this.ttl = e;
	}
	set(e, t) {
		let n = Date.now();
		n - this._lastCleanup > this.ttl / 2 && this.cleanup();
		let r = n + this.ttl;
		return this._map.set(e, {
			value: t,
			expiresAt: r
		}), this;
	}
	get(e) {
		let t = this._map.get(e);
		if (t) {
			if (t.expiresAt < Date.now()) {
				this._map.delete(e);
				return;
			}
			return t.value;
		}
	}
	has(e) {
		let t = this._map.get(e);
		return t ? t.expiresAt < Date.now() ? (this._map.delete(e), !1) : !0 : !1;
	}
	delete(e) {
		return this._map.delete(e);
	}
	clear() {
		this._map.clear();
	}
	cleanup() {
		let e = Date.now();
		for (let n of this._map.entries()) {
			var t = g(n, 2);
			let r = t[0];
			t[1].expiresAt < e && this._map.delete(r);
		}
		this._lastCleanup = e;
	}
	get size() {
		return this.cleanup(), this._map.size;
	}
	forEach(e) {
		this.cleanup();
		for (let n of this._map.entries()) {
			var t = g(n, 2);
			let r = t[0], i = t[1];
			i.expiresAt >= Date.now() && e(i.value, r, this.asValueMap());
		}
	}
	map(e) {
		this.cleanup();
		let t = [], n = this.asValueMap();
		for (let i of n.entries()) {
			var r = g(i, 2);
			let a = r[0], o = r[1];
			t.push(e(o, a, n));
		}
		return t;
	}
	asValueMap() {
		let e = /* @__PURE__ */ new Map();
		for (let n of this._map.entries()) {
			var t = g(n, 2);
			let r = t[0], i = t[1];
			i.expiresAt >= Date.now() && e.set(r, i.value);
		}
		return e;
	}
}, Zc = {}, Qc = {}, $c = { exports: {} }, el;
function tl() {
	if (el) return $c.exports;
	el = 1;
	var e = $c.exports = {
		v: [{
			name: "version",
			reg: /^(\d*)$/
		}],
		o: [{
			name: "origin",
			reg: /^(\S*) (\d*) (\d*) (\S*) IP(\d) (\S*)/,
			names: [
				"username",
				"sessionId",
				"sessionVersion",
				"netType",
				"ipVer",
				"address"
			],
			format: "%s %s %d %s IP%d %s"
		}],
		s: [{ name: "name" }],
		i: [{ name: "description" }],
		u: [{ name: "uri" }],
		e: [{ name: "email" }],
		p: [{ name: "phone" }],
		z: [{ name: "timezones" }],
		r: [{ name: "repeats" }],
		t: [{
			name: "timing",
			reg: /^(\d*) (\d*)/,
			names: ["start", "stop"],
			format: "%d %d"
		}],
		c: [{
			name: "connection",
			reg: /^IN IP(\d) (\S*)/,
			names: ["version", "ip"],
			format: "IN IP%d %s"
		}],
		b: [{
			push: "bandwidth",
			reg: /^(TIAS|AS|CT|RR|RS):(\d*)/,
			names: ["type", "limit"],
			format: "%s:%s"
		}],
		m: [{
			reg: /^(\w*) (\d*) ([\w/]*)(?: (.*))?/,
			names: [
				"type",
				"port",
				"protocol",
				"payloads"
			],
			format: "%s %d %s %s"
		}],
		a: [
			{
				push: "rtp",
				reg: /^rtpmap:(\d*) ([\w\-.]*)(?:\s*\/(\d*)(?:\s*\/(\S*))?)?/,
				names: [
					"payload",
					"codec",
					"rate",
					"encoding"
				],
				format: function(e) {
					return e.encoding ? "rtpmap:%d %s/%s/%s" : e.rate ? "rtpmap:%d %s/%s" : "rtpmap:%d %s";
				}
			},
			{
				push: "fmtp",
				reg: /^fmtp:(\d*) ([\S| ]*)/,
				names: ["payload", "config"],
				format: "fmtp:%d %s"
			},
			{
				name: "control",
				reg: /^control:(.*)/,
				format: "control:%s"
			},
			{
				name: "rtcp",
				reg: /^rtcp:(\d*)(?: (\S*) IP(\d) (\S*))?/,
				names: [
					"port",
					"netType",
					"ipVer",
					"address"
				],
				format: function(e) {
					return e.address == null ? "rtcp:%d" : "rtcp:%d %s IP%d %s";
				}
			},
			{
				push: "rtcpFbTrrInt",
				reg: /^rtcp-fb:(\*|\d*) trr-int (\d*)/,
				names: ["payload", "value"],
				format: "rtcp-fb:%s trr-int %d"
			},
			{
				push: "rtcpFb",
				reg: /^rtcp-fb:(\*|\d*) ([\w-_]*)(?: ([\w-_]*))?/,
				names: [
					"payload",
					"type",
					"subtype"
				],
				format: function(e) {
					return e.subtype == null ? "rtcp-fb:%s %s" : "rtcp-fb:%s %s %s";
				}
			},
			{
				push: "ext",
				reg: /^extmap:(\d+)(?:\/(\w+))?(?: (urn:ietf:params:rtp-hdrext:encrypt))? (\S*)(?: (\S*))?/,
				names: [
					"value",
					"direction",
					"encrypt-uri",
					"uri",
					"config"
				],
				format: function(e) {
					return "extmap:%d" + (e.direction ? "/%s" : "%v") + (e["encrypt-uri"] ? " %s" : "%v") + " %s" + (e.config ? " %s" : "");
				}
			},
			{
				name: "extmapAllowMixed",
				reg: /^(extmap-allow-mixed)/
			},
			{
				push: "crypto",
				reg: /^crypto:(\d*) ([\w_]*) (\S*)(?: (\S*))?/,
				names: [
					"id",
					"suite",
					"config",
					"sessionConfig"
				],
				format: function(e) {
					return e.sessionConfig == null ? "crypto:%d %s %s" : "crypto:%d %s %s %s";
				}
			},
			{
				name: "setup",
				reg: /^setup:(\w*)/,
				format: "setup:%s"
			},
			{
				name: "connectionType",
				reg: /^connection:(new|existing)/,
				format: "connection:%s"
			},
			{
				name: "mid",
				reg: /^mid:([^\s]*)/,
				format: "mid:%s"
			},
			{
				name: "msid",
				reg: /^msid:(.*)/,
				format: "msid:%s"
			},
			{
				name: "ptime",
				reg: /^ptime:(\d*(?:\.\d*)*)/,
				format: "ptime:%d"
			},
			{
				name: "maxptime",
				reg: /^maxptime:(\d*(?:\.\d*)*)/,
				format: "maxptime:%d"
			},
			{
				name: "direction",
				reg: /^(sendrecv|recvonly|sendonly|inactive)/
			},
			{
				name: "icelite",
				reg: /^(ice-lite)/
			},
			{
				name: "iceUfrag",
				reg: /^ice-ufrag:(\S*)/,
				format: "ice-ufrag:%s"
			},
			{
				name: "icePwd",
				reg: /^ice-pwd:(\S*)/,
				format: "ice-pwd:%s"
			},
			{
				name: "fingerprint",
				reg: /^fingerprint:(\S*) (\S*)/,
				names: ["type", "hash"],
				format: "fingerprint:%s %s"
			},
			{
				push: "candidates",
				reg: /^candidate:(\S*) (\d*) (\S*) (\d*) (\S*) (\d*) typ (\S*)(?: raddr (\S*) rport (\d*))?(?: tcptype (\S*))?(?: generation (\d*))?(?: network-id (\d*))?(?: network-cost (\d*))?/,
				names: [
					"foundation",
					"component",
					"transport",
					"priority",
					"ip",
					"port",
					"type",
					"raddr",
					"rport",
					"tcptype",
					"generation",
					"network-id",
					"network-cost"
				],
				format: function(e) {
					var t = "candidate:%s %d %s %d %s %d typ %s";
					return t += e.raddr == null ? "%v%v" : " raddr %s rport %d", t += e.tcptype == null ? "%v" : " tcptype %s", e.generation != null && (t += " generation %d"), t += e["network-id"] == null ? "%v" : " network-id %d", t += e["network-cost"] == null ? "%v" : " network-cost %d", t;
				}
			},
			{
				name: "endOfCandidates",
				reg: /^(end-of-candidates)/
			},
			{
				name: "remoteCandidates",
				reg: /^remote-candidates:(.*)/,
				format: "remote-candidates:%s"
			},
			{
				name: "iceOptions",
				reg: /^ice-options:(\S*)/,
				format: "ice-options:%s"
			},
			{
				push: "ssrcs",
				reg: /^ssrc:(\d*) ([\w_-]*)(?::(.*))?/,
				names: [
					"id",
					"attribute",
					"value"
				],
				format: function(e) {
					var t = "ssrc:%d";
					return e.attribute != null && (t += " %s", e.value != null && (t += ":%s")), t;
				}
			},
			{
				push: "ssrcGroups",
				reg: /^ssrc-group:([\x21\x23\x24\x25\x26\x27\x2A\x2B\x2D\x2E\w]*) (.*)/,
				names: ["semantics", "ssrcs"],
				format: "ssrc-group:%s %s"
			},
			{
				name: "msidSemantic",
				reg: /^msid-semantic:\s?(\w*) (\S*)/,
				names: ["semantic", "token"],
				format: "msid-semantic: %s %s"
			},
			{
				push: "groups",
				reg: /^group:(\w*) (.*)/,
				names: ["type", "mids"],
				format: "group:%s %s"
			},
			{
				name: "rtcpMux",
				reg: /^(rtcp-mux)/
			},
			{
				name: "rtcpRsize",
				reg: /^(rtcp-rsize)/
			},
			{
				name: "sctpmap",
				reg: /^sctpmap:([\w_/]*) (\S*)(?: (\S*))?/,
				names: [
					"sctpmapNumber",
					"app",
					"maxMessageSize"
				],
				format: function(e) {
					return e.maxMessageSize == null ? "sctpmap:%s %s" : "sctpmap:%s %s %s";
				}
			},
			{
				name: "xGoogleFlag",
				reg: /^x-google-flag:([^\s]*)/,
				format: "x-google-flag:%s"
			},
			{
				push: "rids",
				reg: /^rid:([\d\w]+) (\w+)(?: ([\S| ]*))?/,
				names: [
					"id",
					"direction",
					"params"
				],
				format: function(e) {
					return e.params ? "rid:%s %s %s" : "rid:%s %s";
				}
			},
			{
				push: "imageattrs",
				reg: /* @__PURE__ */ RegExp("^imageattr:(\\d+|\\*)[\\s\\t]+(send|recv)[\\s\\t]+(\\*|\\[\\S+\\](?:[\\s\\t]+\\[\\S+\\])*)(?:[\\s\\t]+(recv|send)[\\s\\t]+(\\*|\\[\\S+\\](?:[\\s\\t]+\\[\\S+\\])*))?"),
				names: [
					"pt",
					"dir1",
					"attrs1",
					"dir2",
					"attrs2"
				],
				format: function(e) {
					return "imageattr:%s %s %s" + (e.dir2 ? " %s %s" : "");
				}
			},
			{
				name: "simulcast",
				reg: /* @__PURE__ */ RegExp("^simulcast:(send|recv) ([a-zA-Z0-9\\-_~;,]+)(?:\\s?(send|recv) ([a-zA-Z0-9\\-_~;,]+))?$"),
				names: [
					"dir1",
					"list1",
					"dir2",
					"list2"
				],
				format: function(e) {
					return "simulcast:%s %s" + (e.dir2 ? " %s %s" : "");
				}
			},
			{
				name: "simulcast_03",
				reg: /^simulcast:[\s\t]+([\S+\s\t]+)$/,
				names: ["value"],
				format: "simulcast: %s"
			},
			{
				name: "framerate",
				reg: /^framerate:(\d+(?:$|\.\d+))/,
				format: "framerate:%s"
			},
			{
				name: "sourceFilter",
				reg: /^source-filter: *(excl|incl) (\S*) (IP4|IP6|\*) (\S*) (.*)/,
				names: [
					"filterMode",
					"netType",
					"addressTypes",
					"destAddress",
					"srcList"
				],
				format: "source-filter: %s %s %s %s %s"
			},
			{
				name: "bundleOnly",
				reg: /^(bundle-only)/
			},
			{
				name: "label",
				reg: /^label:(.+)/,
				format: "label:%s"
			},
			{
				name: "sctpPort",
				reg: /^sctp-port:(\d+)$/,
				format: "sctp-port:%s"
			},
			{
				name: "maxMessageSize",
				reg: /^max-message-size:(\d+)$/,
				format: "max-message-size:%s"
			},
			{
				push: "tsRefClocks",
				reg: /^ts-refclk:([^\s=]*)(?:=(\S*))?/,
				names: ["clksrc", "clksrcExt"],
				format: function(e) {
					return "ts-refclk:%s" + (e.clksrcExt == null ? "" : "=%s");
				}
			},
			{
				name: "mediaClk",
				reg: /^mediaclk:(?:id=(\S*))? *([^\s=]*)(?:=(\S*))?(?: *rate=(\d+)\/(\d+))?/,
				names: [
					"id",
					"mediaClockName",
					"mediaClockValue",
					"rateNumerator",
					"rateDenominator"
				],
				format: function(e) {
					var t = "mediaclk:";
					return t += e.id == null ? "%v%s" : "id=%s %s", t += e.mediaClockValue == null ? "" : "=%s", t += e.rateNumerator == null ? "" : " rate=%s", t += e.rateDenominator == null ? "" : "/%s", t;
				}
			},
			{
				name: "keywords",
				reg: /^keywds:(.+)$/,
				format: "keywds:%s"
			},
			{
				name: "content",
				reg: /^content:(.+)/,
				format: "content:%s"
			},
			{
				name: "bfcpFloorCtrl",
				reg: /^floorctrl:(c-only|s-only|c-s)/,
				format: "floorctrl:%s"
			},
			{
				name: "bfcpConfId",
				reg: /^confid:(\d+)/,
				format: "confid:%s"
			},
			{
				name: "bfcpUserId",
				reg: /^userid:(\d+)/,
				format: "userid:%s"
			},
			{
				name: "bfcpFloorId",
				reg: /^floorid:(.+) (?:m-stream|mstrm):(.+)/,
				names: ["id", "mStream"],
				format: "floorid:%s mstrm:%s"
			},
			{
				push: "invalid",
				names: ["value"]
			}
		]
	};
	return Object.keys(e).forEach(function(t) {
		e[t].forEach(function(e) {
			e.reg ||= /(.*)/, e.format ||= "%s";
		});
	}), $c.exports;
}
var nl;
function rl() {
	return nl ? Qc : (nl = 1, (function(e) {
		var t = function(e) {
			return String(Number(e)) === e ? Number(e) : e;
		}, n = function(e, n, r, i) {
			if (i && !r) n[i] = t(e[1]);
			else for (var a = 0; a < r.length; a += 1) e[a + 1] != null && (n[r[a]] = t(e[a + 1]));
		}, r = function(e, t, r) {
			var i = e.name && e.names;
			e.push && !t[e.push] ? t[e.push] = [] : i && !t[e.name] && (t[e.name] = {});
			var a = e.push ? {} : i ? t[e.name] : t;
			n(r.match(e.reg), a, e.names, e.name), e.push && t[e.push].push(a);
		}, i = tl(), a = RegExp.prototype.test.bind(/^([a-z])=(.*)/);
		e.parse = function(e) {
			var t = {}, n = [], o = t;
			return e.split(/(\r\n|\r|\n)/).filter(a).forEach(function(e) {
				var t = e[0], a = e.slice(2);
				t === "m" && (n.push({
					rtp: [],
					fmtp: []
				}), o = n[n.length - 1]);
				for (var s = 0; s < (i[t] || []).length; s += 1) {
					var c = i[t][s];
					if (c.reg.test(a)) return r(c, o, a);
				}
			}), t.media = n, t;
		};
		var o = function(e, n) {
			var r = n.split(/=(.+)/, 2);
			return r.length === 2 ? e[r[0]] = t(r[1]) : r.length === 1 && n.length > 1 && (e[r[0]] = void 0), e;
		};
		e.parseParams = function(e) {
			return e.split(/;\s?/).reduce(o, {});
		}, e.parseFmtpConfig = e.parseParams, e.parsePayloads = function(e) {
			return e.toString().split(" ").map(Number);
		}, e.parseRemoteCandidates = function(e) {
			for (var n = [], r = e.split(" ").map(t), i = 0; i < r.length; i += 3) n.push({
				component: r[i],
				ip: r[i + 1],
				port: r[i + 2]
			});
			return n;
		}, e.parseImageAttributes = function(e) {
			return e.split(" ").map(function(e) {
				return e.substring(1, e.length - 1).split(",").reduce(o, {});
			});
		}, e.parseSimulcastStreamList = function(e) {
			return e.split(";").map(function(e) {
				return e.split(",").map(function(e) {
					var n, r = !1;
					return e[0] === "~" ? (n = t(e.substring(1, e.length)), r = !0) : n = t(e), {
						scid: n,
						paused: r
					};
				});
			});
		};
	})(Qc), Qc);
}
var il, al;
function ol() {
	if (al) return il;
	al = 1;
	var e = tl(), t = /%[sdv%]/g, n = function(e) {
		var n = 1, r = arguments, i = r.length;
		return e.replace(t, function(e) {
			if (n >= i) return e;
			var t = r[n];
			switch (n += 1, e) {
				case "%%": return "%";
				case "%s": return String(t);
				case "%d": return Number(t);
				case "%v": return "";
			}
		});
	}, r = function(e, t, r) {
		var i = t.format instanceof Function ? t.format(t.push ? r : r[t.name]) : t.format, a = [e + "=" + i];
		if (t.names) for (var o = 0; o < t.names.length; o += 1) {
			var s = t.names[o];
			t.name ? a.push(r[t.name][s]) : a.push(r[t.names[o]]);
		}
		else a.push(r[t.name]);
		return n.apply(null, a);
	}, i = [
		"v",
		"o",
		"s",
		"i",
		"u",
		"e",
		"p",
		"c",
		"b",
		"t",
		"r",
		"z",
		"a"
	], a = [
		"i",
		"c",
		"b",
		"a"
	];
	return il = function(t, n) {
		n ||= {}, t.version ??= 0, t.name ??= " ", t.media.forEach(function(e) {
			e.payloads ??= "";
		});
		var o = n.outerOrder || i, s = n.innerOrder || a, c = [];
		return o.forEach(function(n) {
			e[n].forEach(function(e) {
				e.name in t && t[e.name] != null ? c.push(r(n, e, t)) : e.push in t && t[e.push] != null && t[e.push].forEach(function(t) {
					c.push(r(n, e, t));
				});
			});
		}), t.media.forEach(function(t) {
			c.push(r("m", e.m[0], t)), s.forEach(function(n) {
				e[n].forEach(function(e) {
					e.name in t && t[e.name] != null ? c.push(r(n, e, t)) : e.push in t && t[e.push] != null && t[e.push].forEach(function(t) {
						c.push(r(n, e, t));
					});
				});
			});
		}), c.join("\r\n") + "\r\n";
	}, il;
}
var sl;
function cl() {
	if (sl) return Zc;
	sl = 1;
	var e = rl(), t = ol();
	return Zc.grammar = tl(), Zc.write = t, Zc.parse = e.parse, Zc.parseParams = e.parseParams, Zc.parseFmtpConfig = e.parseFmtpConfig, Zc.parsePayloads = e.parsePayloads, Zc.parseRemoteCandidates = e.parseRemoteCandidates, Zc.parseImageAttributes = e.parseImageAttributes, Zc.parseSimulcastStreamList = e.parseSimulcastStreamList, Zc;
}
var ll = cl(), ul = .7, dl = 20, fl = {
	NegotiationStarted: "negotiationStarted",
	NegotiationComplete: "negotiationComplete",
	OfferAnswered: "offerAnswered",
	RTPVideoPayloadTypes: "rtpVideoPayloadTypes"
}, pl = class extends Oi.EventEmitter {
	get pc() {
		return this._pc ||= this.createPC(), this._pc;
	}
	constructor(e) {
		let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
		super(), this.log = w, this.ddExtID = 0, this.latestOfferId = 0, this.latestAcknowledgedOfferId = 0, this.pendingCandidates = [], this.restartingIce = !1, this.renegotiate = !1, this.trackBitrates = [], this.remoteStereoMids = [], this.remoteNackMids = [], this.negotiate = lc((e) => E(this, void 0, void 0, function* () {
			this.emit(fl.NegotiationStarted);
			try {
				yield this.createAndSendOffer();
			} catch (t) {
				if (e) e(t);
				else throw t;
			}
		}), dl), this.close = () => {
			this._pc &&= (this.pendingInitialOffer = void 0, this._pc.close(), this._pc.onconnectionstatechange = null, this._pc.oniceconnectionstatechange = null, this._pc.onicegatheringstatechange = null, this._pc.ondatachannel = null, this._pc.onnegotiationneeded = null, this._pc.onsignalingstatechange = null, this._pc.onicecandidate = null, this._pc.ondatachannel = null, this._pc.ontrack = null, this._pc.onconnectionstatechange = null, this._pc.oniceconnectionstatechange = null, null);
		}, this.log = T(t.loggerName ?? C.PCTransport), this.loggerOptions = t, this.config = e, this._pc = this.createPC(), this.offerLock = new i();
	}
	createPC() {
		let e = new RTCPeerConnection(this.config);
		return e.onicecandidate = (e) => {
			var t;
			e.candidate && ((t = this.onIceCandidate) == null || t.call(this, e.candidate));
		}, e.onicecandidateerror = (e) => {
			var t;
			(t = this.onIceCandidateError) == null || t.call(this, e);
		}, e.oniceconnectionstatechange = () => {
			var t;
			(t = this.onIceConnectionStateChange) == null || t.call(this, e.iceConnectionState);
		}, e.onsignalingstatechange = () => {
			var t;
			(t = this.onSignalingStatechange) == null || t.call(this, e.signalingState);
		}, e.onconnectionstatechange = () => {
			var t;
			(t = this.onConnectionStateChange) == null || t.call(this, e.connectionState);
		}, e.ondatachannel = (e) => {
			var t;
			(t = this.onDataChannel) == null || t.call(this, e);
		}, e.ontrack = (e) => {
			var t;
			(t = this.onTrack) == null || t.call(this, e);
		}, e;
	}
	get logContext() {
		var e;
		return Object.assign({}, (e = this.loggerOptions).loggerContextCb?.call(e));
	}
	get isICEConnected() {
		return this._pc !== null && (this.pc.iceConnectionState === "connected" || this.pc.iceConnectionState === "completed");
	}
	addIceCandidate(e) {
		return E(this, void 0, void 0, function* () {
			if (this.pc.remoteDescription && !this.restartingIce) return this.pc.addIceCandidate(e);
			this.pendingCandidates.push(e);
		});
	}
	setRemoteDescription(e, t) {
		return E(this, void 0, void 0, function* () {
			if (e.type === "answer" && this.latestOfferId > 0 && t > 0 && t !== this.latestOfferId) return this.log.warn("ignoring answer for old offer", Object.assign(Object.assign({}, this.logContext), {
				offerId: t,
				latestOfferId: this.latestOfferId
			})), !1;
			let n;
			if (e.type === "offer") {
				let t = hl(e), n = t.stereoMids, r = t.nackMids;
				this.remoteStereoMids = n, this.remoteNackMids = r;
			} else if (e.type === "answer") {
				if (this.pendingInitialOffer && this._pc) {
					let e = this.pendingInitialOffer;
					this.pendingInitialOffer = void 0;
					let t = ll.parse(e.sdp ?? "");
					t.media.forEach((e) => {
						gl(e);
					}), this.log.debug("setting pending initial offer before processing answer", this.logContext), yield this.setMungedSDP(e, ll.write(t));
				}
				let t = ll.parse(e.sdp ?? "");
				t.media.forEach((e) => {
					let t = _l(e.mid);
					e.type === "audio" && this.trackBitrates.some((n) => {
						if (!n.transceiver || t != n.transceiver.mid) return !1;
						let r = 0;
						if (e.rtp.some((e) => e.codec.toUpperCase() === n.codec.toUpperCase() ? (r = e.payload, !0) : !1), r === 0) return !0;
						let i = !1;
						for (let t of e.fmtp) if (t.payload === r) {
							t.config = t.config.split(";").filter((e) => !e.includes("maxaveragebitrate")).join(";"), n.maxbr > 0 && (t.config += `;maxaveragebitrate=${n.maxbr * 1e3}`), i = !0;
							break;
						}
						return i || n.maxbr > 0 && e.fmtp.push({
							payload: r,
							config: `maxaveragebitrate=${n.maxbr * 1e3}`
						}), !0;
					});
				}), n = ll.write(t);
			}
			return yield this.setMungedSDP(e, n, !0), this.pendingCandidates.forEach((e) => {
				this.pc.addIceCandidate(e);
			}), this.pendingCandidates = [], this.restartingIce = !1, e.type === "answer" && (this.latestAcknowledgedOfferId = t, this.emit(fl.OfferAnswered, t)), this.renegotiate ? (this.renegotiate = !1, yield this.createAndSendOffer()) : e.type === "answer" && (this.emit(fl.NegotiationComplete), e.sdp && ll.parse(e.sdp).media.forEach((e) => {
				e.type === "video" && this.emit(fl.RTPVideoPayloadTypes, e.rtp);
			})), !0;
		});
	}
	createInitialOffer() {
		return E(this, void 0, void 0, function* () {
			let e = yield this.offerLock.lock();
			try {
				if (this.pc.signalingState !== "stable") {
					this.log.warn("signaling state is not stable, cannot create initial offer", this.logContext);
					return;
				}
				let e = this.latestOfferId + 1;
				this.latestOfferId = e;
				let t = yield this.pc.createOffer();
				this.pendingInitialOffer = {
					sdp: t.sdp,
					type: t.type
				};
				let n = ll.parse(t.sdp ?? "");
				return n.media.forEach((e) => {
					gl(e);
				}), t.sdp = ll.write(n), {
					offer: t,
					offerId: e
				};
			} finally {
				e();
			}
		});
	}
	createAndSendOffer(e) {
		return E(this, void 0, void 0, function* () {
			let t = yield this.offerLock.lock();
			try {
				if (this.onOffer === void 0) return;
				if (e?.iceRestart && (this.log.debug("restarting ICE", this.logContext), this.restartingIce = !0), this._pc && (this._pc.signalingState === "have-local-offer" || this.pendingInitialOffer)) {
					let t = this._pc.remoteDescription;
					if (e?.iceRestart && t) yield this._pc.setRemoteDescription(t);
					else {
						this.renegotiate = !0, this.log.debug("requesting renegotiation", Object.assign({}, this.logContext));
						return;
					}
				} else if (!this._pc || this._pc.signalingState === "closed") {
					this.log.warn("could not createOffer with closed peer connection", this.logContext);
					return;
				}
				this.log.debug("starting to negotiate", this.logContext);
				let t = this.latestOfferId + 1;
				this.latestOfferId = t;
				let n = yield this.pc.createOffer(e);
				this.log.debug("original offer", Object.assign({ sdp: n.sdp }, this.logContext));
				let r = ll.parse(n.sdp ?? "");
				if (r.media.forEach((e) => {
					gl(e), e.type === "audio" ? ml(e, ["all"], []) : e.type === "video" && this.trackBitrates.some((t) => {
						if (!e.msid || !t.cid || !e.msid.includes(t.cid)) return !1;
						let n = 0;
						if (e.rtp.some((e) => e.codec.toUpperCase() === t.codec.toUpperCase() ? (n = e.payload, !0) : !1), n === 0 || (Wo(t.codec) && !Xo() && this.ensureVideoDDExtensionForSVC(e, r), !Wo(t.codec))) return !0;
						let i = Math.round(t.maxbr * ul);
						for (let t of e.fmtp) if (t.payload === n) {
							t.config.includes("x-google-start-bitrate") || (t.config += `;x-google-start-bitrate=${i}`);
							break;
						}
						return !0;
					});
				}), this.latestOfferId > t) {
					this.log.warn("latestOfferId mismatch", Object.assign(Object.assign({}, this.logContext), {
						latestOfferId: this.latestOfferId,
						offerId: t
					}));
					return;
				}
				yield this.setMungedSDP(n, ll.write(r)), this.onOffer(n, this.latestOfferId);
			} finally {
				t();
			}
		});
	}
	createAndSetAnswer() {
		return E(this, void 0, void 0, function* () {
			let e = yield this.pc.createAnswer(), t = ll.parse(e.sdp ?? "");
			return t.media.forEach((e) => {
				gl(e), e.type === "audio" && ml(e, this.remoteStereoMids, this.remoteNackMids);
			}), yield this.setMungedSDP(e, ll.write(t)), e;
		});
	}
	createDataChannel(e, t) {
		return this.pc.createDataChannel(e, t);
	}
	addTransceiver(e, t) {
		return this.pc.addTransceiver(e, t);
	}
	addTransceiverOfKind(e, t) {
		return this.pc.addTransceiver(e, t);
	}
	addTrack(e) {
		if (!this._pc) throw new j("PC closed, cannot add track");
		return this._pc.addTrack(e);
	}
	setTrackCodecBitrate(e) {
		this.trackBitrates.push(e);
	}
	setConfiguration(e) {
		if (!this._pc) throw new j("PC closed, cannot configure");
		return this._pc?.setConfiguration(e);
	}
	canRemoveTrack() {
		return !!this._pc?.removeTrack;
	}
	removeTrack(e) {
		return this._pc?.removeTrack(e);
	}
	getConnectionState() {
		return this._pc?.connectionState ?? "closed";
	}
	getICEConnectionState() {
		return this._pc?.iceConnectionState ?? "closed";
	}
	getSignallingState() {
		return this._pc?.signalingState ?? "closed";
	}
	getTransceivers() {
		return this._pc?.getTransceivers() ?? [];
	}
	getSenders() {
		return this._pc?.getSenders() ?? [];
	}
	getLocalDescription() {
		return this._pc?.localDescription;
	}
	getRemoteDescription() {
		return this.pc?.remoteDescription;
	}
	getStats() {
		return this.pc.getStats();
	}
	getConnectedAddress() {
		return E(this, void 0, void 0, function* () {
			if (!this._pc) return;
			let e = "", t = /* @__PURE__ */ new Map(), n = /* @__PURE__ */ new Map();
			if ((yield this._pc.getStats()).forEach((r) => {
				switch (r.type) {
					case "transport":
						e = r.selectedCandidatePairId;
						break;
					case "candidate-pair":
						e === "" && r.selected && (e = r.id), t.set(r.id, r);
						break;
					case "remote-candidate":
						n.set(r.id, `${r.address}:${r.port}`);
						break;
				}
			}), e === "") return;
			let r = t.get(e)?.remoteCandidateId;
			if (r !== void 0) return n.get(r);
		});
	}
	setMungedSDP(e, t, n) {
		return E(this, void 0, void 0, function* () {
			let r = e.sdp;
			if (t) {
				e.sdp = t;
				try {
					this.log.debug(`setting munged ${n ? "remote" : "local"} description`, this.logContext), n ? yield this.pc.setRemoteDescription(e) : yield this.pc.setLocalDescription(e);
					return;
				} catch (n) {
					this.log.warn(`not able to set ${e.type}, falling back to unmodified sdp`, Object.assign(Object.assign({}, this.logContext), {
						error: n,
						mungedSdp: t,
						originalSdp: r
					})), e.sdp = r;
				}
			}
			try {
				n ? yield this._pc?.setRemoteDescription(e) : yield this._pc?.setLocalDescription(e);
			} catch (i) {
				let a = "unknown error";
				i instanceof Error ? a = i.message : typeof i == "string" && (a = i);
				let o = {
					error: a,
					sdp: e.sdp
				};
				throw t && t !== r && (o.mungedSdp = t), !n && this.pc.remoteDescription && (o.remoteSdp = this.pc.remoteDescription), this.log.error(`unable to set ${e.type}`, Object.assign(Object.assign({}, this.logContext), { fields: o })), new $a(a);
			}
		});
	}
	ensureVideoDDExtensionForSVC(e, t) {
		var n;
		if (!e.ext?.some((e) => e.uri === Ro)) {
			if (this.ddExtID === 0) {
				let e = 0;
				t.media.forEach((t) => {
					var n;
					(n = t.ext) == null || n.forEach((t) => {
						t.value > e && (e = t.value);
					});
				}), this.ddExtID = e + 1;
			}
			(n = e.ext) == null || n.push({
				value: this.ddExtID,
				uri: Ro
			});
		}
	}
};
function ml(e, t, n) {
	let r = _l(e.mid), i = 0;
	e.rtp.some((e) => e.codec === "opus" ? (i = e.payload, !0) : !1), i > 0 && (e.rtcpFb ||= [], n.includes(r) && !e.rtcpFb.some((e) => e.payload === i && e.type === "nack") && e.rtcpFb.push({
		payload: i,
		type: "nack"
	}), (t.includes(r) || t.length === 1 && t[0] === "all") && e.fmtp.some((e) => e.payload === i ? (e.config.includes("stereo=1") || (e.config += ";stereo=1"), !0) : !1));
}
function hl(e) {
	let t = [], n = [], r = ll.parse(e.sdp ?? ""), i = 0;
	return r.media.forEach((e) => {
		let r = _l(e.mid);
		e.type === "audio" && (e.rtp.some((e) => e.codec === "opus" ? (i = e.payload, !0) : !1), e.rtcpFb?.some((e) => e.payload === i && e.type === "nack") && n.push(r), e.fmtp.some((e) => e.payload === i ? (e.config.includes("sprop-stereo=1") && t.push(r), !0) : !1));
	}), {
		stereoMids: t,
		nackMids: n
	};
}
function gl(e) {
	if (e.connection) {
		let t = e.connection.ip.indexOf(":") >= 0;
		(e.connection.version === 4 && t || e.connection.version === 6 && !t) && (e.connection.ip = "0.0.0.0", e.connection.version = 4);
	}
}
function _l(e) {
	return typeof e == "number" ? e.toFixed(0) : e;
}
var vl = "vp8", yl = {
	audioPreset: fo.music,
	dtx: !0,
	red: !0,
	forceStereo: !1,
	simulcast: !0,
	screenShareEncoding: ho.h1080fps15.encoding,
	stopMicTrackOnMute: !1,
	videoCodec: vl,
	backupCodec: !0,
	preConnectBuffer: !1
}, bl = {
	deviceId: { ideal: "default" },
	autoGainControl: !0,
	echoCancellation: !0,
	noiseSuppression: !0,
	voiceIsolation: !0
}, xl = {
	deviceId: { ideal: "default" },
	resolution: po.h720.resolution
}, Sl = {
	adaptiveStream: !1,
	dynacast: !1,
	stopLocalTrackOnUnpublish: !0,
	reconnectPolicy: new vi(),
	disconnectOnPageLeave: !0,
	webAudioMix: !1,
	singlePeerConnection: !0
}, Cl = {
	autoSubscribe: !0,
	maxRetries: 1,
	peerConnectionTimeout: 15e3,
	websocketTimeout: 15e3
}, G;
(function(e) {
	e[e.NEW = 0] = "NEW", e[e.CONNECTING = 1] = "CONNECTING", e[e.CONNECTED = 2] = "CONNECTED", e[e.FAILED = 3] = "FAILED", e[e.CLOSING = 4] = "CLOSING", e[e.CLOSED = 5] = "CLOSED";
})(G ||= {});
var wl = class {
	get needsPublisher() {
		return this.isPublisherConnectionRequired;
	}
	get needsSubscriber() {
		return this.isSubscriberConnectionRequired;
	}
	get currentState() {
		return this.state;
	}
	get mode() {
		return this._mode;
	}
	constructor(e, t, n) {
		this.peerConnectionTimeout = Cl.peerConnectionTimeout, this.log = w, this.updateState = () => {
			var e;
			let t = this.state, n = this.requiredTransports.map((e) => e.getConnectionState());
			n.every((e) => e === "connected") ? this.state = G.CONNECTED : n.some((e) => e === "failed") ? this.state = G.FAILED : n.some((e) => e === "connecting") ? this.state = G.CONNECTING : n.every((e) => e === "closed") ? this.state = G.CLOSED : n.some((e) => e === "closed") ? this.state = G.CLOSING : n.every((e) => e === "new") && (this.state = G.NEW), t !== this.state && (this.log.debug(`pc state change: from ${G[t]} to ${G[this.state]}`, this.logContext), (e = this.onStateChange) == null || e.call(this, this.state, this.publisher.getConnectionState(), this.subscriber?.getConnectionState()));
		}, this.log = T(t.loggerName ?? C.PCManager), this.loggerOptions = t, this.isPublisherConnectionRequired = e !== "subscriber-primary", this.isSubscriberConnectionRequired = e === "subscriber-primary", this.publisher = new pl(n, t), this._mode = e, e !== "publisher-only" && (this.subscriber = new pl(n, t), this.subscriber.onConnectionStateChange = this.updateState, this.subscriber.onIceConnectionStateChange = this.updateState, this.subscriber.onSignalingStatechange = this.updateState, this.subscriber.onIceCandidate = (e) => {
			var t;
			(t = this.onIceCandidate) == null || t.call(this, e, Xn.SUBSCRIBER);
		}, this.subscriber.onDataChannel = (e) => {
			var t;
			(t = this.onDataChannel) == null || t.call(this, e);
		}, this.subscriber.onTrack = (e) => {
			var t;
			(t = this.onTrack) == null || t.call(this, e);
		}), this.publisher.onConnectionStateChange = this.updateState, this.publisher.onIceConnectionStateChange = this.updateState, this.publisher.onSignalingStatechange = this.updateState, this.publisher.onIceCandidate = (e) => {
			var t;
			(t = this.onIceCandidate) == null || t.call(this, e, Xn.PUBLISHER);
		}, this.publisher.onTrack = (e) => {
			var t;
			(t = this.onTrack) == null || t.call(this, e);
		}, this.publisher.onOffer = (e, t) => {
			var n;
			(n = this.onPublisherOffer) == null || n.call(this, e, t);
		}, this.state = G.NEW, this.connectionLock = new i(), this.remoteOfferLock = new i();
	}
	get logContext() {
		var e;
		return Object.assign({}, (e = this.loggerOptions).loggerContextCb?.call(e));
	}
	requirePublisher() {
		let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : !0;
		this.isPublisherConnectionRequired = e, this.updateState();
	}
	createAndSendPublisherOffer(e) {
		return this.publisher.createAndSendOffer(e);
	}
	setPublisherAnswer(e, t) {
		return this.publisher.setRemoteDescription(e, t);
	}
	removeTrack(e) {
		return this.publisher.removeTrack(e);
	}
	close() {
		return E(this, void 0, void 0, function* () {
			if (this.publisher && this.publisher.getSignallingState() !== "closed") {
				let e = this.publisher;
				for (let t of e.getSenders()) try {
					e.canRemoveTrack() && e.removeTrack(t);
				} catch (e) {
					this.log.warn("could not removeTrack", Object.assign(Object.assign({}, this.logContext), { error: e }));
				}
			}
			yield Promise.all([this.publisher.close(), this.subscriber?.close()]), this.updateState();
		});
	}
	triggerIceRestart() {
		return E(this, void 0, void 0, function* () {
			this.subscriber && (this.subscriber.restartingIce = !0), this.needsPublisher && (yield this.createAndSendPublisherOffer({ iceRestart: !0 }));
		});
	}
	addIceCandidate(e, t) {
		return E(this, void 0, void 0, function* () {
			t === Xn.PUBLISHER ? yield this.publisher.addIceCandidate(e) : yield this.subscriber?.addIceCandidate(e);
		});
	}
	createSubscriberAnswerFromOffer(e, t) {
		return E(this, void 0, void 0, function* () {
			this.log.debug("received server offer", Object.assign(Object.assign({}, this.logContext), {
				RTCSdpType: e.type,
				sdp: e.sdp,
				signalingState: this.subscriber?.getSignallingState().toString()
			}));
			let n = yield this.remoteOfferLock.lock();
			try {
				return (yield this.subscriber?.setRemoteDescription(e, t)) ? yield this.subscriber?.createAndSetAnswer() : void 0;
			} finally {
				n();
			}
		});
	}
	updateConfiguration(e, t) {
		var n;
		this.publisher.setConfiguration(e), (n = this.subscriber) == null || n.setConfiguration(e), t && this.triggerIceRestart();
	}
	ensurePCTransportConnection(e, t) {
		return E(this, void 0, void 0, function* () {
			let n = yield this.connectionLock.lock();
			try {
				this.isPublisherConnectionRequired && this.publisher.getConnectionState() !== "connected" && this.publisher.getConnectionState() !== "connecting" && (this.log.debug("negotiation required, start negotiating", this.logContext), this.publisher.negotiate()), yield Promise.all(this.requiredTransports?.map((n) => this.ensureTransportConnected(n, e, t)));
			} finally {
				n();
			}
		});
	}
	negotiate(e) {
		return E(this, void 0, void 0, function* () {
			return new D((t, n) => {
				let r = this.publisher.latestOfferId;
				if (this.publisher.latestAcknowledgedOfferId > r) {
					this.log.debug("negotiation already handled in more recent acknowledged offer", this.logContext), t();
					return;
				}
				let i = !1, a = () => {
					i || (i = !0, clearTimeout(c), this.publisher.off(fl.OfferAnswered, o), e.signal.removeEventListener("abort", s));
				}, o = (e) => {
					e > r && (a(), t());
				}, s = () => {
					a(), n(new $a("negotiation aborted"));
				}, c = setTimeout(() => {
					a(), n(new $a("negotiation timed out"));
				}, this.peerConnectionTimeout);
				e.signal.addEventListener("abort", s), this.publisher.on(fl.OfferAnswered, o), this.publisher.negotiate((e) => {
					a(), e instanceof Error ? n(e) : n(Error(String(e)));
				});
			});
		});
	}
	addPublisherTransceiver(e, t) {
		return this.publisher.addTransceiver(e, t);
	}
	addPublisherTransceiverOfKind(e, t) {
		return this.publisher.addTransceiverOfKind(e, t);
	}
	getMidForReceiver(e) {
		return (this.subscriber ? this.subscriber.getTransceivers() : this.publisher.getTransceivers()).find((t) => t.receiver === e)?.mid;
	}
	addPublisherTrack(e) {
		return this.publisher.addTrack(e);
	}
	createPublisherDataChannel(e, t) {
		return this.publisher.createDataChannel(e, t);
	}
	getConnectedAddress(e) {
		return e === Xn.PUBLISHER || e === Xn.SUBSCRIBER ? this.publisher.getConnectedAddress() : this.requiredTransports[0].getConnectedAddress();
	}
	get requiredTransports() {
		let e = [];
		return this.isPublisherConnectionRequired && e.push(this.publisher), this.isSubscriberConnectionRequired && this.subscriber && e.push(this.subscriber), e;
	}
	ensureTransportConnected(e, t) {
		return E(this, arguments, void 0, function(e, t) {
			var n = this;
			let r = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : this.peerConnectionTimeout;
			return function* () {
				if (e.getConnectionState() !== "connected") return new Promise((e, i) => E(n, void 0, void 0, function* () {
					let n = () => {
						this.log.warn("abort transport connection", this.logContext), N.clearTimeout(a), i(A.cancelled("room connection has been cancelled"));
					};
					t?.signal.aborted && n(), t?.signal.addEventListener("abort", n);
					let a = N.setTimeout(() => {
						t?.signal.removeEventListener("abort", n), i(A.internal("could not establish pc connection"));
					}, r);
					for (; this.state !== G.CONNECTED;) if (yield V(50), t?.signal.aborted) {
						i(A.cancelled("room connection has been cancelled"));
						return;
					}
					N.clearTimeout(a), t?.signal.removeEventListener("abort", n), e();
				}));
			}();
		});
	}
}, Tl = typeof MediaRecorder < "u", El = Tl ? MediaRecorder : class {
	constructor() {
		throw Error("MediaRecorder is not available in this environment");
	}
}, Dl = class extends El {
	constructor(e, t) {
		if (!Tl) throw Error("MediaRecorder is not available in this environment");
		super(new MediaStream([e.mediaStreamTrack]), t);
		let n, r, i = () => r === void 0, a = () => {
			this.removeEventListener("dataavailable", n), this.removeEventListener("stop", a), this.removeEventListener("error", o), r?.close(), r = void 0;
		}, o = (e) => {
			r?.error(e), this.removeEventListener("dataavailable", n), this.removeEventListener("stop", a), this.removeEventListener("error", o), r = void 0;
		};
		this.byteStream = new ReadableStream({
			start: (e) => {
				r = e, n = (t) => E(this, void 0, void 0, function* () {
					let n;
					if (t.data.arrayBuffer) {
						let e = yield t.data.arrayBuffer();
						n = new Uint8Array(e);
					} else if (t.data.byteArray) n = t.data.byteArray;
					else throw Error("no data available!");
					i() || e.enqueue(n);
				}), this.addEventListener("dataavailable", n);
			},
			cancel: () => {
				a();
			}
		}), this.addEventListener("stop", a), this.addEventListener("error", o);
	}
};
function Ol() {
	return Tl;
}
var kl = 1e3, Al = 1e4, jl = class extends B {
	get sender() {
		return this._sender;
	}
	set sender(e) {
		this._sender = e;
	}
	get constraints() {
		return this._constraints;
	}
	get hasPreConnectBuffer() {
		return !!this.localTrackRecorder;
	}
	constructor(e, t, n) {
		let r = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : !1, a = arguments.length > 4 ? arguments[4] : void 0;
		super(e, t, a), this.manuallyStopped = !1, this.pendingDeviceChange = !1, this._isUpstreamPaused = !1, this.handleTrackMuteEvent = () => this.debouncedTrackMuteHandler().catch(() => this.log.debug("track mute bounce got cancelled by an unmute event", this.logContext)), this.debouncedTrackMuteHandler = lc(() => E(this, void 0, void 0, function* () {
			yield this.pauseUpstream();
		}), 5e3), this.handleTrackUnmuteEvent = () => E(this, void 0, void 0, function* () {
			this.debouncedTrackMuteHandler.cancel("unmute"), yield this.resumeUpstream();
		}), this.handleEnded = () => {
			this.isInBackground && (this.reacquireTrack = !0), this._mediaStreamTrack.removeEventListener("mute", this.handleTrackMuteEvent), this._mediaStreamTrack.removeEventListener("unmute", this.handleTrackUnmuteEvent), this.emit(L.Ended, this);
		}, this.reacquireTrack = !1, this.providedByUser = r, this.muteLock = new i(), this.pauseUpstreamLock = new i(), this.trackChangeLock = new i(), this.trackChangeLock.lock().then((t) => E(this, void 0, void 0, function* () {
			try {
				yield this.setMediaStreamTrack(e, !0);
			} finally {
				t();
			}
		})), this._constraints = e.getConstraints(), n && (this._constraints = n);
	}
	get id() {
		return this._mediaStreamTrack.id;
	}
	get dimensions() {
		if (this.kind !== B.Kind.Video) return;
		let e = this._mediaStreamTrack.getSettings(), t = e.width, n = e.height;
		if (t && n) return {
			width: t,
			height: n
		};
	}
	get isUpstreamPaused() {
		return this._isUpstreamPaused;
	}
	get isUserProvided() {
		return this.providedByUser;
	}
	get mediaStreamTrack() {
		return this.processor?.processedTrack ?? this._mediaStreamTrack;
	}
	get isLocal() {
		return !0;
	}
	getSourceTrackSettings() {
		return this._mediaStreamTrack.getSettings();
	}
	setMediaStreamTrack(e, t, n) {
		return E(this, void 0, void 0, function* () {
			if (e === this._mediaStreamTrack && !t) return;
			this._mediaStreamTrack && (this.attachedElements.forEach((e) => {
				Io(this._mediaStreamTrack, e);
			}), this.debouncedTrackMuteHandler.cancel("new-track"), this._mediaStreamTrack.removeEventListener("ended", this.handleEnded), this._mediaStreamTrack.removeEventListener("mute", this.handleTrackMuteEvent), this._mediaStreamTrack.removeEventListener("unmute", this.handleTrackUnmuteEvent)), this.mediaStream = new MediaStream([e]), e && (e.addEventListener("ended", this.handleEnded), e.addEventListener("mute", this.handleTrackMuteEvent), e.addEventListener("unmute", this.handleTrackUnmuteEvent), this._constraints = e.getConstraints());
			let r;
			if (this.processor && e) {
				if (this.log.debug("restarting processor", this.logContext), this.kind === "unknown") throw TypeError("cannot set processor on track of unknown kind");
				this.processorElement && (Fo(e, this.processorElement), this.processorElement.muted = !0), yield this.processor.restart({
					track: e,
					kind: this.kind,
					element: this.processorElement,
					localTrack: this
				}), r = this.processor.processedTrack;
			}
			this.sender && this.sender.transport?.state !== "closed" && (yield this.sender.replaceTrack(r ?? e)), !this.providedByUser && this._mediaStreamTrack !== e && this._mediaStreamTrack.stop(), this._mediaStreamTrack = e, e && (this._mediaStreamTrack.enabled = n ? !0 : !this.isMuted, yield this.resumeUpstream(), this.attachedElements.forEach((t) => {
				Fo(r ?? e, t);
			}));
		});
	}
	waitForDimensions() {
		return E(this, arguments, void 0, function() {
			var e = this;
			let t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : kl;
			return function* () {
				if (e.kind === B.Kind.Audio) throw Error("cannot get dimensions for audio tracks");
				O()?.os === "iOS" && (yield V(10));
				let n = Date.now();
				for (; Date.now() - n < t;) {
					let t = e.dimensions;
					if (t) return t;
					yield V(50);
				}
				throw new Za("unable to get track dimensions after timeout");
			}();
		});
	}
	setDeviceId(e) {
		return E(this, void 0, void 0, function* () {
			return this._constraints.deviceId === e && this._mediaStreamTrack.getSettings().deviceId === bs(e) ? !0 : (this._constraints.deviceId = e, this.isMuted ? (this.pendingDeviceChange = !0, !0) : (yield this.restartTrack(), bs(e) === this._mediaStreamTrack.getSettings().deviceId));
		});
	}
	getDeviceId() {
		return E(this, arguments, void 0, function() {
			var e = this;
			let t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : !0;
			return function* () {
				if (e.source === B.Source.ScreenShare) return;
				let n = e._mediaStreamTrack.getSettings(), r = n.deviceId, i = n.groupId, a = e.kind === B.Kind.Audio ? "audioinput" : "videoinput";
				return t ? Ec.getInstance().normalizeDeviceId(a, r, i) : r;
			}();
		});
	}
	mute() {
		return E(this, void 0, void 0, function* () {
			return this.setTrackMuted(!0), this;
		});
	}
	unmute() {
		return E(this, void 0, void 0, function* () {
			return this.setTrackMuted(!1), this;
		});
	}
	replaceTrack(e, t) {
		return E(this, void 0, void 0, function* () {
			let n = yield this.trackChangeLock.lock();
			try {
				if (!this.sender) throw new Za("unable to replace an unpublished track");
				let n, r;
				typeof t == "boolean" ? n = t : t !== void 0 && (n = t.userProvidedTrack, r = t.stopProcessor), this.providedByUser = n ?? !0, this.log.debug("replace MediaStreamTrack", this.logContext), yield this.setMediaStreamTrack(e), r && this.processor && (yield this.internalStopProcessor());
			} finally {
				n();
			}
			return yield this.onSenderTrackSwapped(), this;
		});
	}
	onSenderTrackSwapped() {
		return E(this, void 0, void 0, function* () {});
	}
	restart(e, t) {
		return E(this, void 0, void 0, function* () {
			this.manuallyStopped = !1;
			let n = yield this.trackChangeLock.lock();
			try {
				e ||= this._constraints;
				let n = e, r = n.deviceId, i = n.facingMode, a = yi(e, ["deviceId", "facingMode"]);
				this.log.debug("restarting track with constraints", Object.assign(Object.assign({}, this.logContext), { constraints: e }));
				let o = {
					audio: !1,
					video: !1
				};
				this.kind === B.Kind.Video ? o.video = r || i ? {
					deviceId: r,
					facingMode: i
				} : !0 : o.audio = r ? Object.assign({ deviceId: r }, a) : !0, this.attachedElements.forEach((e) => {
					Io(this.mediaStreamTrack, e);
				}), this._mediaStreamTrack.removeEventListener("ended", this.handleEnded), this._mediaStreamTrack.stop();
				let s = (yield navigator.mediaDevices.getUserMedia(o)).getTracks()[0];
				return this.kind === B.Kind.Video && (yield s.applyConstraints(a)), s.addEventListener("ended", this.handleEnded), this.log.debug("re-acquired MediaStreamTrack", this.logContext), yield this.setMediaStreamTrack(s, !1, t), this._constraints = e, this.pendingDeviceChange = !1, this.emit(L.Restarted, this), this.manuallyStopped && (this.log.warn("track was stopped during a restart, stopping restarted track", this.logContext), this.stop()), this;
			} finally {
				n();
			}
		});
	}
	setTrackMuted(e) {
		this.log.debug(`setting ${this.kind} track ${e ? "muted" : "unmuted"}`, this.logContext), !(this.isMuted === e && this._mediaStreamTrack.enabled !== e) && (this.isMuted = e, this._mediaStreamTrack.enabled = !e, this.emit(e ? L.Muted : L.Unmuted, this));
	}
	get needsReAcquisition() {
		return this._mediaStreamTrack.readyState !== "live" || this._mediaStreamTrack.muted || !this._mediaStreamTrack.enabled || this.reacquireTrack;
	}
	handleAppVisibilityChanged() {
		let e = Object.create(null, { handleAppVisibilityChanged: { get: () => super.handleAppVisibilityChanged } });
		return E(this, void 0, void 0, function* () {
			yield e.handleAppVisibilityChanged.call(this), es() && (this.log.debug(`visibility changed, is in Background: ${this.isInBackground}`, this.logContext), !this.isInBackground && this.needsReAcquisition && !this.isUserProvided && !this.isMuted && (this.log.debug(`track needs to be reacquired, restarting ${this.source}`, this.logContext), yield this.restart(), this.reacquireTrack = !1));
		});
	}
	stop() {
		var e;
		this.manuallyStopped = !0, super.stop(), this._mediaStreamTrack.removeEventListener("ended", this.handleEnded), this._mediaStreamTrack.removeEventListener("mute", this.handleTrackMuteEvent), this._mediaStreamTrack.removeEventListener("unmute", this.handleTrackUnmuteEvent), (e = this.processor) == null || e.destroy(), this.processor = void 0;
	}
	pauseUpstream() {
		return E(this, void 0, void 0, function* () {
			let e = yield this.pauseUpstreamLock.lock();
			try {
				if (this._isUpstreamPaused === !0) return;
				if (!this.sender) {
					this.log.warn("unable to pause upstream for an unpublished track", this.logContext);
					return;
				}
				this._isUpstreamPaused = !0, this.emit(L.UpstreamPaused, this);
				let e = O();
				if (e?.name === "Safari" && cs(e.version, "12.0") < 0) throw new Xa("pauseUpstream is not supported on Safari < 12.");
				this.sender.transport?.state !== "closed" && (yield this.sender.replaceTrack(null));
			} finally {
				e();
			}
		});
	}
	resumeUpstream() {
		return E(this, void 0, void 0, function* () {
			let e = yield this.pauseUpstreamLock.lock();
			try {
				if (this._isUpstreamPaused === !1) return;
				if (!this.sender) {
					this.log.warn("unable to resume upstream for an unpublished track", this.logContext);
					return;
				}
				this._isUpstreamPaused = !1, this.emit(L.UpstreamResumed, this), this.sender.transport?.state !== "closed" && (yield this.sender.replaceTrack(this.mediaStreamTrack));
			} finally {
				e();
			}
		});
	}
	getRTCStatsReport() {
		return E(this, void 0, void 0, function* () {
			if (this.sender?.getStats) return yield this.sender.getStats();
		});
	}
	setProcessor(e) {
		return E(this, arguments, void 0, function(e) {
			var t = this;
			let n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !0;
			return function* () {
				let r = yield t.trackChangeLock.lock();
				try {
					t.log.debug("setting up processor", t.logContext);
					let r = document.createElement(t.kind), i = {
						kind: t.kind,
						track: t._mediaStreamTrack,
						element: r,
						audioContext: t.audioContext,
						localTrack: t
					};
					if (yield e.init(i), t.log.debug("processor initialized", t.logContext), t.processor && (yield t.internalStopProcessor()), t.kind === "unknown") throw TypeError("cannot set processor on track of unknown kind");
					if (Fo(t._mediaStreamTrack, r), r.muted = !0, r.play().catch((e) => {
						e instanceof DOMException && e.name === "AbortError" ? (t.log.warn("failed to play processor element, retrying", Object.assign(Object.assign({}, t.logContext), { error: e })), setTimeout(() => {
							r.play().catch((e) => {
								t.log.error("failed to play processor element", Object.assign(Object.assign({}, t.logContext), { err: e }));
							});
						}, 100)) : t.log.error("failed to play processor element", Object.assign(Object.assign({}, t.logContext), { error: e }));
					}), t.processor = e, t.processorElement = r, t.processor.processedTrack) {
						for (let e of t.attachedElements) e !== t.processorElement && n && (Io(t._mediaStreamTrack, e), Fo(t.processor.processedTrack, e));
						yield t.sender?.replaceTrack(t.processor.processedTrack);
					}
					t.emit(L.TrackProcessorUpdate, t.processor);
				} finally {
					r();
				}
				yield t.onSenderTrackSwapped();
			}();
		});
	}
	getProcessor() {
		return this.processor;
	}
	stopProcessor() {
		return E(this, arguments, void 0, function() {
			var e = this;
			let t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : !0;
			return function* () {
				let n = yield e.trackChangeLock.lock();
				try {
					yield e.internalStopProcessor(t);
				} finally {
					n();
				}
				yield e.onSenderTrackSwapped();
			}();
		});
	}
	internalStopProcessor() {
		return E(this, arguments, void 0, function() {
			var e = this;
			let t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : !0;
			return function* () {
				var n, r;
				e.processor && (e.log.debug("stopping processor", e.logContext), (n = e.processor.processedTrack) == null || n.stop(), yield e.processor.destroy(), e.processor = void 0, t || ((r = e.processorElement) == null || r.remove(), e.processorElement = void 0), yield e._mediaStreamTrack.applyConstraints(e._constraints), yield e.setMediaStreamTrack(e._mediaStreamTrack, !0), e.emit(L.TrackProcessorUpdate));
			}();
		});
	}
	startPreConnectBuffer() {
		let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : 100;
		if (!Ol()) {
			this.log.warn("MediaRecorder is not available, cannot start preconnect buffer", this.logContext);
			return;
		}
		if (this.localTrackRecorder) {
			this.log.warn("preconnect buffer already started");
			return;
		} else {
			let e = "audio/webm;codecs=opus";
			MediaRecorder.isTypeSupported(e) || (e = "video/mp4"), this.localTrackRecorder = new Dl(this, { mimeType: e });
		}
		this.localTrackRecorder.start(e), this.autoStopPreConnectBuffer = setTimeout(() => {
			this.log.warn("preconnect buffer timed out, stopping recording automatically", this.logContext), this.stopPreConnectBuffer();
		}, Al);
	}
	stopPreConnectBuffer() {
		clearTimeout(this.autoStopPreConnectBuffer), this.localTrackRecorder &&= (this.localTrackRecorder.stop(), void 0);
	}
	getPreConnectBuffer() {
		return this.localTrackRecorder?.byteStream;
	}
	getPreConnectBufferMimeType() {
		return this.localTrackRecorder?.mimeType;
	}
}, Ml = class extends jl {
	get enhancedNoiseCancellation() {
		return this.isKrispNoiseFilterEnabled;
	}
	constructor(e, t) {
		let n = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : !0, r = arguments.length > 3 ? arguments[3] : void 0, i = arguments.length > 4 ? arguments[4] : void 0;
		super(e, B.Kind.Audio, t, n, i), this.stopOnMute = !1, this.isKrispNoiseFilterEnabled = !1, this.monitorSender = () => E(this, void 0, void 0, function* () {
			if (!this.sender) {
				this._currentBitrate = 0;
				return;
			}
			let e;
			try {
				e = yield this.getSenderStats();
			} catch (e) {
				this.log.error("could not get audio sender stats", Object.assign(Object.assign({}, this.logContext), { error: e }));
				return;
			}
			e && this.prevStats && (this._currentBitrate = dc(e, this.prevStats)), this.prevStats = e;
		}), this.handleKrispNoiseFilterEnable = () => {
			this.isKrispNoiseFilterEnabled = !0, this.log.debug("Krisp noise filter enabled", this.logContext), this.emit(L.AudioTrackFeatureUpdate, this, b.TF_ENHANCED_NOISE_CANCELLATION, !0);
		}, this.handleKrispNoiseFilterDisable = () => {
			this.isKrispNoiseFilterEnabled = !1, this.log.debug("Krisp noise filter disabled", this.logContext), this.emit(L.AudioTrackFeatureUpdate, this, b.TF_ENHANCED_NOISE_CANCELLATION, !1);
		}, this.audioContext = r, this.checkForSilence();
	}
	mute() {
		let e = Object.create(null, { mute: { get: () => super.mute } });
		return E(this, void 0, void 0, function* () {
			let t = yield this.muteLock.lock();
			try {
				return this.isMuted ? (this.log.debug("Track already muted", this.logContext), this) : (this.source === B.Source.Microphone && this.stopOnMute && !this.isUserProvided && (this.log.debug("stopping mic track", this.logContext), this._mediaStreamTrack.stop()), yield e.mute.call(this), this);
			} finally {
				t();
			}
		});
	}
	unmute() {
		let e = Object.create(null, { unmute: { get: () => super.unmute } });
		return E(this, void 0, void 0, function* () {
			let t = yield this.muteLock.lock();
			try {
				return this.isMuted ? (this.source === B.Source.Microphone && (this.stopOnMute || this._mediaStreamTrack.readyState === "ended" || this.pendingDeviceChange) && !this.isUserProvided && (this.log.debug("reacquiring mic track", this.logContext), yield this.restart(void 0, !0)), yield e.unmute.call(this), this) : (this.log.debug("Track already unmuted", this.logContext), this);
			} finally {
				t();
			}
		});
	}
	restartTrack(e) {
		return E(this, void 0, void 0, function* () {
			let t;
			if (e) {
				let n = vo({ audio: e });
				typeof n.audio != "boolean" && (t = n.audio);
			}
			yield this.restart(t);
		});
	}
	restart(e, t) {
		let n = Object.create(null, { restart: { get: () => super.restart } });
		return E(this, void 0, void 0, function* () {
			let r = yield n.restart.call(this, e, t);
			return this.checkForSilence(), r;
		});
	}
	startMonitor() {
		H() && (this.monitorInterval ||= setInterval(() => {
			this.monitorSender();
		}, uc));
	}
	setProcessor(e) {
		return E(this, void 0, void 0, function* () {
			let t = yield this.trackChangeLock.lock();
			try {
				if (!ns() && !this.audioContext) throw Error("Audio context needs to be set on LocalAudioTrack in order to enable processors");
				this.processor && (yield this.internalStopProcessor());
				let t = {
					kind: this.kind,
					track: this._mediaStreamTrack,
					audioContext: this.audioContext,
					localTrack: this
				};
				this.log.debug(`setting up audio processor ${e.name}`, this.logContext), yield e.init(t), this.processor = e, this.processor.processedTrack && (yield this.sender?.replaceTrack(this.processor.processedTrack), this.processor.processedTrack.addEventListener("enable-lk-krisp-noise-filter", this.handleKrispNoiseFilterEnable), this.processor.processedTrack.addEventListener("disable-lk-krisp-noise-filter", this.handleKrispNoiseFilterDisable)), this.emit(L.TrackProcessorUpdate, this.processor);
			} finally {
				t();
			}
		});
	}
	setAudioContext(e) {
		this.audioContext = e;
	}
	getSenderStats() {
		return E(this, void 0, void 0, function* () {
			if (!this.sender?.getStats) return;
			let e = yield this.sender.getStats(), t;
			return e.forEach((e) => {
				e.type === "outbound-rtp" && (t = {
					type: "audio",
					streamId: e.id,
					packetsSent: e.packetsSent,
					packetsLost: e.packetsLost,
					bytesSent: e.bytesSent,
					timestamp: e.timestamp,
					roundTripTime: e.roundTripTime,
					jitter: e.jitter
				});
			}), t;
		});
	}
	checkForSilence() {
		return E(this, void 0, void 0, function* () {
			let e = yield yo(this);
			return e && (this.isMuted || this.log.debug("silence detected on local audio track", this.logContext), this.emit(L.AudioSilenceDetected)), e;
		});
	}
};
function Nl(e, t, n) {
	switch (e.kind) {
		case "audio": return new Ml(e, t, !1, void 0, n);
		case "video": return new Zl(e, t, !1, n);
		default: throw new Za(`unsupported track type: ${e.kind}`);
	}
}
var Pl = Object.values(po), Fl = Object.values(mo), Il = Object.values(ho), Ll = [po.h180, po.h360], Rl = [mo.h180, mo.h360], zl = (e) => [{
	scaleResolutionDownBy: 2,
	fps: e.encoding.maxFramerate
}].map((t) => new R(Math.floor(e.width / t.scaleResolutionDownBy), Math.floor(e.height / t.scaleResolutionDownBy), Math.max(15e4, Math.floor(e.encoding.maxBitrate / (t.scaleResolutionDownBy ** 2 * ((e.encoding.maxFramerate ?? 30) / (t.fps ?? 30))))), t.fps, e.encoding.priority)), Bl = [
	"q",
	"h",
	"f"
];
function Vl(e, t, n, r) {
	let i = r?.videoEncoding;
	e && (i = r?.screenShareEncoding);
	let a = r?.simulcast, o = r?.scalabilityMode, s = r?.videoCodec;
	if (!i && !a && !o || !t || !n) return [{}];
	i || (i = Ul(e, t, n, s), w.debug("using video encoding", i));
	let c = i.maxFramerate, l = new R(t, n, i.maxBitrate, i.maxFramerate, i.priority);
	if (o && Wo(s)) {
		let e = new Jl(o), t = [];
		if (e.spatial > 3) throw Error(`unsupported scalabilityMode: ${o}`);
		let n = O();
		if (Zo() || ns() || n?.name === "Chrome" && cs(n?.version, "113") < 0) {
			let r = e.suffix == "h" ? 2 : 3, a = $o(n);
			for (let n = 0; n < e.spatial; n += 1) t.push({
				rid: Bl[2 - n],
				maxBitrate: i.maxBitrate / r ** +n,
				maxFramerate: l.encoding.maxFramerate,
				scaleResolutionDownBy: a ? 2 ** n : void 0
			});
			t[0].scalabilityMode = o;
		} else t.push({
			maxBitrate: i.maxBitrate,
			maxFramerate: l.encoding.maxFramerate,
			scalabilityMode: o
		});
		return l.encoding.priority && (t[0].priority = l.encoding.priority, t[0].networkPriority = l.encoding.priority), w.debug("using svc encoding", { encodings: t }), t;
	}
	if (!a) return [i];
	let u;
	u = e ? ql(r?.screenShareSimulcastLayers) ?? Gl(e, l) : ql(r?.videoSimulcastLayers) ?? Gl(e, l);
	let d;
	if (u.length > 0) {
		let e = u[0];
		u.length > 1 && (d = g(u, 2)[1]);
		let r = Math.max(t, n);
		if (r >= 960 && d) return Kl(t, n, [
			e,
			d,
			l
		], c);
		if (r >= 480) return Kl(t, n, [e, l], c);
	}
	return Kl(t, n, [l]);
}
function Hl(e, t, n) {
	if (!n.backupCodec || n.backupCodec === !0 || n.backupCodec.codec === n.videoCodec) return;
	t !== n.backupCodec.codec && w.warn("requested a different codec than specified as backup", {
		serverRequested: t,
		backup: n.backupCodec.codec
	}), n.videoCodec = t, n.videoEncoding = n.backupCodec.encoding;
	let r = e.mediaStreamTrack.getSettings(), i = r.width ?? e.dimensions?.width, a = r.height ?? e.dimensions?.height;
	return e.source === B.Source.ScreenShare && n.simulcast && (n.simulcast = !1), Vl(e.source === B.Source.ScreenShare, i, a, n);
}
function Ul(e, t, n, r) {
	let i = Wl(e, t, n), a = i[0].encoding, o = Math.max(t, n);
	for (let e = 0; e < i.length; e += 1) {
		let t = i[e];
		if (a = t.encoding, t.width >= o) break;
	}
	if (r) switch (r) {
		case "av1":
		case "h265":
			a = Object.assign({}, a), a.maxBitrate *= .7;
			break;
		case "vp9":
			a = Object.assign({}, a), a.maxBitrate *= .85;
			break;
	}
	return a;
}
function Wl(e, t, n) {
	if (e) return Il;
	let r = t > n ? t / n : n / t;
	return Math.abs(r - 16 / 9) < Math.abs(r - 4 / 3) ? Pl : Fl;
}
function Gl(e, t) {
	if (e) return zl(t);
	let n = t.width, r = t.height, i = n > r ? n / r : r / n;
	return Math.abs(i - 16 / 9) < Math.abs(i - 4 / 3) ? Ll : Rl;
}
function Kl(e, t, n, r) {
	let i = [];
	if (n.forEach((n, a) => {
		if (a >= Bl.length) return;
		let o = Math.min(e, t), s = {
			rid: Bl[a],
			scaleResolutionDownBy: Math.max(1, o / Math.min(n.width, n.height)),
			maxBitrate: n.encoding.maxBitrate
		}, c = r && n.encoding.maxFramerate ? Math.min(r, n.encoding.maxFramerate) : n.encoding.maxFramerate;
		c && (s.maxFramerate = c);
		let l = O(), u = l?.name === "Firefox" && l.os !== "iOS" || a === 0;
		n.encoding.priority && u && (s.priority = n.encoding.priority, s.networkPriority = n.encoding.priority), i.push(s);
	}), ns() && os() === "ios") {
		let e;
		i.forEach((t) => {
			e ? t.maxFramerate && t.maxFramerate > e && (e = t.maxFramerate) : e = t.maxFramerate;
		});
		let t = !0;
		i.forEach((n) => {
			n.maxFramerate != e && (t && (t = !1, w.info("Simulcast on iOS React-Native requires all encodings to share the same framerate.")), w.info(`Setting framerate of encoding "${n.rid ?? ""}" to ${e}`), n.maxFramerate = e);
		});
	}
	return i;
}
function ql(e) {
	if (e) return e.sort((e, t) => {
		let n = e.encoding, r = t.encoding;
		return n.maxBitrate > r.maxBitrate ? 1 : n.maxBitrate < r.maxBitrate ? -1 : n.maxBitrate === r.maxBitrate && n.maxFramerate && r.maxFramerate ? n.maxFramerate > r.maxFramerate ? 1 : -1 : 0;
	});
}
var Jl = class {
	constructor(e) {
		let t = e.match(/^L(\d)T(\d)(h|_KEY|_KEY_SHIFT){0,1}$/);
		if (!t) throw Error("invalid scalability mode");
		if (this.spatial = parseInt(t[1]), this.temporal = parseInt(t[2]), t.length > 3) switch (t[3]) {
			case "h":
			case "_KEY":
			case "_KEY_SHIFT": this.suffix = t[3];
		}
	}
	toString() {
		return `L${this.spatial}T${this.temporal}${this.suffix ?? ""}`;
	}
};
function Yl(e) {
	return e.source === B.Source.ScreenShare || e.constraints.height && bs(e.constraints.height) >= 1080 ? "maintain-resolution" : "balanced";
}
var Xl = 5e3, Zl = class extends jl {
	get sender() {
		return this._sender;
	}
	set sender(e) {
		this._sender = e, this.degradationPreference && this.setDegradationPreference(this.degradationPreference);
	}
	constructor(e, t) {
		let n = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : !0, r = arguments.length > 3 ? arguments[3] : void 0;
		super(e, B.Kind.Video, t, n, r), this.simulcastCodecs = /* @__PURE__ */ new Map(), this.degradationPreference = "balanced", this.isCpuConstrained = !1, this.optimizeForPerformance = !1, this.monitorSender = () => E(this, void 0, void 0, function* () {
			if (!this.sender) {
				this._currentBitrate = 0;
				return;
			}
			let e;
			try {
				e = yield this.getSenderStats();
			} catch (e) {
				this.log.error("could not get video sender stats", Object.assign(Object.assign({}, this.logContext), { error: e }));
				return;
			}
			let t = new Map(e.map((e) => [e.rid, e])), n = e.some((e) => e.qualityLimitationReason === "cpu");
			if (n !== this.isCpuConstrained && (this.isCpuConstrained = n, this.isCpuConstrained && this.emit(L.CpuConstrained)), this.prevStats) {
				let e = 0;
				t.forEach((t, n) => {
					let r = this.prevStats?.get(n);
					e += dc(t, r);
				}), this._currentBitrate = e;
			}
			this.prevStats = t;
		}), this.senderLock = new i();
	}
	get isSimulcast() {
		return !!(this.sender && this.sender.getParameters().encodings.length > 1);
	}
	startMonitor(e) {
		if (this.signalClient = e, !H()) return;
		let t = this.sender?.getParameters();
		t && (this.encodings = t.encodings), !this.monitorInterval && (this.monitorInterval = setInterval(() => {
			this.monitorSender();
		}, uc));
	}
	stop() {
		this._mediaStreamTrack.getConstraints(), this.simulcastCodecs.forEach((e) => {
			e.mediaStreamTrack.stop();
		}), super.stop();
	}
	pauseUpstream() {
		let e = Object.create(null, { pauseUpstream: { get: () => super.pauseUpstream } });
		return E(this, void 0, void 0, function* () {
			var t, n, r, i;
			yield e.pauseUpstream.call(this);
			try {
				for (var a = !0, o = wi(this.simulcastCodecs.values()), s; s = yield o.next(), t = s.done, !t; a = !0) i = s.value, a = !1, yield i.sender?.replaceTrack(null);
			} catch (e) {
				n = { error: e };
			} finally {
				try {
					!a && !t && (r = o.return) && (yield r.call(o));
				} finally {
					if (n) throw n.error;
				}
			}
		});
	}
	resumeUpstream() {
		let e = Object.create(null, { resumeUpstream: { get: () => super.resumeUpstream } });
		return E(this, void 0, void 0, function* () {
			var t, n, r, i;
			yield e.resumeUpstream.call(this);
			try {
				for (var a = !0, o = wi(this.simulcastCodecs.values()), s; s = yield o.next(), t = s.done, !t; a = !0) {
					i = s.value, a = !1;
					let e = i;
					yield e.sender?.replaceTrack(e.mediaStreamTrack);
				}
			} catch (e) {
				n = { error: e };
			} finally {
				try {
					!a && !t && (r = o.return) && (yield r.call(o));
				} finally {
					if (n) throw n.error;
				}
			}
		});
	}
	mute() {
		let e = Object.create(null, { mute: { get: () => super.mute } });
		return E(this, void 0, void 0, function* () {
			let t = yield this.muteLock.lock();
			try {
				return this.isMuted ? (this.log.debug("Track already muted", this.logContext), this) : (this.source === B.Source.Camera && !this.isUserProvided && (this.log.debug("stopping camera track", this.logContext), this._mediaStreamTrack.stop()), yield e.mute.call(this), this);
			} finally {
				t();
			}
		});
	}
	unmute() {
		let e = Object.create(null, { unmute: { get: () => super.unmute } });
		return E(this, void 0, void 0, function* () {
			let t = yield this.muteLock.lock();
			try {
				return this.isMuted ? (this.source === B.Source.Camera && !this.isUserProvided && (this.log.debug("reacquiring camera track", this.logContext), yield this.restart(void 0, !0)), yield e.unmute.call(this), this) : (this.log.debug("Track already unmuted", this.logContext), this);
			} finally {
				t();
			}
		});
	}
	setTrackMuted(e) {
		super.setTrackMuted(e);
		for (let t of this.simulcastCodecs.values()) t.mediaStreamTrack.enabled = !e;
	}
	getSenderStats() {
		return E(this, void 0, void 0, function* () {
			if (!this.sender?.getStats) return [];
			let e = [], t = yield this.sender.getStats();
			return t.forEach((n) => {
				if (n.type === "outbound-rtp") {
					let r = {
						type: "video",
						streamId: n.id,
						frameHeight: n.frameHeight,
						frameWidth: n.frameWidth,
						framesPerSecond: n.framesPerSecond,
						framesSent: n.framesSent,
						firCount: n.firCount,
						pliCount: n.pliCount,
						nackCount: n.nackCount,
						packetsSent: n.packetsSent,
						bytesSent: n.bytesSent,
						qualityLimitationReason: n.qualityLimitationReason,
						qualityLimitationDurations: n.qualityLimitationDurations,
						qualityLimitationResolutionChanges: n.qualityLimitationResolutionChanges,
						rid: n.rid ?? n.id,
						retransmittedPacketsSent: n.retransmittedPacketsSent,
						targetBitrate: n.targetBitrate,
						timestamp: n.timestamp
					}, i = t.get(n.remoteId);
					i && (r.jitter = i.jitter, r.packetsLost = i.packetsLost, r.roundTripTime = i.roundTripTime), e.push(r);
				}
			}), e.sort((e, t) => (t.frameWidth ?? 0) - (e.frameWidth ?? 0)), e;
		});
	}
	setPublishingQuality(e) {
		let t = [];
		for (let n = Po.LOW; n <= Po.HIGH; n += 1) t.push(new Pr({
			quality: n,
			enabled: n <= e
		}));
		this.log.debug(`setting publishing quality. max quality ${e}`, this.logContext), this.setPublishingLayers(Wo(this.codec), t);
	}
	restartTrack(e) {
		return E(this, void 0, void 0, function* () {
			var t, n, r, i;
			let a;
			if (e) {
				let t = vo({ video: e });
				typeof t.video != "boolean" && (a = t.video);
			}
			yield this.restart(a), this.isCpuConstrained = !1;
			try {
				for (var o = !0, s = wi(this.simulcastCodecs.values()), c; c = yield s.next(), t = c.done, !t; o = !0) {
					i = c.value, o = !1;
					let e = i;
					e.sender && e.sender.transport?.state !== "closed" && (e.mediaStreamTrack = this.mediaStreamTrack.clone(), yield e.sender.replaceTrack(e.mediaStreamTrack));
				}
			} catch (e) {
				n = { error: e };
			} finally {
				try {
					!o && !t && (r = s.return) && (yield r.call(s));
				} finally {
					if (n) throw n.error;
				}
			}
			yield this.onSenderTrackSwapped();
		});
	}
	onSenderTrackSwapped() {
		return E(this, void 0, void 0, function* () {
			yield this.refreshSenderEncodings();
		});
	}
	refreshSenderEncodings() {
		return E(this, void 0, void 0, function* () {
			if (!this.sender || !this.publishOptions || this.optimizeForPerformance) return;
			let e = yield this.senderLock.lock();
			try {
				let e;
				try {
					e = yield this.waitForDimensions();
				} catch (e) {
					this.log.warn("could not determine new track dimensions, skipping encoding recompute", Object.assign(Object.assign({}, this.logContext), { error: e }));
					return;
				}
				if (this.lastEncodedDimensions && this.lastEncodedDimensions.width === e.width && this.lastEncodedDimensions.height === e.height) return;
				let n = Vl(this.source === B.Source.ScreenShare, e.width, e.height, Object.assign({}, this.publishOptions));
				yield this.applyEncodingsToSender(this.sender, n), this.encodings = n, this.lastEncodedDimensions = e;
				for (let e of this.simulcastCodecs) {
					var t = g(e, 2);
					let n = t[0], r = t[1];
					if (!r.sender || r.sender.transport?.state === "closed" || !co(n)) continue;
					let i = Object.assign({}, this.publishOptions), a = Hl(this, n, i);
					a && (yield this.applyEncodingsToSender(r.sender, a), r.encodings = a);
				}
			} catch (e) {
				this.log.warn("failed to apply recomputed encodings", Object.assign(Object.assign({}, this.logContext), { error: e }));
			} finally {
				e();
			}
		});
	}
	applyEncodingsToSender(e, t) {
		return E(this, void 0, void 0, function* () {
			let n = e.getParameters();
			!n.encodings || n.encodings.length !== t.length || (n.encodings.forEach((e, n) => {
				if (e.active === !1) return;
				let r = t[n];
				r.scaleResolutionDownBy !== void 0 && (e.scaleResolutionDownBy = r.scaleResolutionDownBy), r.maxBitrate !== void 0 && (e.maxBitrate = r.maxBitrate), r.maxFramerate !== void 0 && (e.maxFramerate = r.maxFramerate), r.priority !== void 0 && (e.priority = r.priority, e.networkPriority = r.priority);
			}), this.log.debug("updating sender encodings after track restart", Object.assign(Object.assign({}, this.logContext), { encodings: n.encodings })), yield e.setParameters(n));
		});
	}
	setProcessor(e) {
		let t = Object.create(null, { setProcessor: { get: () => super.setProcessor } });
		return E(this, arguments, void 0, function(e) {
			var n = this;
			let r = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !0;
			return function* () {
				var i, a, o, s;
				if (yield t.setProcessor.call(n, e, r), n.processor?.processedTrack) try {
					for (var c = !0, l = wi(n.simulcastCodecs.values()), u; u = yield l.next(), i = u.done, !i; c = !0) s = u.value, c = !1, yield s.sender?.replaceTrack(n.processor.processedTrack);
				} catch (e) {
					a = { error: e };
				} finally {
					try {
						!c && !i && (o = l.return) && (yield o.call(l));
					} finally {
						if (a) throw a.error;
					}
				}
			}();
		});
	}
	setDegradationPreference(e) {
		return E(this, void 0, void 0, function* () {
			if (this.degradationPreference = e, this.sender) try {
				this.log.debug(`setting degradationPreference to ${e}`, this.logContext);
				let t = this.sender.getParameters();
				t.degradationPreference = e, this.sender.setParameters(t);
			} catch (e) {
				this.log.warn("failed to set degradationPreference", Object.assign({ error: e }, this.logContext));
			}
		});
	}
	addSimulcastTrack(e, t) {
		if (this.simulcastCodecs.has(e)) {
			this.log.error(`${e} already added, skipping adding simulcast codec`, this.logContext);
			return;
		}
		let n = {
			codec: e,
			mediaStreamTrack: this.mediaStreamTrack.clone(),
			sender: void 0,
			encodings: t
		};
		return this.simulcastCodecs.set(e, n), n;
	}
	setSimulcastTrackSender(e, t) {
		let n = this.simulcastCodecs.get(e);
		n && (n.sender = t, setTimeout(() => {
			this.subscribedCodecs && this.setPublishingCodecs(this.subscribedCodecs);
		}, Xl));
	}
	setPublishingCodecs(e) {
		return E(this, void 0, void 0, function* () {
			var t, n, r, i, a, o, s;
			if (this.log.debug("setting publishing codecs", Object.assign(Object.assign({}, this.logContext), {
				codecs: e,
				currentCodec: this.codec
			})), !this.codec && e.length > 0) return yield this.setPublishingLayers(Wo(e[0].codec), e[0].qualities), [];
			this.subscribedCodecs = e;
			let c = [];
			try {
				for (t = !0, n = wi(e); r = yield n.next(), i = r.done, !i; t = !0) {
					s = r.value, t = !1;
					let e = s;
					if (!this.codec || this.codec === e.codec) yield this.setPublishingLayers(Wo(e.codec), e.qualities);
					else {
						let t = this.simulcastCodecs.get(e.codec);
						if (this.log.debug(`try setPublishingCodec for ${e.codec}`, Object.assign(Object.assign({}, this.logContext), { simulcastCodecInfo: t })), !t || !t.sender) {
							for (let t of e.qualities) if (t.enabled) {
								c.push(e.codec);
								break;
							}
						} else t.encodings && (this.log.debug(`try setPublishingLayersForSender ${e.codec}`, this.logContext), yield Ql(t.sender, t.encodings, e.qualities, this.senderLock, Wo(e.codec), this.log, this.logContext));
					}
				}
			} catch (e) {
				a = { error: e };
			} finally {
				try {
					!t && !i && (o = n.return) && (yield o.call(n));
				} finally {
					if (a) throw a.error;
				}
			}
			return c;
		});
	}
	setPublishingLayers(e, t) {
		return E(this, void 0, void 0, function* () {
			if (this.optimizeForPerformance) {
				this.log.info("skipping setPublishingLayers due to optimized publishing performance", Object.assign(Object.assign({}, this.logContext), { qualities: t }));
				return;
			}
			this.log.debug("setting publishing layers", Object.assign(Object.assign({}, this.logContext), { qualities: t })), !(!this.sender || !this.encodings) && (yield Ql(this.sender, this.encodings, t, this.senderLock, e, this.log, this.logContext));
		});
	}
	prioritizePerformance() {
		return E(this, void 0, void 0, function* () {
			if (!this.sender) throw Error("sender not found");
			let e = yield this.senderLock.lock();
			try {
				this.optimizeForPerformance = !0;
				let e = this.sender.getParameters();
				e.encodings = e.encodings.map((e, t) => Object.assign(Object.assign({}, e), {
					active: t === 0,
					scaleResolutionDownBy: Math.max(1, Math.ceil((this.mediaStreamTrack.getSettings().height ?? 360) / 360)),
					scalabilityMode: t === 0 && Wo(this.codec) ? "L1T3" : void 0,
					maxFramerate: t === 0 ? 15 : 0,
					maxBitrate: t === 0 ? e.maxBitrate : 0
				})), this.log.debug("setting performance optimised encodings", Object.assign(Object.assign({}, this.logContext), { encodings: e.encodings })), this.encodings = e.encodings, yield this.sender.setParameters(e);
			} catch (e) {
				this.log.error("failed to set performance optimised encodings", Object.assign(Object.assign({}, this.logContext), { error: e })), this.optimizeForPerformance = !1;
			} finally {
				e();
			}
		});
	}
	handleAppVisibilityChanged() {
		let e = Object.create(null, { handleAppVisibilityChanged: { get: () => super.handleAppVisibilityChanged } });
		return E(this, void 0, void 0, function* () {
			yield e.handleAppVisibilityChanged.call(this), es() && this.isInBackground && this.source === B.Source.Camera && (this._mediaStreamTrack.enabled = !1);
		});
	}
};
function Ql(e, t, n, r, i, a, o) {
	return E(this, void 0, void 0, function* () {
		let s = yield r.lock();
		a.debug("setPublishingLayersForSender", Object.assign(Object.assign({}, o), {
			sender: e,
			qualities: n,
			senderEncodings: t
		}));
		try {
			let r = e.getParameters(), s = r.encodings;
			if (!s) return;
			if (s.length !== t.length) {
				a.warn("cannot set publishing layers, encodings mismatch", Object.assign(Object.assign({}, o), {
					encodings: s,
					senderEncodings: t
				}));
				return;
			}
			let c = !1;
			i && n.some((e) => e.enabled) && n.forEach((e) => e.enabled = !0), s.forEach((e, r) => {
				let i = e.rid ?? "";
				i === "" && (i = "q");
				let s = $l(i), l = n.find((e) => e.quality === s);
				l && e.active !== l.enabled && (c = !0, e.active = l.enabled, a.debug(`setting layer ${l.quality} to ${e.active ? "enabled" : "disabled"}`, o), qo() && (l.enabled ? (e.scaleResolutionDownBy = t[r].scaleResolutionDownBy, e.maxBitrate = t[r].maxBitrate, e.maxFrameRate = t[r].maxFrameRate) : (e.scaleResolutionDownBy = 4, e.maxBitrate = 10, e.maxFrameRate = 2)));
			}), c && (r.encodings = s, a.debug("setting encodings", Object.assign(Object.assign({}, o), { encodings: r.encodings })), yield e.setParameters(r));
		} finally {
			s();
		}
	});
}
function $l(e) {
	switch (e) {
		case "f": return Po.HIGH;
		case "h": return Po.MEDIUM;
		case "q": return Po.LOW;
		default: return Po.HIGH;
	}
}
function eu(e, t, n, r) {
	if (!n) return [new _n({
		quality: Po.HIGH,
		width: e,
		height: t,
		bitrate: 0,
		ssrc: 0
	})];
	if (r) {
		let r = n[0].scalabilityMode, i = new Jl(r), a = [], o = i.suffix == "h" ? 1.5 : 2, s = i.suffix == "h" ? 2 : 3;
		for (let r = 0; r < i.spatial; r += 1) a.push(new _n({
			quality: Math.min(Po.HIGH, i.spatial - 1) - r,
			width: Math.ceil(e / o ** +r),
			height: Math.ceil(t / o ** +r),
			bitrate: n[0].maxBitrate ? Math.ceil(n[0].maxBitrate / s ** +r) : 0,
			ssrc: 0
		}));
		return a;
	}
	return n.map((n) => {
		let r = n.scaleResolutionDownBy ?? 1;
		return new _n({
			quality: $l(n.rid ?? ""),
			width: Math.ceil(e / r),
			height: Math.ceil(t / r),
			bitrate: n.maxBitrate ?? 0,
			ssrc: 0
		});
	});
}
var tu = "_lossy", nu = "_reliable", ru = "_data_track", iu = 2 * 1e3, au = "leave-reconnect", ou = 3e4, su = 8 * 1024, cu = 256 * 1024, lu = 3, uu = 3, du;
(function(e) {
	e[e.New = 0] = "New", e[e.Connected = 1] = "Connected", e[e.Disconnected = 2] = "Disconnected", e[e.Reconnecting = 3] = "Reconnecting", e[e.Closed = 4] = "Closed";
})(du ||= {});
var K;
(function(e) {
	e[e.RELIABLE = 0] = "RELIABLE", e[e.LOSSY = 1] = "LOSSY", e[e.DATA_TRACK_LOSSY = 2] = "DATA_TRACK_LOSSY";
})(K ||= {});
var fu = class extends Oi.EventEmitter {
	get isClosed() {
		return this._isClosed;
	}
	get isNewlyCreated() {
		return this._isNewlyCreated;
	}
	get pendingReconnect() {
		return !!this.reconnectTimeout;
	}
	constructor(e) {
		super(), this.options = e, this.rtcConfig = {}, this.peerConnectionTimeout = Cl.peerConnectionTimeout, this.fullReconnectOnNext = !1, this.latestRemoteOfferId = 0, this.subscriberPrimary = !1, this.pcState = du.New, this._isClosed = !0, this._isNewlyCreated = !0, this.pendingTrackResolvers = {}, this.reconnectAttempts = 0, this.reconnectStart = 0, this.attemptingReconnect = !1, this.joinAttempts = 0, this.maxJoinAttempts = 1, this.shouldFailNext = !1, this.shouldFailOnV1Path = !1, this.log = w, this.reliableDataSequence = 1, this.reliableMessageBuffer = new Yc(), this.reliableReceivedState = new Xc(ou), this.lossyDataStatCurrentBytes = 0, this.lossyDataStatByterate = 0, this.lossyDataDropCount = 0, this.midToTrackId = {}, this.isWaitingForNetworkReconnect = !1, this.bufferStatusLowClosingFuture = new U(), this.handleDataChannel = (e) => E(this, [e], void 0, function(e) {
			var t = this;
			let n = e.channel;
			return function* () {
				if (!n) return;
				let e;
				if (n.label === nu) t.reliableDCSub = n, e = t.handleDataMessage;
				else if (n.label === tu) t.lossyDCSub = n, e = t.handleDataMessage;
				else if (n.label === ru) t.dataTrackDCSub = n, e = t.handleDataTrackMessage;
				else return;
				t.log.debug(`on data channel ${n.id}, ${n.label}`), n.onmessage = e;
			}();
		}), this.handleDataMessage = (e) => E(this, void 0, void 0, function* () {
			let t = yield this.dataProcessLock.lock();
			try {
				let t;
				if (e.data instanceof ArrayBuffer) t = e.data;
				else if (e.data instanceof Blob) t = yield e.data.arrayBuffer();
				else {
					this.log.error("unsupported data type", { data: e.data });
					return;
				}
				let n = S.fromBinary(new Uint8Array(t));
				if (n.sequence > 0 && n.participantSid !== "") {
					let e = this.reliableReceivedState.get(n.participantSid);
					if (e && n.sequence <= e) return;
					this.reliableReceivedState.set(n.participantSid, n.sequence);
				}
				if (n.value?.case === "speaker") this.emit(I.ActiveSpeakersUpdate, n.value.value.speakers);
				else if (n.value?.case === "encryptedPacket") {
					if (!this.e2eeManager) {
						this.log.error("Received encrypted packet but E2EE not set up");
						return;
					}
					let e = yield this.e2eeManager?.handleEncryptedData(n.value.value.encryptedValue, n.value.value.iv, n.participantIdentity, n.value.value.keyIndex), t = new S({
						value: xn.fromBinary(e.payload).value,
						participantIdentity: n.participantIdentity,
						participantSid: n.participantSid
					});
					t.value?.case === "user" && pu(t, t.value.value), this.emit(I.DataPacketReceived, t, n.value.value.encryptionType);
				} else n.value?.case === "user" && pu(n, n.value.value), this.emit(I.DataPacketReceived, n, x.NONE);
			} finally {
				t();
			}
		}), this.handleDataTrackMessage = (e) => E(this, void 0, void 0, function* () {
			let t;
			if (e.data instanceof ArrayBuffer) t = e.data;
			else if (e.data instanceof Blob) t = yield e.data.arrayBuffer();
			else {
				this.log.error("unsupported data type", { data: e.data });
				return;
			}
			this.emit("dataTrackPacketReceived", new Uint8Array(t));
		}), this.handleDataError = (e) => {
			let t = e.currentTarget.maxRetransmits === 0 ? "lossy" : "reliable";
			if (e instanceof ErrorEvent && e.error) {
				let n = e.error.error;
				this.log.error(`DataChannel error on ${t}: ${e.message}`, { error: n });
			} else this.log.error(`Unknown DataChannel error on ${t}`, { event: e });
		}, this.handleBufferedAmountLow = (e) => {
			this.updateAndEmitDCBufferStatus(e);
		}, this.handleDisconnect = (e, t) => {
			if (this._isClosed) return;
			this.log.warn(`${e} disconnected`), this.reconnectAttempts === 0 && (this.reconnectStart = Date.now());
			let n = (e) => {
				this.log.warn(`could not recover connection after ${this.reconnectAttempts} attempts, ${e}ms. giving up`), this.emit(I.Disconnected), this.close();
			}, r = Date.now() - this.reconnectStart, i = this.getNextRetryDelay({
				elapsedMs: r,
				retryCount: this.reconnectAttempts
			});
			if (i === null) {
				n(r);
				return;
			}
			e === au && (i = 0), this.log.debug(`reconnecting in ${i}ms`), this.clearReconnectTimeout(), this.token && this.emit(I.TokenRefreshed, this.token), this.reconnectTimeout = N.setTimeout(() => this.attemptReconnect(t).finally(() => this.reconnectTimeout = void 0), i);
		}, this.waitForRestarted = () => new Promise((e, t) => {
			this.pcState === du.Connected && e();
			let n = () => {
				this.off(I.Disconnected, r), e();
			}, r = () => {
				this.off(I.Restarted, n), t();
			};
			this.once(I.Restarted, n), this.once(I.Disconnected, r);
		}), this.updateAndEmitDCBufferStatus = (e) => {
			if (e === K.RELIABLE) {
				let t = this.dataChannelForKind(e);
				t && this.reliableMessageBuffer.alignBufferedAmount(t.bufferedAmount);
			}
			let t = this.isBufferStatusLow(e);
			t !== void 0 && t !== this.dcBufferStatus.get(e) && (this.dcBufferStatus.set(e, t), this.emit(I.DCBufferStatusChanged, t, e));
		}, this.isBufferStatusLow = (e) => {
			let t = this.dataChannelForKind(e);
			if (t) return t.bufferedAmount <= t.bufferedAmountLowThreshold;
		}, this.onRtpMapAvailable = (e) => {
			let t = /* @__PURE__ */ new Map();
			e.forEach((e) => {
				let n = e.codec.toLowerCase();
				ys(n) && t.set(e.payload, n);
			}), this.emit(I.RTPVideoMapUpdate, t);
		}, this.handleBrowserOnLine = () => E(this, void 0, void 0, function* () {
			this.url && (yield fetch(Ss(this.url), { method: "HEAD" }).then((e) => e.ok).catch(() => !1)) && (this.log.info("detected network reconnected"), (this.client.currentState === W.RECONNECTING || this.isWaitingForNetworkReconnect && this.client.currentState === W.CONNECTED) && (this.clearReconnectTimeout(), this.attemptReconnect(nn.RR_SIGNAL_DISCONNECTED), this.isWaitingForNetworkReconnect = !1));
		}), this.handleBrowserOffline = () => E(this, void 0, void 0, function* () {
			if (this.url) try {
				yield Promise.race([fetch(Ss(this.url), { method: "HEAD" }), V(4e3).then(() => Promise.reject())]);
			} catch {
				window.navigator.onLine === !1 && (this.log.info("detected network interruption"), this.isWaitingForNetworkReconnect = !0);
			}
		}), this.log = T(e.loggerName ?? C.Engine, () => this.logContext), this.loggerOptions = {
			loggerName: e.loggerName,
			loggerContextCb: () => this.logContext
		}, this.client = new Wc(void 0, this.loggerOptions), this.client.signalLatency = this.options.expSignalLatency, this.reconnectPolicy = this.options.reconnectPolicy, this.closingLock = new i(), this.dataProcessLock = new i(), this.dcBufferStatus = new Map([
			[K.RELIABLE, !0],
			[K.LOSSY, !0],
			[K.DATA_TRACK_LOSSY, !0]
		]), this.client.onParticipantUpdate = (e) => this.emit(I.ParticipantUpdate, e), this.client.onConnectionQuality = (e) => this.emit(I.ConnectionQualityUpdate, e), this.client.onRoomUpdate = (e) => this.emit(I.RoomUpdate, e), this.client.onSubscriptionError = (e) => this.emit(I.SubscriptionError, e), this.client.onSubscriptionPermissionUpdate = (e) => this.emit(I.SubscriptionPermissionUpdate, e), this.client.onSpeakersChanged = (e) => this.emit(I.SpeakersChanged, e), this.client.onStreamStateUpdate = (e) => this.emit(I.StreamStateChanged, e), this.client.onRequestResponse = (e) => this.emit(I.SignalRequestResponse, e), this.client.onParticipantUpdate = (e) => this.emit(I.ParticipantUpdate, e), this.client.onJoined = (e) => this.emit(I.Joined, e), this.on(I.Closing, () => {
			var e, t;
			(t = (e = this.bufferStatusLowClosingFuture).reject) == null || t.call(e, new j("engine closed"));
		}), this.bufferStatusLowClosingFuture.promise.catch(() => {});
	}
	get logContext() {
		return {
			room: this.latestJoinResponse?.room?.name,
			roomID: this.latestJoinResponse?.room?.sid,
			participant: this.latestJoinResponse?.participant?.identity,
			participantID: this.participantSid
		};
	}
	join(e, t, n, r) {
		return E(this, arguments, void 0, function(e, t, n, r) {
			var i = this;
			let a = arguments.length > 4 && arguments[4] !== void 0 ? arguments[4] : !1;
			return function* () {
				var o;
				i._isNewlyCreated = !1, i.url = e, i.token = t, i.signalOpts = n, i.maxJoinAttempts = n.maxRetries;
				try {
					i.joinAttempts += 1, i.setupSignalClientCallbacks();
					let s = !a && Bs(), c;
					if (s) {
						i.pcManager || (yield i.configure(), i.applyInitialPublisherLayout());
						let e = yield i.pcManager?.publisher.createInitialOffer();
						e && (c = Kc(e.offer, e.offerId));
					}
					if (r?.aborted) throw A.cancelled("Connection aborted");
					if (!a && i.shouldFailOnV1Path) throw i.shouldFailOnV1Path = !1, A.serviceNotFound("Simulated v1 path failure", "v0-rtc");
					let l = yield i.client.join(e, t, n, r, a, c);
					i._isClosed = !1, i.latestJoinResponse = l, i.participantSid = l.participant?.sid, i.subscriberPrimary = l.subscriberPrimary, s ? (o = i.pcManager) == null || o.updateConfiguration(i.makeRTCConfiguration(l)) : (i.pcManager || (yield i.configure(l, !a), a || i.applyInitialPublisherLayout()), (!i.subscriberPrimary || l.fastPublish) && i.negotiate().catch((e) => {
						i.log.error(e);
					})), i.registerOnLineListener(), i.clientConfiguration = l.clientConfiguration, i.emit(I.SignalConnected, l);
					let u = l.serverInfo;
					return u ||= {
						version: l.serverVersion,
						region: l.serverRegion
					}, i.log.info(`connected to Livekit Server ${Object.entries(u).map((e) => {
						let t = g(e, 2);
						return `${t[0]}: ${t[1]}`;
					}).join(", ")}`), {
						joinResponse: l,
						serverInfo: u
					};
				} catch (o) {
					if (o instanceof A) {
						if (o.reason === k.ServerUnreachable) {
							if (i.log.warn(`Couldn't connect to server, attempt ${i.joinAttempts} of ${i.maxJoinAttempts}`), i.joinAttempts < i.maxJoinAttempts) return i.join(e, t, n, r, a);
						} else if (o.reason === k.ServiceNotFound) return i.log.warn(`Initial connection failed: ${o.message} – Retrying`), i.pcManager && (i.pcManager.onStateChange = void 0, yield i.cleanupPeerConnections()), i.join(e, t, n, r, !0);
					}
					throw o;
				}
			}();
		});
	}
	close() {
		return E(this, void 0, void 0, function* () {
			let e = yield this.closingLock.lock();
			if (this.isClosed) {
				e();
				return;
			}
			try {
				this._isClosed = !0, this.joinAttempts = 0, this.emit(I.Closing), this.removeAllListeners(), this.deregisterOnLineListener(), this.clearPendingReconnect(), this.cleanupLossyDataStats(), yield this.cleanupPeerConnections(), yield this.cleanupClient();
			} finally {
				e();
			}
		});
	}
	cleanupPeerConnections() {
		return E(this, void 0, void 0, function* () {
			yield this.pcManager?.close(), this.pcManager = void 0;
			let e = (e) => {
				e && (e.close(), e.onbufferedamountlow = null, e.onclose = null, e.onclosing = null, e.onerror = null, e.onmessage = null, e.onopen = null);
			};
			e(this.lossyDC), e(this.lossyDCSub), e(this.reliableDC), e(this.reliableDCSub), e(this.dataTrackDC), e(this.dataTrackDCSub), this.lossyDC = void 0, this.lossyDCSub = void 0, this.reliableDC = void 0, this.reliableDCSub = void 0, this.dataTrackDC = void 0, this.dataTrackDCSub = void 0, this.reliableMessageBuffer = new Yc(), this.reliableDataSequence = 1, this.reliableReceivedState.clear();
		});
	}
	cleanupLossyDataStats() {
		this.lossyDataStatByterate = 0, this.lossyDataStatCurrentBytes = 0, this.lossyDataStatInterval &&= (clearInterval(this.lossyDataStatInterval), void 0), this.lossyDataDropCount = 0;
	}
	cleanupClient() {
		return E(this, void 0, void 0, function* () {
			yield this.client.close(), this.client.resetCallbacks();
			for (let e of Object.keys(this.pendingTrackResolvers)) this.pendingTrackResolvers[e].reject();
			this.pendingTrackResolvers = {};
		});
	}
	addTrack(e) {
		if (this.pendingTrackResolvers[e.cid]) throw new Za("a track with the same ID has already been published");
		return new Promise((t, n) => {
			let r = setTimeout(() => {
				delete this.pendingTrackResolvers[e.cid], n(A.timeout("publication of local track timed out, no response from server"));
			}, 1e4);
			this.pendingTrackResolvers[e.cid] = {
				resolve: (e) => {
					clearTimeout(r), t(e);
				},
				reject: () => {
					clearTimeout(r), n(/* @__PURE__ */ Error("Cancelled publication by calling unpublish"));
				}
			}, this.client.sendAddTrack(e);
		});
	}
	removeTrack(e) {
		if (e.track && this.pendingTrackResolvers[e.track.id]) {
			let t = this.pendingTrackResolvers[e.track.id].reject;
			t && t(), delete this.pendingTrackResolvers[e.track.id];
		}
		try {
			return this.pcManager.removeTrack(e), !0;
		} catch (e) {
			this.log.warn("failed to remove track", { error: e });
		}
		return !1;
	}
	updateMuteStatus(e, t) {
		this.client.sendMuteTrack(e, t);
	}
	get dataSubscriberReadyState() {
		return this.reliableDCSub?.readyState;
	}
	getConnectedServerAddress() {
		return E(this, void 0, void 0, function* () {
			return this.pcManager?.getConnectedAddress();
		});
	}
	setRegionStrategy(e) {
		this.regionStrategy = e;
	}
	configure(e, t) {
		return E(this, void 0, void 0, function* () {
			if (!(this.pcManager && this.pcManager.currentState !== G.NEW)) {
				if (e) {
					this.participantSid = e.participant?.sid;
					let n = this.makeRTCConfiguration(e);
					this.pcManager = new wl(t ? "publisher-only" : e.subscriberPrimary ? "subscriber-primary" : "publisher-primary", this.loggerOptions, n);
				} else {
					let e = this.makeRTCConfiguration();
					this.pcManager = new wl("publisher-only", this.loggerOptions, e);
				}
				this.emit(I.TransportsCreated, this.pcManager.publisher, this.pcManager.subscriber), this.pcManager.onIceCandidate = (e, t) => {
					this.client.sendIceCandidate(e, t);
				}, this.pcManager.onPublisherOffer = (e, t) => {
					this.client.sendOffer(e, t);
				}, this.pcManager.onDataChannel = this.handleDataChannel, this.pcManager.onStateChange = (e, t, n) => E(this, void 0, void 0, function* () {
					if (this.log.debug(`primary PC state changed ${e}`), [
						"closed",
						"disconnected",
						"failed"
					].includes(t) && (this.publisherConnectionPromise = void 0), e === G.CONNECTED) {
						let e = this.pcState === du.New;
						this.pcState = du.Connected, e && this.emit(I.Connected, this.latestJoinResponse);
					} else e === G.FAILED && (this.pcState === du.Connected || this.pcState === du.Reconnecting) && (this.pcState = du.Disconnected, this.handleDisconnect("peerconnection failed", n === "failed" ? nn.RR_SUBSCRIBER_FAILED : nn.RR_PUBLISHER_FAILED));
					let r = this.client.isDisconnected || this.client.currentState === W.RECONNECTING, i = [
						G.FAILED,
						G.CLOSING,
						G.CLOSED
					].includes(e);
					r && i && !this._isClosed && this.emit(I.Offline);
				}), this.pcManager.onTrack = (e) => {
					e.streams.length !== 0 && this.emit(I.MediaTrackAdded, e.track, e.streams[0], e.receiver);
				};
			}
		});
	}
	setupSignalClientCallbacks() {
		this.client.onAnswer = (e, t, n) => E(this, void 0, void 0, function* () {
			this.pcManager && (this.log.debug("received server answer", {
				RTCSdpType: e.type,
				sdp: e.sdp,
				midToTrackId: n
			}), this.midToTrackId = n, yield this.pcManager.setPublisherAnswer(e, t));
		}), this.client.onTrickle = (e, t) => {
			this.pcManager && (this.log.debug("got ICE candidate from peer", {
				candidate: e,
				target: t
			}), this.pcManager.addIceCandidate(e, t));
		}, this.client.onOffer = (e, t, n) => E(this, void 0, void 0, function* () {
			if (this.latestRemoteOfferId = t, !this.pcManager) return;
			this.midToTrackId = n;
			let r = yield this.pcManager.createSubscriberAnswerFromOffer(e, t);
			r && this.client.sendAnswer(r, t);
		}), this.client.onLocalTrackPublished = (e) => {
			if (this.log.debug("received trackPublishedResponse", {
				cid: e.cid,
				track: e.track?.sid
			}), !this.pendingTrackResolvers[e.cid]) {
				this.log.error(`missing track resolver for ${e.cid}`, { cid: e.cid });
				return;
			}
			let t = this.pendingTrackResolvers[e.cid].resolve;
			delete this.pendingTrackResolvers[e.cid], t(e.track);
		}, this.client.onLocalTrackUnpublished = (e) => {
			this.emit(I.LocalTrackUnpublished, e);
		}, this.client.onLocalTrackSubscribed = (e) => {
			this.emit(I.LocalTrackSubscribed, e);
		}, this.client.onTokenRefresh = (e) => {
			this.token = e, this.emit(I.TokenRefreshed, e);
		}, this.client.onRemoteMuteChanged = (e, t) => {
			this.emit(I.RemoteMute, e, t);
		}, this.client.onSubscribedQualityUpdate = (e) => {
			this.emit(I.SubscribedQualityUpdate, e);
		}, this.client.onRoomMoved = (e) => {
			this.participantSid = e.participant?.sid, this.latestJoinResponse && (this.latestJoinResponse.room = e.room), this.emit(I.RoomMoved, e);
		}, this.client.onMediaSectionsRequirement = (e) => {
			this.addMediaSections(e.numAudios, e.numVideos), this.negotiate();
		}, this.client.onPublishDataTrackResponse = (e) => {
			this.emit(I.PublishDataTrackResponse, e);
		}, this.client.onUnPublishDataTrackResponse = (e) => {
			this.emit(I.UnPublishDataTrackResponse, e);
		}, this.client.onDataTrackSubscriberHandles = (e) => {
			this.emit(I.DataTrackSubscriberHandles, e);
		}, this.client.onClose = () => {
			this.handleDisconnect("signal", nn.RR_SIGNAL_DISCONNECTED);
		}, this.client.onLeave = (e) => {
			switch (this.log.info(`client leave request received (action=${e?.action})`, { reason: e?.reason }), e.regions && (this.log.debug("updating regions"), this.emit(I.ServerRegionsReported, e.regions)), e.action) {
				case wr.DISCONNECT:
					this.emit(I.Disconnected, e?.reason), this.close();
					break;
				case wr.RECONNECT:
					this.fullReconnectOnNext = !0, this.handleDisconnect(au);
					break;
				case wr.RESUME: this.handleDisconnect(au);
			}
		};
	}
	makeRTCConfiguration(e) {
		let t = Object.assign({}, this.rtcConfig);
		if ((this.signalOpts?.e2eeEnabled || this.options.packetTrailer?.worker && !ic()) && tc() && (this.log.debug("E2EE - setting up transports with insertable streams"), t.encodedInsertableStreams = !0), t.sdpSemantics = "unified-plan", t.continualGatheringPolicy = "gather_continually", !e) return t;
		if (e.iceServers && !t.iceServers) {
			let n = [];
			e.iceServers.forEach((e) => {
				let t = { urls: e.urls };
				e.username && (t.username = e.username), e.credential && (t.credential = e.credential), n.push(t);
			}), t.iceServers = n;
		}
		return e.clientConfiguration && e.clientConfiguration.forceRelay === en.ENABLED && (t.iceTransportPolicy = "relay"), t;
	}
	applyInitialPublisherLayout() {
		this.createDataChannels(), this.addMediaSections(lu, uu);
	}
	addMediaSections(e, t) {
		var n, r;
		let i = { direction: "recvonly" };
		for (let t = 0; t < e; t++) (n = this.pcManager) == null || n.addPublisherTransceiverOfKind("audio", i);
		for (let e = 0; e < t; e++) (r = this.pcManager) == null || r.addPublisherTransceiverOfKind("video", i);
	}
	createDataChannels() {
		this.pcManager && (this.lossyDC && (this.lossyDC.onmessage = null, this.lossyDC.onerror = null), this.reliableDC && (this.reliableDC.onmessage = null, this.reliableDC.onerror = null), this.dataTrackDC && (this.dataTrackDC.onmessage = null, this.dataTrackDC.onerror = null), this.lossyDC = this.pcManager.createPublisherDataChannel(tu, {
			ordered: !1,
			maxRetransmits: 0
		}), this.reliableDC = this.pcManager.createPublisherDataChannel(nu, { ordered: !0 }), this.dataTrackDC = this.pcManager.createPublisherDataChannel(ru, {
			ordered: !1,
			maxRetransmits: 0
		}), this.lossyDC.onmessage = this.handleDataMessage, this.reliableDC.onmessage = this.handleDataMessage, this.dataTrackDC.onmessage = this.handleDataTrackMessage, this.lossyDC.onerror = this.handleDataError, this.reliableDC.onerror = this.handleDataError, this.dataTrackDC.onerror = this.handleDataError, this.lossyDC.bufferedAmountLowThreshold = 65535, this.reliableDC.bufferedAmountLowThreshold = 65535, this.dataTrackDC.bufferedAmountLowThreshold = 65535, this.lossyDC.onbufferedamountlow = () => this.handleBufferedAmountLow(K.LOSSY), this.reliableDC.onbufferedamountlow = () => this.handleBufferedAmountLow(K.RELIABLE), this.dataTrackDC.onbufferedamountlow = () => this.handleBufferedAmountLow(K.DATA_TRACK_LOSSY), this.cleanupLossyDataStats(), this.lossyDataStatInterval = setInterval(() => {
			this.lossyDataStatByterate = this.lossyDataStatCurrentBytes, this.lossyDataStatCurrentBytes = 0;
			let e = this.dataChannelForKind(K.LOSSY);
			if (e) {
				let t = this.lossyDataStatByterate / 10;
				e.bufferedAmountLowThreshold = Math.min(Math.max(t, su), cu);
			}
		}, 1e3));
	}
	createSender(e, t, n) {
		return E(this, void 0, void 0, function* () {
			let r;
			if (Bo()) r = yield this.createTransceiverRTCRtpSender(e, t, n);
			else if (Vo()) this.log.warn("using add-track fallback"), r = yield this.createRTCRtpSender(e.mediaStreamTrack);
			else throw new j("Required webRTC APIs not supported on this device");
			return this.setupPacketTrailerSender(r, t), r;
		});
	}
	createSimulcastSender(e, t, n, r) {
		return E(this, void 0, void 0, function* () {
			let i;
			if (Bo()) i = yield this.createSimulcastTransceiverSender(e, t, n, r);
			else if (Vo()) this.log.debug("using add-track fallback"), i = yield this.createRTCRtpSender(e.mediaStreamTrack);
			else throw new j("Cannot stream on this device");
			return i && this.setupPacketTrailerSender(i, n), i;
		});
	}
	setupPacketTrailerSender(e) {
		let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
		if (!this.options.packetTrailer?.worker || this.signalOpts?.e2eeEnabled) return;
		let n = t.packetTrailer, r = oc(n);
		if (ic()) {
			r && (e.transform = new RTCRtpScriptTransform(this.options.packetTrailer.worker, {
				kind: "encode",
				packetTrailer: n
			}));
			return;
		}
		if (!ac(this.options.packetTrailer) || !("createEncodedStreams" in e)) {
			r && this.log.warn("packet trailer transform not supported; skipping write", this.logContext);
			return;
		}
		let i = e.createEncodedStreams(), a = i.readable, o = i.writable;
		r ? this.options.packetTrailer.worker.postMessage({
			kind: "encode",
			data: {
				readableStream: a,
				writableStream: o,
				packetTrailer: n
			}
		}, [a, o]) : a.pipeTo(o);
	}
	createTransceiverRTCRtpSender(e, t, n) {
		return E(this, void 0, void 0, function* () {
			if (!this.pcManager) throw new j("publisher is closed");
			let r = [];
			e.mediaStream && r.push(e.mediaStream), As(e) && (e.codec = t.videoCodec);
			let i = {
				direction: "sendonly",
				streams: r
			};
			return n && (i.sendEncodings = n), (yield this.pcManager.addPublisherTransceiver(e.mediaStreamTrack, i)).sender;
		});
	}
	createSimulcastTransceiverSender(e, t, n, r) {
		return E(this, void 0, void 0, function* () {
			if (!this.pcManager) throw new j("publisher is closed");
			let i = { direction: "sendonly" };
			r && (i.sendEncodings = r);
			let a = yield this.pcManager.addPublisherTransceiver(t.mediaStreamTrack, i);
			if (n.videoCodec) return e.setSimulcastTrackSender(n.videoCodec, a.sender), a.sender;
		});
	}
	createRTCRtpSender(e) {
		return E(this, void 0, void 0, function* () {
			if (!this.pcManager) throw new j("publisher is closed");
			return this.pcManager.addPublisherTrack(e);
		});
	}
	attemptReconnect(e) {
		return E(this, void 0, void 0, function* () {
			if (!this._isClosed) {
				if (this.attemptingReconnect) {
					this.log.warn("already attempting reconnect, returning early");
					return;
				}
				(this.clientConfiguration?.resumeConnection === en.DISABLED || (this.pcManager?.currentState ?? G.NEW) === G.NEW) && (this.fullReconnectOnNext = !0);
				try {
					this.attemptingReconnect = !0, this.fullReconnectOnNext ? yield this.restartConnection() : yield this.resumeConnection(e), this.clearPendingReconnect(), this.fullReconnectOnNext = !1;
				} catch (e) {
					this.reconnectAttempts += 1;
					let t = !0;
					e instanceof j ? (this.log.debug("received unrecoverable error", { error: e }), t = !1) : e instanceof ro || (this.fullReconnectOnNext = !0), t ? this.handleDisconnect("reconnect", nn.RR_UNKNOWN) : (this.log.info(`could not recover connection after ${this.reconnectAttempts} attempts, ${Date.now() - this.reconnectStart}ms. giving up`), this.emit(I.Disconnected), yield this.close());
				} finally {
					this.attemptingReconnect = !1;
				}
			}
		});
	}
	getNextRetryDelay(e) {
		try {
			return this.reconnectPolicy.nextRetryDelayInMs(e);
		} catch (e) {
			this.log.warn("encountered error in reconnect policy", { error: e });
		}
		return null;
	}
	restartConnection(e) {
		return E(this, void 0, void 0, function* () {
			var t, n;
			try {
				if (!this.url || !this.token) throw new j("could not reconnect, url or token not saved");
				this.log.info(`reconnecting, attempt: ${this.reconnectAttempts}`), this.emit(I.Restarting), this.client.isDisconnected || (yield this.client.sendLeave()), yield this.cleanupPeerConnections(), yield this.cleanupClient();
				let n;
				try {
					if (!this.signalOpts) throw this.log.warn("attempted connection restart, without signal options present"), new ro();
					n = (yield this.join(e ?? this.url, this.token, this.signalOpts, void 0, !this.options.singlePeerConnection)).joinResponse;
				} catch (e) {
					throw e instanceof A && e.reason === k.NotAllowed ? new j("could not reconnect, token might be expired") : new ro();
				}
				if (this.shouldFailNext) throw this.shouldFailNext = !1, Error("simulated failure");
				if (this.client.setReconnected(), this.emit(I.SignalRestarted, n), yield this.waitForPCReconnected(), this.client.currentState !== W.CONNECTED) throw new ro("Signal connection got severed during reconnect");
				(t = this.regionStrategy) == null || t.resetAttempts(), this.emit(I.Restarted);
			} catch (e) {
				let t = yield this.regionStrategy?.getNextUrl();
				if (t) {
					yield this.restartConnection(t);
					return;
				} else throw (n = this.regionStrategy) == null || n.resetAttempts(), e;
			}
		});
	}
	resumeConnection(e) {
		return E(this, void 0, void 0, function* () {
			if (!this.url || !this.token) throw new j("could not reconnect, url or token not saved");
			if (!this.pcManager) throw new j("publisher and subscriber connections unset");
			this.log.info(`resuming signal connection, attempt ${this.reconnectAttempts}`), this.emit(I.Resuming);
			let t;
			try {
				this.setupSignalClientCallbacks(), t = yield this.client.reconnect(this.url, this.token, this.participantSid, e);
			} catch (e) {
				let t = "";
				throw e instanceof Error && (t = e.message, this.log.error(e.message, { error: e })), e instanceof A && e.reason === k.NotAllowed ? new j("could not reconnect, token might be expired") : e instanceof A && e.reason === k.LeaveRequest ? e : new ro(t);
			}
			if (this.emit(I.SignalResumed), t) {
				let e = this.makeRTCConfiguration(t);
				this.pcManager.updateConfiguration(e), this.latestJoinResponse && (this.latestJoinResponse.serverInfo = t.serverInfo);
			} else this.log.warn("Did not receive reconnect response");
			if (this.shouldFailNext) throw this.shouldFailNext = !1, Error("simulated failure");
			if (yield this.pcManager.triggerIceRestart(), yield this.waitForPCReconnected(), this.client.currentState !== W.CONNECTED) throw new ro("Signal connection got severed during reconnect");
			this.client.setReconnected(), this.reliableDC?.readyState === "open" && this.reliableDC.id === null && this.createDataChannels(), t?.lastMessageSeq && this.resendReliableMessagesForResume(t.lastMessageSeq), this.emit(I.Resumed);
		});
	}
	waitForPCInitialConnection(e, t) {
		return E(this, void 0, void 0, function* () {
			if (!this.pcManager) throw new j("PC manager is closed");
			yield this.pcManager.ensurePCTransportConnection(t, e);
		});
	}
	waitForPCReconnected() {
		return E(this, void 0, void 0, function* () {
			this.pcState = du.Reconnecting, this.log.debug("waiting for peer connection to reconnect");
			try {
				if (yield V(iu), !this.pcManager) throw new j("PC manager is closed");
				yield this.pcManager.ensurePCTransportConnection(void 0, this.peerConnectionTimeout), this.pcState = du.Connected;
			} catch (e) {
				throw this.pcState = du.Disconnected, A.internal(`could not establish PC connection, ${e.message}`);
			}
		});
	}
	publishRpcAck(e, t) {
		return E(this, void 0, void 0, function* () {
			let n = new S({
				destinationIdentities: [e],
				kind: yn.RELIABLE,
				value: {
					case: "rpcAck",
					value: new An({ requestId: t })
				}
			});
			yield this.sendDataPacket(n, K.RELIABLE);
		});
	}
	sendDataPacket(e, t) {
		return E(this, void 0, void 0, function* () {
			if (yield this.ensurePublisherConnected(t), this.e2eeManager && this.e2eeManager.isDataChannelEncryptionEnabled) {
				let t = nc(e);
				if (t) {
					let n = yield this.e2eeManager.encryptData(t.toBinary());
					e.value = {
						case: "encryptedPacket",
						value: new bn({
							encryptedValue: n.payload,
							iv: n.iv,
							keyIndex: n.keyIndex
						})
					};
				}
			}
			t === K.RELIABLE && (e.sequence = this.reliableDataSequence, this.reliableDataSequence += 1);
			let n = e.toBinary();
			switch (t) {
				case K.LOSSY:
				case K.DATA_TRACK_LOSSY: return this.sendLossyBytes(n, t);
				case K.RELIABLE:
					let r = this.dataChannelForKind(t);
					if (r) {
						if (yield this.waitForBufferStatusLow(t), this.reliableMessageBuffer.push({
							data: n,
							sequence: e.sequence
						}), this.attemptingReconnect) return;
						r.send(n);
					}
					this.updateAndEmitDCBufferStatus(t);
					break;
			}
		});
	}
	sendLossyBytes(e, t) {
		return E(this, arguments, void 0, function(e, t) {
			var n = this;
			let r = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : "drop";
			return function* () {
				yield n.ensurePublisherConnected(t);
				let i = n.dataChannelForKind(t);
				if (i) {
					if (!n.isBufferStatusLow(t)) switch (r) {
						case "wait":
							yield n.waitForBufferStatusLow(t);
							break;
						case "drop":
							n.lossyDataDropCount += 1, n.lossyDataDropCount % 100 == 0 && n.log.warn(`dropping lossy data channel messages, total dropped: ${n.lossyDataDropCount}`);
							return;
					}
					if (n.lossyDataStatCurrentBytes += e.byteLength, n.attemptingReconnect) return;
					i.send(e);
				}
				n.updateAndEmitDCBufferStatus(t);
			}();
		});
	}
	resendReliableMessagesForResume(e) {
		return E(this, void 0, void 0, function* () {
			yield this.ensurePublisherConnected(K.RELIABLE);
			let t = this.dataChannelForKind(K.RELIABLE);
			t && (this.reliableMessageBuffer.popToSequence(e), this.reliableMessageBuffer.getAll().forEach((e) => {
				t.send(e.data);
			})), this.updateAndEmitDCBufferStatus(K.RELIABLE);
		});
	}
	waitForBufferStatusLow(e) {
		return E(this, void 0, void 0, function* () {
			return new D((t, n) => E(this, void 0, void 0, function* () {
				if (this.isClosed && n(new j("engine closed")), this.isBufferStatusLow(e)) t();
				else {
					let r = this.dataChannelForKind(e);
					if (!r) {
						n(new j(`DataChannel not found, kind: ${e}`));
						return;
					}
					this.bufferStatusLowClosingFuture.promise.catch((e) => n(e)), r.addEventListener("bufferedamountlow", () => t(), { once: !0 });
				}
			}));
		});
	}
	ensureDataTransportConnected(e) {
		return E(this, arguments, void 0, function(e) {
			var t = this;
			let n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : this.subscriberPrimary;
			return function* () {
				if (!t.pcManager) throw new j("PC manager is closed");
				let r = n ? t.pcManager.subscriber : t.pcManager.publisher, i = n ? "Subscriber" : "Publisher";
				if (!r) throw A.internal(`${i} connection not set`);
				let a = !1;
				if (!n && !t.dataChannelForKind(e, n) && (t.createDataChannels(), a = !0), !a && !n && !t.pcManager.publisher.isICEConnected && t.pcManager.publisher.getICEConnectionState() !== "checking" && (a = !0), a && t.negotiate().catch((e) => {
					t.log.error(e);
				}), t.dataChannelForKind(e, n)?.readyState === "open") return;
				let o = (/* @__PURE__ */ new Date()).getTime() + t.peerConnectionTimeout;
				for (; (/* @__PURE__ */ new Date()).getTime() < o;) {
					if (r.isICEConnected && t.dataChannelForKind(e, n)?.readyState === "open") return;
					yield V(50);
				}
				throw A.internal(`could not establish ${i} connection, state: ${r.getICEConnectionState()}`);
			}();
		});
	}
	ensurePublisherConnected(e) {
		return E(this, void 0, void 0, function* () {
			this.publisherConnectionPromise ||= this.ensureDataTransportConnected(e, !1), yield this.publisherConnectionPromise;
		});
	}
	verifyTransport() {
		return !(!this.pcManager || ![G.CONNECTING, G.CONNECTED].includes(this.pcManager.currentState) || !this.client.ws || this.client.ws.readyState === WebSocket.CLOSED);
	}
	negotiate() {
		return E(this, void 0, void 0, function* () {
			return new D((e, t) => E(this, void 0, void 0, function* () {
				if (!this.pcManager) {
					t(new $a("PC manager is closed"));
					return;
				}
				this.pcManager.requirePublisher(), this.pcManager.publisher.getTransceivers().length == 0 && !this.lossyDC && !this.reliableDC && !this.dataTrackDC && this.createDataChannels();
				let n = new AbortController(), r = () => {
					n.abort(), this.log.debug("engine disconnected while negotiation was ongoing"), e();
				};
				this.isClosed && t(new $a("cannot negotiate on closed engine")), this.on(I.Closing, r), this.on(I.Restarting, r), this.pcManager.publisher.off(fl.RTPVideoPayloadTypes, this.onRtpMapAvailable), this.pcManager.publisher.once(fl.RTPVideoPayloadTypes, this.onRtpMapAvailable);
				try {
					yield this.pcManager.negotiate(n), e();
				} catch (r) {
					if (n.signal.aborted) {
						e();
						return;
					}
					r instanceof $a && (this.fullReconnectOnNext = !0), this.handleDisconnect("negotiation", nn.RR_UNKNOWN), r instanceof Error ? t(r) : t(Error(String(r)));
				} finally {
					this.off(I.Closing, r), this.off(I.Restarting, r);
				}
			}));
		});
	}
	dataChannelForKind(e, t) {
		switch (e) {
			case K.RELIABLE: return t ? this.reliableDCSub : this.reliableDC;
			case K.LOSSY: return t ? this.lossyDCSub : this.lossyDC;
			case K.DATA_TRACK_LOSSY: return t ? this.dataTrackDCSub : this.dataTrackDC;
		}
	}
	sendSyncState(e, t, n) {
		if (!this.pcManager) {
			this.log.warn("sync state cannot be sent without peer connection setup");
			return;
		}
		let r = this.pcManager.publisher.getLocalDescription(), i = this.pcManager.publisher.getRemoteDescription(), a = this.pcManager.subscriber?.getRemoteDescription(), o = this.pcManager.subscriber?.getLocalDescription(), s = this.signalOpts?.autoSubscribe ?? !0, c = [], l = [];
		e.forEach((e) => {
			e.isDesired !== s && c.push(e.trackSid), e.isEnabled || l.push(e.trackSid);
		}), this.client.sendSyncState(new Hr({
			answer: this.pcManager.mode === "publisher-only" ? i ? Kc({
				sdp: i.sdp,
				type: i.type
			}) : void 0 : o ? Kc({
				sdp: o.sdp,
				type: o.type
			}) : void 0,
			offer: this.pcManager.mode === "publisher-only" ? r ? Kc({
				sdp: r.sdp,
				type: r.type
			}) : void 0 : a ? Kc({
				sdp: a.sdp,
				type: a.type
			}) : void 0,
			subscription: new _r({
				trackSids: c,
				subscribe: !s,
				participantTracks: []
			}),
			publishTracks: To(t),
			dataChannels: this.dataChannelsInfo(),
			trackSidsDisabled: l,
			datachannelReceiveStates: this.reliableReceivedState.map((e, t) => new Ur({
				publisherSid: t,
				lastSeq: e
			})),
			publishDataTracks: n.map((e) => new ir({ info: Lc.toProtobuf(e) }))
		}));
	}
	failNext() {
		this.shouldFailNext = !0;
	}
	failNextV1Path() {
		this.shouldFailOnV1Path = !0;
	}
	dataChannelsInfo() {
		let e = [], t = (t, n) => {
			t?.id !== void 0 && t.id !== null && e.push(new Wr({
				label: t.label,
				id: t.id,
				target: n
			}));
		};
		return t(this.dataChannelForKind(K.LOSSY), Xn.PUBLISHER), t(this.dataChannelForKind(K.RELIABLE), Xn.PUBLISHER), t(this.dataChannelForKind(K.LOSSY, !0), Xn.SUBSCRIBER), t(this.dataChannelForKind(K.RELIABLE, !0), Xn.SUBSCRIBER), e;
	}
	clearReconnectTimeout() {
		this.reconnectTimeout && N.clearTimeout(this.reconnectTimeout);
	}
	clearPendingReconnect() {
		this.clearReconnectTimeout(), this.reconnectAttempts = 0;
	}
	registerOnLineListener() {
		H() && (window.addEventListener("online", this.handleBrowserOnLine), window.addEventListener("offline", this.handleBrowserOffline));
	}
	deregisterOnLineListener() {
		H() && (window.removeEventListener("online", this.handleBrowserOnLine), window.removeEventListener("offline", this.handleBrowserOffline));
	}
	getTrackIdForReceiver(e) {
		let t = this.pcManager?.getMidForReceiver(e);
		if (t) {
			let e = Object.entries(this.midToTrackId).find((e) => g(e, 1)[0] === t);
			if (e) return e[1];
		}
	}
};
function pu(e, t) {
	let n = e.participantIdentity ? e.participantIdentity : t.participantIdentity;
	e.participantIdentity = n, t.participantIdentity = n;
	let r = e.destinationIdentities.length === 0 ? t.destinationIdentities : e.destinationIdentities;
	e.destinationIdentities = r, t.destinationIdentities = r;
}
var mu = 5e3, hu = 3e4, gu = class e {
	static fetchRegionSettings(t, n, r) {
		return E(this, void 0, void 0, function* () {
			let i = yield e.fetchLock.lock();
			try {
				let e = yield fetch(`${_u(t)}/regions`, {
					headers: { authorization: `Bearer ${n}` },
					signal: r
				});
				if (e.ok) {
					let t = Rs(e.headers), n = t ? t * 1e3 : mu;
					return {
						regionSettings: yield e.json(),
						updatedAtInMs: Date.now(),
						maxAgeInMs: n
					};
				} else if (e.status === 401) throw A.notAllowed(`Could not fetch region settings: ${e.statusText}`, e.status);
				else throw A.internal(`Could not fetch region settings: ${e.statusText}`);
			} catch (e) {
				throw e instanceof A ? e : r?.aborted ? A.cancelled("Region fetching was aborted") : A.serverUnreachable(`Could not fetch region settings, ${e instanceof Error ? `${e.name}: ${e.message}` : e}`);
			} finally {
				i();
			}
		});
	}
	static scheduleRefetch(t, n, r) {
		return E(this, void 0, void 0, function* () {
			let i = e.settingsTimeouts.get(t.hostname);
			clearTimeout(i), e.settingsTimeouts.set(t.hostname, setTimeout(() => E(this, void 0, void 0, function* () {
				try {
					let r = yield e.fetchRegionSettings(t, n);
					e.updateCachedRegionSettings(t, n, r);
				} catch (i) {
					if (i instanceof A && i.reason === k.NotAllowed) {
						w.debug("token is not valid, cancelling auto region refresh");
						return;
					}
					w.debug("auto refetching of region settings failed", { error: i }), e.scheduleRefetch(t, n, r);
				}
			}), r));
		});
	}
	static updateCachedRegionSettings(t, n, r) {
		e.cache.set(t.hostname, r), e.scheduleRefetch(t, n, r.maxAgeInMs);
	}
	static stopRefetch(t) {
		let n = e.settingsTimeouts.get(t);
		n && (clearTimeout(n), e.settingsTimeouts.delete(t));
	}
	static scheduleCleanup(t) {
		let n = e.connectionTrackers.get(t);
		n && (n.cleanupTimeout && clearTimeout(n.cleanupTimeout), n.cleanupTimeout = setTimeout(() => {
			let n = e.connectionTrackers.get(t);
			n && n.connectionCount === 0 && (w.debug("stopping region refetch after disconnect delay", { hostname: t }), e.stopRefetch(t)), n && (n.cleanupTimeout = void 0);
		}, hu));
	}
	static cancelCleanup(t) {
		let n = e.connectionTrackers.get(t);
		n?.cleanupTimeout && (clearTimeout(n.cleanupTimeout), n.cleanupTimeout = void 0);
	}
	notifyConnected() {
		let t = this.serverUrl.hostname, n = e.connectionTrackers.get(t);
		n || (n = { connectionCount: 0 }, e.connectionTrackers.set(t, n)), n.connectionCount++, e.cancelCleanup(t);
	}
	notifyDisconnected() {
		let t = this.serverUrl.hostname, n = e.connectionTrackers.get(t);
		n && (n.connectionCount = Math.max(0, n.connectionCount - 1), n.connectionCount === 0 && e.scheduleCleanup(t));
	}
	constructor(e, t) {
		this.attemptedRegions = [], this.serverUrl = new URL(e), this.token = t;
	}
	updateToken(t) {
		this.token = t;
		let n = this.getServerUrl(), r = e.cache.get(n.hostname);
		e.scheduleRefetch(this.serverUrl, this.token, r?.maxAgeInMs ?? mu);
	}
	isCloud() {
		return rs(this.serverUrl);
	}
	getServerUrl() {
		return this.serverUrl;
	}
	fetchRegionSettings(t) {
		return E(this, void 0, void 0, function* () {
			return e.fetchRegionSettings(this.serverUrl, this.token, t);
		});
	}
	getNextBestRegionUrl(t) {
		return E(this, void 0, void 0, function* () {
			if (!this.isCloud()) throw Error("region availability is only supported for LiveKit Cloud domains");
			let n = e.cache.get(this.serverUrl.hostname);
			(!n || Date.now() - n.updatedAtInMs > n.maxAgeInMs) && (n = yield this.fetchRegionSettings(t), e.updateCachedRegionSettings(this.serverUrl, this.token, n));
			let r = n.regionSettings.regions.filter((e) => !this.attemptedRegions.find((t) => t.url === e.url));
			if (r.length > 0) {
				let e = r[0];
				return this.attemptedRegions.push(e), w.debug(`next region: ${e.region}`), e.url;
			} else return null;
		});
	}
	resetAttempts() {
		this.attemptedRegions = [];
	}
	setServerReportedRegions(t) {
		e.updateCachedRegionSettings(this.serverUrl, this.token, t);
	}
};
gu.cache = /* @__PURE__ */ new Map(), gu.settingsTimeouts = /* @__PURE__ */ new Map(), gu.connectionTrackers = /* @__PURE__ */ new Map(), gu.fetchLock = new i();
function _u(e) {
	return `${e.protocol.replace("ws", "http")}//${e.host}/settings`;
}
var vu = class {
	get info() {
		return this._info;
	}
	validateBytesReceived() {
		let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : !1;
		if (!(typeof this.totalByteSize != "number" || this.totalByteSize === 0)) {
			if (e && this.bytesReceived < this.totalByteSize) throw new no(`Not enough chunk(s) received - expected ${this.totalByteSize} bytes of data total, only received ${this.bytesReceived} bytes`, M.Incomplete);
			if (this.bytesReceived > this.totalByteSize) throw new no(`Extra chunk(s) received - expected ${this.totalByteSize} bytes of data total, received ${this.bytesReceived} bytes`, M.LengthExceeded);
		}
	}
	constructor(e, t, n) {
		this.reader = t, this.totalByteSize = n, this._info = e, this.bytesReceived = 0;
	}
}, yu = class extends vu {
	handleChunkReceived(e) {
		var t;
		this.bytesReceived += e.content.byteLength, this.validateBytesReceived();
		let n = this.totalByteSize ? this.bytesReceived / this.totalByteSize : void 0;
		(t = this.onProgress) == null || t.call(this, n);
	}
	[Symbol.asyncIterator]() {
		let e = this.reader.getReader();
		e.closed.catch(() => {});
		let t = () => {
			e.releaseLock(), this.signal = void 0;
		};
		return {
			next: () => E(this, void 0, void 0, function* () {
				try {
					let t = this.signal;
					if (t?.aborted) throw t.reason;
					let n = yield new Promise((n, r) => {
						if (t) {
							let i = () => r(t.reason);
							t.addEventListener("abort", i, { once: !0 }), e.read().then(n, r).finally(() => {
								t.removeEventListener("abort", i);
							});
						} else e.read().then(n, r);
					});
					return n.done ? (this.validateBytesReceived(!0), {
						done: !0,
						value: void 0
					}) : (this.handleChunkReceived(n.value), {
						done: !1,
						value: n.value.content
					});
				} catch (e) {
					throw t(), e;
				}
			}),
			return() {
				return E(this, void 0, void 0, function* () {
					return t(), {
						done: !0,
						value: void 0
					};
				});
			}
		};
	}
	withAbortSignal(e) {
		return this.signal = e, this;
	}
	readAll() {
		return E(this, arguments, void 0, function() {
			var e = this;
			let t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
			return function* () {
				var n, r, i, a;
				let o = /* @__PURE__ */ new Set(), s = t.signal ? e.withAbortSignal(t.signal) : e;
				try {
					for (var c = !0, l = wi(s), u; u = yield l.next(), n = u.done, !n; c = !0) {
						a = u.value, c = !1;
						let e = a;
						o.add(e);
					}
				} catch (e) {
					r = { error: e };
				} finally {
					try {
						!c && !n && (i = l.return) && (yield i.call(l));
					} finally {
						if (r) throw r.error;
					}
				}
				return Array.from(o);
			}();
		});
	}
}, bu = class extends vu {
	constructor(e, t, n) {
		super(e, t, n), this.receivedChunks = /* @__PURE__ */ new Map();
	}
	handleChunkReceived(e) {
		var t;
		let n = Es(e.chunkIndex), r = this.receivedChunks.get(n);
		if (r && r.version > e.version) return;
		this.receivedChunks.set(n, e), this.bytesReceived += e.content.byteLength, this.validateBytesReceived();
		let i = this.totalByteSize ? this.bytesReceived / this.totalByteSize : void 0;
		(t = this.onProgress) == null || t.call(this, i);
	}
	[Symbol.asyncIterator]() {
		let e = this.reader.getReader();
		e.closed.catch(() => {});
		let t = new TextDecoder("utf-8", { fatal: !0 }), n = this.signal, r = () => {
			e.releaseLock(), this.signal = void 0;
		};
		return {
			next: () => E(this, void 0, void 0, function* () {
				try {
					if (n?.aborted) throw n.reason;
					let r = yield new Promise((t, r) => {
						if (n) {
							let i = () => r(n.reason);
							n.addEventListener("abort", i, { once: !0 }), e.read().then(t, r).finally(() => {
								n.removeEventListener("abort", i);
							});
						} else e.read().then(t, r);
					});
					if (r.done) return this.validateBytesReceived(!0), {
						done: !0,
						value: void 0
					};
					{
						this.handleChunkReceived(r.value);
						let e;
						try {
							e = t.decode(r.value.content);
						} catch (e) {
							throw new no(`Cannot decode datastream chunk ${r.value.chunkIndex} as text: ${e}`, M.DecodeFailed);
						}
						return {
							done: !1,
							value: e
						};
					}
				} catch (e) {
					throw r(), e;
				}
			}),
			return() {
				return E(this, void 0, void 0, function* () {
					return r(), {
						done: !0,
						value: void 0
					};
				});
			}
		};
	}
	withAbortSignal(e) {
		return this.signal = e, this;
	}
	readAll() {
		return E(this, arguments, void 0, function() {
			var e = this;
			let t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
			return function* () {
				var n, r, i, a;
				let o = "", s = t.signal ? e.withAbortSignal(t.signal) : e;
				try {
					for (var c = !0, l = wi(s), u; u = yield l.next(), n = u.done, !n; c = !0) a = u.value, c = !1, o += a;
				} catch (e) {
					r = { error: e };
				} finally {
					try {
						!c && !n && (i = l.return) && (yield i.call(l));
					} finally {
						if (r) throw r.error;
					}
				}
				return o;
			}();
		});
	}
}, xu = class {
	constructor() {
		this.log = w, this.byteStreamControllers = /* @__PURE__ */ new Map(), this.textStreamControllers = /* @__PURE__ */ new Map(), this.byteStreamHandlers = /* @__PURE__ */ new Map(), this.textStreamHandlers = /* @__PURE__ */ new Map(), this.isConnected = !1, this.bufferedPackets = [];
	}
	setConnected(e) {
		this.isConnected = e, e && this.flushBufferedPackets();
	}
	flushBufferedPackets() {
		let e = this.bufferedPackets;
		this.bufferedPackets = [];
		for (let t of e) {
			let e = t.packet, n = t.encryptionType;
			this.handleDataStreamPacket(e, n);
		}
	}
	registerTextStreamHandler(e, t) {
		if (this.textStreamHandlers.has(e)) throw new no(`A text stream handler for topic "${e}" has already been set.`, M.HandlerAlreadyRegistered);
		this.textStreamHandlers.set(e, t);
	}
	unregisterTextStreamHandler(e) {
		this.textStreamHandlers.delete(e);
	}
	registerByteStreamHandler(e, t) {
		if (this.byteStreamHandlers.has(e)) throw new no(`A byte stream handler for topic "${e}" has already been set.`, M.HandlerAlreadyRegistered);
		this.byteStreamHandlers.set(e, t);
	}
	unregisterByteStreamHandler(e) {
		this.byteStreamHandlers.delete(e);
	}
	clearControllers() {
		this.byteStreamControllers.clear(), this.textStreamControllers.clear(), this.bufferedPackets = [];
	}
	validateParticipantHasNoActiveDataStreams(e) {
		let t = Array.from(this.textStreamControllers.entries()).filter((t) => t[1].sendingParticipantIdentity === e), n = Array.from(this.byteStreamControllers.entries()).filter((t) => t[1].sendingParticipantIdentity === e);
		if (t.length > 0 || n.length > 0) {
			let a = new no(`Participant ${e} unexpectedly disconnected in the middle of sending data`, M.AbnormalEnd);
			for (let e of n) {
				var r = g(e, 2);
				let t = r[0];
				r[1].controller.error(a), this.byteStreamControllers.delete(t);
			}
			for (let e of t) {
				var i = g(e, 2);
				let t = i[0];
				i[1].controller.error(a), this.textStreamControllers.delete(t);
			}
		}
	}
	handleDataStreamPacket(e, t) {
		if (!this.isConnected) {
			this.bufferedPackets.push({
				packet: e,
				encryptionType: t
			});
			return;
		}
		switch (e.value.case) {
			case "streamHeader": return this.handleStreamHeader(e.value.value, e.participantIdentity, t);
			case "streamChunk": return this.handleStreamChunk(e.value.value, t);
			case "streamTrailer": return this.handleStreamTrailer(e.value.value, t);
			default: throw Error(`DataPacket of value "${e.value.case}" is not data stream related!`);
		}
	}
	handleStreamHeader(e, t, n) {
		if (e.contentHeader.case === "byteHeader") {
			let r = this.byteStreamHandlers.get(e.topic);
			if (!r) {
				this.log.debug("ignoring incoming byte stream due to no handler for topic", e.topic);
				return;
			}
			let i, a = {
				id: e.streamId,
				name: e.contentHeader.value.name ?? "unknown",
				mimeType: e.mimeType,
				size: e.totalLength ? Number(e.totalLength) : void 0,
				topic: e.topic,
				timestamp: Es(e.timestamp),
				attributes: e.attributes,
				encryptionType: n
			};
			r(new yu(a, new ReadableStream({ start: (n) => {
				if (i = n, this.textStreamControllers.has(e.streamId)) throw new no(`A data stream read is already in progress for a stream with id ${e.streamId}.`, M.AlreadyOpened);
				this.byteStreamControllers.set(e.streamId, {
					info: a,
					controller: i,
					startTime: Date.now(),
					sendingParticipantIdentity: t
				});
			} }), Es(e.totalLength)), { identity: t });
		} else if (e.contentHeader.case === "textHeader") {
			let r = this.textStreamHandlers.get(e.topic);
			if (!r) {
				this.log.debug("ignoring incoming text stream due to no handler for topic", e.topic);
				return;
			}
			let i, a = {
				id: e.streamId,
				mimeType: e.mimeType,
				size: e.totalLength ? Number(e.totalLength) : void 0,
				topic: e.topic,
				timestamp: Number(e.timestamp),
				attributes: e.attributes,
				encryptionType: n,
				attachedStreamIds: e.contentHeader.value.attachedStreamIds
			};
			r(new bu(a, new ReadableStream({ start: (n) => {
				if (i = n, this.textStreamControllers.has(e.streamId)) throw new no(`A data stream read is already in progress for a stream with id ${e.streamId}.`, M.AlreadyOpened);
				this.textStreamControllers.set(e.streamId, {
					info: a,
					controller: i,
					startTime: Date.now(),
					sendingParticipantIdentity: t
				});
			} }), Es(e.totalLength)), { identity: t });
		}
	}
	handleStreamChunk(e, t) {
		let n = this.byteStreamControllers.get(e.streamId);
		n && (n.info.encryptionType === t ? e.content.length > 0 && n.controller.enqueue(e) : (n.controller.error(new no(`Encryption type mismatch for stream ${e.streamId}. Expected ${t}, got ${n.info.encryptionType}`, M.EncryptionTypeMismatch)), this.byteStreamControllers.delete(e.streamId)));
		let r = this.textStreamControllers.get(e.streamId);
		r && (r.info.encryptionType === t ? e.content.length > 0 && r.controller.enqueue(e) : (r.controller.error(new no(`Encryption type mismatch for stream ${e.streamId}. Expected ${t}, got ${r.info.encryptionType}`, M.EncryptionTypeMismatch)), this.textStreamControllers.delete(e.streamId)));
	}
	handleStreamTrailer(e, t) {
		let n = this.textStreamControllers.get(e.streamId);
		n && (n.info.encryptionType === t ? (n.info.attributes = Object.assign(Object.assign({}, n.info.attributes), e.attributes), n.controller.close(), this.textStreamControllers.delete(e.streamId)) : n.controller.error(new no(`Encryption type mismatch for stream ${e.streamId}. Expected ${t}, got ${n.info.encryptionType}`, M.EncryptionTypeMismatch)));
		let r = this.byteStreamControllers.get(e.streamId);
		r && (r.info.encryptionType === t ? (r.info.attributes = Object.assign(Object.assign({}, r.info.attributes), e.attributes), r.controller.close()) : r.controller.error(new no(`Encryption type mismatch for stream ${e.streamId}. Expected ${t}, got ${r.info.encryptionType}`, M.EncryptionTypeMismatch)), this.byteStreamControllers.delete(e.streamId));
	}
}, Su = class {
	constructor(e, t, n) {
		this.writableStream = e, this.defaultWriter = e.getWriter(), this.onClose = n, this.info = t;
	}
	write(e) {
		return this.defaultWriter.write(e);
	}
	close() {
		return E(this, void 0, void 0, function* () {
			var e;
			yield this.defaultWriter.close(), this.defaultWriter.releaseLock(), (e = this.onClose) == null || e.call(this);
		});
	}
}, Cu = class extends Su {}, wu = class extends Su {}, Tu = 15e3, Eu = class {
	constructor(e, t) {
		this.engine = e, this.log = t;
	}
	setupEngine(e) {
		this.engine = e;
	}
	sendText(e, t) {
		return E(this, void 0, void 0, function* () {
			let n = crypto.randomUUID(), r = new TextEncoder().encode(e).byteLength, i = (t?.attachments)?.map(() => crypto.randomUUID()), a = Array(i ? i.length + 1 : 1).fill(0), o = (e, n) => {
				var r;
				a[n] = e;
				let i = a.reduce((e, t) => e + t, 0);
				(r = t?.onProgress) == null || r.call(t, i);
			}, s = yield this.streamText({
				streamId: n,
				totalSize: r,
				destinationIdentities: t?.destinationIdentities,
				topic: t?.topic,
				attachedStreamIds: i,
				attributes: t?.attributes
			});
			return yield s.write(e), o(1, 0), yield s.close(), t?.attachments && i && (yield Promise.all(t.attachments.map((e, n) => E(this, void 0, void 0, function* () {
				return this._sendFile(i[n], e, {
					topic: t.topic,
					mimeType: e.type,
					onProgress: (e) => {
						o(e, n + 1);
					}
				});
			})))), s.info;
		});
	}
	streamText(e) {
		return E(this, void 0, void 0, function* () {
			let t = e?.streamId ?? crypto.randomUUID(), n = {
				id: t,
				mimeType: "text/plain",
				timestamp: Date.now(),
				topic: e?.topic ?? "",
				size: e?.totalSize,
				attributes: e?.attributes,
				encryptionType: this.engine.e2eeManager?.isDataChannelEncryptionEnabled ? x.GCM : x.NONE,
				attachedStreamIds: e?.attachedStreamIds
			}, r = new Kn({
				streamId: t,
				mimeType: n.mimeType,
				topic: n.topic,
				timestamp: Ds(n.timestamp),
				totalLength: Ds(n.size),
				attributes: n.attributes,
				contentHeader: {
					case: "textHeader",
					value: new Wn({
						version: e?.version,
						attachedStreamIds: n.attachedStreamIds,
						replyToStreamId: e?.replyToStreamId,
						operationType: e?.type === "update" ? Un.UPDATE : Un.CREATE
					})
				}
			}), i = e?.destinationIdentities, a = new S({
				destinationIdentities: i,
				value: {
					case: "streamHeader",
					value: r
				}
			});
			yield this.engine.sendDataPacket(a, K.RELIABLE);
			let o = 0, s = this.engine, c = new WritableStream({
				write(e) {
					return E(this, void 0, void 0, function* () {
						for (let n of Ls(e, Tu)) {
							let e = new S({
								destinationIdentities: i,
								value: {
									case: "streamChunk",
									value: new qn({
										content: n,
										streamId: t,
										chunkIndex: Ds(o)
									})
								}
							});
							yield s.sendDataPacket(e, K.RELIABLE), o += 1;
						}
					});
				},
				close() {
					return E(this, void 0, void 0, function* () {
						let e = new S({
							destinationIdentities: i,
							value: {
								case: "streamTrailer",
								value: new Jn({ streamId: t })
							}
						});
						yield s.sendDataPacket(e, K.RELIABLE);
					});
				},
				abort(e) {
					console.log("Sink error:", e);
				}
			}), l = () => E(this, void 0, void 0, function* () {
				yield u.close();
			});
			s.once(I.Closing, l);
			let u = new Cu(c, n, () => this.engine.off(I.Closing, l));
			return u;
		});
	}
	sendFile(e, t) {
		return E(this, void 0, void 0, function* () {
			let n = crypto.randomUUID();
			return yield this._sendFile(n, e, t), { id: n };
		});
	}
	_sendFile(e, t, n) {
		return E(this, void 0, void 0, function* () {
			let r = yield this.streamBytes({
				streamId: e,
				totalSize: t.size,
				name: t.name,
				mimeType: n?.mimeType ?? t.type,
				topic: n?.topic,
				destinationIdentities: n?.destinationIdentities
			}), i = t.stream().getReader();
			for (;;) {
				let e = yield i.read(), t = e.done, n = e.value;
				if (t) break;
				yield r.write(n);
			}
			return yield r.close(), r.info;
		});
	}
	streamBytes(e) {
		return E(this, void 0, void 0, function* () {
			let t = e?.streamId ?? crypto.randomUUID(), n = e?.destinationIdentities, r = {
				id: t,
				mimeType: e?.mimeType ?? "application/octet-stream",
				topic: e?.topic ?? "",
				timestamp: Date.now(),
				attributes: e?.attributes,
				size: e?.totalSize,
				name: e?.name ?? "unknown",
				encryptionType: this.engine.e2eeManager?.isDataChannelEncryptionEnabled ? x.GCM : x.NONE
			}, a = new S({
				destinationIdentities: n,
				value: {
					case: "streamHeader",
					value: new Kn({
						totalLength: Ds(r.size),
						mimeType: r.mimeType,
						streamId: t,
						topic: r.topic,
						timestamp: Ds(Date.now()),
						attributes: r.attributes,
						contentHeader: {
							case: "byteHeader",
							value: new Gn({ name: r.name })
						}
					})
				}
			});
			yield this.engine.sendDataPacket(a, K.RELIABLE);
			let o = 0, s = new i(), c = this.engine, l = this.log;
			return new wu(new WritableStream({
				write(e) {
					return E(this, void 0, void 0, function* () {
						let r = yield s.lock(), i = 0;
						try {
							for (; i < e.byteLength;) {
								let r = e.slice(i, i + Tu), a = new S({
									destinationIdentities: n,
									value: {
										case: "streamChunk",
										value: new qn({
											content: r,
											streamId: t,
											chunkIndex: Ds(o)
										})
									}
								});
								yield c.sendDataPacket(a, K.RELIABLE), o += 1, i += r.byteLength;
							}
						} finally {
							r();
						}
					});
				},
				close() {
					return E(this, void 0, void 0, function* () {
						let e = new S({
							destinationIdentities: n,
							value: {
								case: "streamTrailer",
								value: new Jn({ streamId: t })
							}
						});
						yield c.sendDataPacket(e, K.RELIABLE);
					});
				},
				abort(e) {
					l.error("Sink error:", e);
				}
			}), r);
		});
	}
};
function Du(e) {
	if (e.length === 0) return new AbortController().signal;
	if (e.length === 1) return e[0];
	for (let t of e) if (t.aborted) return t;
	let t = new AbortController(), n = Array(e.length), r = () => {
		for (let e of n) e();
	};
	return e.forEach((e, i) => {
		let a = () => {
			t.abort(e.reason), r();
		};
		e.addEventListener("abort", a), n[i] = () => e.removeEventListener("abort", a);
	}), t.signal;
}
function Ou(e) {
	let t = new AbortController();
	return setTimeout(() => {
		t.abort(new DOMException(`signal timed out after ${e} ms`, "TimeoutError"));
	}, e), t.signal;
}
var q = 1, ku = 2, Au = 4, ju = 8, Mu = 0, Nu = 12, Pu = 5, Fu = 7, Iu = 3, Lu = 3, Ru = 2, zu = 1, Bu = 0, Vu = 3, Hu = 2, Uu = 2, Wu = 1, Gu = 0, Ku;
(function(e) {
	e[e.TooShort = 0] = "TooShort", e[e.HeaderOverrun = 1] = "HeaderOverrun", e[e.MissingExtWords = 2] = "MissingExtWords", e[e.UnsupportedVersion = 3] = "UnsupportedVersion", e[e.InvalidHandle = 4] = "InvalidHandle", e[e.MalformedExt = 5] = "MalformedExt";
})(Ku ||= {});
var qu = class e extends Ya {
	constructor(e, t, n) {
		super(19, e, n), this.name = "DataTrackDeserializeError", this.reason = t, this.reasonName = Ku[t];
	}
	static tooShort() {
		return new e("Too short to contain a valid header", Ku.TooShort);
	}
	static headerOverrun() {
		return new e("Header exceeds total packet length", Ku.HeaderOverrun);
	}
	static missingExtWords() {
		return new e("Extension word indicator is missing", Ku.MissingExtWords);
	}
	static unsupportedVersion(t) {
		return new e(`Unsupported version ${t}`, Ku.UnsupportedVersion);
	}
	static invalidHandle(t) {
		return new e(`invalid track handle: ${t.message}`, Ku.InvalidHandle, { cause: t });
	}
	static malformedExt(t) {
		return new e(`Extension with tag ${t} is malformed`, Ku.MalformedExt);
	}
}, Ju;
(function(e) {
	e[e.TooSmallForHeader = 0] = "TooSmallForHeader", e[e.TooSmallForPayload = 1] = "TooSmallForPayload";
})(Ju ||= {});
var Yu = class e extends Ya {
	constructor(e, t, n) {
		super(19, e, n), this.name = "DataTrackSerializeError", this.reason = t, this.reasonName = Ju[t];
	}
	static tooSmallForHeader() {
		return new e("Buffer cannot fit header", Ju.TooSmallForHeader);
	}
	static tooSmallForPayload() {
		return new e("Buffer cannot fit payload", Ju.TooSmallForPayload);
	}
}, Xu = class {
	toBinary() {
		let e = this.toBinaryLengthBytes(), t = new ArrayBuffer(e), n = new DataView(t), r = this.toBinaryInto(n);
		if (e !== r) throw Error(`${this.constructor.name}.toBinary: written bytes (${r} bytes) not equal to allocated array buffer length (${e} bytes).`);
		return new Uint8Array(t);
	}
}, Zu;
(function(e) {
	e[e.UserTimestamp = 2] = "UserTimestamp", e[e.E2ee = 1] = "E2ee";
})(Zu ||= {});
var Qu = class extends Xu {}, $u = class e extends Qu {
	constructor(e) {
		super(), this.timestamp = e;
	}
	toBinaryLengthBytes() {
		return 2 + e.lengthBytes;
	}
	toBinaryInto(t) {
		let n = 0;
		t.setUint8(n, e.tag), n += q, t.setUint8(n, e.lengthBytes), n += q, t.setBigUint64(n, this.timestamp), n += ju;
		let r = this.toBinaryLengthBytes();
		if (n !== r) throw Error(`DataTrackUserTimestampExtension.toBinaryInto: Wrote ${n} bytes but expected length was ${r} bytes`);
		return n;
	}
	toJSON() {
		return {
			tag: e.tag,
			lengthBytes: e.lengthBytes,
			timestamp: this.timestamp
		};
	}
};
$u.tag = Zu.UserTimestamp, $u.lengthBytes = 8;
var ed = class e extends Qu {
	constructor(e, t) {
		super(), this.keyIndex = e, this.iv = t;
	}
	toBinaryLengthBytes() {
		return 2 + e.lengthBytes;
	}
	toBinaryInto(t) {
		let n = 0;
		t.setUint8(n, e.tag), n += q, t.setUint8(n, e.lengthBytes), n += q, t.setUint8(n, this.keyIndex), n += q;
		for (let e = 0; e < this.iv.length; e += 1) t.setUint8(n, this.iv[e]), n += q;
		let r = this.toBinaryLengthBytes();
		if (n !== r) throw Error(`DataTrackE2eeExtension.toBinaryInto: Wrote ${n} bytes but expected length was ${r} bytes`);
		return n;
	}
	toJSON() {
		return {
			tag: e.tag,
			lengthBytes: e.lengthBytes,
			keyIndex: this.keyIndex,
			iv: this.iv
		};
	}
};
ed.tag = Zu.E2ee, ed.lengthBytes = 13;
var td = class e extends Xu {
	constructor() {
		let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
		super(), this.userTimestamp = e.userTimestamp, this.e2ee = e.e2ee;
	}
	toBinaryLengthBytes() {
		let e = 0;
		return this.userTimestamp && (e += this.userTimestamp.toBinaryLengthBytes()), this.e2ee && (e += this.e2ee.toBinaryLengthBytes()), e;
	}
	toBinaryInto(e) {
		let t = 0;
		if (this.e2ee) {
			let n = this.e2ee.toBinaryInto(e);
			t += n;
		}
		if (this.userTimestamp) {
			let n = this.userTimestamp.toBinaryInto(new DataView(e.buffer, e.byteOffset + t));
			t += n;
		}
		let n = this.toBinaryLengthBytes();
		if (t !== n) throw Error(`DataTrackExtensions.toBinaryInto: Wrote ${t} bytes but expected length was ${n} bytes`);
		return t;
	}
	static fromBinary(t) {
		let n = Mc(t), r, i, a = 0;
		for (; n.byteLength - a >= 2;) {
			let e = n.getUint8(a);
			a += q;
			let t = n.getUint8(a);
			if (a += q, e !== Gu) switch (e) {
				case Zu.UserTimestamp:
					if (n.byteLength - a < $u.lengthBytes) throw qu.malformedExt(e);
					r = new $u(n.getBigUint64(a)), a += t;
					break;
				case Zu.E2ee:
					if (n.byteLength - a < ed.lengthBytes) throw qu.malformedExt(e);
					let o = n.getUint8(a), s = new Uint8Array(12);
					for (let e = 0; e < s.length; e += 1) {
						let t = a;
						t += q, t += e * q, s[e] = n.getUint8(t);
					}
					i = new ed(o, s), a += t;
					break;
				default:
					if (n.byteLength - a < t) throw qu.malformedExt(e);
					a += t;
					break;
			}
		}
		return [new e({
			userTimestamp: r,
			e2ee: i
		}), n.byteLength];
	}
	toJSON() {
		return {
			userTimestamp: this.userTimestamp?.toJSON() ?? null,
			e2ee: this.e2ee?.toJSON() ?? null
		};
	}
}, nd = {
	from(e) {
		return {
			payload: e.payload,
			extensions: new td({ userTimestamp: e.userTimestamp ? new $u(e.userTimestamp) : void 0 })
		};
	},
	lossyIntoFrame(e) {
		return {
			payload: e.payload,
			userTimestamp: e.extensions.userTimestamp?.timestamp
		};
	}
}, rd = Symbol.for("lk.track"), id = Symbol.for("lk.data-track"), ad = class {
	constructor(e, t, n) {
		this.trackSymbol = rd, this.isLocal = !1, this.typeSymbol = id, this.info = e, this.manager = t, this.publisherIdentity = n.publisherIdentity;
	}
	subscribe(e) {
		try {
			let t = g(this.manager.openSubscriptionStream(this.info.sid, e?.signal, e?.bufferSize), 2), n = t[0];
			return t[1].catch(() => {}), n;
		} catch (e) {
			throw e;
		}
	}
	setPipelineOptions(e) {
		this.manager.setPipelineOptions(this.info.sid, e);
	}
}, od = class e extends Xu {
	constructor(e) {
		super(), this.marker = e.marker, this.trackHandle = e.trackHandle, this.sequence = e.sequence, this.frameNumber = e.frameNumber, this.timestamp = e.timestamp, this.extensions = e.extensions ?? new td();
	}
	extensionsMetrics() {
		let e = this.extensions.toBinaryLengthBytes(), t = Math.ceil((Hu + e) / 4);
		return {
			lengthBytes: e,
			lengthWords: t,
			paddingLengthBytes: t * 4 - Hu - e
		};
	}
	toBinaryLengthBytes() {
		let e = this.extensionsMetrics(), t = e.lengthBytes, n = e.paddingLengthBytes, r = Nu;
		return t > 0 && (r += Hu + t + n), r;
	}
	toBinaryInto(e) {
		if (e.byteLength < this.toBinaryLengthBytes()) throw Yu.tooSmallForHeader();
		let t = Mu << Pu, n;
		switch (this.marker) {
			case J.Inter:
				n = Bu;
				break;
			case J.Final:
				n = zu;
				break;
			case J.Start:
				n = Ru;
				break;
			case J.Single:
				n = Vu;
				break;
		}
		t |= n << Iu;
		let r = this.extensionsMetrics(), i = r.lengthBytes, a = r.lengthWords, o = r.paddingLengthBytes;
		i > 0 && (t |= 1 << Uu);
		let s = 0;
		if (e.setUint8(s, t), s += q, e.setUint8(s, 0), s += q, e.setUint16(s, this.trackHandle), s += ku, e.setUint16(s, this.sequence.value), s += ku, e.setUint16(s, this.frameNumber.value), s += ku, e.setUint32(s, this.timestamp.asTicks()), s += Au, i > 0) {
			let t = a - 1;
			e.setUint16(s, t), s += ku;
			let n = this.extensions.toBinaryInto(new DataView(e.buffer, e.byteOffset + s));
			s += n;
			for (let t = 0; t < o; t += 1) e.setUint8(s, 0), s += q;
		}
		let c = this.toBinaryLengthBytes();
		if (s !== c) throw Error(`DataTrackPacketHeader.toBinaryInto: Wrote ${s} bytes but expected length was ${c} bytes`);
		return c;
	}
	static fromBinary(t) {
		let n = Mc(t);
		if (n.byteLength < Nu) throw qu.tooShort();
		let r = 0, i = n.getUint8(r);
		r += q;
		let a = i >> Pu & Fu;
		if (a > Mu) throw qu.unsupportedVersion(a);
		let o;
		switch (i >> Iu & Lu) {
			case Ru:
				o = J.Start;
				break;
			case zu:
				o = J.Final;
				break;
			case Vu:
				o = J.Single;
				break;
			case Bu:
			default:
				o = J.Inter;
				break;
		}
		let s = (i >> Uu & Wu) > 0;
		r += q;
		let c;
		try {
			c = Fc.fromNumber(n.getUint16(r));
		} catch (e) {
			throw e instanceof Pc && (e.isReason(Nc.Reserved) || e.isReason(Nc.TooLarge)) ? qu.invalidHandle(e) : e;
		}
		r += ku;
		let l = kc.u16(n.getUint16(r));
		r += ku;
		let u = kc.u16(n.getUint16(r));
		r += ku;
		let d = Ac.fromRtpTicks(n.getUint32(r));
		r += Au;
		let f = new td();
		if (s) {
			if (n.byteLength - r < ku) throw qu.missingExtWords();
			let e = n.getUint16(r);
			r += ku;
			let t = 4 * (e + 1) - Hu;
			if (r + t > n.byteLength) throw qu.headerOverrun();
			let i = new DataView(n.buffer, n.byteOffset + r, t), a = g(td.fromBinary(i), 2), o = a[0], s = a[1];
			f = o, r += s;
		}
		return [new e({
			marker: o,
			trackHandle: c,
			sequence: l,
			frameNumber: u,
			timestamp: d,
			extensions: f
		}), r];
	}
	toJSON() {
		return {
			marker: this.marker,
			trackHandle: this.trackHandle,
			sequence: this.sequence.value,
			frameNumber: this.frameNumber.value,
			timestamp: this.timestamp.asTicks(),
			extensions: this.extensions.toJSON()
		};
	}
}, J;
(function(e) {
	e[e.Start = 0] = "Start", e[e.Inter = 1] = "Inter", e[e.Final = 2] = "Final", e[e.Single = 3] = "Single";
})(J ||= {});
var sd = class e extends Xu {
	constructor(e, t) {
		super(), this.header = e, this.payload = t;
	}
	toBinaryLengthBytes() {
		return this.header.toBinaryLengthBytes() + this.payload.byteLength;
	}
	toBinaryInto(e) {
		let t = 0, n = this.header.toBinaryInto(e);
		if (t += n, e.byteLength - t < this.payload.byteLength) throw Yu.tooSmallForPayload();
		for (let n = 0; n < this.payload.length; n += 1) e.setUint8(t, this.payload[n]), t += q;
		let r = this.toBinaryLengthBytes();
		if (t !== r) throw Error(`DataTrackPacket.toBinaryInto: Wrote ${t} bytes but expected length was ${r} bytes`);
		return r;
	}
	static fromBinary(t) {
		let n = Mc(t), r = g(od.fromBinary(n), 2), i = r[0], a = r[1], o = n.buffer.slice(n.byteOffset + a, n.byteOffset + n.byteLength);
		return [new e(i, new Uint8Array(o)), n.byteLength];
	}
	toJSON() {
		return {
			header: this.header.toJSON(),
			payload: this.payload
		};
	}
}, cd = T(C.DataTracks), ld = class e extends Ya {
	constructor(e, t, n, r) {
		super(19, `Frame ${n} dropped: ${e}`, r), this.name = "DataTrackDepacketizerDropError", this.reason = t, this.reasonName = ud[t], this.frameNumber = n;
	}
	static interrupted(t, n) {
		return new e(`Interrupted by the start of a new frame ${n}`, ud.Interrupted, t);
	}
	static unknownFrame(t) {
		return new e("Initial packet was never received.", ud.UnknownFrame, t);
	}
	static bufferFull(t) {
		return new e("Reorder buffer is full.", ud.BufferFull, t);
	}
	static incomplete(t, n, r) {
		return new e(`Not all packets received before final packet. Received ${n} packets, expected ${r} packets.`, ud.Incomplete, t);
	}
}, ud;
(function(e) {
	e[e.Interrupted = 0] = "Interrupted", e[e.UnknownFrame = 1] = "UnknownFrame", e[e.BufferFull = 2] = "BufferFull", e[e.Incomplete = 3] = "Incomplete";
})(ud ||= {});
var dd = class e {
	constructor() {
		this.partials = /* @__PURE__ */ new Map();
	}
	push(e, t) {
		switch (e.header.marker) {
			case J.Single: return this.frameFromSingle(e, t);
			case J.Start: return this.beginPartial(e, t);
			case J.Inter:
			case J.Final: return this.pushToPartial(e);
		}
	}
	reset() {
		this.partials.clear();
	}
	peekOldestPartialFrameNumber() {
		let e = this.partials.keys().next();
		return e.done ? null : e.value;
	}
	frameFromSingle(e, t) {
		if (e.header.marker !== J.Single) throw Error(`Depacketizer.frameFromSingle: packet.header.marker was not FrameMarker.Single, found ${e.header.marker}.`);
		let n = t?.maxPartialFrames ?? 1;
		if (this.partials.size >= n) {
			let n = this.peekOldestPartialFrameNumber();
			if (typeof n != "number") throw Error(`Depacketizer.frameFromSingle: no oldest frame number found, but partials.size is ${this.partials.size}.`);
			if (this.partials.delete(n), t?.throwOnInterruption) throw ld.interrupted(n, e.header.frameNumber.value);
			cd.warn(`Data track frame ${n} was interrupted by single-packet frame ${e.header.frameNumber.value}, dropping.`);
		}
		return {
			payload: e.payload,
			extensions: e.header.extensions
		};
	}
	beginPartial(e, t) {
		if (e.header.marker !== J.Start) throw Error(`Depacketizer.beginPartial: packet.header.marker was not FrameMarker.Start, found ${e.header.marker}.`);
		let n = e.header.sequence, r = e.header.frameNumber.value, i = {
			startSequence: n,
			extensions: e.header.extensions,
			payloads: new Map([[n.value, e.payload]])
		}, a = t?.maxPartialFrames ?? 1;
		for (; this.partials.size >= a;) {
			let e = this.peekOldestPartialFrameNumber();
			if (typeof e != "number") break;
			if (this.partials.delete(e), t?.throwOnInterruption) throw ld.interrupted(e, r);
			cd.warn(`Data track partials full (max ${a}), evicted oldest frame ${e} to make room for new frame ${r}.`);
		}
		return this.partials.set(r, i), null;
	}
	pushToPartial(t) {
		if (t.header.marker !== J.Inter && t.header.marker !== J.Final) throw Error(`Depacketizer.pushToPartial: packet.header.marker was not FrameMarker.Inter or FrameMarker.Final, found ${t.header.marker}.`);
		let n = t.header.frameNumber.value, r = this.partials.get(n);
		if (!r) throw this.partials.delete(n), ld.unknownFrame(n);
		if (r.payloads.size >= e.MAX_BUFFER_PACKETS) throw this.partials.delete(n), ld.bufferFull(n);
		return r.payloads.has(t.header.sequence.value) && cd.warn(`Data track frame ${n} received duplicate packet for sequence ${t.header.sequence.value}, so replacing with newly received packet.`), r.payloads.set(t.header.sequence.value, t.payload), t.header.marker === J.Final ? this.finalize(n, r, t.header.sequence.value) : null;
	}
	finalize(e, t, n) {
		let r = t.payloads.size, i = 0;
		for (let e of t.payloads.values()) i += e.length;
		let a = new Uint8Array(i), o = t.startSequence.clone(), s = 0;
		for (;;) {
			let r = t.payloads.get(o.value);
			if (!r) break;
			t.payloads.delete(o.value);
			let i = a.length - s;
			if (r.length > i) throw Error(`Depacketizer.finalize: Expected at least ${r.length} more bytes left in the payload buffer, only got ${i} bytes.`);
			if (a.set(r, s), s += r.length, o.value != n) {
				o.increment();
				continue;
			}
			return this.partials.delete(e), {
				payload: a,
				extensions: t.extensions
			};
		}
		throw this.partials.delete(e), ld.incomplete(e, r, n - t.startSequence.value + 1);
	}
};
dd.MAX_BUFFER_PACKETS = 128;
var fd;
(function(e) {
	e[e.Unpublished = 0] = "Unpublished", e[e.Timeout = 1] = "Timeout", e[e.Disconnected = 2] = "Disconnected", e[e.Cancelled = 4] = "Cancelled";
})(fd ||= {});
var pd = class e extends Ya {
	constructor(e, t, n) {
		super(22, e, n), this.name = "DataTrackSubscribeError", this.reason = t, this.reasonName = fd[t];
	}
	static unpublished() {
		return new e("The track has been unpublished and is no longer available", fd.Unpublished);
	}
	static timeout() {
		return new e("Request to subscribe to data track timed-out", fd.Timeout);
	}
	static disconnected() {
		return new e("Cannot subscribe to data track when disconnected", fd.Disconnected);
	}
	static cancelled() {
		return new e("Subscription to data track cancelled by caller", fd.Cancelled);
	}
}, md = T(C.DataTracks), hd = class {
	constructor(e) {
		let t = e.e2eeManager !== null;
		if (e.info.usesE2ee !== t) throw Error("IncomingDataTrackPipeline: DataTrackInfo.usesE2ee must match presence of decryptionProvider");
		let n = new dd();
		this.publisherIdentity = e.publisherIdentity, this.e2eeManager = e.e2eeManager ?? null, this.depacketizer = n, this.options = e.pipelineOptions ?? {};
	}
	updateE2eeManager(e) {
		this.e2eeManager = e;
	}
	setOptions(e) {
		this.options = e;
	}
	processPacket(e) {
		return E(this, void 0, void 0, function* () {
			let t = this.depacketize(e);
			return t && (yield this.decryptIfNeeded(t)) || null;
		});
	}
	depacketize(e) {
		let t;
		try {
			t = this.depacketizer.push(e, {
				throwOnInterruption: !1,
				maxPartialFrames: this.options.maxPartialFrames
			});
		} catch (e) {
			return md.warn(`Data frame depacketize error: ${e}`), null;
		}
		return t;
	}
	decryptIfNeeded(e) {
		return E(this, void 0, void 0, function* () {
			let t = this.e2eeManager;
			if (!t) return e;
			let n = e.extensions?.e2ee ?? null;
			if (!n) return md.error("Missing E2EE meta"), null;
			let r;
			try {
				r = yield t.handleEncryptedData(e.payload, n.iv, this.publisherIdentity, n.keyIndex);
			} catch (e) {
				return md.error(`Error decrypting packet: ${e}`), null;
			}
			return e.payload = r.payload, e;
		});
	}
}, Y = T(C.DataTracks), gd = 1e4, _d = 16, vd = class extends Oi.EventEmitter {
	constructor(e) {
		super(), this.descriptors = /* @__PURE__ */ new Map(), this.subscriptionHandles = /* @__PURE__ */ new Map(), this.e2eeManager = e?.e2eeManager ?? null;
	}
	updateE2eeManager(e) {
		this.e2eeManager = e;
		for (let t of this.descriptors.values()) t.subscription.type === "active" && t.subscription.pipeline.updateE2eeManager(e);
	}
	setPipelineOptions(e, t) {
		let n = this.descriptors.get(e);
		if (!n) {
			Y.warn(`Unknown track ${e}, cannot set pipeline options.`);
			return;
		}
		n.pipelineOptions = t, n.subscription.type === "active" && n.subscription.pipeline.setOptions(t);
	}
	openSubscriptionStream(e, t) {
		let n = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : _d, r = null, i = new U(), a = () => {
			t?.removeEventListener("abort", s);
		}, o = () => {
			if (a(), !r) {
				Y.warn(`ReadableStream subscribed to ${e} was not started.`);
				return;
			}
			let t = this.descriptors.get(e);
			if (!t) {
				Y.warn(`Unknown track ${e}, skipping cancel...`);
				return;
			}
			if (t.subscription.type !== "active") {
				Y.warn(`Subscription for track ${e} is not active, skipping cancel...`);
				return;
			}
			t.subscription.streamControllers.delete(r), t.subscription.streamControllers.size === 0 && this.unSubscribeRequest(t.info.sid);
		}, s = () => {
			var t;
			if (!r) return;
			let n = this.descriptors.get(e);
			n?.subscription.type === "active" && n.subscription.streamControllers.delete(r), r.error(pd.cancelled()), (t = i.reject) == null || t.call(i, pd.cancelled()), o();
		};
		return [new ReadableStream({
			start: (n) => {
				r = n, this.subscribeRequest(e, t).then(() => E(this, void 0, void 0, function* () {
					var r, o, c;
					let l = this.descriptors.get(e);
					if (!l) {
						Y.error(`Unknown track ${e}`);
						let t = pd.disconnected();
						n.error(t), (r = i.reject) == null || r.call(i, t);
						return;
					}
					if (l.subscription.type !== "active") {
						Y.error(`Subscription for track ${e} is not active`);
						let t = pd.disconnected();
						n.error(t), (o = i.reject) == null || o.call(i, t);
						return;
					}
					if (t?.aborted) {
						s();
						return;
					}
					t?.addEventListener("abort", s), l.subscription.streamControllers.set(n, a), (c = i.resolve) == null || c.call(i);
				})).catch((e) => {
					var t;
					n.error(e), (t = i.reject) == null || t.call(i, e);
				});
			},
			cancel: () => {
				o();
			}
		}, new CountQueuingStrategy({ highWaterMark: n })), i.promise];
	}
	subscribeRequest(e, t) {
		return E(this, void 0, void 0, function* () {
			let n = this.descriptors.get(e);
			if (!n) throw Error("Cannot subscribe to unknown track");
			let r = (t, n, r) => E(this, void 0, void 0, function* () {
				if (t.subscription.type === "active") return;
				if (t.subscription.type !== "pending") throw Error(`Descriptor for track ${e} is not pending, found ${t.subscription.type}`);
				let i = Du([n, r].filter((e) => e !== void 0)), a = new U();
				t.subscription.completionFuture.promise.then(() => a.resolve?.call(a)).catch((e) => a.reject?.call(a, e));
				let o = () => {
					var e;
					if (t.subscription.type === "pending") {
						if (--t.subscription.pendingRequestCount, r?.aborted) {
							t.subscription.cancel();
							return;
						}
						if (t.subscription.pendingRequestCount <= 0) {
							t.subscription.cancel();
							return;
						}
						(e = a.reject) == null || e.call(a, pd.cancelled());
					}
				};
				i.aborted && o(), i.addEventListener("abort", o), yield a.promise, i.removeEventListener("abort", o);
			});
			switch (n.subscription.type) {
				case "none": {
					n.subscription = {
						type: "pending",
						completionFuture: new U(),
						pendingRequestCount: 1,
						cancel: () => {
							var t, r;
							let a = n.subscription;
							n.subscription = { type: "none" }, this.emit("sfuUpdateSubscription", {
								sid: e,
								subscribe: !1
							}), a.type === "pending" && ((r = (t = a.completionFuture).reject) == null || r.call(t, i.aborted ? pd.timeout() : pd.cancelled()));
						}
					}, this.emit("sfuUpdateSubscription", {
						sid: e,
						subscribe: !0
					});
					let i = Ou(gd);
					yield r(n, t, i);
					return;
				}
				case "pending":
					n.subscription.pendingRequestCount += 1, yield r(n, t);
					return;
				case "active": return;
			}
		});
	}
	querySubscribed() {
		return E(this, void 0, void 0, function* () {
			return Array.from(this.descriptors.values()).filter((e) => e.subscription.type === "active").map((e) => [e.info, e.publisherIdentity]);
		});
	}
	unSubscribeRequest(e) {
		let t = this.descriptors.get(e);
		if (!t) throw Error("Cannot subscribe to unknown track");
		if (t.subscription.type !== "active") {
			Y.warn(`Unexpected descriptor state in unSubscribeRequest, expected active, found ${t.subscription?.type}`);
			return;
		}
		this.closeStreamControllers(t.subscription.streamControllers, e);
		let n = t.subscription;
		t.subscription = { type: "none" }, this.subscriptionHandles.delete(n.subcriptionHandle), this.emit("sfuUpdateSubscription", {
			sid: e,
			subscribe: !1
		});
	}
	closeStreamControllers(e, t) {
		for (let r of e) {
			var n = g(r, 2);
			let e = n[0], i = n[1];
			i();
			try {
				e.close();
			} catch (e) {
				Y.warn(`Failed to close readable stream for track ${t}: ${e}`);
			}
		}
	}
	receiveSfuPublicationUpdates(e) {
		return E(this, void 0, void 0, function* () {
			if (e.size === 0) return;
			let t = /* @__PURE__ */ new Map();
			for (let r of e.entries()) {
				var n = g(r, 2);
				let e = n[0], i = n[1], a = /* @__PURE__ */ new Set();
				for (let t of i) a.add(t.sid), !this.descriptors.has(t.sid) && (yield this.handleTrackPublished(e, t));
				t.set(e, a);
			}
			for (let e of t.entries()) {
				var r = g(e, 2);
				let t = r[0], n = r[1], i = Array.from(this.descriptors.entries()).filter((e) => {
					let n = g(e, 2);
					return n[0], n[1].publisherIdentity === t;
				}).map((e) => g(e, 1)[0]).filter((e) => !n.has(e));
				for (let e of i) this.handleTrackUnpublished(e);
			}
		});
	}
	queryPublications() {
		return E(this, void 0, void 0, function* () {
			return Array.from(this.descriptors.values()).map((e) => e.info);
		});
	}
	handleTrackPublished(e, t) {
		return E(this, void 0, void 0, function* () {
			if (this.descriptors.has(t.sid)) {
				Y.error(`Existing descriptor for track ${t.sid}`);
				return;
			}
			let n = {
				info: t,
				publisherIdentity: e,
				subscription: { type: "none" },
				pipelineOptions: {}
			};
			this.descriptors.set(n.info.sid, n);
			let r = new ad(n.info, this, { publisherIdentity: e });
			this.emit("trackPublished", { track: r });
		});
	}
	handleTrackUnpublished(e) {
		let t = this.descriptors.get(e);
		if (!t) {
			Y.error(`Unknown track ${e}`);
			return;
		}
		this.descriptors.delete(e), t.subscription.type === "active" && (this.closeStreamControllers(t.subscription.streamControllers, e), this.subscriptionHandles.delete(t.subscription.subcriptionHandle)), this.emit("trackUnpublished", {
			sid: e,
			publisherIdentity: t.publisherIdentity
		});
	}
	receivedSfuSubscriberHandles(e) {
		for (let n of e.entries()) {
			var t = g(n, 2);
			let e = t[0], r = t[1];
			this.registerSubscriberHandle(e, r);
		}
	}
	registerSubscriberHandle(e, t) {
		var n, r;
		let i = this.descriptors.get(t);
		if (!i) {
			Y.error(`Unknown track ${t}`);
			return;
		}
		switch (i.subscription.type) {
			case "none":
				Y.warn(`No subscription for ${t}`);
				return;
			case "active":
				i.subscription.subcriptionHandle = e, this.subscriptionHandles.set(e, t);
				return;
			case "pending": {
				let a = new hd({
					info: i.info,
					publisherIdentity: i.publisherIdentity,
					e2eeManager: this.e2eeManager,
					pipelineOptions: i.pipelineOptions
				}), o = i.subscription;
				i.subscription = {
					type: "active",
					subcriptionHandle: e,
					pipeline: a,
					streamControllers: /* @__PURE__ */ new Map()
				}, this.subscriptionHandles.set(e, t), (r = (n = o.completionFuture).resolve) == null || r.call(n);
			}
		}
	}
	packetReceived(e) {
		return E(this, void 0, void 0, function* () {
			let t;
			try {
				t = g(sd.fromBinary(e), 1)[0];
			} catch (e) {
				Y.error(`Failed to deserialize packet: ${e}`);
				return;
			}
			let n = this.subscriptionHandles.get(t.header.trackHandle);
			if (!n) {
				Y.warn(`Unknown subscriber handle ${t.header.trackHandle}`);
				return;
			}
			let r = this.descriptors.get(n);
			if (!r) {
				Y.error(`Missing descriptor for track ${n}`);
				return;
			}
			if (r.subscription.type !== "active") {
				Y.warn(`Received packet for track ${n} without active subscription`);
				return;
			}
			let i = yield r.subscription.pipeline.processPacket(t);
			if (i) for (let e of r.subscription.streamControllers.keys()) {
				if (e.desiredSize !== null && e.desiredSize <= 0) {
					Y.warn(`Cannot send frame to subscribers: readable stream is full (desiredSize is ${e.desiredSize}). To increase this threshold, set a higher 'options.highWaterMark' when calling .subscribe().`);
					continue;
				}
				let t = nd.lossyIntoFrame(i);
				e.enqueue(t);
			}
		});
	}
	resendSubscriptionUpdates() {
		for (let t of this.descriptors) {
			var e = g(t, 2);
			let n = e[0];
			e[1].subscription.type !== "none" && this.emit("sfuUpdateSubscription", {
				sid: n,
				subscribe: !0
			});
		}
	}
	handleRemoteParticipantDisconnected(e) {
		var t, n;
		for (let r of this.descriptors.values()) if (r.publisherIdentity === e) switch (r.subscription.type) {
			case "none": break;
			case "pending":
				(n = (t = r.subscription.completionFuture).reject) == null || n.call(t, pd.disconnected());
				break;
			case "active":
				this.unSubscribeRequest(r.info.sid);
				break;
		}
	}
	reset() {
		var e, t;
		for (let n of this.descriptors.values()) this.emit("trackUnpublished", {
			sid: n.info.sid,
			publisherIdentity: n.publisherIdentity
		}), n.subscription.type === "pending" && ((t = (e = n.subscription.completionFuture).reject) == null || t.call(e, pd.disconnected())), n.subscription.type === "active" && this.closeStreamControllers(n.subscription.streamControllers, n.info.sid);
		this.descriptors.clear(), this.subscriptionHandles.clear();
	}
}, yd = class e extends Ya {
	constructor(e, t, n) {
		super(19, e, n), this.name = "DataTrackPacketizerError", this.reason = t, this.reasonName = bd[t];
	}
	static mtuTooShort() {
		return new e("MTU is too short to send frame", bd.MtuTooShort);
	}
}, bd;
(function(e) {
	e[e.MtuTooShort = 0] = "MtuTooShort";
})(bd ||= {});
var xd = class e {
	constructor(e, t) {
		this.sequence = kc.u16(0), this.frameNumber = kc.u16(0), this.clock = jc.rtpStartingNow(Ac.rtpRandom()), this.handle = e, this.mtuSizeBytes = t;
	}
	static computeFrameMarker(e, t) {
		return t <= 1 ? J.Single : e === 0 ? J.Start : e === t - 1 ? J.Final : J.Inter;
	}
	*packetize(t, n) {
		let r = this.frameNumber.getThenIncrement(), i = {
			marker: J.Inter,
			trackHandle: this.handle,
			sequence: kc.u16(0),
			frameNumber: r,
			timestamp: n?.now ?? this.clock.now(),
			extensions: t.extensions
		}, a = new od(i).toBinaryLengthBytes();
		if (a >= this.mtuSizeBytes) throw yd.mtuTooShort();
		let o = this.mtuSizeBytes - a, s = Math.ceil(t.payload.byteLength / o);
		for (let n = 0, r = 0; r < t.payload.byteLength; c = [n + 1, r + o], n = c[0], r = c[1]) {
			var c;
			let a = this.sequence.getThenIncrement(), l = new od(Object.assign(Object.assign({}, i), {
				marker: e.computeFrameMarker(n, s),
				sequence: a
			})), u = Math.min(o, t.payload.byteLength - r);
			yield new sd(l, new Uint8Array(t.payload.buffer, t.payload.byteOffset + r, u));
		}
	}
}, Sd;
(function(e) {
	e[e.NotAllowed = 0] = "NotAllowed", e[e.DuplicateName = 1] = "DuplicateName", e[e.Timeout = 2] = "Timeout", e[e.LimitReached = 3] = "LimitReached", e[e.Disconnected = 4] = "Disconnected", e[e.Cancelled = 5] = "Cancelled", e[e.InvalidName = 6] = "InvalidName", e[e.Unknown = 7] = "Unknown";
})(Sd ||= {});
var Cd = class e extends Ya {
	constructor(e, t, n) {
		super(21, e, n), this.name = "DataTrackPublishError", this.reason = t, this.reasonName = Sd[t], this.rawMessage = n?.rawMessage;
	}
	static notAllowed(t) {
		return new e("Data track publishing unauthorized", Sd.NotAllowed, { rawMessage: t });
	}
	static duplicateName(t) {
		return new e("Track name already taken", Sd.DuplicateName, { rawMessage: t });
	}
	static invalidName(t) {
		return new e("Track name is invalid", Sd.InvalidName, { rawMessage: t });
	}
	static timeout() {
		return new e("Publish data track timed-out. Does the LiveKit server support data tracks?", Sd.Timeout);
	}
	static limitReached(t) {
		return new e("Data track publication limit reached", Sd.LimitReached, { rawMessage: t });
	}
	static unknown(t, n) {
		return new e(`Received RequestResponse for publishDataTrack, but reason was unrecognised (${t}, ${n})`, Sd.Unknown);
	}
	static disconnected() {
		return new e("Room disconnected", Sd.Disconnected);
	}
	static cancelled() {
		return new e("Publish data track cancelled by caller", Sd.Cancelled);
	}
}, wd;
(function(e) {
	e[e.TrackUnpublished = 0] = "TrackUnpublished", e[e.Dropped = 1] = "Dropped";
})(wd ||= {});
var Td = class e extends Ya {
	constructor(e, t, n) {
		super(22, e, n), this.name = "DataTrackPushFrameError", this.reason = t, this.reasonName = wd[t];
	}
	static trackUnpublished() {
		return new e("Track is no longer published", wd.TrackUnpublished);
	}
	static dropped(t) {
		return new e("Frame was dropped", wd.Dropped, { cause: t });
	}
}, Ed;
(function(e) {
	e[e.Packetizer = 0] = "Packetizer", e[e.Encryption = 1] = "Encryption";
})(Ed ||= {});
var Dd = class e extends Ya {
	constructor(e, t, n) {
		super(21, e, n), this.name = "DataTrackOutgoingPipelineError", this.reason = t, this.reasonName = Ed[t];
	}
	static packetizer(t) {
		return new e("Error packetizing frame", Ed.Packetizer, { cause: t });
	}
	static encryption(t) {
		return new e("Error encrypting frame", Ed.Encryption, { cause: t });
	}
}, Od = class e {
	constructor(e, t) {
		this.trackSymbol = rd, this.isLocal = !0, this.typeSymbol = id, this.handle = null, this.log = w, this.flushedFuture = new U(), this.isFlushed = !0, this.handleManagerReset = () => {
			var e, t;
			(t = (e = this.flushedFuture).resolve) == null || t.call(e), this.manager.off("packetsFlushedChange", this.handleManagerPacketsFlushedChange), this.manager.off("reset", this.handleManagerReset);
		}, this.handleManagerPacketsFlushedChange = (e) => {
			var t, n;
			this.isFlushed = e.isFlushed, e.isFlushed && ((n = (t = this.flushedFuture).resolve) == null || n.call(t), this.flushedFuture = new U());
		}, this.options = e, this.manager = t, this.log = T(C.DataTracks), this.manager.on("packetsFlushedChange", this.handleManagerPacketsFlushedChange), this.manager.on("reset", this.handleManagerReset);
	}
	static withExplicitHandle(t, n, r) {
		let i = new e(t, n);
		return i.handle = r, i;
	}
	get info() {
		let e = this.descriptor;
		if (e?.type === "active") return e.info;
	}
	get descriptor() {
		return this.handle ? this.manager.getDescriptor(this.handle) : null;
	}
	publish(e) {
		return E(this, void 0, void 0, function* () {
			try {
				this.handle = yield this.manager.publishRequest(this.options, e);
			} catch (e) {
				throw e;
			}
		});
	}
	isPublished() {
		return this.descriptor?.type === "active" && this.descriptor.publishState !== "unpublished";
	}
	tryPush(e) {
		if (!this.handle) throw Td.trackUnpublished();
		let t = nd.from(e);
		try {
			return this.manager.tryProcessAndSend(this.handle, t);
		} catch (e) {
			throw e;
		}
	}
	flush() {
		return E(this, void 0, void 0, function* () {
			if (!this.isFlushed) return this.flushedFuture.promise;
		});
	}
	unpublish() {
		return E(this, void 0, void 0, function* () {
			if (!this.handle) {
				w.warn(`Data track "${this.options.name}" is not published, so unpublishing has no effect.`);
				return;
			}
			try {
				yield this.manager.unpublishRequest(this.handle);
			} catch (e) {
				throw e;
			}
		});
	}
}, kd = class e {
	constructor(t) {
		this.e2eeManager = t.e2eeManager, this.packetizer = new xd(t.info.pubHandle, e.TRANSPORT_MTU_BYTES);
	}
	updateE2eeManager(e) {
		this.e2eeManager = e;
	}
	processFrame(e) {
		return Si(this, arguments, function* () {
			let t = yield xi(this.encryptIfNeeded(e));
			try {
				yield xi(yield* Ci(wi(this.packetizer.packetize(t))));
			} catch (e) {
				throw e instanceof yd ? Dd.packetizer(e) : e;
			}
		});
	}
	encryptIfNeeded(e) {
		return E(this, void 0, void 0, function* () {
			if (!this.e2eeManager) return e;
			let t;
			try {
				t = yield this.e2eeManager.encryptData(e.payload);
			} catch (e) {
				throw Dd.encryption(e);
			}
			return e.payload = t.payload, e.extensions.e2ee = new ed(t.keyIndex, t.iv), e;
		});
	}
};
kd.TRANSPORT_MTU_BYTES = 16e3;
var Ad = T(C.DataTracks), jd = {
	pending() {
		return {
			type: "pending",
			completionFuture: new U()
		};
	},
	active(e, t) {
		return {
			type: "active",
			info: e,
			publishState: "published",
			pipeline: new kd({
				info: e,
				e2eeManager: t
			}),
			unpublishingFuture: new U()
		};
	}
}, Md = 1e4, Nd = class e extends Oi.EventEmitter {
	constructor(e) {
		super(), this.handleAllocator = new Ic(), this.descriptors = /* @__PURE__ */ new Map(), this.inFlightPacketCounter = /* @__PURE__ */ new Map(), this.e2eeManager = e?.e2eeManager ?? null;
	}
	static withDescriptors(t) {
		let n = new e();
		return n.descriptors = t, n;
	}
	updateE2eeManager(e) {
		this.e2eeManager = e;
		for (let t of this.descriptors.values()) t.type === "active" && t.pipeline.updateE2eeManager(e);
	}
	getDescriptor(e) {
		return this.descriptors.get(e) ?? null;
	}
	tryProcessAndSend(e, t) {
		return E(this, void 0, void 0, function* () {
			var n, r, i, a;
			let o = this.getDescriptor(e);
			if (o?.type !== "active" || o.publishState === "unpublished") throw Td.trackUnpublished();
			if (o.publishState === "republishing") throw Td.dropped("Data track republishing");
			try {
				try {
					for (var s = !0, c = wi(o.pipeline.processFrame(t)), l; l = yield c.next(), n = l.done, !n; s = !0) {
						a = l.value, s = !1;
						let t = a, n = this.inFlightPacketCounter.get(e) ?? 0;
						this.inFlightPacketCounter.set(e, n + 1), n === 0 && this.emit("packetsFlushedChange", {
							handle: e,
							isFlushed: !1
						}), this.emit("packetAvailable", {
							handle: e,
							bytes: t.toBinary()
						});
					}
				} catch (e) {
					r = { error: e };
				} finally {
					try {
						!s && !n && (i = c.return) && (yield i.call(c));
					} finally {
						if (r) throw r.error;
					}
				}
			} catch (e) {
				throw Td.dropped(e);
			}
		});
	}
	handlePacketSendComplete(e) {
		let t = (this.inFlightPacketCounter.get(e) ?? 0) - 1;
		t < 0 && (Ad.warn(`OutgoingDataTrackManager.handlePacketSendComplete: inFlightPacketCounter was decremented below 0 (got ${this.inFlightPacketCounter} - resetting to 0. Were more packets send than were emitted?`), t = 0), this.inFlightPacketCounter.set(e, t), t === 0 && this.emit("packetsFlushedChange", {
			handle: e,
			isFlushed: !0
		});
	}
	publishRequest(e, t) {
		return E(this, void 0, void 0, function* () {
			let n = this.handleAllocator.get();
			if (!n) throw Cd.limitReached();
			let r = Ou(Md), i = t ? Du([t, r]) : r;
			if (this.descriptors.has(n)) throw Error("Descriptor for handle already exists");
			let a = jd.pending();
			this.descriptors.set(n, a);
			let o = () => {
				var e, t;
				let i = this.descriptors.get(n);
				if (!i) {
					Ad.warn(`No descriptor for ${n}`);
					return;
				}
				this.descriptors.delete(n), this.emit("sfuUnpublishRequest", { handle: n }), i.type === "pending" && ((t = (e = i.completionFuture).reject) == null || t.call(e, r.aborted ? Cd.timeout() : Cd.cancelled()));
			};
			return i.aborted ? (o(), a.completionFuture.promise.then(() => n)) : (i.addEventListener("abort", o), this.emit("sfuPublishRequest", {
				handle: n,
				name: e.name,
				usesE2ee: this.e2eeManager !== null
			}), yield a.completionFuture.promise, i.removeEventListener("abort", o), this.emit("trackPublished", { track: Od.withExplicitHandle(e, this, n) }), n);
		});
	}
	queryPublished() {
		return Array.from(this.descriptors.values()).filter((e) => e.type === "active").map((e) => e.info);
	}
	unpublishRequest(e) {
		return E(this, void 0, void 0, function* () {
			let t = this.descriptors.get(e);
			if (!t) {
				Ad.warn(`No descriptor for ${e}`);
				return;
			}
			if (t.type !== "active") {
				Ad.warn(`Track ${e} not active`);
				return;
			}
			this.emit("sfuUnpublishRequest", { handle: e }), yield t.unpublishingFuture.promise, this.inFlightPacketCounter.delete(e), this.emit("trackUnpublished", { sid: t.info.sid });
		});
	}
	receivedSfuPublishResponse(e, t) {
		var n, r, i, a;
		let o = this.descriptors.get(e);
		if (!o) {
			Ad.warn(`No descriptor for ${e}`);
			return;
		}
		switch (this.descriptors.delete(e), o.type) {
			case "pending":
				if (t.type === "ok") {
					let e = t.data, i = e.usesE2ee ? this.e2eeManager : null;
					this.descriptors.set(e.pubHandle, jd.active(e, i)), (r = (n = o.completionFuture).resolve) == null || r.call(n);
				} else (a = (i = o.completionFuture).reject) == null || a.call(i, t.error);
				return;
			case "active":
				if (o.publishState !== "republishing") {
					Ad.warn(`Track ${e} already active`);
					return;
				}
				if (t.type === "error") {
					Ad.warn(`Republish failed for track ${e}`);
					return;
				}
				Ad.debug(`Track ${e} republished`), o.info.sid = t.data.sid, o.publishState = "published", this.descriptors.set(o.info.pubHandle, o);
		}
	}
	receivedSfuUnpublishResponse(e) {
		var t, n;
		let r = this.descriptors.get(e);
		if (!r) {
			Ad.warn(`No descriptor for ${e}`);
			return;
		}
		if (this.descriptors.delete(e), r.type !== "active") {
			Ad.warn(`Track ${e} not active`);
			return;
		}
		r.publishState = "unpublished", (n = (t = r.unpublishingFuture).resolve) == null || n.call(t);
	}
	sfuWillRepublishTracks() {
		var e, t;
		for (let r of this.descriptors.entries()) {
			var n = g(r, 2);
			let i = n[0], a = n[1];
			switch (a.type) {
				case "pending":
					this.descriptors.delete(i), (t = (e = a.completionFuture).reject) == null || t.call(e, Cd.disconnected());
					break;
				case "active": a.publishState = "republishing", this.emit("sfuPublishRequest", {
					handle: a.info.pubHandle,
					name: a.info.name,
					usesE2ee: a.info.usesE2ee
				});
			}
		}
	}
	reset() {
		return E(this, void 0, void 0, function* () {
			var e, t, n, r;
			this.handleAllocator.reset();
			for (let i of this.descriptors.values()) switch (i.type) {
				case "pending":
					(t = (e = i.completionFuture).reject) == null || t.call(e, Cd.disconnected());
					break;
				case "active":
					(r = (n = i.unpublishingFuture).resolve) == null || r.call(n), yield this.unpublishRequest(i.info.pubHandle);
					break;
			}
			this.descriptors.clear(), this.inFlightPacketCounter.clear(), this.emit("reset");
		});
	}
}, X = class e extends Error {
	constructor(t, n, r, i) {
		super(n), this.code = t, this.message = Bd(n, e.MAX_MESSAGE_BYTES), this.data = r ? Bd(r, e.MAX_DATA_BYTES) : void 0, i?.cause !== void 0 && (this.cause = i?.cause);
	}
	static fromProto(t) {
		return new e(t.code, t.message, t.data);
	}
	toProto() {
		return new Mn({
			code: this.code,
			message: this.message,
			data: this.data
		});
	}
	static builtIn(t, n, r) {
		return new e(e.ErrorCode[t], e.ErrorMessage[t], n, r);
	}
};
X.MAX_MESSAGE_BYTES = 256, X.MAX_DATA_BYTES = 15360, X.ErrorCode = {
	APPLICATION_ERROR: 1500,
	CONNECTION_TIMEOUT: 1501,
	RESPONSE_TIMEOUT: 1502,
	RECIPIENT_DISCONNECTED: 1503,
	RESPONSE_PAYLOAD_TOO_LARGE: 1504,
	SEND_FAILED: 1505,
	UNSUPPORTED_METHOD: 1400,
	RECIPIENT_NOT_FOUND: 1401,
	REQUEST_PAYLOAD_TOO_LARGE: 1402,
	UNSUPPORTED_SERVER: 1403,
	UNSUPPORTED_VERSION: 1404
}, X.ErrorMessage = {
	APPLICATION_ERROR: "Application error in method handler",
	CONNECTION_TIMEOUT: "Connection timeout",
	RESPONSE_TIMEOUT: "Response timeout",
	RECIPIENT_DISCONNECTED: "Recipient disconnected",
	RESPONSE_PAYLOAD_TOO_LARGE: "Response payload too large",
	SEND_FAILED: "Failed to send",
	UNSUPPORTED_METHOD: "Method not supported at destination",
	RECIPIENT_NOT_FOUND: "Recipient not found",
	REQUEST_PAYLOAD_TOO_LARGE: "Request payload too large",
	UNSUPPORTED_SERVER: "RPC not supported by server",
	UNSUPPORTED_VERSION: "Unsupported RPC version"
};
var Pd = 15360, Fd = "lk.rpc_request", Id = "lk.rpc_response", Z;
(function(e) {
	e.RPC_REQUEST_ID = "lk.rpc_request_id", e.RPC_REQUEST_METHOD = "lk.rpc_request_method", e.RPC_REQUEST_RESPONSE_TIMEOUT_MS = "lk.rpc_request_response_timeout_ms", e.RPC_REQUEST_VERSION = "lk.rpc_request_version";
})(Z ||= {});
var Ld = 1, Rd = 2;
function zd(e) {
	return new TextEncoder().encode(e).length;
}
function Bd(e, t) {
	if (zd(e) <= t) return e;
	let n = 0, r = e.length, i = new TextEncoder();
	for (; n < r;) {
		let a = Math.floor((n + r + 1) / 2);
		i.encode(e.slice(0, a)).length <= t ? n = a : r = a - 1;
	}
	return e.slice(0, n);
}
var Vd = class extends ki {
	constructor(e, t, n, r) {
		super(), this.pendingAcks = /* @__PURE__ */ new Map(), this.pendingResponses = /* @__PURE__ */ new Map(), this.log = e, this.outgoingDataStreamManager = t, this.getRemoteParticipantClientProtocol = n, this.getServerVersion = r;
	}
	performRpc(e) {
		return E(this, arguments, void 0, function(e) {
			var t = this;
			let n = e.destinationIdentity, r = e.method, i = e.payload, a = e.responseTimeout, o = a === void 0 ? 15e3 : a;
			return function* () {
				let e = t.getRemoteParticipantClientProtocol(n);
				if (zd(i) > Pd && e < 1) throw X.builtIn("REQUEST_PAYLOAD_TOO_LARGE");
				let a = t.getServerVersion();
				if (a && cs(a, "1.8.0") < 0) throw X.builtIn("UNSUPPORTED_SERVER");
				let s = Math.max(o, 8e3), c = crypto.randomUUID(), l = new U(), u = null, d = setTimeout(() => {
					var e;
					t.pendingAcks.delete(c), (e = l.reject) == null || e.call(l, X.builtIn("CONNECTION_TIMEOUT")), t.pendingResponses.delete(c), u !== null && clearTimeout(u);
				}, 7e3);
				return t.pendingAcks.set(c, {
					resolve: () => {
						clearTimeout(d);
					},
					participantIdentity: n
				}), t.pendingResponses.set(c, {
					completionFuture: l,
					participantIdentity: n
				}), yield t.publishRpcRequest(n, c, r, i, s, e), u = setTimeout(() => {
					var e;
					t.pendingResponses.delete(c), (e = l.reject) == null || e.call(l, X.builtIn("RESPONSE_TIMEOUT"));
				}, o), [c, l.promise.finally(() => {
					clearTimeout(u), t.pendingAcks.has(c) && (t.log.warn("RPC response received before ack", c), t.pendingAcks.delete(c), clearTimeout(d));
				})];
			}();
		});
	}
	publishRpcRequest(e, t, n, r, i, a) {
		return E(this, void 0, void 0, function* () {
			if (a >= 1) {
				let a = yield this.outgoingDataStreamManager.streamText({
					topic: Fd,
					destinationIdentities: [e],
					attributes: {
						[Z.RPC_REQUEST_ID]: t,
						[Z.RPC_REQUEST_METHOD]: n,
						[Z.RPC_REQUEST_RESPONSE_TIMEOUT_MS]: `${i}`,
						[Z.RPC_REQUEST_VERSION]: `${Rd}`
					}
				});
				yield a.write(r), yield a.close();
				return;
			}
			this.emit("sendDataPacket", { packet: new S({
				destinationIdentities: [e],
				kind: yn.RELIABLE,
				value: {
					case: "rpcRequest",
					value: new kn({
						id: t,
						method: n,
						payload: r,
						responseTimeoutMs: i,
						version: Ld
					})
				}
			}) });
		});
	}
	handleIncomingDataStream(e, t, n) {
		return E(this, void 0, void 0, function* () {
			let r = n[Z.RPC_REQUEST_ID];
			if (!r) {
				this.log.warn(`RPC data stream malformed: ${Z.RPC_REQUEST_ID} not set.`);
				return;
			}
			let i = this.pendingResponses.get(r);
			if (i && i.participantIdentity !== t) {
				this.log.warn(`RPC response stream for ${r} arrived from unexpected sender ${t}, expected ${i.participantIdentity}. Ignoring.`);
				return;
			}
			let a;
			try {
				a = yield e.readAll();
			} catch (e) {
				this.log.warn(`Error reading RPC response payload: ${e}`), this.handleIncomingRpcResponseFailure(r, X.builtIn("APPLICATION_ERROR", "Error reading RPC response payload", { cause: e }));
				return;
			}
			this.handleIncomingRpcResponseSuccess(r, a);
		});
	}
	handleIncomingRpcResponseSuccess(e, t) {
		var n, r;
		let i = this.pendingResponses.get(e);
		i ? ((r = (n = i.completionFuture).resolve) == null || r.call(n, t), this.pendingResponses.delete(e)) : this.log.error("Response received for unexpected RPC request", e);
	}
	handleIncomingRpcResponseFailure(e, t) {
		var n, r;
		let i = this.pendingResponses.get(e);
		i ? ((r = (n = i.completionFuture).reject) == null || r.call(n, t), this.pendingResponses.delete(e)) : this.log.error("Response received for unexpected RPC request", e);
	}
	handleIncomingRpcAck(e) {
		let t = this.pendingAcks.get(e);
		t ? (t.resolve(), this.pendingAcks.delete(e)) : this.log.error(`Ack received for unexpected RPC request: ${e}`);
	}
	handleParticipantDisconnected(e) {
		var t;
		for (let t of this.pendingAcks) {
			var n = g(t, 2);
			let r = n[0];
			n[1].participantIdentity === e && this.pendingAcks.delete(r);
		}
		for (let n of this.pendingResponses) {
			var r = g(n, 2);
			let a = r[0];
			var i = r[1];
			let o = i.participantIdentity, s = i.completionFuture;
			o === e && ((t = s.reject) == null || t.call(s, X.builtIn("RECIPIENT_DISCONNECTED")), this.pendingResponses.delete(a));
		}
	}
}, Hd = class extends ki {
	constructor(e, t, n) {
		super(), this.rpcHandlers = /* @__PURE__ */ new Map(), this.log = e, this.outgoingDataStreamManager = t, this.getRemoteParticipantClientProtocol = n;
	}
	registerRpcMethod(e, t) {
		if (this.rpcHandlers.has(e)) throw Error(`RPC handler already registered for method ${e}, unregisterRpcMethod before trying to register again`);
		this.rpcHandlers.set(e, t);
	}
	unregisterRpcMethod(e) {
		this.rpcHandlers.delete(e);
	}
	handleIncomingRpcRequest(e, t) {
		return E(this, void 0, void 0, function* () {
			if (this.publishRpcAck(e, t.id), t.version !== 1) {
				this.publishRpcResponsePacket(e, t.id, null, X.builtIn("UNSUPPORTED_VERSION"));
				return;
			}
			let n = this.rpcHandlers.get(t.method);
			if (!n) {
				this.publishRpcResponsePacket(e, t.id, null, X.builtIn("UNSUPPORTED_METHOD"));
				return;
			}
			let r;
			try {
				r = yield n({
					requestId: t.id,
					callerIdentity: e,
					payload: t.payload,
					responseTimeout: t.responseTimeoutMs
				});
			} catch (n) {
				let r;
				n instanceof X ? r = n : (this.log.warn(`Uncaught error returned by RPC handler for ${t.method}. Returning APPLICATION_ERROR instead.`, n), r = X.builtIn("APPLICATION_ERROR", `Uncaught error: ${n?.message ?? n}`, { cause: n })), this.publishRpcResponsePacket(e, t.id, null, r);
				return;
			}
			yield this.publishRpcResponse(e, t.id, r ?? "");
		});
	}
	handleIncomingDataStream(e, t, n) {
		return E(this, void 0, void 0, function* () {
			let r = n[Z.RPC_REQUEST_ID], i = n[Z.RPC_REQUEST_METHOD], a = parseInt(n[Z.RPC_REQUEST_RESPONSE_TIMEOUT_MS], 10), o = parseInt(n[Z.RPC_REQUEST_VERSION], 10);
			if (!r || !i || Number.isNaN(a) || Number.isNaN(o)) {
				this.log.warn(`RPC data stream malformed: ${Z.RPC_REQUEST_ID} / ${Z.RPC_REQUEST_METHOD} / ${Z.RPC_REQUEST_RESPONSE_TIMEOUT_MS} / ${Z.RPC_REQUEST_VERSION} not set.`), this.publishRpcResponsePacket(t, r, null, X.builtIn("APPLICATION_ERROR", "RPC data stream malformed"));
				return;
			}
			if (this.publishRpcAck(t, r), o !== Rd) {
				this.publishRpcResponsePacket(t, r, null, X.builtIn("UNSUPPORTED_VERSION"));
				return;
			}
			let s;
			try {
				s = yield e.readAll();
			} catch (e) {
				this.log.warn(`Error reading RPC request payload: ${e}`), this.publishRpcResponsePacket(t, r, null, X.builtIn("APPLICATION_ERROR", "Error reading RPC request payload", { cause: e }));
				return;
			}
			let c = this.rpcHandlers.get(i);
			if (!c) {
				this.publishRpcResponsePacket(t, r, null, X.builtIn("UNSUPPORTED_METHOD"));
				return;
			}
			let l;
			try {
				l = yield c({
					requestId: r,
					callerIdentity: t,
					payload: s,
					responseTimeout: a
				});
			} catch (e) {
				let n;
				e instanceof X ? n = e : (this.log.warn(`Uncaught error returned by RPC handler for ${i}. Returning APPLICATION_ERROR instead.`, e), n = X.builtIn("APPLICATION_ERROR")), this.publishRpcResponsePacket(t, r, null, n);
				return;
			}
			yield this.publishRpcResponse(t, r, l ?? "");
		});
	}
	publishRpcAck(e, t) {
		this.emit("sendDataPacket", { packet: new S({
			destinationIdentities: [e],
			kind: yn.RELIABLE,
			value: {
				case: "rpcAck",
				value: new An({ requestId: t })
			}
		}) });
	}
	publishRpcResponsePacket(e, t, n, r) {
		this.emit("sendDataPacket", { packet: new S({
			destinationIdentities: [e],
			kind: yn.RELIABLE,
			value: {
				case: "rpcResponse",
				value: new jn({
					requestId: t,
					value: r ? {
						case: "error",
						value: r.toProto()
					} : {
						case: "payload",
						value: n ?? ""
					}
				})
			}
		}) });
	}
	publishRpcResponse(e, t, n) {
		return E(this, void 0, void 0, function* () {
			if (this.getRemoteParticipantClientProtocol(e) >= 1) {
				let r = yield this.outgoingDataStreamManager.streamText({
					topic: Id,
					destinationIdentities: [e],
					attributes: { [Z.RPC_REQUEST_ID]: t }
				});
				yield r.write(n), yield r.close();
				return;
			}
			if (zd(n) > Pd) {
				this.log.warn(`RPC Response payload too large for request ${t}. To send larger responses, consider updating the sending client.`), this.publishRpcResponsePacket(e, t, null, X.builtIn("RESPONSE_PAYLOAD_TOO_LARGE"));
				return;
			}
			this.publishRpcResponsePacket(e, t, n, null);
		});
	}
}, Ud = class extends fc {
	constructor(e, t, n, r, i, a) {
		super(e, t, B.Kind.Audio, n, a), this.monitorReceiver = () => E(this, void 0, void 0, function* () {
			if (!this.receiver) {
				this._currentBitrate = 0;
				return;
			}
			let e = yield this.getReceiverStats();
			e && this.prevStats && this.receiver && (this._currentBitrate = dc(e, this.prevStats)), this.prevStats = e;
		}), this.audioContext = r, this.webAudioPluginNodes = [], i && (this.sinkId = i.deviceId);
	}
	setVolume(e) {
		var t;
		for (let n of this.attachedElements) this.audioContext ? (t = this.gainNode) == null || t.gain.setTargetAtTime(e, 0, .1) : n.volume = e;
		ns() && this._mediaStreamTrack._setVolume(e), this.elementVolume = e;
	}
	getVolume() {
		if (this.elementVolume) return this.elementVolume;
		if (ns()) return 1;
		let e = 0;
		return this.attachedElements.forEach((t) => {
			t.volume > e && (e = t.volume);
		}), e;
	}
	setSinkId(e) {
		return E(this, void 0, void 0, function* () {
			this.sinkId = e, yield Promise.all(this.attachedElements.map((t) => {
				if (Go(t)) return t.setSinkId(e);
			}));
		});
	}
	attach(e) {
		let t = this.attachedElements.length === 0;
		return e ? super.attach(e) : e = super.attach(), this.sinkId && Go(e) && e.setSinkId(this.sinkId).catch((e) => {
			this.log.error("Failed to set sink id on remote audio track", e, this.logContext);
		}), this.audioContext && t && (this.log.debug("using audio context mapping", this.logContext), this.connectWebAudio(this.audioContext, e), e.volume = 0, e.muted = !0), this.elementVolume && this.setVolume(this.elementVolume), e;
	}
	detach(e) {
		let t;
		return e ? (t = super.detach(e), this.audioContext && (this.attachedElements.length > 0 ? this.connectWebAudio(this.audioContext, this.attachedElements[0]) : this.disconnectWebAudio())) : (t = super.detach(), this.disconnectWebAudio()), t;
	}
	setAudioContext(e) {
		this.audioContext = e, e && this.attachedElements.length > 0 ? this.connectWebAudio(e, this.attachedElements[0]) : e || this.disconnectWebAudio();
	}
	setWebAudioPlugins(e) {
		this.webAudioPluginNodes = e, this.attachedElements.length > 0 && this.audioContext && this.connectWebAudio(this.audioContext, this.attachedElements[0]);
	}
	connectWebAudio(e, t) {
		this.disconnectWebAudio(), this.sourceNode = e.createMediaStreamSource(t.srcObject);
		let n = this.sourceNode;
		this.webAudioPluginNodes.forEach((e) => {
			n.connect(e), n = e;
		}), this.gainNode = e.createGain(), n.connect(this.gainNode), this.gainNode.connect(e.destination), this.elementVolume && this.gainNode.gain.setTargetAtTime(this.elementVolume, 0, .1), e.state !== "running" && e.resume().then(() => {
			e.state !== "running" && this.emit(L.AudioPlaybackFailed, /* @__PURE__ */ Error("Audio Context couldn't be started automatically"));
		}).catch((e) => {
			this.emit(L.AudioPlaybackFailed, e);
		});
	}
	disconnectWebAudio() {
		var e, t;
		(e = this.gainNode) == null || e.disconnect(), (t = this.sourceNode) == null || t.disconnect(), this.gainNode = void 0, this.sourceNode = void 0;
	}
	getReceiverStats() {
		return E(this, void 0, void 0, function* () {
			if (!this.receiver || !this.receiver.getStats) return;
			let e = yield this.receiver.getStats(), t;
			return e.forEach((e) => {
				e.type === "inbound-rtp" && (t = {
					type: "audio",
					streamId: e.id,
					timestamp: e.timestamp,
					jitter: e.jitter,
					bytesReceived: e.bytesReceived,
					concealedSamples: e.concealedSamples,
					concealmentEvents: e.concealmentEvents,
					silentConcealedSamples: e.silentConcealedSamples,
					silentConcealmentEvents: e.silentConcealmentEvents,
					totalAudioEnergy: e.totalAudioEnergy,
					totalSamplesDuration: e.totalSamplesDuration
				});
			}), t;
		});
	}
}, Wd = class extends Oi.EventEmitter {
	constructor(e, t, n, r) {
		super(), this.metadataMuted = !1, this.encryption = x.NONE, this.log = w, this.handleMuted = () => {
			this.emit(L.Muted);
		}, this.handleUnmuted = () => {
			this.emit(L.Unmuted);
		}, this.log = T(r?.loggerName ?? C.Publication), this.loggerContextCb = this.loggerContextCb, this.setMaxListeners(100), this.kind = e, this.trackSid = t, this.trackName = n, this.source = B.Source.Unknown;
	}
	setTrack(e) {
		this.track && (this.track.off(L.Muted, this.handleMuted), this.track.off(L.Unmuted, this.handleUnmuted)), this.track = e, e && (e.on(L.Muted, this.handleMuted), e.on(L.Unmuted, this.handleUnmuted));
	}
	get logContext() {
		return Object.assign(Object.assign({}, this.loggerContextCb?.call(this)), z(this));
	}
	get isMuted() {
		return this.metadataMuted;
	}
	get isEnabled() {
		return !0;
	}
	get isSubscribed() {
		return this.track !== void 0;
	}
	get isEncrypted() {
		return this.encryption !== x.NONE;
	}
	get audioTrack() {
		if (ks(this.track)) return this.track;
	}
	get videoTrack() {
		if (As(this.track)) return this.track;
	}
	updateInfo(e) {
		this.trackSid = e.sid, this.trackName = e.name, this.source = B.sourceFromProto(e.source), this.mimeType = e.mimeType, this.kind === B.Kind.Video && e.width > 0 && (this.dimensions = {
			width: e.width,
			height: e.height
		}, this.simulcasted = e.simulcast), this.encryption = e.encryption, this.trackInfo = e, this.log.debug("update publication info", Object.assign(Object.assign({}, this.logContext), { info: e }));
	}
};
(function(e) {
	(function(e) {
		e.Desired = "desired", e.Subscribed = "subscribed", e.Unsubscribed = "unsubscribed";
	})(e.SubscriptionStatus ||= {}), (function(e) {
		e.Allowed = "allowed", e.NotAllowed = "not_allowed";
	})(e.PermissionStatus ||= {});
})(Wd ||= {});
var Gd = class extends Wd {
	get isUpstreamPaused() {
		return this.track?.isUpstreamPaused;
	}
	constructor(e, t, n, r) {
		super(e, t.sid, t.name, r), this.track = void 0, this.handleTrackEnded = () => {
			this.emit(L.Ended);
		}, this.handleCpuConstrained = () => {
			this.track && As(this.track) && this.emit(L.CpuConstrained, this.track);
		}, this.updateInfo(t), this.setTrack(n);
	}
	setTrack(e) {
		this.track && (this.track.off(L.Ended, this.handleTrackEnded), this.track.off(L.CpuConstrained, this.handleCpuConstrained)), super.setTrack(e), e && (e.on(L.Ended, this.handleTrackEnded), e.on(L.CpuConstrained, this.handleCpuConstrained));
	}
	get isMuted() {
		return this.track ? this.track.isMuted : super.isMuted;
	}
	get audioTrack() {
		return super.audioTrack;
	}
	get videoTrack() {
		return super.videoTrack;
	}
	get isLocal() {
		return !0;
	}
	mute() {
		return E(this, void 0, void 0, function* () {
			return this.track?.mute();
		});
	}
	unmute() {
		return E(this, void 0, void 0, function* () {
			return this.track?.unmute();
		});
	}
	pauseUpstream() {
		return E(this, void 0, void 0, function* () {
			yield this.track?.pauseUpstream();
		});
	}
	resumeUpstream() {
		return E(this, void 0, void 0, function* () {
			yield this.track?.resumeUpstream();
		});
	}
	getTrackFeatures() {
		if (ks(this.track)) {
			let e = this.track.getSourceTrackSettings(), t = /* @__PURE__ */ new Set();
			return e.autoGainControl && t.add(b.TF_AUTO_GAIN_CONTROL), e.echoCancellation && t.add(b.TF_ECHO_CANCELLATION), e.noiseSuppression && t.add(b.TF_NOISE_SUPPRESSION), e.channelCount && e.channelCount > 1 && t.add(b.TF_STEREO), this.options?.dtx || t.add(b.TF_NO_DTX), this.track.enhancedNoiseCancellation && t.add(b.TF_ENHANCED_NOISE_CANCELLATION), Array.from(t.values());
		} else return [];
	}
};
function Kd(e, t) {
	return E(this, void 0, void 0, function* () {
		e ??= {};
		let n = !1, r = Oo(e), i = r.audioProcessor, a = r.videoProcessor, o = r.optionsWithoutProcessor, s = o.audio, c = o.video;
		if (i && typeof o.audio == "object" && (o.audio.processor = i), a && typeof o.video == "object" && (o.video.processor = a), e.audio && typeof o.audio == "object" && typeof o.audio.deviceId == "string") {
			let e = o.audio.deviceId;
			o.audio.deviceId = { exact: e }, n = !0, s = Object.assign(Object.assign({}, o.audio), { deviceId: { ideal: e } });
		}
		if (o.video && typeof o.video == "object" && typeof o.video.deviceId == "string") {
			let e = o.video.deviceId;
			o.video.deviceId = { exact: e }, n = !0, c = Object.assign(Object.assign({}, o.video), { deviceId: { ideal: e } });
		}
		o.audio === !0 ? o.audio = { deviceId: "default" } : typeof o.audio == "object" && o.audio !== null && (o.audio = Object.assign(Object.assign({}, o.audio), { deviceId: o.audio.deviceId || "default" })), o.video === !0 ? o.video = { deviceId: "default" } : typeof o.video == "object" && !o.video.deviceId && (o.video.deviceId = "default");
		let l = vo(go(o, bl, xl)), u = navigator.mediaDevices.getUserMedia(l);
		o.audio && (Ec.userMediaPromiseMap.set("audioinput", u), u.catch(() => Ec.userMediaPromiseMap.delete("audioinput"))), o.video && (Ec.userMediaPromiseMap.set("videoinput", u), u.catch(() => Ec.userMediaPromiseMap.delete("videoinput")));
		try {
			let e = yield u;
			return yield Promise.all(e.getTracks().map((n) => E(this, void 0, void 0, function* () {
				let r = n.kind === "audio", o, s = r ? l.audio : l.video;
				typeof s != "boolean" && (o = s);
				let c = n.getSettings().deviceId;
				o?.deviceId && bs(o.deviceId) !== c ? o.deviceId = c : o ||= { deviceId: c };
				let u = Nl(n, o, t);
				return u.kind === B.Kind.Video ? u.source = B.Source.Camera : u.kind === B.Kind.Audio && (u.source = B.Source.Microphone), u.mediaStream = e, ks(u) && i ? yield u.setProcessor(i) : As(u) && a && (yield u.setProcessor(a)), u;
			})));
		} catch (r) {
			if (!n) throw r;
			return Kd(Object.assign(Object.assign({}, e), {
				audio: s,
				video: c
			}), t);
		}
	});
}
function qd(e) {
	return E(this, void 0, void 0, function* () {
		return (yield Kd({
			audio: !1,
			video: e ?? !0
		}))[0];
	});
}
function Jd(e) {
	return E(this, void 0, void 0, function* () {
		return (yield Kd({
			audio: e ?? !0,
			video: !1
		}))[0];
	});
}
function Yd(e) {
	return E(this, void 0, void 0, function* () {
		if (e === void 0 && (e = {}), e.resolution === void 0 && !Qo() && (e.resolution = ho.h1080fps30.resolution), navigator.mediaDevices.getDisplayMedia === void 0) throw new Xa("getDisplayMedia not supported");
		let t = Co(e), n = yield navigator.mediaDevices.getDisplayMedia(t), r = n.getVideoTracks();
		if (r.length === 0) throw new Za("no video track found");
		let i = new Zl(r[0], void 0, !1);
		i.source = B.Source.ScreenShare;
		let a = [i];
		if (n.getAudioTracks().length > 0) {
			let e = new Ml(n.getAudioTracks()[0], void 0, !1);
			e.source = B.Source.ScreenShareAudio, a.push(e);
		}
		return a;
	});
}
var Xd;
(function(e) {
	e.Excellent = "excellent", e.Good = "good", e.Poor = "poor", e.Lost = "lost", e.Unknown = "unknown";
})(Xd ||= {});
function Zd(e) {
	switch (e) {
		case $t.EXCELLENT: return Xd.Excellent;
		case $t.GOOD: return Xd.Good;
		case $t.POOR: return Xd.Poor;
		case $t.LOST: return Xd.Lost;
		default: return Xd.Unknown;
	}
}
var Qd = class extends Oi.EventEmitter {
	get logContext() {
		var e;
		return Object.assign({}, ((e = this.loggerOptions)?.loggerContextCb)?.call(e));
	}
	get isEncrypted() {
		return this.trackPublications.size > 0 && Array.from(this.trackPublications.values()).every((e) => e.isEncrypted);
	}
	get isAgent() {
		return this.permissions?.agent || this.kind === dn.AGENT;
	}
	get isActive() {
		return this.participantInfo?.state === un.ACTIVE;
	}
	get kind() {
		return this._kind;
	}
	get attributes() {
		return Object.freeze(Object.assign({}, this._attributes));
	}
	constructor(e, t, n, r, i, a) {
		let o = arguments.length > 6 && arguments[6] !== void 0 ? arguments[6] : dn.STANDARD;
		super(), this.audioLevel = 0, this.isSpeaking = !1, this._connectionQuality = Xd.Unknown, this.log = w, this.loggerOptions = a, this.log = T(a?.loggerName ?? C.Participant, () => this.logContext), this.setMaxListeners(100), this.sid = e, this.identity = t, this.name = n, this.metadata = r, this.audioTrackPublications = /* @__PURE__ */ new Map(), this.videoTrackPublications = /* @__PURE__ */ new Map(), this.trackPublications = /* @__PURE__ */ new Map(), this._kind = o, this._attributes = i ?? {};
	}
	getTrackPublications() {
		return Array.from(this.trackPublications.values());
	}
	getTrackPublication(e) {
		for (let t of this.trackPublications) {
			let n = g(t, 2)[1];
			if (n.source === e) return n;
		}
	}
	getTrackPublicationByName(e) {
		for (let t of this.trackPublications) {
			let n = g(t, 2)[1];
			if (n.trackName === e) return n;
		}
	}
	waitUntilActive() {
		return this.isActive ? Promise.resolve() : this.activeFuture ? this.activeFuture.promise : (this.activeFuture = new U(), this.once(F.Active, () => {
			var e, t;
			(t = (e = this.activeFuture)?.resolve) == null || t.call(e), this.activeFuture = void 0;
		}), this.activeFuture.promise);
	}
	get connectionQuality() {
		return this._connectionQuality;
	}
	get isCameraEnabled() {
		return !(this.getTrackPublication(B.Source.Camera)?.isMuted ?? !0);
	}
	get isMicrophoneEnabled() {
		return !(this.getTrackPublication(B.Source.Microphone)?.isMuted ?? !0);
	}
	get isScreenShareEnabled() {
		return !!this.getTrackPublication(B.Source.ScreenShare);
	}
	get isLocal() {
		return !1;
	}
	get joinedAt() {
		return this.participantInfo ? /* @__PURE__ */ new Date(Number.parseInt(this.participantInfo.joinedAt.toString()) * 1e3) : /* @__PURE__ */ new Date();
	}
	updateInfo(e) {
		return this.participantInfo && this.participantInfo.sid === e.sid && this.participantInfo.version > e.version ? !1 : (this.identity = e.identity, this.sid = e.sid, this._setName(e.name), this._setMetadata(e.metadata), this._setAttributes(e.attributes), e.state === un.ACTIVE && this.participantInfo?.state !== un.ACTIVE && this.emit(F.Active), e.permission && this.setPermissions(e.permission), this.participantInfo = e, !0);
	}
	_setMetadata(e) {
		let t = this.metadata !== e, n = this.metadata;
		this.metadata = e, t && this.emit(F.ParticipantMetadataChanged, n);
	}
	_setName(e) {
		let t = this.name !== e;
		this.name = e, t && this.emit(F.ParticipantNameChanged, e);
	}
	_setAttributes(e) {
		let t = Do(this.attributes, e);
		this._attributes = e, Object.keys(t).length > 0 && this.emit(F.AttributesChanged, t);
	}
	setPermissions(e) {
		let t = this.permissions, n = e.canPublish !== this.permissions?.canPublish || e.canSubscribe !== this.permissions?.canSubscribe || e.canPublishData !== this.permissions?.canPublishData || e.hidden !== this.permissions?.hidden || e.recorder !== this.permissions?.recorder || e.canPublishSources.length !== this.permissions.canPublishSources.length || e.canPublishSources.some((e, t) => e !== this.permissions?.canPublishSources[t]) || e.canSubscribeMetrics !== this.permissions?.canSubscribeMetrics;
		return this.permissions = e, n && this.emit(F.ParticipantPermissionsChanged, t), n;
	}
	setIsSpeaking(e) {
		e !== this.isSpeaking && (this.isSpeaking = e, e && (this.lastSpokeAt = /* @__PURE__ */ new Date()), this.emit(F.IsSpeakingChanged, e));
	}
	setConnectionQuality(e) {
		let t = this._connectionQuality;
		this._connectionQuality = Zd(e), t !== this._connectionQuality && this.emit(F.ConnectionQualityChanged, this._connectionQuality);
	}
	setDisconnected() {
		var e, t;
		this.activeFuture &&= ((t = (e = this.activeFuture).reject) == null || t.call(e, /* @__PURE__ */ Error("Participant disconnected")), void 0);
	}
	setAudioContext(e) {
		this.audioContext = e, this.audioTrackPublications.forEach((t) => ks(t.track) && t.track.setAudioContext(e));
	}
	addTrackPublication(e) {
		e.on(L.Muted, () => {
			this.emit(F.TrackMuted, e);
		}), e.on(L.Unmuted, () => {
			this.emit(F.TrackUnmuted, e);
		});
		let t = e;
		switch (t.track && (t.track.sid = e.trackSid), this.trackPublications.set(e.trackSid, e), e.kind) {
			case B.Kind.Audio:
				this.audioTrackPublications.set(e.trackSid, e);
				break;
			case B.Kind.Video:
				this.videoTrackPublications.set(e.trackSid, e);
				break;
		}
	}
};
function $d(e) {
	if (!e.participantSid && !e.participantIdentity) throw Error("Invalid track permission, must provide at least one of participantIdentity and participantSid");
	return new Rr({
		participantIdentity: e.participantIdentity ?? "",
		participantSid: e.participantSid ?? "",
		allTracks: e.allowAll ?? !1,
		trackSids: e.allowedTrackSids || []
	});
}
var ef = class extends Qd {
	constructor(e, t, n, r, a, o, s, c) {
		super(e, t, void 0, void 0, void 0, {
			loggerName: r.loggerName,
			loggerContextCb: () => this.engine.logContext
		}), this.pendingPublishing = /* @__PURE__ */ new Set(), this.pendingPublishPromises = /* @__PURE__ */ new Map(), this.participantTrackPermissions = [], this.allParticipantsAllowedToSubscribe = !0, this.encryptionType = x.NONE, this.e2eeStateMutex = new i(), this.enabledPublishVideoCodecs = [], this.handleReconnecting = () => {
			this.reconnectFuture ||= new U();
		}, this.handleReconnected = () => {
			var e, t;
			(t = (e = this.reconnectFuture)?.resolve) == null || t.call(e), this.reconnectFuture = void 0, this.updateTrackSubscriptionPermissions();
		}, this.handleClosing = () => {
			var e, t, n, r, i, a;
			this.reconnectFuture &&= (this.reconnectFuture.promise.catch((e) => this.log.warn(e.message)), (t = (e = this.reconnectFuture)?.reject) == null || t.call(e, /* @__PURE__ */ Error("Got disconnected during reconnection attempt")), void 0), this.signalConnectedFuture &&= ((r = (n = this.signalConnectedFuture).reject) == null || r.call(n, /* @__PURE__ */ Error("Got disconnected without signal connected")), void 0), (a = (i = this.activeAgentFuture)?.reject) == null || a.call(i, /* @__PURE__ */ Error("Got disconnected without active agent present")), this.activeAgentFuture = void 0, this.firstActiveAgent = void 0;
		}, this.handleSignalConnected = (e) => {
			var t, n;
			e.participant && this.updateInfo(e.participant), this.signalConnectedFuture ||= new U(), (n = (t = this.signalConnectedFuture).resolve) == null || n.call(t);
		}, this.handleSignalRequestResponse = (e) => {
			let t = e.requestId, n = e.reason, r = e.message, i = this.pendingSignalRequests.get(t);
			switch (i && (n !== Qr.OK && i.reject(new to(r, n)), this.pendingSignalRequests.delete(t)), e.request.case) {
				case "publishDataTrack": {
					let t;
					switch (e.reason) {
						case Qr.NOT_ALLOWED:
							t = Cd.notAllowed(e.message);
							break;
						case Qr.DUPLICATE_NAME:
							t = Cd.duplicateName(e.message);
							break;
						case Qr.INVALID_NAME:
							t = Cd.invalidName(e.message);
							break;
						case Qr.LIMIT_EXCEEDED:
							t = Cd.limitReached(e.message);
							break;
						default:
							t = Cd.unknown(e.reason, e.message);
							break;
					}
					this.roomOutgoingDataTrackManager.receivedSfuPublishResponse(e.request.value.pubHandle, {
						type: "error",
						error: t
					});
					break;
				}
			}
		}, this.updateTrackSubscriptionPermissions = () => {
			this.log.debug("updating track subscription permissions", {
				allParticipantsAllowed: this.allParticipantsAllowedToSubscribe,
				participantTrackPermissions: this.participantTrackPermissions
			}), this.engine.client.sendUpdateSubscriptionPermissions(this.allParticipantsAllowedToSubscribe, this.participantTrackPermissions.map((e) => $d(e)));
		}, this.onTrackUnmuted = (e) => {
			this.onTrackMuted(e, e.isUpstreamPaused);
		}, this.onTrackMuted = (e, t) => {
			if (t === void 0 && (t = !0), !e.sid) {
				this.log.error("could not update mute status for unpublished track", z(e));
				return;
			}
			this.engine.updateMuteStatus(e.sid, t);
		}, this.onTrackUpstreamPaused = (e) => {
			this.log.debug("upstream paused", z(e)), this.onTrackMuted(e, !0);
		}, this.onTrackUpstreamResumed = (e) => {
			this.log.debug("upstream resumed", z(e)), this.onTrackMuted(e, e.isMuted);
		}, this.onTrackFeatureUpdate = (e) => {
			let t = this.audioTrackPublications.get(e.sid);
			if (!t) {
				this.log.warn(`Could not update local audio track settings, missing publication for track ${e.sid}`);
				return;
			}
			this.engine.client.sendUpdateLocalAudioTrack(t.trackSid, t.getTrackFeatures());
		}, this.onTrackCpuConstrained = (e, t) => {
			this.log.debug("track cpu constrained", z(t)), this.emit(F.LocalTrackCpuConstrained, e, t);
		}, this.handleSubscribedQualityUpdate = (e) => E(this, void 0, void 0, function* () {
			var t, n, r, i;
			if (!this.roomOptions?.dynacast) return;
			let a = this.videoTrackPublications.get(e.trackSid);
			if (!a) {
				this.log.warn("received subscribed quality update for unknown track", { trackSid: e.trackSid });
				return;
			}
			if (!a.videoTrack) return;
			let o = yield a.videoTrack.setPublishingCodecs(e.subscribedCodecs);
			try {
				for (var s = !0, c = wi(o), l; l = yield c.next(), t = l.done, !t; s = !0) {
					i = l.value, s = !1;
					let e = i;
					lo(e) && (this.log.debug(`publish ${e} for ${a.videoTrack.sid}`, z(a)), yield this.publishAdditionalCodecForTrack(a.videoTrack, e, a.options));
				}
			} catch (e) {
				n = { error: e };
			} finally {
				try {
					!s && !t && (r = c.return) && (yield r.call(c));
				} finally {
					if (n) throw n.error;
				}
			}
		}), this.handleLocalTrackUnpublished = (e) => {
			let t = this.trackPublications.get(e.trackSid);
			if (!t) {
				this.log.warn("received unpublished event for unknown track", { trackSid: e.trackSid });
				return;
			}
			this.unpublishTrack(t.track);
		}, this.handleTrackEnded = (e) => E(this, void 0, void 0, function* () {
			if (e.source === B.Source.ScreenShare || e.source === B.Source.ScreenShareAudio) this.log.debug("unpublishing local track due to TrackEnded", z(e)), this.unpublishTrack(e);
			else if (e.isUserProvided) yield e.mute();
			else if (Ms(e) || js(e)) try {
				if (H()) try {
					let t = yield navigator == null ? void 0 : navigator.permissions.query({ name: e.source === B.Source.Camera ? "camera" : "microphone" });
					if (t && t.state === "denied") throw this.log.warn(`user has revoked access to ${e.source}`, z(e)), t.onchange = () => {
						t.state !== "denied" && (e.isMuted || e.restartTrack(), t.onchange = null);
					}, Error("GetUserMedia Permission denied");
				} catch {}
				e.isMuted || (this.log.debug("track ended, attempting to use a different device", z(e)), Ms(e) ? yield e.restartTrack({ deviceId: "default" }) : yield e.restartTrack());
			} catch {
				this.log.warn("could not restart track, muting instead", z(e)), yield e.mute();
			}
		}), this.audioTrackPublications = /* @__PURE__ */ new Map(), this.videoTrackPublications = /* @__PURE__ */ new Map(), this.trackPublications = /* @__PURE__ */ new Map(), this.engine = n, this.roomOptions = r, this.setupEngine(n), this.activeDeviceMap = new Map([
			["audioinput", "default"],
			["videoinput", "default"],
			["audiooutput", "default"]
		]), this.pendingSignalRequests = /* @__PURE__ */ new Map(), this.roomOutgoingDataStreamManager = a, this.roomOutgoingDataTrackManager = o, this.rpcClientManager = s, this.rpcServerManager = c;
	}
	get lastCameraError() {
		return this.cameraError;
	}
	get lastMicrophoneError() {
		return this.microphoneError;
	}
	get isE2EEEnabled() {
		return this.encryptionType !== x.NONE;
	}
	getTrackPublication(e) {
		let t = super.getTrackPublication(e);
		if (t) return t;
	}
	getTrackPublicationByName(e) {
		let t = super.getTrackPublicationByName(e);
		if (t) return t;
	}
	setupEngine(e) {
		this.engine = e, this.engine.on(I.RemoteMute, (e, t) => {
			let n = this.trackPublications.get(e);
			!n || !n.track || (t ? n.mute() : n.unmute());
		}), this.signalConnectedFuture?.isResolved && (this.signalConnectedFuture = void 0), this.engine.on(I.Connected, this.handleReconnected).on(I.SignalConnected, this.handleSignalConnected).on(I.SignalRestarted, this.handleReconnected).on(I.SignalResumed, this.handleReconnected).on(I.Restarting, this.handleReconnecting).on(I.Resuming, this.handleReconnecting).on(I.LocalTrackUnpublished, this.handleLocalTrackUnpublished).on(I.SubscribedQualityUpdate, this.handleSubscribedQualityUpdate).on(I.Closing, this.handleClosing).on(I.SignalRequestResponse, this.handleSignalRequestResponse);
	}
	setMetadata(e) {
		return E(this, void 0, void 0, function* () {
			yield this.requestMetadataUpdate({ metadata: e });
		});
	}
	setName(e) {
		return E(this, void 0, void 0, function* () {
			yield this.requestMetadataUpdate({ name: e });
		});
	}
	setAttributes(e) {
		return E(this, void 0, void 0, function* () {
			yield this.requestMetadataUpdate({ attributes: e });
		});
	}
	requestMetadataUpdate(e) {
		return E(this, arguments, void 0, function(e) {
			var t = this;
			let n = e.metadata, r = e.name, i = e.attributes;
			return function* () {
				return new D((e, a) => E(t, void 0, void 0, function* () {
					try {
						let t = !1, o = yield this.engine.client.sendUpdateLocalMetadata(n ?? this.metadata ?? "", r ?? this.name ?? "", i), s = performance.now();
						for (this.pendingSignalRequests.set(o, {
							resolve: e,
							reject: (e) => {
								a(e), t = !0;
							},
							values: {
								name: r,
								metadata: n,
								attributes: i
							}
						}); performance.now() - s < 5e3 && !t;) {
							if ((!r || this.name === r) && (!n || this.metadata === n) && (!i || Object.entries(i).every((e) => {
								let t = g(e, 2), n = t[0], r = t[1];
								return this.attributes[n] === r || r === "" && !this.attributes[n];
							}))) {
								this.pendingSignalRequests.delete(o), e();
								return;
							}
							yield V(50);
						}
						a(new to("Request to update local metadata timed out", "TimeoutError"));
					} catch (e) {
						e instanceof Error ? a(e) : a(Error(String(e)));
					}
				}));
			}();
		});
	}
	setCameraEnabled(e, t, n) {
		return this.setTrackEnabled(B.Source.Camera, e, t, n);
	}
	setMicrophoneEnabled(e, t, n) {
		return this.setTrackEnabled(B.Source.Microphone, e, t, n);
	}
	setScreenShareEnabled(e, t, n) {
		return this.setTrackEnabled(B.Source.ScreenShare, e, t, n);
	}
	setE2EEEnabled(e) {
		return E(this, void 0, void 0, function* () {
			let t = yield this.e2eeStateMutex.lock();
			try {
				if (this.encryptionType = e ? x.GCM : x.NONE, yield Promise.all(this.pendingPublishPromises.values()), this.trackPublications.size === 0 || Array.from(this.trackPublications.values()).every((t) => t.isEncrypted === e)) return;
				yield this.republishAllTracks(void 0, !1);
			} finally {
				t();
			}
		});
	}
	setTrackEnabled(e, t, n, r) {
		return E(this, void 0, void 0, function* () {
			this.log.debug("setTrackEnabled", {
				source: e,
				enabled: t
			}), this.republishPromise && (yield this.republishPromise);
			let i = this.getTrackPublication(e);
			if (t) if (i) yield i.unmute();
			else {
				let t;
				if (this.pendingPublishing.has(e)) {
					let t = yield this.waitForPendingPublicationOfSource(e);
					return t || this.log.info("waiting for pending publication promise timed out", { source: e }), yield t?.unmute(), t;
				}
				this.pendingPublishing.add(e);
				try {
					switch (e) {
						case B.Source.Camera:
							t = yield this.createTracks({ video: n ?? !0 });
							break;
						case B.Source.Microphone:
							t = yield this.createTracks({ audio: n ?? !0 });
							break;
						case B.Source.ScreenShare:
							t = yield this.createScreenTracks(Object.assign({}, n));
							break;
						default: throw new Za(e);
					}
				} catch (n) {
					throw t?.forEach((e) => {
						e.stop();
					}), n instanceof Error && this.emit(F.MediaDevicesError, n, So(e)), this.pendingPublishing.delete(e), n;
				}
				for (let r of t) {
					let t = Object.assign(Object.assign({}, this.roomOptions.publishDefaults), n);
					e === B.Source.Microphone && ks(r) && t.preConnectBuffer && (this.log.info("starting preconnect buffer for microphone"), r.startPreConnectBuffer());
				}
				try {
					let e = [];
					for (let n of t) this.log.info("publishing track", z(n)), e.push(this.publishTrack(n, r));
					i = g(yield Promise.all(e), 1)[0];
				} catch (e) {
					throw t?.forEach((e) => {
						e.stop();
					}), e;
				} finally {
					this.pendingPublishing.delete(e);
				}
			}
			else if (!i?.track && this.pendingPublishing.has(e) && (i = yield this.waitForPendingPublicationOfSource(e), i || this.log.info("waiting for pending publication promise timed out", { source: e })), i && i.track) if (e === B.Source.ScreenShare) {
				let e = [this.unpublishTrack(i.track)], t = this.getTrackPublication(B.Source.ScreenShareAudio);
				t && t.track && e.push(this.unpublishTrack(t.track)), i = g(yield Promise.all(e), 1)[0];
			} else yield i.mute();
			return i;
		});
	}
	enableCameraAndMicrophone() {
		return E(this, void 0, void 0, function* () {
			if (!(this.pendingPublishing.has(B.Source.Camera) || this.pendingPublishing.has(B.Source.Microphone))) {
				this.pendingPublishing.add(B.Source.Camera), this.pendingPublishing.add(B.Source.Microphone);
				try {
					let e = yield this.createTracks({
						audio: !0,
						video: !0
					});
					yield Promise.all(e.map((e) => this.publishTrack(e)));
				} finally {
					this.pendingPublishing.delete(B.Source.Camera), this.pendingPublishing.delete(B.Source.Microphone);
				}
			}
		});
	}
	createTracks(e) {
		return E(this, void 0, void 0, function* () {
			e ??= {};
			let t = go(e, this.roomOptions?.audioCaptureDefaults, this.roomOptions?.videoCaptureDefaults);
			try {
				return (yield Kd(t, {
					loggerName: this.roomOptions.loggerName,
					loggerContextCb: () => this.logContext
				})).map((e) => (ks(e) && (this.microphoneError = void 0, e.setAudioContext(this.audioContext), e.source = B.Source.Microphone, this.emit(F.AudioStreamAcquired)), As(e) && (this.cameraError = void 0, e.source = B.Source.Camera), e));
			} catch (t) {
				throw t instanceof Error && (e.audio && (this.microphoneError = t), e.video && (this.cameraError = t)), t;
			}
		});
	}
	createScreenTracks(e) {
		return E(this, void 0, void 0, function* () {
			if (e === void 0 && (e = {}), navigator.mediaDevices.getDisplayMedia === void 0) throw new Xa("getDisplayMedia not supported");
			e.resolution === void 0 && !Qo() && (e.resolution = ho.h1080fps30.resolution);
			let t = Co(e), n = yield navigator.mediaDevices.getDisplayMedia(t), r = n.getVideoTracks();
			if (r.length === 0) throw new Za("no video track found");
			let i = new Zl(r[0], void 0, !1, {
				loggerName: this.roomOptions.loggerName,
				loggerContextCb: () => this.logContext
			});
			i.source = B.Source.ScreenShare, e.contentHint && (i.mediaStreamTrack.contentHint = e.contentHint);
			let a = [i];
			if (n.getAudioTracks().length > 0) {
				this.emit(F.AudioStreamAcquired);
				let e = new Ml(n.getAudioTracks()[0], void 0, !1, this.audioContext, {
					loggerName: this.roomOptions.loggerName,
					loggerContextCb: () => this.logContext
				});
				e.source = B.Source.ScreenShareAudio, a.push(e);
			}
			return a;
		});
	}
	publishTrack(e, t) {
		return E(this, void 0, void 0, function* () {
			return this.publishOrRepublishTrack(e, t);
		});
	}
	waitForNextEngineRestart() {
		let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : 15e3;
		return new Promise((t, n) => {
			let r = () => {
				clearTimeout(o), this.engine.off(I.Restarted, i), this.engine.off(I.Closing, a);
			}, i = () => {
				r(), t();
			}, a = () => {
				r(), n(/* @__PURE__ */ Error("engine closed before restart completed"));
			}, o = setTimeout(() => {
				r(), n(/* @__PURE__ */ Error("timed out waiting for engine restart"));
			}, e);
			this.engine.once(I.Restarted, i), this.engine.once(I.Closing, a);
		});
	}
	publishOrRepublishTrack(e, t) {
		return E(this, arguments, void 0, function(e, t) {
			var n = this;
			let r = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : !1, i = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : !1;
			return function* () {
				Ms(e) && e.setAudioContext(n.audioContext), yield n.reconnectFuture?.promise, n.republishPromise && !r && (yield n.republishPromise), Os(e) && n.pendingPublishPromises.has(e) && (yield n.pendingPublishPromises.get(e));
				let a;
				if (e instanceof MediaStreamTrack) a = e.getConstraints();
				else {
					a = e.constraints;
					let t;
					switch (e.source) {
						case B.Source.Microphone:
							t = "audioinput";
							break;
						case B.Source.Camera: t = "videoinput";
					}
					t && n.activeDeviceMap.has(t) && (a = Object.assign(Object.assign({}, a), { deviceId: n.activeDeviceMap.get(t) }));
				}
				if (e instanceof MediaStreamTrack) switch (e.kind) {
					case "audio":
						e = new Ml(e, a, !0, n.audioContext, {
							loggerName: n.roomOptions.loggerName,
							loggerContextCb: () => n.logContext
						});
						break;
					case "video":
						e = new Zl(e, a, !0, {
							loggerName: n.roomOptions.loggerName,
							loggerContextCb: () => n.logContext
						});
						break;
					default: throw new Za(`unsupported MediaStreamTrack kind ${e.kind}`);
				}
				else e.updateLoggerOptions({
					loggerName: n.roomOptions.loggerName,
					loggerContextCb: () => n.logContext
				});
				let o;
				if (n.trackPublications.forEach((t) => {
					t.track && t.track === e && (o = t);
				}), o) return n.log.warn("track has already been published, skipping", z(o)), o;
				let s = Object.assign(Object.assign({}, n.roomOptions.publishDefaults), t), c = "channelCount" in e.mediaStreamTrack.getSettings() && e.mediaStreamTrack.getSettings().channelCount === 2 || e.mediaStreamTrack.getConstraints().channelCount === 2, l = s.forceStereo ?? c;
				l && (s.dtx === void 0 && n.log.debug("Opus DTX will be disabled for stereo tracks by default. Enable them explicitly to make it work.", z(e)), s.red === void 0 && n.log.debug("Opus RED will be disabled for stereo tracks by default. Enable them explicitly to make it work."), s.dtx ??= !1, s.red ??= !1), !ts() && n.roomOptions.e2ee && (n.log.info("End-to-end encryption is set up, simulcast publishing will be disabled on Safari versions and iOS browsers running iOS < v17.2"), s.simulcast = !1), s.source && (e.source = s.source);
				let u = new Promise((t, r) => E(n, void 0, void 0, function* () {
					try {
						if (this.engine.client.currentState !== W.CONNECTED) {
							this.log.debug("deferring track publication until signal is connected", { track: z(e) });
							let n = !1, i = setTimeout(() => {
								n = !0, e.stop(), r(new eo("publishing rejected as engine not connected within timeout", 408));
							}, 15e3);
							if (yield this.waitUntilEngineConnected(), clearTimeout(i), n) return;
							t(yield this.publish(e, s, l));
						} else try {
							t(yield this.publish(e, s, l));
						} catch (e) {
							r(e);
						}
					} catch (e) {
						r(e);
					}
				}));
				n.pendingPublishPromises.set(e, u);
				try {
					return yield u;
				} catch (a) {
					if (!i && a instanceof $a) return n.log.warn("negotiation due to track publish failed, retrying after reconnect", { error: a }), n.pendingPublishPromises.delete(e), yield n.waitForNextEngineRestart(), yield n.publishOrRepublishTrack(e, t, r, !0);
					throw a;
				} finally {
					n.pendingPublishPromises.delete(e);
				}
			}();
		});
	}
	waitUntilEngineConnected() {
		return this.signalConnectedFuture ||= new U(), this.signalConnectedFuture.promise;
	}
	hasPermissionsToPublish(e) {
		if (!this.permissions) return this.log.warn("no permissions present for publishing track", z(e)), !1;
		let t = this.permissions, n = t.canPublish, r = t.canPublishSources;
		return n && (r.length === 0 || r.map((e) => ko(e)).includes(e.source)) ? !0 : (this.log.warn("insufficient permissions to publish", z(e)), !1);
	}
	publish(e, t, n) {
		return E(this, void 0, void 0, function* () {
			if (!this.hasPermissionsToPublish(e)) throw new eo("failed to publish track, insufficient permissions", 403);
			Array.from(this.trackPublications.values()).find((t) => Os(e) && t.source === e.source) && e.source !== B.Source.Unknown && this.log.info(`publishing a second track with the same source: ${e.source}`, z(e)), t.stopMicTrackOnMute && ks(e) && (e.stopOnMute = !0), e.source === B.Source.ScreenShare && qo() && (t.simulcast = !1), t.videoCodec === "av1" && !Ho() && (t.videoCodec = void 0), t.videoCodec === "vp9" && !Uo() && (t.videoCodec = void 0), t.videoCodec === void 0 && (t.videoCodec = vl), this.enabledPublishVideoCodecs.length > 0 && (this.enabledPublishVideoCodecs.some((e) => t.videoCodec === wo(e.mime)) || (t.videoCodec = wo(this.enabledPublishVideoCodecs[0].mime)));
			let r = t.videoCodec;
			e.on(L.Muted, this.onTrackMuted), e.on(L.Unmuted, this.onTrackUnmuted), e.on(L.Ended, this.handleTrackEnded), e.on(L.UpstreamPaused, this.onTrackUpstreamPaused), e.on(L.UpstreamResumed, this.onTrackUpstreamResumed), e.on(L.AudioTrackFeatureUpdate, this.onTrackFeatureUpdate);
			let i = [], a = !(t.dtx ?? !0), o = e.getSourceTrackSettings();
			o.autoGainControl && i.push(b.TF_AUTO_GAIN_CONTROL), o.echoCancellation && i.push(b.TF_ECHO_CANCELLATION), o.noiseSuppression && i.push(b.TF_NOISE_SUPPRESSION), o.channelCount && o.channelCount > 1 && i.push(b.TF_STEREO), a && i.push(b.TF_NO_DTX), Ms(e) && e.hasPreConnectBuffer && i.push(b.TF_PRECONNECT_BUFFER);
			let s = this.normalizeRequestedPacketTrailerOptions(e, t), c = new nr({
				cid: e.mediaStreamTrack.id,
				name: t.name,
				type: B.kindToProto(e.kind),
				muted: e.isMuted,
				source: B.sourceToProto(e.source),
				disableDtx: a,
				encryption: this.encryptionType,
				stereo: n,
				disableRed: this.isE2EEEnabled || !(t.red ?? !0),
				stream: t?.stream,
				backupCodecPolicy: t?.backupCodecPolicy,
				audioFeatures: i,
				packetTrailerFeatures: s
			}), l;
			if (e.kind === B.Kind.Video) {
				let n;
				try {
					n = yield e.waitForDimensions();
				} catch {
					let t = this.roomOptions.videoCaptureDefaults?.resolution ?? po.h720.resolution;
					n = {
						width: t.width,
						height: t.height
					}, this.log.error("could not determine track dimensions, using defaults", Object.assign(Object.assign({}, z(e)), { dims: n }));
				}
				c.width = n.width, c.height = n.height, js(e) && (Wo(r) && (e.source === B.Source.ScreenShare && (t.scalabilityMode = "L1T3", "contentHint" in e.mediaStreamTrack && (e.mediaStreamTrack.contentHint = "motion", this.log.debug("forcing contentHint to motion for screenshare with SVC codecs", z(e)))), t.scalabilityMode = t.scalabilityMode ?? "L3T3_KEY"), c.simulcastCodecs = [new tr({
					codec: r,
					cid: e.mediaStreamTrack.id
				})], t.backupCodec === !0 && (t.backupCodec = { codec: vl }), t.backupCodec && r !== t.backupCodec.codec && c.encryption === x.NONE && (this.roomOptions.dynacast || (this.roomOptions.dynacast = !0), c.simulcastCodecs.push(new tr({
					codec: t.backupCodec.codec,
					cid: ""
				})))), l = Vl(e.source === B.Source.ScreenShare, c.width, c.height, t), c.layers = eu(c.width, c.height, l, Wo(t.videoCodec));
			} else e.kind === B.Kind.Audio && (l = [{
				maxBitrate: t.audioPreset?.maxBitrate,
				priority: t.audioPreset?.priority ?? "high",
				networkPriority: t.audioPreset?.priority ?? "high"
			}]);
			if (!this.engine || this.engine.isClosed) throw new j("cannot publish track when not connected");
			let u = () => E(this, void 0, void 0, function* () {
				if (!this.engine.pcManager) throw new j("pcManager is not ready");
				if (e.sender = yield this.engine.createSender(e, t, l), js(e) && (e.publishOptions = t), this.emit(F.LocalSenderCreated, e.sender, e), js(e) && (t.degradationPreference ??= Yl(e), e.setDegradationPreference(t.degradationPreference)), l) if (qo() && e.kind === B.Kind.Audio) {
					let t;
					for (let n of this.engine.pcManager.publisher.getTransceivers()) if (n.sender === e.sender) {
						t = n;
						break;
					}
					t && this.engine.pcManager.publisher.setTrackCodecBitrate({
						transceiver: t,
						codec: "opus",
						maxbr: l[0]?.maxBitrate ? l[0].maxBitrate / 1e3 : 0
					});
				} else e.codec && Wo(e.codec) && l[0]?.maxBitrate && this.engine.pcManager.publisher.setTrackCodecBitrate({
					cid: c.cid,
					codec: e.codec,
					maxbr: l[0].maxBitrate / 1e3
				});
				yield this.engine.negotiate();
			}), d, f = new Promise((t, n) => E(this, void 0, void 0, function* () {
				try {
					d = yield this.engine.addTrack(c), t(d);
				} catch (t) {
					if (e.sender && this.engine.pcManager?.publisher) {
						try {
							this.engine.pcManager.publisher.removeTrack(e.sender);
						} catch (e) {
							this.log.error(e);
						}
						yield this.engine.negotiate().catch((t) => {
							this.log.error("failed to negotiate after removing track due to failed add track request", Object.assign(Object.assign({}, z(e)), { error: t }));
						});
					}
					n(t);
				}
			}));
			if (this.enabledPublishVideoCodecs.length > 0 && s.length === 0) d = (yield Promise.all([f, u()]))[0];
			else {
				d = yield f;
				let n;
				if (d.codecs.forEach((e) => {
					n === void 0 && (n = e.mimeType);
				}), n && e.kind === B.Kind.Video) {
					let i = wo(n);
					i !== r && (this.log.debug("falling back to server selected codec", Object.assign(Object.assign({}, z(e)), { codec: i })), t.videoCodec = i, l = Vl(e.source === B.Source.ScreenShare, c.width, c.height, t));
				}
				yield u();
			}
			let ee = new Gd(e.kind, d, e, {
				loggerName: this.roomOptions.loggerName,
				loggerContextCb: () => this.logContext
			});
			if (ee.on(L.CpuConstrained, (e) => this.onTrackCpuConstrained(e, ee)), ee.options = t, e.sid = d.sid, js(e) && (e.publishOptions = t, c.width && c.height && (e.lastEncodedDimensions = {
				width: c.width,
				height: c.height
			})), this.log.debug(`publishing ${e.kind} with encodings`, {
				encodings: l,
				trackInfo: d
			}), js(e) ? e.startMonitor(this.engine.client) : Ms(e) && e.startMonitor(), this.addTrackPublication(ee), this.emit(F.LocalTrackPublished, ee), Ms(e) && d.audioFeatures.includes(b.TF_PRECONNECT_BUFFER)) {
				let t = e.getPreConnectBuffer(), n = e.getPreConnectBufferMimeType();
				this.on(F.LocalTrackSubscribed, (t) => {
					if (t.trackSid === d.sid) {
						if (!e.hasPreConnectBuffer) {
							this.log.warn("subscribe event came to late, buffer already closed");
							return;
						}
						this.log.debug("finished recording preconnect buffer", z(e)), e.stopPreConnectBuffer();
					}
				}), t && new Promise((r, i) => E(this, void 0, void 0, function* () {
					var a, s, c, l;
					try {
						this.log.debug("waiting for agent", z(e));
						let te = setTimeout(() => {
							i(/* @__PURE__ */ Error("agent not active within 10 seconds"));
						}, 1e4), ne = yield this.waitUntilActiveAgentPresent();
						clearTimeout(te), this.log.debug("sending preconnect buffer", z(e));
						let re = yield this.streamBytes({
							name: "preconnect-buffer",
							mimeType: n,
							topic: "lk.agent.pre-connect-audio-buffer",
							destinationIdentities: [ne.identity],
							attributes: {
								trackId: ee.trackSid,
								sampleRate: String(o.sampleRate ?? "48000"),
								channels: String(o.channelCount ?? "1")
							}
						});
						try {
							for (var u = !0, d = wi(t), f; f = yield d.next(), a = f.done, !a; u = !0) {
								l = f.value, u = !1;
								let e = l;
								yield re.write(e);
							}
						} catch (e) {
							s = { error: e };
						} finally {
							try {
								!u && !a && (c = d.return) && (yield c.call(d));
							} finally {
								if (s) throw s.error;
							}
						}
						yield re.close(), r();
					} catch (e) {
						i(e);
					}
				})).then(() => {
					this.log.debug("preconnect buffer sent successfully", z(e));
				}).catch((t) => {
					this.log.error("error sending preconnect buffer", Object.assign(Object.assign({}, z(e)), { error: t }));
				});
			}
			return ee;
		});
	}
	canPublishPacketTrailer() {
		return !!(this.roomOptions.e2ee || this.roomOptions.encryption || ac(this.roomOptions.packetTrailer));
	}
	normalizeRequestedPacketTrailerOptions(e, t) {
		if (e.kind !== B.Kind.Video || !oc(t.packetTrailer)) return t.packetTrailer = void 0, [];
		if (!this.canPublishPacketTrailer()) return this.log.warn("packet trailer transform not supported; not advertising features", Object.assign(Object.assign({}, this.logContext), z(e))), t.packetTrailer = void 0, [];
		let n = sc(t.packetTrailer);
		return t.packetTrailer = cc(n), n;
	}
	get isLocal() {
		return !0;
	}
	publishAdditionalCodecForTrack(e, t, n) {
		return E(this, void 0, void 0, function* () {
			if (this.encryptionType !== x.NONE) return;
			let r;
			if (this.trackPublications.forEach((t) => {
				t.track && t.track === e && (r = t);
			}), !r) throw new Za("track is not published");
			if (!js(e)) throw new Za("track is not a video track");
			let i = Object.assign(Object.assign({}, this.roomOptions?.publishDefaults), n), a = Hl(e, t, i);
			if (!a) {
				this.log.info("backup codec has been disabled, ignoring request to add additional codec for track", z(e));
				return;
			}
			let o = e.addSimulcastTrack(t, a);
			if (!o) return;
			let s = this.normalizeRequestedPacketTrailerOptions(e, i), c = new nr({
				cid: o.mediaStreamTrack.id,
				type: B.kindToProto(e.kind),
				muted: e.isMuted,
				source: B.sourceToProto(e.source),
				sid: e.sid,
				packetTrailerFeatures: s,
				simulcastCodecs: [{
					codec: i.videoCodec,
					cid: o.mediaStreamTrack.id
				}]
			});
			if (c.layers = eu(c.width, c.height, a), !this.engine || this.engine.isClosed) throw new j("cannot publish track when not connected");
			let l = (yield Promise.all([this.engine.addTrack(c), E(this, void 0, void 0, function* () {
				yield this.engine.createSimulcastSender(e, o, i, a), yield this.engine.negotiate();
			})]))[0];
			this.log.debug(`published ${t} for track ${e.sid}`, {
				encodings: a,
				trackInfo: l
			});
		});
	}
	unpublishTrack(e, t) {
		return E(this, void 0, void 0, function* () {
			if (Os(e)) {
				let t = this.pendingPublishPromises.get(e);
				t && (this.log.debug("awaiting publish promise before attempting to unpublish", z(e)), yield t);
			}
			let n = this.getPublicationForTrack(e), r = n ? z(n) : void 0;
			if (this.log.info("unpublishing track", r), !n || !n.track) {
				this.log.warn("track was not unpublished because no publication was found", r);
				return;
			}
			e = n.track, e.off(L.Muted, this.onTrackMuted), e.off(L.Unmuted, this.onTrackUnmuted), e.off(L.Ended, this.handleTrackEnded), e.off(L.UpstreamPaused, this.onTrackUpstreamPaused), e.off(L.UpstreamResumed, this.onTrackUpstreamResumed), e.off(L.AudioTrackFeatureUpdate, this.onTrackFeatureUpdate), t === void 0 && (t = this.roomOptions?.stopLocalTrackOnUnpublish ?? !0), t ? e.stop() : e.stopMonitor();
			let i = !1, a = e.sender;
			if (e.sender = void 0, this.engine.pcManager && this.engine.pcManager.currentState < G.FAILED && a) try {
				for (let e of this.engine.pcManager.publisher.getTransceivers()) e.sender === a && (e.direction = "inactive", i = !0);
				try {
					i = this.engine.removeTrack(a);
				} catch (e) {
					this.log.warn(e), i = !0;
				}
				if (js(e)) {
					for (let t of e.simulcastCodecs) {
						let e = g(t, 2)[1];
						if (e.sender) {
							try {
								i = this.engine.removeTrack(e.sender);
							} catch (e) {
								this.log.warn(e), i = !0;
							}
							e.sender = void 0;
						}
					}
					e.simulcastCodecs.clear();
				}
			} catch (e) {
				this.log.warn("failed to unpublish track", Object.assign(Object.assign({}, r), { error: e }));
			}
			switch (this.trackPublications.delete(n.trackSid), n.kind) {
				case B.Kind.Audio:
					this.audioTrackPublications.delete(n.trackSid);
					break;
				case B.Kind.Video:
					this.videoTrackPublications.delete(n.trackSid);
					break;
			}
			return this.emit(F.LocalTrackUnpublished, n), n.setTrack(void 0), i && (yield this.engine.negotiate()), n;
		});
	}
	unpublishTracks(e) {
		return E(this, void 0, void 0, function* () {
			return (yield Promise.all(e.map((e) => this.unpublishTrack(e)))).filter((e) => !!e);
		});
	}
	republishAllTracks(e) {
		return E(this, arguments, void 0, function(e) {
			var t = this;
			let n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !0;
			return function* () {
				t.republishPromise && (yield t.republishPromise), t.republishPromise = new D((r, i) => E(t, void 0, void 0, function* () {
					try {
						let t = [];
						this.trackPublications.forEach((n) => {
							n.track && (e && (n.options = Object.assign(Object.assign({}, n.options), e)), t.push(n));
						}), yield Promise.all(t.map((e) => E(this, void 0, void 0, function* () {
							let t = e.track;
							yield this.unpublishTrack(t, !1), n && !t.isMuted && t.source !== B.Source.ScreenShare && t.source !== B.Source.ScreenShareAudio && (Ms(t) || js(t)) && !t.isUserProvided && (this.log.debug("restarting existing track", { track: e.trackSid }), yield t.restartTrack()), yield this.publishOrRepublishTrack(t, e.options, !0);
						}))), r();
					} catch (e) {
						e instanceof Error ? i(e) : i(Error(String(e)));
					} finally {
						this.republishPromise = void 0;
					}
				})), yield t.republishPromise;
			}();
		});
	}
	publishData(e) {
		return E(this, arguments, void 0, function(e) {
			var t = this;
			let n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
			return function* () {
				let r = n.reliable ? K.RELIABLE : K.LOSSY, i = n.reliable ? yn.RELIABLE : yn.LOSSY, a = n.destinationIdentities, o = n.topic, s = new S({
					kind: i,
					value: {
						case: "user",
						value: new wn({
							participantIdentity: t.identity,
							payload: e,
							destinationIdentities: a,
							topic: o
						})
					}
				});
				yield t.engine.sendDataPacket(s, r);
			}();
		});
	}
	publishDtmf(e, t) {
		return E(this, void 0, void 0, function* () {
			let n = new S({
				kind: yn.RELIABLE,
				value: {
					case: "sipDtmf",
					value: new Tn({
						code: e,
						digit: t
					})
				}
			});
			yield this.engine.sendDataPacket(n, K.RELIABLE);
		});
	}
	sendChatMessage(e, t) {
		return E(this, void 0, void 0, function* () {
			let n = {
				id: crypto.randomUUID(),
				message: e,
				timestamp: Date.now(),
				attachedFiles: t?.attachments
			}, r = new S({ value: {
				case: "chatMessage",
				value: new On(Object.assign(Object.assign({}, n), { timestamp: p.parse(n.timestamp) }))
			} });
			return yield this.engine.sendDataPacket(r, K.RELIABLE), this.emit(F.ChatMessage, n), n;
		});
	}
	editChatMessage(e, t) {
		return E(this, void 0, void 0, function* () {
			let n = Object.assign(Object.assign({}, t), {
				message: e,
				editTimestamp: Date.now()
			}), r = new S({ value: {
				case: "chatMessage",
				value: new On(Object.assign(Object.assign({}, n), {
					timestamp: p.parse(n.timestamp),
					editTimestamp: p.parse(n.editTimestamp)
				}))
			} });
			return yield this.engine.sendDataPacket(r, K.RELIABLE), this.emit(F.ChatMessage, n), n;
		});
	}
	sendText(e, t) {
		return E(this, void 0, void 0, function* () {
			return this.roomOutgoingDataStreamManager.sendText(e, t);
		});
	}
	streamText(e) {
		return E(this, void 0, void 0, function* () {
			return this.roomOutgoingDataStreamManager.streamText(e);
		});
	}
	sendFile(e, t) {
		return E(this, void 0, void 0, function* () {
			return this.roomOutgoingDataStreamManager.sendFile(e, t);
		});
	}
	streamBytes(e) {
		return E(this, void 0, void 0, function* () {
			return this.roomOutgoingDataStreamManager.streamBytes(e);
		});
	}
	performRpc(e) {
		return this.rpcClientManager.performRpc(e).then((e) => {
			let t = g(e, 2);
			return t[0], t[1];
		});
	}
	registerRpcMethod(e, t) {
		this.rpcServerManager.registerRpcMethod(e, t);
	}
	unregisterRpcMethod(e) {
		this.rpcServerManager.unregisterRpcMethod(e);
	}
	setTrackSubscriptionPermissions(e) {
		let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : [];
		this.participantTrackPermissions = t, this.allParticipantsAllowedToSubscribe = e, this.engine.client.isDisconnected || this.updateTrackSubscriptionPermissions();
	}
	setEnabledPublishCodecs(e) {
		this.enabledPublishVideoCodecs = e.filter((e) => e.mime.split("/")[0].toLowerCase() === "video");
	}
	updateInfo(e) {
		return super.updateInfo(e) ? (e.tracks.forEach((e) => {
			let t = this.trackPublications.get(e.sid);
			if (t) {
				let n = t.isMuted || (t.track?.isUpstreamPaused ?? !1);
				n !== e.muted && (this.log.debug("updating server mute state after reconcile", Object.assign(Object.assign({}, z(t)), { mutedOnServer: n })), this.engine.client.sendMuteTrack(e.sid, n));
			}
		}), !0) : !1;
	}
	setActiveAgent(e) {
		var t, n, r, i;
		this.firstActiveAgent = e, e && !this.firstActiveAgent && (this.firstActiveAgent = e), e ? (n = (t = this.activeAgentFuture)?.resolve) == null || n.call(t, e) : (i = (r = this.activeAgentFuture)?.reject) == null || i.call(r, /* @__PURE__ */ Error("Agent disconnected")), this.activeAgentFuture = void 0;
	}
	waitUntilActiveAgentPresent() {
		return this.firstActiveAgent ? Promise.resolve(this.firstActiveAgent) : (this.activeAgentFuture ||= new U(), this.activeAgentFuture.promise);
	}
	getPublicationForTrack(e) {
		let t;
		return this.trackPublications.forEach((n) => {
			let r = n.track;
			r && (e instanceof MediaStreamTrack ? (Ms(r) || js(r)) && r.mediaStreamTrack === e && (t = n) : e === r && (t = n));
		}), t;
	}
	waitForPendingPublicationOfSource(e) {
		return E(this, void 0, void 0, function* () {
			let t = Date.now();
			for (; Date.now() < t + 1e4;) {
				let t = Array.from(this.pendingPublishPromises.entries()).find((t) => g(t, 1)[0].source === e);
				if (t) return t[1];
				yield V(20);
			}
		});
	}
	publishDataTrack(e) {
		return E(this, void 0, void 0, function* () {
			let t = new Od(e, this.roomOutgoingDataTrackManager);
			return yield t.publish(), t;
		});
	}
}, tf = class extends DOMException {
	constructor(e, t) {
		super(e, "AbortError"), this.reason = t;
	}
}, nf = class extends Map {
	constructor() {
		super(...arguments), this.pending = /* @__PURE__ */ new Map();
	}
	set(e, t) {
		var n;
		super.set(e, t);
		let r = this.pending?.get(e);
		if (r) {
			for (let e of r) e.isResolved || (n = e.resolve) == null || n.call(e, t);
			this.pending.delete(e);
		}
		return this;
	}
	get [Symbol.toStringTag]() {
		return "DeferrableMap";
	}
	getDeferred(e, t) {
		return E(this, void 0, void 0, function* () {
			let n = this.get(e);
			if (n !== void 0) return n;
			if (t?.aborted) throw new tf("The operation was aborted.", t.reason);
			let r = new U(void 0, () => {
				let t = this.pending.get(e);
				if (!t) return;
				let n = t.indexOf(r);
				n !== -1 && t.splice(n, 1), t.length === 0 && this.pending.delete(e);
			}), i = this.pending.get(e);
			if (i ? i.push(r) : this.pending.set(e, [r]), t) {
				let e = () => {
					var e;
					r.isResolved || (e = r.reject) == null || e.call(r, new tf("The operation was aborted.", t.reason));
				};
				t.addEventListener("abort", e, { once: !0 }), r.promise.finally(() => {
					t.removeEventListener("abort", e);
				});
			}
			return r.promise;
		});
	}
}, rf = class extends Wd {
	constructor(e, t, n, r) {
		super(e, t.sid, t.name, r), this.track = void 0, this.allowed = !0, this.requestedDisabled = void 0, this.visible = !0, this.handleEnded = (e) => {
			this.setTrack(void 0), this.emit(L.Ended, e);
		}, this.handleVisibilityChange = (e) => {
			this.log.debug(`adaptivestream video visibility ${this.trackSid}, visible=${e}`, this.logContext), this.visible = e, this.emitTrackUpdate();
		}, this.handleVideoDimensionsChange = (e) => {
			this.log.debug(`adaptivestream video dimensions ${e.width}x${e.height}`, this.logContext), this.videoDimensionsAdaptiveStream = e, this.emitTrackUpdate();
		}, this.subscribed = n, this.updateInfo(t);
	}
	setSubscribed(e) {
		let t = this.subscriptionStatus, n = this.permissionStatus;
		this.subscribed = e, e && (this.allowed = !0);
		let r = new _r({
			trackSids: [this.trackSid],
			subscribe: this.subscribed,
			participantTracks: [new Nn({
				participantSid: "",
				trackSids: [this.trackSid]
			})]
		});
		this.emit(L.UpdateSubscription, r), this.emitSubscriptionUpdateIfChanged(t), this.emitPermissionUpdateIfChanged(n);
	}
	get subscriptionStatus() {
		return this.subscribed === !1 ? Wd.SubscriptionStatus.Unsubscribed : super.isSubscribed ? Wd.SubscriptionStatus.Subscribed : Wd.SubscriptionStatus.Desired;
	}
	get permissionStatus() {
		return this.allowed ? Wd.PermissionStatus.Allowed : Wd.PermissionStatus.NotAllowed;
	}
	get isSubscribed() {
		return this.subscribed === !1 ? !1 : super.isSubscribed;
	}
	get isDesired() {
		return this.subscribed !== !1;
	}
	get isEnabled() {
		return this.requestedDisabled === void 0 ? this.isAdaptiveStream ? this.visible : !0 : !this.requestedDisabled;
	}
	get isLocal() {
		return !1;
	}
	setEnabled(e) {
		!this.isManualOperationAllowed() || this.requestedDisabled === !e || (this.requestedDisabled = !e, this.emitTrackUpdate());
	}
	setVideoQuality(e) {
		!this.isManualOperationAllowed() || this.requestedMaxQuality === e || (this.requestedMaxQuality = e, this.requestedVideoDimensions = void 0, this.emitTrackUpdate());
	}
	setVideoDimensions(e) {
		this.isManualOperationAllowed() && (this.requestedVideoDimensions?.width === e.width && this.requestedVideoDimensions?.height === e.height || (Fs(this.track) && (this.requestedVideoDimensions = e), this.requestedMaxQuality = void 0, this.emitTrackUpdate()));
	}
	setVideoFPS(e) {
		this.isManualOperationAllowed() && Fs(this.track) && this.fps !== e && (this.fps = e, this.emitTrackUpdate());
	}
	get videoQuality() {
		return this.requestedMaxQuality ?? Po.HIGH;
	}
	setTrack(e) {
		let t = this.subscriptionStatus, n = this.permissionStatus, r = this.track;
		r !== e && (r && (r.off(L.VideoDimensionsChanged, this.handleVideoDimensionsChange), r.off(L.VisibilityChanged, this.handleVisibilityChange), r.off(L.Ended, this.handleEnded), r.detach(), r.stopMonitor(), this.emit(L.Unsubscribed, r)), super.setTrack(e), e && (e.sid = this.trackSid, e.on(L.VideoDimensionsChanged, this.handleVideoDimensionsChange), e.on(L.VisibilityChanged, this.handleVisibilityChange), e.on(L.Ended, this.handleEnded), this.emit(L.Subscribed, e)), this.emitPermissionUpdateIfChanged(n), this.emitSubscriptionUpdateIfChanged(t));
	}
	setAllowed(e) {
		let t = this.subscriptionStatus, n = this.permissionStatus;
		this.allowed = e, this.emitPermissionUpdateIfChanged(n), this.emitSubscriptionUpdateIfChanged(t);
	}
	setSubscriptionError(e) {
		this.emit(L.SubscriptionFailed, e);
	}
	updateInfo(e) {
		super.updateInfo(e);
		let t = this.metadataMuted;
		this.metadataMuted = e.muted, this.track ? this.track.setMuted(e.muted) : t !== e.muted && this.emit(e.muted ? L.Muted : L.Unmuted);
	}
	emitSubscriptionUpdateIfChanged(e) {
		let t = this.subscriptionStatus;
		e !== t && this.emit(L.SubscriptionStatusChanged, t, e);
	}
	emitPermissionUpdateIfChanged(e) {
		this.permissionStatus !== e && this.emit(L.SubscriptionPermissionChanged, this.permissionStatus, e);
	}
	isManualOperationAllowed() {
		return this.isDesired ? !0 : (this.log.warn("cannot update track settings when not subscribed", this.logContext), !1);
	}
	get isAdaptiveStream() {
		return Fs(this.track) && this.track.isAdaptiveStream;
	}
	emitTrackUpdate() {
		let e = new br({
			trackSids: [this.trackSid],
			disabled: !this.isEnabled,
			fps: this.fps
		});
		if (this.kind === B.Kind.Video) {
			let t = this.requestedVideoDimensions;
			if (this.videoDimensionsAdaptiveStream !== void 0) if (t) Ao(this.videoDimensionsAdaptiveStream, t) && (this.log.debug("using adaptive stream dimensions instead of requested", Object.assign(Object.assign({}, this.logContext), this.videoDimensionsAdaptiveStream)), t = this.videoDimensionsAdaptiveStream);
			else if (this.requestedMaxQuality !== void 0 && this.trackInfo) {
				let e = jo(this.trackInfo, this.requestedMaxQuality);
				e && Ao(this.videoDimensionsAdaptiveStream, e) && (this.log.debug("using adaptive stream dimensions instead of max quality layer", Object.assign(Object.assign({}, this.logContext), this.videoDimensionsAdaptiveStream)), t = this.videoDimensionsAdaptiveStream);
			} else this.log.debug("using adaptive stream dimensions", Object.assign(Object.assign({}, this.logContext), this.videoDimensionsAdaptiveStream)), t = this.videoDimensionsAdaptiveStream;
			t ? (e.width = Math.ceil(t.width), e.height = Math.ceil(t.height)) : this.requestedMaxQuality === void 0 ? (this.log.debug("using default quality", Object.assign(Object.assign({}, this.logContext), { quality: Po.HIGH })), e.quality = Po.HIGH) : (this.log.debug("using requested max quality", Object.assign(Object.assign({}, this.logContext), { quality: this.requestedMaxQuality })), e.quality = this.requestedMaxQuality);
		}
		this.emit(L.UpdateSettings, e);
	}
}, af = class e extends Qd {
	static fromParticipantInfo(t, n, r, i) {
		return new e(t, n.sid, n.identity, n.name, n.metadata, n.attributes, r, n.kind, n.dataTracks.map((e) => new ad(Lc.from(e), i, { publisherIdentity: n.identity })), n.clientProtocol);
	}
	get logContext() {
		return Object.assign(Object.assign({}, super.logContext), {
			remoteParticipantID: this.sid,
			remoteParticipant: this.identity
		});
	}
	constructor(e, t, n, r, i, a, o) {
		let s = arguments.length > 7 && arguments[7] !== void 0 ? arguments[7] : dn.STANDARD, c = arguments.length > 8 && arguments[8] !== void 0 ? arguments[8] : [], l = arguments.length > 9 && arguments[9] !== void 0 ? arguments[9] : 0;
		super(t, n || "", r, i, a, o, s), this.signalClient = e, this.trackPublications = /* @__PURE__ */ new Map(), this.audioTrackPublications = /* @__PURE__ */ new Map(), this.videoTrackPublications = /* @__PURE__ */ new Map(), this.dataTracks = new nf(c.map((e) => [e.info.name, e])), this.volumeMap = /* @__PURE__ */ new Map(), this.clientProtocol = l;
	}
	addTrackPublication(e) {
		super.addTrackPublication(e), e.on(L.UpdateSettings, (t) => {
			this.log.debug("send update settings", Object.assign(Object.assign(Object.assign({}, this.logContext), z(e)), { settings: t })), this.signalClient.sendUpdateTrackSettings(t);
		}), e.on(L.UpdateSubscription, (e) => {
			e.participantTracks.forEach((e) => {
				e.participantSid = this.sid;
			}), this.signalClient.sendUpdateSubscription(e);
		}), e.on(L.SubscriptionPermissionChanged, (t) => {
			this.emit(F.TrackSubscriptionPermissionChanged, e, t);
		}), e.on(L.SubscriptionStatusChanged, (t) => {
			this.emit(F.TrackSubscriptionStatusChanged, e, t);
		}), e.on(L.Subscribed, (t) => {
			this.emit(F.TrackSubscribed, t, e);
		}), e.on(L.Unsubscribed, (t) => {
			this.emit(F.TrackUnsubscribed, t, e);
		}), e.on(L.SubscriptionFailed, (t) => {
			this.emit(F.TrackSubscriptionFailed, e.trackSid, t);
		});
	}
	getTrackPublication(e) {
		let t = super.getTrackPublication(e);
		if (t) return t;
	}
	getTrackPublicationByName(e) {
		let t = super.getTrackPublicationByName(e);
		if (t) return t;
	}
	setVolume(e) {
		let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : B.Source.Microphone;
		this.volumeMap.set(t, e);
		let n = this.getTrackPublication(t);
		n && n.track && n.track.setVolume(e);
	}
	getVolume() {
		let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : B.Source.Microphone, t = this.getTrackPublication(e);
		return t && t.track ? t.track.getVolume() : this.volumeMap.get(e);
	}
	addSubscribedMediaTrack(e, t, n, r, i, a) {
		let o = this.getTrackPublicationBySid(t);
		if (o || t.startsWith("TR") || this.trackPublications.forEach((t) => {
			!o && e.kind === t.kind.toString() && (o = t);
		}), !o) {
			if (a === 0) {
				this.log.error("could not find published track", Object.assign(Object.assign({}, this.logContext), { trackSid: t })), this.emit(F.TrackSubscriptionFailed, t);
				return;
			}
			a === void 0 && (a = 20), setTimeout(() => {
				this.addSubscribedMediaTrack(e, t, n, r, i, a - 1);
			}, 150);
			return;
		}
		if (e.readyState === "ended") {
			this.log.error("unable to subscribe because MediaStreamTrack is ended. Do not call MediaStreamTrack.stop()", Object.assign(Object.assign({}, this.logContext), z(o))), this.emit(F.TrackSubscriptionFailed, t);
			return;
		}
		let s = e.kind === "video", c;
		return c = s ? new mc(e, t, r, i) : new Ud(e, t, r, this.audioContext, this.audioOutput), c.source = o.source, c.isMuted = o.isMuted, c.setMediaStream(n), c.start(), o.setTrack(c), this.volumeMap.has(o.source) && Ns(c) && ks(c) && c.setVolume(this.volumeMap.get(o.source)), o;
	}
	get hasMetadata() {
		return !!this.participantInfo;
	}
	getTrackPublicationBySid(e) {
		return this.trackPublications.get(e);
	}
	updateInfo(e) {
		if (!super.updateInfo(e)) return !1;
		let t = /* @__PURE__ */ new Map(), n = /* @__PURE__ */ new Map();
		return e.tracks.forEach((e) => {
			let r = this.getTrackPublicationBySid(e.sid);
			if (r) r.updateInfo(e);
			else {
				let t = B.kindFromProto(e.type);
				if (!t) return;
				r = new rf(t, e, this.signalClient.connectOptions?.autoSubscribe, {
					loggerContextCb: () => this.logContext,
					loggerName: this.loggerOptions?.loggerName
				}), r.updateInfo(e), n.set(e.sid, r);
				let i = Array.from(this.trackPublications.values()).find((e) => e.source === r?.source);
				i && r.source !== B.Source.Unknown && this.log.debug(`received a second track publication for ${this.identity} with the same source: ${r.source}`, Object.assign(Object.assign({}, this.logContext), {
					oldTrack: z(i),
					newTrack: z(r)
				})), this.addTrackPublication(r);
			}
			t.set(e.sid, r);
		}), this.trackPublications.forEach((e) => {
			t.has(e.trackSid) || (this.log.trace("detected removed track on remote participant, unpublishing", Object.assign(Object.assign({}, this.logContext), z(e))), this.unpublishTrack(e.trackSid, !0));
		}), n.forEach((e) => {
			this.emit(F.TrackPublished, e);
		}), !0;
	}
	unpublishTrack(e, t) {
		let n = this.trackPublications.get(e);
		if (!n) return;
		let r = n.track;
		switch (r && (r.stop(), n.setTrack(void 0)), this.trackPublications.delete(e), n.kind) {
			case B.Kind.Audio:
				this.audioTrackPublications.delete(e);
				break;
			case B.Kind.Video:
				this.videoTrackPublications.delete(e);
				break;
		}
		t && this.emit(F.TrackUnpublished, n);
	}
	setAudioOutput(e) {
		return E(this, void 0, void 0, function* () {
			this.audioOutput = e;
			let t = [];
			this.audioTrackPublications.forEach((n) => {
				ks(n.track) && Ns(n.track) && t.push(n.track.setSinkId(e.deviceId ?? "default"));
			}), yield Promise.all(t);
		});
	}
	addRemoteDataTrack(e) {
		this.dataTracks.set(e.info.name, e);
	}
	removeRemoteDataTrack(e) {
		for (let n of this.dataTracks.entries()) {
			var t = g(n, 2);
			let r = t[0];
			e === t[1].info.sid && this.dataTracks.delete(r);
		}
	}
	emit(e) {
		var t = [...arguments].slice(1);
		return this.log.trace("participant event", Object.assign(Object.assign({}, this.logContext), {
			event: e,
			args: t
		})), super.emit(e, ...t);
	}
}, Q;
(function(e) {
	e.Disconnected = "disconnected", e.Connecting = "connecting", e.Connected = "connected", e.Reconnecting = "reconnecting", e.SignalReconnecting = "signalReconnecting";
})(Q ||= {});
var of = 4 * 1e3, sf = class e extends Oi.EventEmitter {
	get hasE2EESetup() {
		return this.e2eeManager !== void 0;
	}
	constructor(t) {
		var n, r, a;
		if (super(), n = this, this.state = Q.Disconnected, this.activeSpeakers = [], this.isE2EEEnabled = !1, this.audioEnabled = !0, this.e2eeStateMutex = new i(), this.isVideoPlaybackBlocked = !1, this.log = w, this.bufferedEvents = [], this.isResuming = !1, this.connect = (e, t, n) => E(this, void 0, void 0, function* () {
			if (!Ko()) throw ns() ? Error("WebRTC isn't detected, have you called registerGlobals?") : Error("LiveKit doesn't seem to be supported on this browser. Try to update your browser and make sure no browser extensions are disabling webRTC.");
			let r = yield this.disconnectLock.lock();
			if (this.state === Q.Connected) return this.log.info(`already connected to room ${this.name}`), r(), Promise.resolve();
			if (this.connectFuture) return r(), this.connectFuture.promise;
			this.setAndEmitConnectionState(Q.Connecting), this.regionUrlProvider?.getServerUrl().toString() !== Ws(e) && (this.regionUrl = void 0, this.regionUrlProvider = void 0), rs(new URL(e)) && (this.regionUrlProvider === void 0 ? this.regionUrlProvider = new gu(e, t) : this.regionUrlProvider.updateToken(t), this.regionUrlProvider.fetchRegionSettings().then((e) => {
				var t;
				(t = this.regionUrlProvider) == null || t.setServerReportedRegions(e);
			}).catch((e) => {
				this.log.warn("could not fetch region settings", { error: e });
			}));
			let i = (a, o, s) => E(this, void 0, void 0, function* () {
				this.abortController && this.abortController.abort();
				let c = new AbortController();
				this.abortController = c, r?.();
				try {
					if (yield wc.getInstance().getBackOffPromise(e), c.signal.aborted) throw A.cancelled("Connection attempt aborted");
					yield this.attemptConnection(s ?? e, t, n, c), this.abortController = void 0, a();
				} catch (t) {
					if (this.regionUrlProvider && t instanceof A && t.reason !== k.Cancelled && t.reason !== k.NotAllowed) {
						let n = null;
						try {
							this.log.debug("Fetching next region"), n = yield this.regionUrlProvider.getNextBestRegionUrl(this.abortController?.signal);
						} catch (e) {
							if (e instanceof A && (e.status === 401 || e.reason === k.Cancelled)) {
								this.handleDisconnect(this.options.stopLocalTrackOnUnpublish), o(e);
								return;
							}
						}
						[
							k.InternalError,
							k.ServerUnreachable,
							k.Timeout
						].includes(t.reason) && (this.log.debug("Adding failed connection attempt to back off"), wc.getInstance().addFailedConnectionAttempt(e)), n && !this.abortController?.signal.aborted ? (this.log.info(`Initial connection failed with ConnectionError: ${t.message}. Retrying with another region: ${n}`), this.recreateEngine(!0), yield i(a, o, n)) : (this.handleDisconnect(this.options.stopLocalTrackOnUnpublish, Ts(t)), o(t));
					} else {
						let e = tn.UNKNOWN_REASON;
						t instanceof A && (e = Ts(t)), this.handleDisconnect(this.options.stopLocalTrackOnUnpublish, e), o(t);
					}
				}
			}), a = this.regionUrl;
			return this.regionUrl = void 0, this.connectFuture = new U((e, t) => {
				i(e, t, a);
			}, () => {
				this.clearConnectionFutures();
			}), this.connectFuture.promise;
		}), this.connectSignal = (e, t, n, r, i, a) => E(this, void 0, void 0, function* () {
			let o = yield n.join(e, t, {
				autoSubscribe: r.autoSubscribe,
				adaptiveStream: typeof i.adaptiveStream == "object" ? !0 : i.adaptiveStream,
				clientInfoCapabilities: ac(i.packetTrailer) || this.e2eeManager ? [Rn.CAP_PACKET_TRAILER] : void 0,
				maxRetries: r.maxRetries,
				e2eeEnabled: !!this.e2eeManager,
				websocketTimeout: r.websocketTimeout
			}, a.signal, !i.singlePeerConnection), s = o.joinResponse, c = o.serverInfo;
			if (this.serverInfo = c, !c.version) throw new Qa("unknown server version");
			return c.version === "0.15.1" && this.options.dynacast && (this.log.debug("disabling dynacast due to server version"), i.dynacast = !1), s;
		}), this.applyJoinResponse = (e) => {
			let t = e.participant;
			if (this.localParticipant.sid = t.sid, this.localParticipant.identity = t.identity, this.localParticipant.setEnabledPublishCodecs(e.enabledPublishCodecs), this.e2eeManager) try {
				this.e2eeManager.setSifTrailer(e.sifTrailer);
			} catch (e) {
				this.log.error(e instanceof Error ? e.message : "Could not set SifTrailer", { error: e });
			}
			this.handleParticipantUpdates([t, ...e.otherParticipants]), e.room && this.handleRoomUpdate(e.room);
		}, this.attemptConnection = (e, t, n, r) => E(this, void 0, void 0, function* () {
			this.state === Q.Reconnecting || this.isResuming || this.engine?.pendingReconnect ? (this.log.info("Reconnection attempt replaced by new connection attempt"), this.recreateEngine(!0)) : this.maybeCreateEngine(), this.regionUrlProvider?.isCloud() && this.engine.setRegionStrategy(this.createRegionStrategy()), this.acquireAudioContext(), this.connOptions = Object.assign(Object.assign({}, Cl), n), this.connOptions.rtcConfig && (this.engine.rtcConfig = this.connOptions.rtcConfig), this.connOptions.peerConnectionTimeout && (this.engine.peerConnectionTimeout = this.connOptions.peerConnectionTimeout);
			try {
				let n = yield this.connectSignal(e, t, this.engine, this.connOptions, this.options, r);
				this.applyJoinResponse(n), this.setupLocalParticipantEvents(), this.emit(P.SignalConnected);
			} catch (e) {
				yield this.engine.close(), this.recreateEngine();
				let t = r.signal.aborted ? A.cancelled("Signal connection aborted") : A.serverUnreachable("could not establish signal connection");
				throw e instanceof Error && (t.message = `${t.message}: ${e.message}`), e instanceof A && (t.reason = e.reason, t.status = e.status), this.log.debug("error trying to establish signal connection", { error: e }), t;
			}
			if (r.signal.aborted) throw yield this.engine.close(), this.recreateEngine(), A.cancelled("Connection attempt aborted");
			try {
				yield this.engine.waitForPCInitialConnection(this.connOptions.peerConnectionTimeout, r);
			} catch (e) {
				throw yield this.engine.close(), this.recreateEngine(), e;
			}
			H() && this.options.disconnectOnPageLeave && (window.addEventListener("pagehide", this.onPageLeave), window.addEventListener("beforeunload", this.onPageLeave)), H() && window.addEventListener("freeze", this.onPageLeave), this.setAndEmitConnectionState(Q.Connected), this.emit(P.Connected), wc.getInstance().resetFailedConnectionAttempts(e), this.registerConnectionReconcile(), this.regionUrlProvider && this.regionUrlProvider.notifyConnected();
		}), this.disconnect = function() {
			return E(n, [...arguments], void 0, function() {
				var e = this;
				let t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : !0;
				return function* () {
					var n, r, i;
					let a = yield e.disconnectLock.lock();
					try {
						if (e.state === Q.Disconnected) {
							e.log.debug("already disconnected");
							return;
						}
						if (e.log.info("disconnect from room"), e.state === Q.Connecting || e.state === Q.Reconnecting || e.isResuming) {
							let t = "Abort connection attempt due to user initiated disconnect";
							e.log.warn(t), (n = e.abortController) == null || n.abort(t), (i = (r = e.connectFuture)?.reject) == null || i.call(r, A.cancelled("Client initiated disconnect")), e.connectFuture = void 0;
						}
						e.engine && (e.engine.client.isDisconnected || (yield e.engine.client.sendLeave()), yield e.engine.close()), e.handleDisconnect(t, tn.CLIENT_INITIATED), e.engine = void 0;
					} finally {
						a();
					}
				}();
			});
		}, this.onPageLeave = () => E(this, void 0, void 0, function* () {
			this.log.info("Page leave detected, disconnecting"), yield this.disconnect();
		}), this.startAudio = () => E(this, void 0, void 0, function* () {
			let e = [], t = O();
			if (t && t.os === "iOS") {
				let t = "livekit-dummy-audio-el", n = document.getElementById(t);
				if (!n) {
					n = document.createElement("audio"), n.id = t, n.autoplay = !0, n.hidden = !0;
					let e = vs();
					e.enabled = !0;
					let r = new MediaStream([e]);
					n.srcObject = r, document.addEventListener("visibilitychange", () => {
						n && (n.srcObject = document.hidden ? null : r, document.hidden || (this.log.debug("page visible again, triggering startAudio to resume playback and update playback status"), this.startAudio()));
					}), document.body.append(n), this.once(P.Disconnected, () => {
						n?.remove(), n = null;
					});
				}
				e.push(n);
			}
			this.remoteParticipants.forEach((t) => {
				t.audioTrackPublications.forEach((t) => {
					t.track && t.track.attachedElements.forEach((t) => {
						e.push(t);
					});
				});
			});
			try {
				yield Promise.all([this.acquireAudioContext(), ...e.map((e) => (e.muted = !1, e.play()))]), this.handleAudioPlaybackStarted();
			} catch (e) {
				throw this.handleAudioPlaybackFailed(e), e;
			}
		}), this.startVideo = () => E(this, void 0, void 0, function* () {
			let e = [];
			for (let t of this.remoteParticipants.values()) t.videoTrackPublications.forEach((t) => {
				var n;
				(n = t.track) == null || n.attachedElements.forEach((t) => {
					e.includes(t) || e.push(t);
				});
			});
			yield Promise.all(e.map((e) => e.play())).then(() => {
				this.handleVideoPlaybackStarted();
			}).catch((e) => {
				e.name === "NotAllowedError" ? this.handleVideoPlaybackFailed() : this.log.warn("Resuming video playback failed, make sure you call `startVideo` directly in a user gesture handler");
			});
		}), this.handleRestarting = () => {
			this.clearConnectionReconcile(), this.isResuming = !1;
			for (let e of this.remoteParticipants.values()) this.handleParticipantDisconnected(e.identity, e);
			this.setAndEmitConnectionState(Q.Reconnecting) && this.emit(P.Reconnecting);
		}, this.handleRestarted = () => {
			this.outgoingDataTrackManager.sfuWillRepublishTracks(), this.incomingDataTrackManager.resendSubscriptionUpdates();
		}, this.handleSignalRestarted = (e) => E(this, void 0, void 0, function* () {
			this.log.debug(`signal reconnected to server, region ${e.serverRegion}`, { region: e.serverRegion }), this.bufferedEvents = [], this.applyJoinResponse(e);
			try {
				yield this.localParticipant.republishAllTracks(void 0, !0);
			} catch (e) {
				this.log.error("error trying to re-publish tracks after reconnection", { error: e });
			}
			try {
				yield this.engine.waitForRestarted(), this.log.debug("fully reconnected to server", { region: e.serverRegion });
			} catch {
				return;
			}
			this.setAndEmitConnectionState(Q.Connected), this.emit(P.Reconnected), this.registerConnectionReconcile(), this.emitBufferedEvents();
		}), this.handleParticipantUpdates = (e) => {
			for (let t of e) {
				if (t.identity === this.localParticipant.identity) {
					this.localParticipant.updateInfo(t);
					continue;
				}
				t.identity === "" && (t.identity = this.sidToIdentity.get(t.sid) ?? "");
				let e = this.remoteParticipants.get(t.identity);
				t.state === un.DISCONNECTED ? this.handleParticipantDisconnected(t.identity, e) : this.getOrCreateParticipant(t.identity, t);
			}
			let t = new Map(e.filter((e) => e.identity !== this.localParticipant.identity).map((e) => [e.identity, e.dataTracks.map((e) => Lc.from(e))]));
			this.incomingDataTrackManager.receiveSfuPublicationUpdates(t);
		}, this.handleActiveSpeakersUpdate = (e) => {
			let t = [], n = {};
			e.forEach((e) => {
				if (n[e.sid] = !0, e.sid === this.localParticipant.sid) this.localParticipant.audioLevel = e.level, this.localParticipant.setIsSpeaking(!0), t.push(this.localParticipant);
				else {
					let n = this.getRemoteParticipantBySid(e.sid);
					n && (n.audioLevel = e.level, n.setIsSpeaking(!0), t.push(n));
				}
			}), n[this.localParticipant.sid] || (this.localParticipant.audioLevel = 0, this.localParticipant.setIsSpeaking(!1)), this.remoteParticipants.forEach((e) => {
				n[e.sid] || (e.audioLevel = 0, e.setIsSpeaking(!1));
			}), this.activeSpeakers = t, this.emitWhenConnected(P.ActiveSpeakersChanged, t);
		}, this.handleSpeakersChanged = (e) => {
			let t = /* @__PURE__ */ new Map();
			this.activeSpeakers.forEach((e) => {
				let n = this.remoteParticipants.get(e.identity);
				n && n.sid !== e.sid || t.set(e.sid, e);
			}), e.forEach((e) => {
				let n = this.getRemoteParticipantBySid(e.sid);
				e.sid === this.localParticipant.sid && (n = this.localParticipant), n && (n.audioLevel = e.level, n.setIsSpeaking(e.active), e.active ? t.set(e.sid, n) : t.delete(e.sid));
			});
			let n = Array.from(t.values());
			n.sort((e, t) => t.audioLevel - e.audioLevel), this.activeSpeakers = n, this.emitWhenConnected(P.ActiveSpeakersChanged, n);
		}, this.handleStreamStateUpdate = (e) => {
			e.streamStates.forEach((e) => {
				let t = this.getRemoteParticipantBySid(e.participantSid);
				if (!t) return;
				let n = t.getTrackPublicationBySid(e.trackSid);
				if (!n || !n.track) return;
				let r = B.streamStateFromProto(e.state);
				n.track.setStreamState(r), r !== n.track.streamState && (t.emit(F.TrackStreamStateChanged, n, n.track.streamState), this.emitWhenConnected(P.TrackStreamStateChanged, n, n.track.streamState, t));
			});
		}, this.handleSubscriptionPermissionUpdate = (e) => {
			let t = this.getRemoteParticipantBySid(e.participantSid);
			if (!t) return;
			let n = t.getTrackPublicationBySid(e.trackSid);
			n && n.setAllowed(e.allowed);
		}, this.handleSubscriptionError = (e) => {
			let t = Array.from(this.remoteParticipants.values()).find((t) => t.trackPublications.has(e.trackSid));
			if (!t) return;
			let n = t.getTrackPublicationBySid(e.trackSid);
			n && n.setSubscriptionError(e.err);
		}, this.handleDataPacket = (e, t) => {
			let n = this.remoteParticipants.get(e.participantIdentity);
			if (e.value.case === "user") this.handleUserPacket(n, e.value.value, e.kind, t);
			else if (e.value.case === "transcription") this.handleTranscription(n, e.value.value);
			else if (e.value.case === "sipDtmf") this.handleSipDtmf(n, e.value.value);
			else if (e.value.case === "chatMessage") this.handleChatMessage(n, e.value.value);
			else if (e.value.case === "metrics") this.handleMetrics(e.value.value, n);
			else if (e.value.case === "streamHeader" || e.value.case === "streamChunk" || e.value.case === "streamTrailer") this.handleDataStream(e, t);
			else if (e.value.case === "rpcRequest") {
				let t = e.value.value;
				this.rpcServerManager.handleIncomingRpcRequest(e.participantIdentity, t);
			} else if (e.value.case === "rpcResponse") {
				let t = e.value.value;
				switch (t.value.case) {
					case "payload":
						this.rpcClientManager.handleIncomingRpcResponseSuccess(t.requestId, t.value.value);
						break;
					case "error":
						this.rpcClientManager.handleIncomingRpcResponseFailure(t.requestId, X.fromProto(t.value.value));
						break;
					default:
						this.log.warn(`Unknown rpcResponse.value.case: ${t.value.case}`, this.logContext);
						break;
				}
			} else e.value.case === "rpcAck" && this.rpcClientManager.handleIncomingRpcAck(e.value.value.requestId);
		}, this.handleUserPacket = (e, t, n, r) => {
			this.emit(P.DataReceived, t.payload, e, n, t.topic, r), e?.emit(F.DataReceived, t.payload, n, r);
		}, this.handleSipDtmf = (e, t) => {
			this.emit(P.SipDTMFReceived, t, e), e?.emit(F.SipDTMFReceived, t);
		}, this.handleTranscription = (e, t) => {
			let n = t.transcribedParticipantIdentity === this.localParticipant.identity ? this.localParticipant : this.getParticipantByIdentity(t.transcribedParticipantIdentity), r = n?.trackPublications.get(t.trackId), i = Cs(t, this.transcriptionReceivedTimes);
			r?.emit(L.TranscriptionReceived, i), n?.emit(F.TranscriptionReceived, i, r), this.emit(P.TranscriptionReceived, i, n, r);
		}, this.handleChatMessage = (e, t) => {
			let n = ws(t);
			this.emit(P.ChatMessage, n, e);
		}, this.handleMetrics = (e, t) => {
			this.emit(P.MetricsReceived, e, t);
		}, this.handleDataStream = (e, t) => {
			this.incomingDataStreamManager.handleDataStreamPacket(e, t);
		}, this.bufferedSegments = /* @__PURE__ */ new Map(), this.handleAudioPlaybackStarted = () => {
			this.canPlaybackAudio || (this.audioEnabled = !0, this.emit(P.AudioPlaybackStatusChanged, !0));
		}, this.handleAudioPlaybackFailed = (e) => {
			this.log.warn("could not playback audio", { error: e }), this.canPlaybackAudio && (this.audioEnabled = !1, this.emit(P.AudioPlaybackStatusChanged, !1));
		}, this.handleVideoPlaybackStarted = () => {
			this.isVideoPlaybackBlocked && (this.isVideoPlaybackBlocked = !1, this.emit(P.VideoPlaybackStatusChanged, !0));
		}, this.handleVideoPlaybackFailed = () => {
			this.isVideoPlaybackBlocked || (this.isVideoPlaybackBlocked = !0, this.emit(P.VideoPlaybackStatusChanged, !1));
		}, this.handleDeviceChange = () => E(this, void 0, void 0, function* () {
			O()?.os !== "iOS" && (yield this.selectDefaultDevices()), this.emit(P.MediaDevicesChanged);
		}), this.handleRoomUpdate = (e) => {
			let t = this.roomInfo;
			this.roomInfo = e, t && t.metadata !== e.metadata && this.emitWhenConnected(P.RoomMetadataChanged, e.metadata), t?.activeRecording !== e.activeRecording && this.emitWhenConnected(P.RecordingStatusChanged, e.activeRecording);
		}, this.handleConnectionQualityUpdate = (e) => {
			e.updates.forEach((e) => {
				if (e.participantSid === this.localParticipant.sid) {
					this.localParticipant.setConnectionQuality(e.quality);
					return;
				}
				let t = this.getRemoteParticipantBySid(e.participantSid);
				t && t.setConnectionQuality(e.quality);
			});
		}, this.getRemoteParticipantClientProtocol = (e) => this.remoteParticipants.get(e)?.clientProtocol ?? 0, this.onLocalParticipantMetadataChanged = (e) => {
			this.emit(P.ParticipantMetadataChanged, e, this.localParticipant);
		}, this.onLocalParticipantNameChanged = (e) => {
			this.emit(P.ParticipantNameChanged, e, this.localParticipant);
		}, this.onLocalAttributesChanged = (e) => {
			this.emit(P.ParticipantAttributesChanged, e, this.localParticipant);
		}, this.onLocalTrackMuted = (e) => {
			this.emit(P.TrackMuted, e, this.localParticipant);
		}, this.onLocalTrackUnmuted = (e) => {
			this.emit(P.TrackUnmuted, e, this.localParticipant);
		}, this.onTrackProcessorUpdate = (e) => {
			var t;
			(t = e?.onPublish) == null || t.call(e, this);
		}, this.onLocalTrackPublished = (e) => E(this, void 0, void 0, function* () {
			var t, n, r, i;
			(t = e.track) == null || t.on(L.TrackProcessorUpdate, this.onTrackProcessorUpdate), (n = e.track) == null || n.on(L.Restarted, this.onLocalTrackRestarted), (i = (r = e.track?.getProcessor())?.onPublish) == null || i.call(r, this), this.emit(P.LocalTrackPublished, e, this.localParticipant), Ms(e.track) && (yield e.track.checkForSilence()) && this.emit(P.LocalAudioSilenceDetected, e);
			let a = yield e.track?.getDeviceId(!1), o = So(e.source);
			o && a && a !== this.localParticipant.activeDeviceMap.get(o) && (this.localParticipant.activeDeviceMap.set(o, a), this.emit(P.ActiveDeviceChanged, o, a));
		}), this.onLocalTrackUnpublished = (e) => {
			var t, n;
			(t = e.track) == null || t.off(L.TrackProcessorUpdate, this.onTrackProcessorUpdate), (n = e.track) == null || n.off(L.Restarted, this.onLocalTrackRestarted), this.emit(P.LocalTrackUnpublished, e, this.localParticipant);
		}, this.onLocalTrackRestarted = (e) => E(this, void 0, void 0, function* () {
			let t = yield e.getDeviceId(!1), n = So(e.source);
			n && t && t !== this.localParticipant.activeDeviceMap.get(n) && (this.log.debug(`local track restarted, setting ${n} ${t} active`), this.localParticipant.activeDeviceMap.set(n, t), this.emit(P.ActiveDeviceChanged, n, t));
		}), this.onLocalConnectionQualityChanged = (e) => {
			this.emit(P.ConnectionQualityChanged, e, this.localParticipant);
		}, this.onMediaDevicesError = (e, t) => {
			this.emit(P.MediaDevicesError, e, t);
		}, this.onLocalParticipantPermissionsChanged = (e) => {
			this.emit(P.ParticipantPermissionsChanged, e, this.localParticipant);
		}, this.onLocalChatMessageSent = (e) => {
			this.emit(P.ChatMessage, e, this.localParticipant);
		}, this.setMaxListeners(100), this.remoteParticipants = /* @__PURE__ */ new Map(), this.sidToIdentity = /* @__PURE__ */ new Map(), this.options = Object.assign(Object.assign({}, Sl), t), this.log = T(this.options.loggerName ?? C.Room, () => this.logContext), this.transcriptionReceivedTimes = /* @__PURE__ */ new Map(), this.options.audioCaptureDefaults = Object.assign(Object.assign({}, bl), t?.audioCaptureDefaults), this.options.videoCaptureDefaults = Object.assign(Object.assign({}, xl), t?.videoCaptureDefaults), this.options.publishDefaults = Object.assign(Object.assign({}, yl), t?.publishDefaults), this.maybeCreateEngine(), this.incomingDataStreamManager = new xu(), this.outgoingDataStreamManager = new Eu(this.engine, this.log), this.incomingDataTrackManager = new vd({ e2eeManager: this.e2eeManager }), this.incomingDataTrackManager.on("sfuUpdateSubscription", (e) => {
			this.engine.client.sendUpdateDataSubscription(e.sid, e.subscribe);
		}).on("trackPublished", (e) => {
			var t;
			e.track.publisherIdentity !== this.localParticipant.identity && (this.emit(P.DataTrackPublished, e.track), (t = this.remoteParticipants.get(e.track.publisherIdentity)) == null || t.addRemoteDataTrack(e.track));
		}).on("trackUnpublished", (e) => {
			var t;
			e.publisherIdentity !== this.localParticipant.identity && (this.emit(P.DataTrackUnpublished, e.sid), (t = this.remoteParticipants.get(e.publisherIdentity)) == null || t.removeRemoteDataTrack(e.sid));
		}), this.outgoingDataTrackManager = new Nd({ e2eeManager: this.e2eeManager }), this.outgoingDataTrackManager.on("sfuPublishRequest", (e) => {
			this.engine.client.sendPublishDataTrackRequest(e.handle, e.name, e.usesE2ee);
		}).on("sfuUnpublishRequest", (e) => {
			this.engine.client.sendUnPublishDataTrackRequest(e.handle);
		}).on("trackPublished", (e) => {
			this.emit(P.LocalDataTrackPublished, e.track);
		}).on("trackUnpublished", (e) => {
			this.emit(P.LocalDataTrackUnpublished, e.sid);
		}).on("packetAvailable", (e) => {
			let t = e.handle, n = e.bytes;
			this.engine.sendLossyBytes(n, K.DATA_TRACK_LOSSY, "wait").finally(() => this.outgoingDataTrackManager.handlePacketSendComplete(t));
		}), this.registerRpcDataStreamHandler(), this.rpcClientManager = new Vd(this.log, this.outgoingDataStreamManager, this.getRemoteParticipantClientProtocol, () => this.engine.latestJoinResponse?.serverInfo?.version), this.rpcClientManager.on("sendDataPacket", (e) => {
			let t = e.packet;
			var n;
			(n = this.engine) == null || n.sendDataPacket(t, K.RELIABLE);
		}), this.rpcServerManager = new Hd(this.log, this.outgoingDataStreamManager, this.getRemoteParticipantClientProtocol), this.rpcServerManager.on("sendDataPacket", (e) => {
			let t = e.packet;
			var n;
			(n = this.engine) == null || n.sendDataPacket(t, K.RELIABLE);
		}), this.disconnectLock = new i(), this.localParticipant = new ef("", "", this.engine, this.options, this.outgoingDataStreamManager, this.outgoingDataTrackManager, this.rpcClientManager, this.rpcServerManager), this.setupPacketTrailer(), (this.options.e2ee || this.options.encryption) && this.setupE2EE(), this.engine.e2eeManager = this.e2eeManager, this.incomingDataTrackManager.updateE2eeManager(this.e2eeManager ?? null), this.outgoingDataTrackManager.updateE2eeManager(this.e2eeManager ?? null), this.options.videoCaptureDefaults.deviceId && this.localParticipant.activeDeviceMap.set("videoinput", bs(this.options.videoCaptureDefaults.deviceId)), this.options.audioCaptureDefaults.deviceId && this.localParticipant.activeDeviceMap.set("audioinput", bs(this.options.audioCaptureDefaults.deviceId)), this.options.audioOutput?.deviceId && this.switchActiveDevice("audiooutput", bs(this.options.audioOutput.deviceId)).catch((e) => this.log.warn(`Could not set audio output: ${e.message}`)), H()) {
			let t = new AbortController(), n;
			if (e.cleanupRegistry) {
				let r = new WeakRef(this);
				n = () => {
					let e = r.deref();
					e && e.handleDeviceChange();
				}, e.cleanupRegistry.register(this, () => {
					t.abort();
				});
			} else n = this.handleDeviceChange;
			(a = (r = navigator.mediaDevices)?.addEventListener) == null || a.call(r, "devicechange", n, { signal: t.signal });
		}
	}
	registerTextStreamHandler(e, t) {
		return this.incomingDataStreamManager.registerTextStreamHandler(e, t);
	}
	unregisterTextStreamHandler(e) {
		return this.incomingDataStreamManager.unregisterTextStreamHandler(e);
	}
	registerByteStreamHandler(e, t) {
		return this.incomingDataStreamManager.registerByteStreamHandler(e, t);
	}
	unregisterByteStreamHandler(e) {
		return this.incomingDataStreamManager.unregisterByteStreamHandler(e);
	}
	registerRpcMethod(e, t) {
		this.rpcServerManager.registerRpcMethod(e, t);
	}
	unregisterRpcMethod(e) {
		this.rpcServerManager.unregisterRpcMethod(e);
	}
	setE2EEEnabled(e) {
		return E(this, void 0, void 0, function* () {
			let t = yield this.e2eeStateMutex.lock();
			try {
				if (this.e2eeManager) this.isE2EEEnabled !== e && (yield this.localParticipant.setE2EEEnabled(e), this.localParticipant.identity !== "" && this.e2eeManager.setParticipantCryptorEnabled(e, this.localParticipant.identity));
				else throw Error("e2ee not configured, please set e2ee settings within the room options");
			} finally {
				t();
			}
		});
	}
	setupE2EE() {
		var e, t;
		let n = !!this.options.encryption, r = this.options.encryption || this.options.e2ee;
		r && ("e2eeManager" in r ? (this.e2eeManager = r.e2eeManager, this.e2eeManager.isDataChannelEncryptionEnabled = n) : this.e2eeManager = new vc(r, n), this.e2eeManager.on(Zs.ParticipantEncryptionStatusChanged, (e, t) => {
			Is(t) && (this.isE2EEEnabled = e), this.emit(P.ParticipantEncryptionStatusChanged, e, t);
		}), this.e2eeManager.on(Zs.EncryptionError, (e, t) => {
			let n = t ? this.getParticipantByIdentity(t) : void 0;
			this.emit(P.EncryptionError, e, n);
		}), (e = this.e2eeManager) == null || e.setup(this), (t = this.e2eeManager) == null || t.setupEngine(this.engine));
	}
	setupPacketTrailer() {
		this.packetTrailerManager = new xc(this.options.packetTrailer), this.packetTrailerManager.setup(this);
	}
	get logContext() {
		return {
			room: this.name,
			roomID: this.roomInfo?.sid,
			participant: this.localParticipant?.identity,
			participantID: this.localParticipant?.sid
		};
	}
	get isRecording() {
		return this.roomInfo?.activeRecording ?? !1;
	}
	getSid() {
		return this.state === Q.Disconnected ? D.resolve("") : this.roomInfo && this.roomInfo.sid !== "" ? D.resolve(this.roomInfo.sid) : new D((e, t) => {
			let n = (t) => {
				t.sid !== "" && (this.engine.off(I.RoomUpdate, n), e(t.sid));
			};
			this.engine.on(I.RoomUpdate, n), this.once(P.Disconnected, () => {
				this.engine.off(I.RoomUpdate, n), t(new j("Room disconnected before room server id was available"));
			});
		});
	}
	get name() {
		return this.roomInfo?.name ?? "";
	}
	get metadata() {
		return this.roomInfo?.metadata;
	}
	get numParticipants() {
		return this.roomInfo?.numParticipants ?? 0;
	}
	get numPublishers() {
		return this.roomInfo?.numPublishers ?? 0;
	}
	maybeCreateEngine() {
		this.engine && (this.engine.isNewlyCreated || !this.engine.isClosed) || (this.engine = new fu(this.options), this.engine.e2eeManager = this.e2eeManager, this.engine.on(I.ParticipantUpdate, this.handleParticipantUpdates).on(I.RoomUpdate, this.handleRoomUpdate).on(I.SpeakersChanged, this.handleSpeakersChanged).on(I.StreamStateChanged, this.handleStreamStateUpdate).on(I.ConnectionQualityUpdate, this.handleConnectionQualityUpdate).on(I.SubscriptionError, this.handleSubscriptionError).on(I.SubscriptionPermissionUpdate, this.handleSubscriptionPermissionUpdate).on(I.MediaTrackAdded, (e, t, n) => {
			this.onTrackAdded(e, t, n);
		}).on(I.Disconnected, (e) => {
			this.handleDisconnect(this.options.stopLocalTrackOnUnpublish, e);
		}).on(I.ActiveSpeakersUpdate, this.handleActiveSpeakersUpdate).on(I.DataPacketReceived, this.handleDataPacket).on(I.Resuming, () => {
			this.clearConnectionReconcile(), this.isResuming = !0, this.log.debug("Resuming signal connection"), this.setAndEmitConnectionState(Q.SignalReconnecting) && this.emit(P.SignalReconnecting);
		}).on(I.Resumed, () => {
			this.registerConnectionReconcile(), this.isResuming = !1, this.log.debug("Resumed signal connection"), this.updateSubscriptions(), this.emitBufferedEvents(), this.setAndEmitConnectionState(Q.Connected) && this.emit(P.Reconnected);
		}).on(I.SignalResumed, () => {
			this.bufferedEvents = [], (this.state === Q.Reconnecting || this.isResuming) && this.sendSyncState();
		}).on(I.Restarting, this.handleRestarting).on(I.Restarted, this.handleRestarted).on(I.SignalRestarted, this.handleSignalRestarted).on(I.Offline, () => {
			this.setAndEmitConnectionState(Q.Reconnecting) && this.emit(P.Reconnecting);
		}).on(I.DCBufferStatusChanged, (e, t) => {
			this.emit(P.DCBufferStatusChanged, e, t);
		}).on(I.LocalTrackSubscribed, (e) => {
			this.handleLocalTrackSubscribed(e);
		}).on(I.RoomMoved, (e) => {
			this.log.debug("room moved", e), e.room && this.handleRoomUpdate(e.room), this.remoteParticipants.forEach((e, t) => {
				this.handleParticipantDisconnected(t, e);
			}), this.emit(P.Moved, e.room.name), e.participant ? this.handleParticipantUpdates([e.participant, ...e.otherParticipants]) : this.handleParticipantUpdates(e.otherParticipants);
		}).on(I.PublishDataTrackResponse, (e) => {
			if (!e.info) {
				this.log.warn(`received PublishDataTrackResponse, but event.info was ${e.info}, so skipping.`);
				return;
			}
			this.outgoingDataTrackManager.receivedSfuPublishResponse(e.info.pubHandle, {
				type: "ok",
				data: {
					sid: e.info.sid,
					pubHandle: e.info.pubHandle,
					name: e.info.name,
					usesE2ee: e.info.encryption !== x.NONE
				}
			});
		}).on(I.UnPublishDataTrackResponse, (e) => {
			if (!e.info) {
				this.log.warn(`received UnPublishDataTrackResponse, but event.info was ${e.info}, so skipping.`);
				return;
			}
			this.outgoingDataTrackManager.receivedSfuUnpublishResponse(e.info.pubHandle);
		}).on(I.DataTrackSubscriberHandles, (e) => {
			let t = new Map(Object.entries(e.subHandles).map((e) => {
				let t = g(e, 2), n = t[0], r = t[1];
				return [parseInt(n, 10), r.trackSid];
			}));
			this.incomingDataTrackManager.receivedSfuSubscriberHandles(t);
		}).on(I.DataTrackPacketReceived, (e) => {
			try {
				this.incomingDataTrackManager.packetReceived(e);
			} catch (e) {
				throw e;
			}
		}).on(I.Joined, (e) => {
			let t = new Map(e.otherParticipants.map((e) => [e.identity, e.dataTracks.map((e) => Lc.from(e))]));
			this.incomingDataTrackManager.receiveSfuPublicationUpdates(t);
		}).on(I.TokenRefreshed, (e) => {
			var t;
			(t = this.regionUrlProvider) == null || t.updateToken(e);
		}).on(I.ServerRegionsReported, (e) => {
			var t;
			(t = this.regionUrlProvider) == null || t.setServerReportedRegions({
				regionSettings: e,
				updatedAtInMs: Date.now(),
				maxAgeInMs: mu
			});
		}), this.localParticipant && this.localParticipant.setupEngine(this.engine), this.e2eeManager && this.e2eeManager.setupEngine(this.engine), this.outgoingDataStreamManager && this.outgoingDataStreamManager.setupEngine(this.engine));
	}
	createRegionStrategy() {
		return {
			getNextUrl: (e) => E(this, void 0, void 0, function* () {
				return this.regionUrlProvider ? this.regionUrlProvider.getNextBestRegionUrl(e) : null;
			}),
			resetAttempts: () => this.regionUrlProvider?.resetAttempts()
		};
	}
	static getLocalDevices(e) {
		let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !0;
		return Ec.getInstance().getDevices(e, t);
	}
	prepareConnection(e, t) {
		return E(this, void 0, void 0, function* () {
			if (this.state === Q.Disconnected) {
				this.log.debug(`prepareConnection to ${e}`);
				try {
					if (rs(new URL(e)) && t) {
						this.regionUrlProvider = new gu(e, t);
						let n = yield this.regionUrlProvider.getNextBestRegionUrl();
						n && this.state === Q.Disconnected && (this.regionUrl = n, yield fetch(Ss(n), { method: "HEAD" }), this.log.debug(`prepared connection to ${n}`));
					} else yield fetch(Ss(e), { method: "HEAD" });
				} catch (e) {
					this.log.warn("could not prepare connection", { error: e });
				}
			}
		});
	}
	getParticipantByIdentity(e) {
		return this.localParticipant.identity === e ? this.localParticipant : this.remoteParticipants.get(e);
	}
	clearConnectionFutures() {
		this.connectFuture = void 0;
	}
	simulateScenario(e, t) {
		return E(this, void 0, void 0, function* () {
			let n = () => E(this, void 0, void 0, function* () {}), r;
			switch (e) {
				case "signal-reconnect":
					yield this.engine.client.handleOnClose("simulate disconnect");
					break;
				case "fail-on-v1-path":
					this.engine.failNextV1Path();
					break;
				case "speaker":
					r = new Gr({ scenario: {
						case: "speakerUpdate",
						value: 3
					} });
					break;
				case "node-failure":
					r = new Gr({ scenario: {
						case: "nodeFailure",
						value: !0
					} });
					break;
				case "server-leave":
					r = new Gr({ scenario: {
						case: "serverLeave",
						value: !0
					} });
					break;
				case "migration":
					r = new Gr({ scenario: {
						case: "migration",
						value: !0
					} });
					break;
				case "resume-reconnect":
					this.engine.failNext(), yield this.engine.client.handleOnClose("simulate resume-disconnect");
					break;
				case "disconnect-signal-on-resume":
					n = () => E(this, void 0, void 0, function* () {
						yield this.engine.client.handleOnClose("simulate resume-disconnect");
					}), r = new Gr({ scenario: {
						case: "disconnectSignalOnResume",
						value: !0
					} });
					break;
				case "disconnect-signal-on-resume-no-messages":
					n = () => E(this, void 0, void 0, function* () {
						yield this.engine.client.handleOnClose("simulate resume-disconnect");
					}), r = new Gr({ scenario: {
						case: "disconnectSignalOnResumeNoMessages",
						value: !0
					} });
					break;
				case "full-reconnect":
					this.engine.fullReconnectOnNext = !0, yield this.engine.client.handleOnClose("simulate full-reconnect");
					break;
				case "force-tcp":
				case "force-tls":
					r = new Gr({ scenario: {
						case: "switchCandidateProtocol",
						value: e === "force-tls" ? 2 : 1
					} }), n = () => E(this, void 0, void 0, function* () {
						let e = this.engine.client.onLeave;
						e && e(new Cr({
							reason: tn.CLIENT_INITIATED,
							action: wr.RECONNECT
						}));
					});
					break;
				case "subscriber-bandwidth":
					if (t === void 0 || typeof t != "number") throw Error("subscriber-bandwidth requires a number as argument");
					r = new Gr({ scenario: {
						case: "subscriberBandwidth",
						value: Ds(t)
					} });
					break;
				case "leave-full-reconnect": r = new Gr({ scenario: {
					case: "leaveRequestFullReconnect",
					value: !0
				} });
			}
			r && (yield this.engine.client.sendSimulateScenario(r), yield n());
		});
	}
	get canPlaybackAudio() {
		return this.audioEnabled;
	}
	get canPlaybackVideo() {
		return !this.isVideoPlaybackBlocked;
	}
	getActiveDevice(e) {
		return this.localParticipant.activeDeviceMap.get(e);
	}
	switchActiveDevice(e, t) {
		return E(this, arguments, void 0, function(e, t) {
			var n = this;
			let r = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : !0;
			return function* () {
				var i, a;
				let o = !0, s = !1, c = r ? { exact: t } : t;
				if (e === "audioinput") {
					s = n.localParticipant.audioTrackPublications.size === 0;
					let t = n.getActiveDevice(e) ?? n.options.audioCaptureDefaults.deviceId;
					n.options.audioCaptureDefaults.deviceId = c;
					let r = Array.from(n.localParticipant.audioTrackPublications.values()).filter((e) => e.source === B.Source.Microphone);
					try {
						o = (yield Promise.all(r.map((e) => e.audioTrack?.setDeviceId(c)))).every((e) => e === !0);
					} catch (e) {
						throw n.options.audioCaptureDefaults.deviceId = t, e;
					}
					let i = r.some((e) => e.track?.isMuted ?? !1);
					o && i && (s = !0);
				} else if (e === "videoinput") {
					s = n.localParticipant.videoTrackPublications.size === 0;
					let t = n.getActiveDevice(e) ?? n.options.videoCaptureDefaults.deviceId;
					n.options.videoCaptureDefaults.deviceId = c;
					let r = Array.from(n.localParticipant.videoTrackPublications.values()).filter((e) => e.source === B.Source.Camera);
					try {
						o = (yield Promise.all(r.map((e) => e.videoTrack?.setDeviceId(c)))).every((e) => e === !0);
					} catch (e) {
						throw n.options.videoCaptureDefaults.deviceId = t, e;
					}
					let i = r.some((e) => e.track?.isMuted ?? !1);
					o && i && (s = !0);
				} else if (e === "audiooutput") {
					if (s = !0, !Go() && !n.options.webAudioMix || n.options.webAudioMix && n.audioContext && !("setSinkId" in n.audioContext)) throw Error("cannot switch audio output, the current browser does not support it");
					n.options.webAudioMix && (t = (yield Ec.getInstance().normalizeDeviceId("audiooutput", t)) ?? ""), (a = n.options).audioOutput ?? (a.audioOutput = {});
					let r = n.getActiveDevice(e) ?? n.options.audioOutput.deviceId;
					n.options.audioOutput.deviceId = t;
					try {
						n.options.webAudioMix && ((i = n.audioContext) == null || i.setSinkId(t)), yield Promise.all(Array.from(n.remoteParticipants.values()).map((e) => e.setAudioOutput({ deviceId: t })));
					} catch (e) {
						throw n.options.audioOutput.deviceId = r, e;
					}
				}
				return s && (n.localParticipant.activeDeviceMap.set(e, t), n.emit(P.ActiveDeviceChanged, e, t)), o;
			}();
		});
	}
	setupLocalParticipantEvents() {
		this.localParticipant.on(F.ParticipantMetadataChanged, this.onLocalParticipantMetadataChanged).on(F.ParticipantNameChanged, this.onLocalParticipantNameChanged).on(F.AttributesChanged, this.onLocalAttributesChanged).on(F.TrackMuted, this.onLocalTrackMuted).on(F.TrackUnmuted, this.onLocalTrackUnmuted).on(F.LocalTrackPublished, this.onLocalTrackPublished).on(F.LocalTrackUnpublished, this.onLocalTrackUnpublished).on(F.ConnectionQualityChanged, this.onLocalConnectionQualityChanged).on(F.MediaDevicesError, this.onMediaDevicesError).on(F.AudioStreamAcquired, this.startAudio).on(F.ChatMessage, this.onLocalChatMessageSent).on(F.ParticipantPermissionsChanged, this.onLocalParticipantPermissionsChanged);
	}
	recreateEngine(e) {
		let t = this.engine;
		e && t && !t.client.isDisconnected ? t.client.sendLeave().finally(() => t.close()) : t?.close(), this.engine = void 0, this.isResuming = !1, this.remoteParticipants.clear(), this.sidToIdentity.clear(), this.bufferedEvents = [], this.maybeCreateEngine();
	}
	onTrackAdded(e, t, n) {
		if (this.state === Q.Connecting || this.state === Q.Reconnecting) {
			let r = () => {
				this.log.debug("deferring on track for later", {
					mediaTrackId: e.id,
					mediaStreamId: t.id,
					tracksInStream: t.getTracks().map((e) => e.id)
				}), this.onTrackAdded(e, t, n), i();
			}, i = () => {
				this.off(P.Reconnected, r), this.off(P.Connected, r), this.off(P.Disconnected, i);
			};
			this.once(P.Reconnected, r), this.once(P.Connected, r), this.once(P.Disconnected, i);
			return;
		}
		if (this.state === Q.Disconnected) {
			this.log.warn("skipping incoming track after Room disconnected");
			return;
		}
		if (e.readyState === "ended") {
			this.log.debug("skipping incoming track as it already ended");
			return;
		}
		let r = zo(t.id), i = r[0], a = r[1], o = e.id;
		if (a && a.startsWith("TR") && (o = a), i === this.localParticipant.sid) {
			this.log.warn("tried to create RemoteParticipant for local participant");
			return;
		}
		let s = Array.from(this.remoteParticipants.values()).find((e) => e.sid === i);
		if (!s) {
			i.startsWith("PA") && this.log.error(`Tried to add a track for a participant, that's not present. Sid: ${i}`);
			return;
		}
		if (!o.startsWith("TR")) {
			let e = this.engine.getTrackIdForReceiver(n);
			if (!e) {
				this.log.error(`Tried to add a track whose 'sid' could not be found for a participant, that's not present. Sid: ${i}`);
				return;
			}
			o = e;
		}
		o.startsWith("TR") || this.log.warn(`Tried to add a track whose 'sid' could not be determined for a participant, that's not present. Sid: ${i}, streamId: ${a}, trackId: ${o}`, {
			remoteParticipantID: i,
			streamId: a,
			trackId: o
		});
		let c;
		this.options.adaptiveStream && (c = typeof this.options.adaptiveStream == "object" ? this.options.adaptiveStream : {});
		let l = s.addSubscribedMediaTrack(e, o, t, n, c);
		l?.isEncrypted && !this.e2eeManager && this.emit(P.EncryptionError, /* @__PURE__ */ Error(`Encrypted ${l.source} track received from participant ${s.sid}, but room does not have encryption enabled!`));
	}
	handleLocalTrackSubscribed(e) {
		let t = () => this.localParticipant.getTrackPublications().find((t) => t.trackSid === e), n = t();
		if (n) {
			this.emitLocalTrackSubscribed(n);
			return;
		}
		this.log.debug("deferring LocalTrackSubscribed, publication not yet available", { subscribedSid: e });
		let r, i = (t) => {
			t.trackSid === e && (a(), this.emitLocalTrackSubscribed(t));
		}, a = () => {
			clearTimeout(r), this.localParticipant.off(F.LocalTrackPublished, i), this.off(P.Disconnected, a);
		};
		this.localParticipant.on(F.LocalTrackPublished, i), this.once(P.Disconnected, a), r = setTimeout(() => {
			a();
			let n = t();
			n ? this.emitLocalTrackSubscribed(n) : this.log.warn("could not find local track publication for LocalTrackSubscribed event after timeout", { subscribedSid: e });
		}, 1e4);
	}
	emitLocalTrackSubscribed(e) {
		this.localParticipant.emit(F.LocalTrackSubscribed, e), this.emitWhenConnected(P.LocalTrackSubscribed, e, this.localParticipant);
	}
	handleDisconnect() {
		let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : !0, t = arguments.length > 1 ? arguments[1] : void 0;
		var n, r;
		if (this.clearConnectionReconcile(), this.isResuming = !1, this.bufferedEvents = [], this.transcriptionReceivedTimes.clear(), this.incomingDataStreamManager.clearControllers(), this.incomingDataTrackManager.reset(), this.outgoingDataTrackManager.reset(), this.state !== Q.Disconnected) {
			this.regionUrl = void 0, this.regionUrlProvider && this.regionUrlProvider.notifyDisconnected();
			try {
				this.remoteParticipants.forEach((e) => {
					e.trackPublications.forEach((t) => {
						e.unpublishTrack(t.trackSid);
					});
				}), this.localParticipant.trackPublications.forEach((t) => {
					var n, r, i;
					t.track && this.localParticipant.unpublishTrack(t.track, e), e ? ((n = t.track) == null || n.detach(), (r = t.track) == null || r.stop()) : (i = t.track) == null || i.stopMonitor();
				}), this.localParticipant.off(F.ParticipantMetadataChanged, this.onLocalParticipantMetadataChanged).off(F.ParticipantNameChanged, this.onLocalParticipantNameChanged).off(F.AttributesChanged, this.onLocalAttributesChanged).off(F.TrackMuted, this.onLocalTrackMuted).off(F.TrackUnmuted, this.onLocalTrackUnmuted).off(F.LocalTrackPublished, this.onLocalTrackPublished).off(F.LocalTrackUnpublished, this.onLocalTrackUnpublished).off(F.ConnectionQualityChanged, this.onLocalConnectionQualityChanged).off(F.MediaDevicesError, this.onMediaDevicesError).off(F.AudioStreamAcquired, this.startAudio).off(F.ChatMessage, this.onLocalChatMessageSent).off(F.ParticipantPermissionsChanged, this.onLocalParticipantPermissionsChanged), this.localParticipant.trackPublications.clear(), this.localParticipant.videoTrackPublications.clear(), this.localParticipant.audioTrackPublications.clear(), this.remoteParticipants.clear(), this.sidToIdentity.clear(), this.activeSpeakers = [], this.audioContext && typeof this.options.webAudioMix == "boolean" && (this.audioContext.close(), this.audioContext = void 0), H() && (window.removeEventListener("beforeunload", this.onPageLeave), window.removeEventListener("pagehide", this.onPageLeave), window.removeEventListener("freeze", this.onPageLeave), (r = (n = navigator.mediaDevices)?.removeEventListener) == null || r.call(n, "devicechange", this.handleDeviceChange));
			} finally {
				this.setAndEmitConnectionState(Q.Disconnected), this.emit(P.Disconnected, t);
			}
		}
	}
	handleParticipantDisconnected(e, t) {
		this.remoteParticipants.delete(e), t && (this.incomingDataStreamManager.validateParticipantHasNoActiveDataStreams(e), this.incomingDataTrackManager.handleRemoteParticipantDisconnected(e), t.trackPublications.forEach((e) => {
			t.unpublishTrack(e.trackSid, !0);
		}), this.emit(P.ParticipantDisconnected, t), t.setDisconnected(), this.rpcClientManager.handleParticipantDisconnected(t.identity));
	}
	selectDefaultDevices() {
		return E(this, void 0, void 0, function* () {
			let e = Ec.getInstance().previousDevices, t = yield Ec.getInstance().getDevices(void 0, !1), n = O();
			if (n?.name === "Chrome" && n.os !== "iOS") for (let n of t) {
				let t = e.find((e) => e.deviceId === n.deviceId);
				t && t.label !== "" && t.kind === n.kind && t.label !== n.label && this.getActiveDevice(n.kind) === "default" && this.emit(P.ActiveDeviceChanged, n.kind, n.deviceId);
			}
			for (let n of [
				"audiooutput",
				"audioinput",
				"videoinput"
			]) {
				let r = xo(n), i = this.localParticipant.getTrackPublication(r);
				if (i && i.track?.isUserProvided) continue;
				let a = t.filter((e) => e.kind === n), o = this.getActiveDevice(n);
				if (o === e.filter((e) => e.kind === n)[0]?.deviceId && a.length > 0 && a[0]?.deviceId !== o) {
					yield this.switchActiveDevice(n, a[0].deviceId);
					continue;
				}
				n === "audioinput" && !Zo() || n === "videoinput" || a.length > 0 && !a.find((e) => e.deviceId === this.getActiveDevice(n)) && (n !== "audiooutput" || !Zo()) && (yield this.switchActiveDevice(n, a[0].deviceId));
			}
		});
	}
	acquireAudioContext() {
		return E(this, void 0, void 0, function* () {
			if (typeof this.options.webAudioMix != "boolean" && this.options.webAudioMix.audioContext ? this.audioContext = this.options.webAudioMix.audioContext : (!this.audioContext || this.audioContext.state === "closed") && (this.audioContext = bo() ?? void 0), this.options.webAudioMix && this.remoteParticipants.forEach((e) => e.setAudioContext(this.audioContext)), this.localParticipant.setAudioContext(this.audioContext), this.audioContext && this.audioContext.state === "suspended") try {
				yield Promise.race([this.audioContext.resume(), V(200)]);
			} catch (e) {
				this.log.warn("Could not resume audio context", { error: e });
			}
			let e = this.audioContext?.state === "running";
			e !== this.canPlaybackAudio && (this.audioEnabled = e, this.emit(P.AudioPlaybackStatusChanged, e));
		});
	}
	createParticipant(e, t) {
		let n;
		return n = t ? af.fromParticipantInfo(this.engine.client, t, {
			loggerContextCb: () => this.logContext,
			loggerName: this.options.loggerName
		}, this.incomingDataTrackManager) : new af(this.engine.client, "", e, void 0, void 0, void 0, {
			loggerContextCb: () => this.logContext,
			loggerName: this.options.loggerName
		}), this.options.webAudioMix && n.setAudioContext(this.audioContext), this.options.audioOutput?.deviceId && n.setAudioOutput(this.options.audioOutput).catch((e) => this.log.warn(`Could not set audio output: ${e.message}`)), n;
	}
	getOrCreateParticipant(e, t) {
		if (this.remoteParticipants.has(e)) {
			let n = this.remoteParticipants.get(e);
			return t && n.updateInfo(t) && this.sidToIdentity.set(t.sid, t.identity), n;
		}
		let n = this.createParticipant(e, t);
		return this.remoteParticipants.set(e, n), this.sidToIdentity.set(t.sid, t.identity), this.emitWhenConnected(P.ParticipantConnected, n), n.on(F.TrackPublished, (e) => {
			this.emitWhenConnected(P.TrackPublished, e, n);
		}).on(F.TrackSubscribed, (e, t) => {
			e.kind === B.Kind.Audio ? (e.on(L.AudioPlaybackStarted, this.handleAudioPlaybackStarted), e.on(L.AudioPlaybackFailed, this.handleAudioPlaybackFailed)) : e.kind === B.Kind.Video && (e.on(L.VideoPlaybackFailed, this.handleVideoPlaybackFailed), e.on(L.VideoPlaybackStarted, this.handleVideoPlaybackStarted)), this.emitWhenConnected(P.TrackSubscribed, e, t, n);
		}).on(F.TrackUnpublished, (e) => {
			this.emit(P.TrackUnpublished, e, n);
		}).on(F.TrackUnsubscribed, (e, t) => {
			this.emit(P.TrackUnsubscribed, e, t, n);
		}).on(F.TrackMuted, (e) => {
			this.emitWhenConnected(P.TrackMuted, e, n);
		}).on(F.TrackUnmuted, (e) => {
			this.emitWhenConnected(P.TrackUnmuted, e, n);
		}).on(F.ParticipantMetadataChanged, (e) => {
			this.emitWhenConnected(P.ParticipantMetadataChanged, e, n);
		}).on(F.ParticipantNameChanged, (e) => {
			this.emitWhenConnected(P.ParticipantNameChanged, e, n);
		}).on(F.AttributesChanged, (e) => {
			this.emitWhenConnected(P.ParticipantAttributesChanged, e, n);
		}).on(F.ConnectionQualityChanged, (e) => {
			this.emitWhenConnected(P.ConnectionQualityChanged, e, n);
		}).on(F.ParticipantPermissionsChanged, (e) => {
			this.emitWhenConnected(P.ParticipantPermissionsChanged, e, n);
		}).on(F.TrackSubscriptionStatusChanged, (e, t) => {
			this.emitWhenConnected(P.TrackSubscriptionStatusChanged, e, t, n);
		}).on(F.TrackSubscriptionFailed, (e, t) => {
			this.emit(P.TrackSubscriptionFailed, e, n, t);
		}).on(F.TrackSubscriptionPermissionChanged, (e, t) => {
			this.emitWhenConnected(P.TrackSubscriptionPermissionChanged, e, t, n);
		}).on(F.Active, () => {
			this.emitWhenConnected(P.ParticipantActive, n), n.kind === dn.AGENT && this.localParticipant.setActiveAgent(n);
		}), t && n.updateInfo(t), n;
	}
	sendSyncState() {
		let e = Array.from(this.remoteParticipants.values()).reduce((e, t) => (e.push(...t.getTrackPublications()), e), []), t = this.localParticipant.getTrackPublications(), n = this.outgoingDataTrackManager.queryPublished();
		this.engine.sendSyncState(e, t, n);
	}
	updateSubscriptions() {
		for (let e of this.remoteParticipants.values()) for (let t of e.videoTrackPublications.values()) t.isSubscribed && Ps(t) && t.emitTrackUpdate();
	}
	getRemoteParticipantBySid(e) {
		let t = this.sidToIdentity.get(e);
		if (t) return this.remoteParticipants.get(t);
	}
	registerRpcDataStreamHandler() {
		this.incomingDataStreamManager.registerTextStreamHandler(Fd, (e, t) => E(this, [e, t], void 0, function(e, t) {
			var n = this;
			let r = t.identity;
			return function* () {
				let t = e.info.attributes ?? {};
				yield n.rpcServerManager.handleIncomingDataStream(e, r, t);
			}();
		})), this.incomingDataStreamManager.registerTextStreamHandler(Id, (e, t) => E(this, [e, t], void 0, function(e, t) {
			var n = this;
			let r = t.identity;
			return function* () {
				let t = e.info.attributes ?? {};
				yield n.rpcClientManager.handleIncomingDataStream(e, r, t);
			}();
		}));
	}
	registerConnectionReconcile() {
		this.clearConnectionReconcile();
		let e = 0;
		this.connectionReconcileInterval = N.setInterval(() => {
			!this.engine || this.engine.isClosed || !this.engine.verifyTransport() ? (e++, this.log.warn("detected connection state mismatch", {
				numFailures: e,
				engine: this.engine ? {
					closed: this.engine.isClosed,
					transportsConnectedOrConnecting: this.engine.verifyTransport()
				} : void 0
			}), e >= 3 && (this.recreateEngine(), this.handleDisconnect(this.options.stopLocalTrackOnUnpublish, tn.STATE_MISMATCH))) : e = 0;
		}, of);
	}
	clearConnectionReconcile() {
		this.connectionReconcileInterval && N.clearInterval(this.connectionReconcileInterval);
	}
	setAndEmitConnectionState(e) {
		return e === this.state ? !1 : (this.log.info(`connection state changed: ${this.state} -> ${e}`), this.state = e, this.incomingDataStreamManager.setConnected(e === Q.Connected), this.emit(P.ConnectionStateChanged, this.state), !0);
	}
	emitBufferedEvents() {
		this.bufferedEvents.forEach((e) => {
			let t = g(e, 2), n = t[0], r = t[1];
			this.emit(n, ...r);
		}), this.bufferedEvents = [];
	}
	emitWhenConnected(e) {
		var t = [...arguments].slice(1);
		if (this.state === Q.Reconnecting || this.isResuming || !this.engine || this.engine.pendingReconnect) this.bufferedEvents.push([e, t]);
		else if (this.state === Q.Connected) return this.emit(e, ...t);
		return !1;
	}
	simulateParticipants(e) {
		return E(this, void 0, void 0, function* () {
			let t = Object.assign({
				audio: !0,
				video: !0,
				useRealTracks: !1
			}, e.publish), n = Object.assign({
				count: 9,
				audio: !1,
				video: !0,
				aspectRatios: [
					1.66,
					1.7,
					1.3
				]
			}, e.participants);
			if (this.handleDisconnect(), this.roomInfo = new on({
				sid: "RM_SIMULATED",
				name: "simulated-room",
				emptyTimeout: 0,
				maxParticipants: 0,
				creationTime: p.parse((/* @__PURE__ */ new Date()).getTime()),
				metadata: "",
				numParticipants: 1,
				numPublishers: 1,
				turnPassword: "",
				enabledCodecs: [],
				activeRecording: !1
			}), this.localParticipant.updateInfo(new ln({
				identity: "simulated-local",
				name: "local-name"
			})), this.setupLocalParticipantEvents(), this.emit(P.SignalConnected), this.emit(P.Connected), this.setAndEmitConnectionState(Q.Connected), t.video) {
				let e = new Gd(B.Kind.Video, new mn({
					source: y.CAMERA,
					sid: Math.floor(Math.random() * 1e4).toString(),
					type: Zt.AUDIO,
					name: "video-dummy"
				}), new Zl(t.useRealTracks && window.navigator.mediaDevices?.getUserMedia ? (yield window.navigator.mediaDevices.getUserMedia({ video: !0 })).getVideoTracks()[0] : gs(160 * (n.aspectRatios[0] ?? 1), 160, !0, !0), void 0, !1, {
					loggerName: this.options.loggerName,
					loggerContextCb: () => this.logContext
				}), {
					loggerName: this.options.loggerName,
					loggerContextCb: () => this.logContext
				});
				this.localParticipant.addTrackPublication(e), this.localParticipant.emit(F.LocalTrackPublished, e);
			}
			if (t.audio) {
				let e = new Gd(B.Kind.Audio, new mn({
					source: y.MICROPHONE,
					sid: Math.floor(Math.random() * 1e4).toString(),
					type: Zt.AUDIO
				}), new Ml(t.useRealTracks && navigator.mediaDevices?.getUserMedia ? (yield navigator.mediaDevices.getUserMedia({ audio: !0 })).getAudioTracks()[0] : vs(), void 0, !1, this.audioContext, {
					loggerName: this.options.loggerName,
					loggerContextCb: () => this.logContext
				}), {
					loggerName: this.options.loggerName,
					loggerContextCb: () => this.logContext
				});
				this.localParticipant.addTrackPublication(e), this.localParticipant.emit(F.LocalTrackPublished, e);
			}
			for (let e = 0; e < n.count - 1; e += 1) {
				let t = new ln({
					sid: Math.floor(Math.random() * 1e4).toString(),
					identity: `simulated-${e}`,
					state: un.ACTIVE,
					tracks: [],
					joinedAt: p.parse(Date.now())
				}), r = this.getOrCreateParticipant(t.identity, t);
				if (n.video) {
					let i = gs(160 * (n.aspectRatios[e % n.aspectRatios.length] ?? 1), 160, !1, !0), a = new mn({
						source: y.CAMERA,
						sid: Math.floor(Math.random() * 1e4).toString(),
						type: Zt.AUDIO
					});
					r.addSubscribedMediaTrack(i, a.sid, new MediaStream([i]), new RTCRtpReceiver()), t.tracks = [...t.tracks, a];
				}
				if (n.audio) {
					let e = vs(), n = new mn({
						source: y.MICROPHONE,
						sid: Math.floor(Math.random() * 1e4).toString(),
						type: Zt.AUDIO
					});
					r.addSubscribedMediaTrack(e, n.sid, new MediaStream([e]), new RTCRtpReceiver()), t.tracks = [...t.tracks, n];
				}
				r.updateInfo(t);
			}
		});
	}
	emit(e) {
		var t = [...arguments].slice(1);
		if (e !== P.ActiveSpeakersChanged && e !== P.TranscriptionReceived) {
			let n = cf(t).filter((e) => e !== void 0);
			(e === P.TrackSubscribed || e === P.TrackUnsubscribed) && this.log.trace(`subscribe trace: ${e}`, {
				event: e,
				args: n
			}), this.log.debug(`room event ${e}`, {
				event: e,
				args: n
			});
		}
		return super.emit(e, ...t);
	}
};
sf.cleanupRegistry = typeof FinalizationRegistry < "u" && typeof WeakRef < "u" && new FinalizationRegistry((e) => {
	e();
});
function cf(e) {
	return e.map((e) => {
		if (e) return Array.isArray(e) ? cf(e) : typeof e == "object" ? "logContext" in e ? e.logContext : void 0 : e;
	});
}
var lf;
(function(e) {
	e[e.IDLE = 0] = "IDLE", e[e.RUNNING = 1] = "RUNNING", e[e.SKIPPED = 2] = "SKIPPED", e[e.SUCCESS = 3] = "SUCCESS", e[e.FAILED = 4] = "FAILED";
})(lf ||= {}), Oi.EventEmitter, Oi.EventEmitter, new TextEncoder(), new TextDecoder();
var $ = class extends Error {
	constructor(e, t) {
		var n;
		super(e, t), h(this, "code", "ERR_JOSE_GENERIC"), this.name = this.constructor.name, (n = Error.captureStackTrace) == null || n.call(Error, this, this.constructor);
	}
};
h($, "code", "ERR_JOSE_GENERIC"), h(class extends $ {
	constructor(e, t) {
		let n = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : "unspecified", r = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : "unspecified";
		super(e, { cause: {
			claim: n,
			reason: r,
			payload: t
		} }), h(this, "code", "ERR_JWT_CLAIM_VALIDATION_FAILED"), h(this, "claim", void 0), h(this, "reason", void 0), h(this, "payload", void 0), this.claim = n, this.reason = r, this.payload = t;
	}
}, "code", "ERR_JWT_CLAIM_VALIDATION_FAILED"), h(class extends $ {
	constructor(e, t) {
		let n = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : "unspecified", r = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : "unspecified";
		super(e, { cause: {
			claim: n,
			reason: r,
			payload: t
		} }), h(this, "code", "ERR_JWT_EXPIRED"), h(this, "claim", void 0), h(this, "reason", void 0), h(this, "payload", void 0), this.claim = n, this.reason = r, this.payload = t;
	}
}, "code", "ERR_JWT_EXPIRED"), h(class extends $ {
	constructor() {
		super(...arguments), h(this, "code", "ERR_JOSE_ALG_NOT_ALLOWED");
	}
}, "code", "ERR_JOSE_ALG_NOT_ALLOWED"), h(class extends $ {
	constructor() {
		super(...arguments), h(this, "code", "ERR_JOSE_NOT_SUPPORTED");
	}
}, "code", "ERR_JOSE_NOT_SUPPORTED"), h(class extends $ {
	constructor() {
		let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "decryption operation failed", t = arguments.length > 1 ? arguments[1] : void 0;
		super(e, t), h(this, "code", "ERR_JWE_DECRYPTION_FAILED");
	}
}, "code", "ERR_JWE_DECRYPTION_FAILED"), h(class extends $ {
	constructor() {
		super(...arguments), h(this, "code", "ERR_JWE_INVALID");
	}
}, "code", "ERR_JWE_INVALID"), h(class extends $ {
	constructor() {
		super(...arguments), h(this, "code", "ERR_JWS_INVALID");
	}
}, "code", "ERR_JWS_INVALID"), h(class extends $ {
	constructor() {
		super(...arguments), h(this, "code", "ERR_JWT_INVALID");
	}
}, "code", "ERR_JWT_INVALID"), h(class extends $ {
	constructor() {
		super(...arguments), h(this, "code", "ERR_JWK_INVALID");
	}
}, "code", "ERR_JWK_INVALID"), h(class extends $ {
	constructor() {
		super(...arguments), h(this, "code", "ERR_JWKS_INVALID");
	}
}, "code", "ERR_JWKS_INVALID"), h(class extends $ {
	constructor() {
		let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "no applicable key found in the JSON Web Key Set", t = arguments.length > 1 ? arguments[1] : void 0;
		super(e, t), h(this, "code", "ERR_JWKS_NO_MATCHING_KEY");
	}
}, "code", "ERR_JWKS_NO_MATCHING_KEY"), h(class extends $ {
	constructor() {
		let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "multiple matching keys found in the JSON Web Key Set", t = arguments.length > 1 ? arguments[1] : void 0;
		super(e, t), h(this, Symbol.asyncIterator, void 0), h(this, "code", "ERR_JWKS_MULTIPLE_MATCHING_KEYS");
	}
}, "code", "ERR_JWKS_MULTIPLE_MATCHING_KEYS"), h(class extends $ {
	constructor() {
		let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "request timed out", t = arguments.length > 1 ? arguments[1] : void 0;
		super(e, t), h(this, "code", "ERR_JWKS_TIMEOUT");
	}
}, "code", "ERR_JWKS_TIMEOUT"), h(class extends $ {
	constructor() {
		let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "signature verification failed", t = arguments.length > 1 ? arguments[1] : void 0;
		super(e, t), h(this, "code", "ERR_JWS_SIGNATURE_VERIFICATION_FAILED");
	}
}, "code", "ERR_JWS_SIGNATURE_VERIFICATION_FAILED");
//#endregion
export { Yd as _, Ml as a, mi as b, F as c, mc as d, sf as f, Jd as g, mo as h, tn as i, Ud as l, B as m, Xd as n, Zl as o, P as p, Q as r, di as s, fo as t, af as u, qd as v, T as y };

//# sourceMappingURL=livekit-client.esm-C4uopDNI.js.map