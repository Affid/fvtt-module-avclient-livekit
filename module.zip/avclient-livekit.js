//#region \0rolldown/runtime.js
var e = Object.create, t = Object.defineProperty, n = Object.getOwnPropertyDescriptor, r = Object.getOwnPropertyNames, i = Object.getPrototypeOf, a = Object.prototype.hasOwnProperty, o = (e, t) => () => (t || (e((t = { exports: {} }).exports, t), e = null), t.exports), s = (e, i, o, s) => {
	if (i && typeof i == "object" || typeof i == "function") for (var c = r(i), l = 0, u = c.length, d; l < u; l++) d = c[l], !a.call(e, d) && d !== o && t(e, d, {
		get: ((e) => i[e]).bind(null, d),
		enumerable: !(s = n(i, d)) || s.enumerable
	});
	return e;
}, c = (n, r, a) => (a = n == null ? {} : e(i(n)), s(r || !n || !n.__esModule ? t(a, "default", {
	value: n,
	enumerable: !0
}) : a, n)), l = "avclient-livekit", u = "LIVEKITAVCLIENT", d = "https://patreon-auth.tavern.at", f = /* @__PURE__ */ o(((e, t) => {
	var n = 1e3, r = n * 60, i = r * 60, a = i * 24, o = a * 7, s = a * 365.25;
	t.exports = function(e, t) {
		t ||= {};
		var n = typeof e;
		if (n === "string" && e.length > 0) return c(e);
		if (n === "number" && isFinite(e)) return t.long ? u(e) : l(e);
		throw Error("val is not a non-empty string or a valid number. val=" + JSON.stringify(e));
	};
	function c(e) {
		if (e = String(e), !(e.length > 100)) {
			var t = /^(-?(?:\d+)?\.?\d+) *(milliseconds?|msecs?|ms|seconds?|secs?|s|minutes?|mins?|m|hours?|hrs?|h|days?|d|weeks?|w|years?|yrs?|y)?$/i.exec(e);
			if (t) {
				var c = parseFloat(t[1]);
				switch ((t[2] || "ms").toLowerCase()) {
					case "years":
					case "year":
					case "yrs":
					case "yr":
					case "y": return c * s;
					case "weeks":
					case "week":
					case "w": return c * o;
					case "days":
					case "day":
					case "d": return c * a;
					case "hours":
					case "hour":
					case "hrs":
					case "hr":
					case "h": return c * i;
					case "minutes":
					case "minute":
					case "mins":
					case "min":
					case "m": return c * r;
					case "seconds":
					case "second":
					case "secs":
					case "sec":
					case "s": return c * n;
					case "milliseconds":
					case "millisecond":
					case "msecs":
					case "msec":
					case "ms": return c;
					default: return;
				}
			}
		}
	}
	function l(e) {
		var t = Math.abs(e);
		return t >= a ? Math.round(e / a) + "d" : t >= i ? Math.round(e / i) + "h" : t >= r ? Math.round(e / r) + "m" : t >= n ? Math.round(e / n) + "s" : e + "ms";
	}
	function u(e) {
		var t = Math.abs(e);
		return t >= a ? d(e, t, a, "day") : t >= i ? d(e, t, i, "hour") : t >= r ? d(e, t, r, "minute") : t >= n ? d(e, t, n, "second") : e + " ms";
	}
	function d(e, t, n, r) {
		var i = t >= n * 1.5;
		return Math.round(e / n) + " " + r + (i ? "s" : "");
	}
})), ee = /* @__PURE__ */ o(((e, t) => {
	function n(e) {
		n.debug = n, n.default = n, n.coerce = c, n.disable = o, n.enable = i, n.enabled = s, n.humanize = f(), n.destroy = l, Object.keys(e).forEach((t) => {
			n[t] = e[t];
		}), n.names = [], n.skips = [], n.formatters = {};
		function t(e) {
			let t = 0;
			for (let n = 0; n < e.length; n++) t = (t << 5) - t + e.charCodeAt(n), t |= 0;
			return n.colors[Math.abs(t) % n.colors.length];
		}
		n.selectColor = t;
		function n(e) {
			let t, i = null, a, o;
			function s(...e) {
				if (!s.enabled) return;
				let r = s, i = Number(/* @__PURE__ */ new Date());
				r.diff = i - (t || i), r.prev = t, r.curr = i, t = i, e[0] = n.coerce(e[0]), typeof e[0] != "string" && e.unshift("%O");
				let a = 0;
				e[0] = e[0].replace(/%([a-zA-Z%])/g, (t, i) => {
					if (t === "%%") return "%";
					a++;
					let o = n.formatters[i];
					if (typeof o == "function") {
						let n = e[a];
						t = o.call(r, n), e.splice(a, 1), a--;
					}
					return t;
				}), n.formatArgs.call(r, e), (r.log || n.log).apply(r, e);
			}
			return s.namespace = e, s.useColors = n.useColors(), s.color = n.selectColor(e), s.extend = r, s.destroy = n.destroy, Object.defineProperty(s, "enabled", {
				enumerable: !0,
				configurable: !1,
				get: () => i === null ? (a !== n.namespaces && (a = n.namespaces, o = n.enabled(e)), o) : i,
				set: (e) => {
					i = e;
				}
			}), typeof n.init == "function" && n.init(s), s;
		}
		function r(e, t) {
			let r = n(this.namespace + (t === void 0 ? ":" : t) + e);
			return r.log = this.log, r;
		}
		function i(e) {
			n.save(e), n.namespaces = e, n.names = [], n.skips = [];
			let t = (typeof e == "string" ? e : "").trim().replace(/\s+/g, ",").split(",").filter(Boolean);
			for (let e of t) e[0] === "-" ? n.skips.push(e.slice(1)) : n.names.push(e);
		}
		function a(e, t) {
			let n = 0, r = 0, i = -1, a = 0;
			for (; n < e.length;) if (r < t.length && (t[r] === e[n] || t[r] === "*")) t[r] === "*" ? (i = r, a = n, r++) : (n++, r++);
			else if (i !== -1) r = i + 1, a++, n = a;
			else return !1;
			for (; r < t.length && t[r] === "*";) r++;
			return r === t.length;
		}
		function o() {
			let e = [...n.names, ...n.skips.map((e) => "-" + e)].join(",");
			return n.enable(""), e;
		}
		function s(e) {
			for (let t of n.skips) if (a(e, t)) return !1;
			for (let t of n.names) if (a(e, t)) return !0;
			return !1;
		}
		function c(e) {
			return e instanceof Error ? e.stack || e.message : e;
		}
		function l() {
			console.warn("Instance method `debug.destroy()` is deprecated and no longer does anything. It will be removed in the next major version of `debug`.");
		}
		return n.enable(n.load()), n;
	}
	t.exports = n;
})), p = /* @__PURE__ */ c((/* @__PURE__ */ o(((e, t) => {
	e.formatArgs = r, e.save = i, e.load = a, e.useColors = n, e.storage = o(), e.destroy = (() => {
		let e = !1;
		return () => {
			e || (e = !0, console.warn("Instance method `debug.destroy()` is deprecated and no longer does anything. It will be removed in the next major version of `debug`."));
		};
	})(), e.colors = /* @__PURE__ */ "#0000CC.#0000FF.#0033CC.#0033FF.#0066CC.#0066FF.#0099CC.#0099FF.#00CC00.#00CC33.#00CC66.#00CC99.#00CCCC.#00CCFF.#3300CC.#3300FF.#3333CC.#3333FF.#3366CC.#3366FF.#3399CC.#3399FF.#33CC00.#33CC33.#33CC66.#33CC99.#33CCCC.#33CCFF.#6600CC.#6600FF.#6633CC.#6633FF.#66CC00.#66CC33.#9900CC.#9900FF.#9933CC.#9933FF.#99CC00.#99CC33.#CC0000.#CC0033.#CC0066.#CC0099.#CC00CC.#CC00FF.#CC3300.#CC3333.#CC3366.#CC3399.#CC33CC.#CC33FF.#CC6600.#CC6633.#CC9900.#CC9933.#CCCC00.#CCCC33.#FF0000.#FF0033.#FF0066.#FF0099.#FF00CC.#FF00FF.#FF3300.#FF3333.#FF3366.#FF3399.#FF33CC.#FF33FF.#FF6600.#FF6633.#FF9900.#FF9933.#FFCC00.#FFCC33".split(".");
	function n() {
		if (typeof window < "u" && window.process && (window.process.type === "renderer" || window.process.__nwjs)) return !0;
		if (typeof navigator < "u" && navigator.userAgent && navigator.userAgent.toLowerCase().match(/(edge|trident)\/(\d+)/)) return !1;
		let e;
		return typeof document < "u" && document.documentElement && document.documentElement.style && document.documentElement.style.WebkitAppearance || typeof window < "u" && window.console && (window.console.firebug || window.console.exception && window.console.table) || typeof navigator < "u" && navigator.userAgent && (e = navigator.userAgent.toLowerCase().match(/firefox\/(\d+)/)) && parseInt(e[1], 10) >= 31 || typeof navigator < "u" && navigator.userAgent && navigator.userAgent.toLowerCase().match(/applewebkit\/(\d+)/);
	}
	function r(e) {
		if (e[0] = (this.useColors ? "%c" : "") + this.namespace + (this.useColors ? " %c" : " ") + e[0] + (this.useColors ? "%c " : " ") + "+" + t.exports.humanize(this.diff), !this.useColors) return;
		let n = "color: " + this.color;
		e.splice(1, 0, n, "color: inherit");
		let r = 0, i = 0;
		e[0].replace(/%[a-zA-Z%]/g, (e) => {
			e !== "%%" && (r++, e === "%c" && (i = r));
		}), e.splice(i, 0, n);
	}
	e.log = console.debug || console.log || (() => {});
	function i(t) {
		try {
			t ? e.storage.setItem("debug", t) : e.storage.removeItem("debug");
		} catch {}
	}
	function a() {
		let t;
		try {
			t = e.storage.getItem("debug") || e.storage.getItem("DEBUG");
		} catch {}
		return !t && typeof process < "u" && "env" in process && (t = process.env.DEBUG), t;
	}
	function o() {
		try {
			return localStorage;
		} catch {}
	}
	t.exports = ee()(e);
	var { formatters: s } = t.exports;
	s.j = function(e) {
		try {
			return JSON.stringify(e);
		} catch (e) {
			return "[UnexpectedJSONParseError]: " + e.message;
		}
	};
})))(), 1), m = class {
	_trace;
	_debug;
	_info;
	_warn;
	_error;
	constructor(e) {
		e ? (this._trace = (0, p.debug)(`${l}:TRACE:${e}`), this._debug = (0, p.debug)(`${l}:DEBUG:${e}`), this._info = (0, p.debug)(`${l}:INFO:${e}`), this._warn = (0, p.debug)(`${l}:WARN:${e}`), this._error = (0, p.debug)(`${l}:ERROR:${e}`)) : (this._trace = (0, p.debug)(`${l}:TRACE`), this._debug = (0, p.debug)(`${l}:DEBUG`), this._info = (0, p.debug)(`${l}:INFO`), this._warn = (0, p.debug)(`${l}:WARN`), this._error = (0, p.debug)(`${l}:ERROR`)), this._trace.log = console.trace.bind(console), this._debug.log = console.debug.bind(console), this._info.log = console.info.bind(console), this._warn.log = console.warn.bind(console), this._error.log = console.error.bind(console);
	}
	get trace() {
		return this._trace;
	}
	get debug() {
		return this._debug;
	}
	get info() {
		return this._info;
	}
	get warn() {
		return this._warn;
	}
	get error() {
		return this._error;
	}
}, te = new m(), ne = foundry.utils.debounce(() => {
	window.location.reload();
}, 100);
foundry.utils.debounce(() => game.webrtc?.render(), 200);
var re = foundry.utils.debounce((e) => {
	ui.webrtc?.render({ parts: [e] }).catch((e) => {
		te.error("Error refreshing user view:", e);
	});
}, 200);
function ie(e) {
	let t = `modules/${l}/${e}`, n = foundry.utils?.getRoute;
	return typeof n == "function" ? n(t) : `/${t}`;
}
function ae(e) {
	if (e.state !== "suspended") return;
	let t = () => {
		e.state === "suspended" && e.resume().catch((e) => {
			te.warn("Unable to resume audio context:", e);
		});
	};
	for (let e of ["pointerdown", "keydown"]) window.addEventListener(e, t, {
		once: !0,
		capture: !0
	});
	t();
}
function oe(e) {
	game.ready ? (te.debug("callWhenReady now", e), e()) : (te.debug("callWhenReady ready", e), Hooks.once("ready", e));
}
//#endregion
//#region node_modules/.pnpm/jose@6.2.3/node_modules/jose/dist/webapi/lib/buffer_utils.js
var se = new TextEncoder(), ce = new TextDecoder();
function le(...e) {
	let t = e.reduce((e, { length: t }) => e + t, 0), n = new Uint8Array(t), r = 0;
	for (let t of e) n.set(t, r), r += t.length;
	return n;
}
function ue(e) {
	let t = new Uint8Array(e.length);
	for (let n = 0; n < e.length; n++) {
		let r = e.charCodeAt(n);
		if (r > 127) throw TypeError("non-ASCII string encountered in encode()");
		t[n] = r;
	}
	return t;
}
//#endregion
//#region node_modules/.pnpm/jose@6.2.3/node_modules/jose/dist/webapi/lib/base64.js
function de(e) {
	if (Uint8Array.prototype.toBase64) return e.toBase64();
	let t = 32768, n = [];
	for (let r = 0; r < e.length; r += t) n.push(String.fromCharCode.apply(null, e.subarray(r, r + t)));
	return btoa(n.join(""));
}
function fe(e) {
	if (Uint8Array.fromBase64) return Uint8Array.fromBase64(e);
	let t = atob(e), n = new Uint8Array(t.length);
	for (let e = 0; e < t.length; e++) n[e] = t.charCodeAt(e);
	return n;
}
//#endregion
//#region node_modules/.pnpm/jose@6.2.3/node_modules/jose/dist/webapi/util/base64url.js
function pe(e) {
	if (Uint8Array.fromBase64) return Uint8Array.fromBase64(typeof e == "string" ? e : ce.decode(e), { alphabet: "base64url" });
	let t = e;
	t instanceof Uint8Array && (t = ce.decode(t)), t = t.replace(/-/g, "+").replace(/_/g, "/");
	try {
		return fe(t);
	} catch {
		throw TypeError("The input to be decoded is not correctly encoded.");
	}
}
function me(e) {
	let t = e;
	return typeof t == "string" && (t = se.encode(t)), Uint8Array.prototype.toBase64 ? t.toBase64({
		alphabet: "base64url",
		omitPadding: !0
	}) : de(t).replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_");
}
//#endregion
//#region node_modules/.pnpm/jose@6.2.3/node_modules/jose/dist/webapi/lib/crypto_key.js
var he = (e, t = "algorithm.name") => /* @__PURE__ */ TypeError(`CryptoKey does not support this operation, its ${t} must be ${e}`), ge = (e, t) => e.name === t;
function _e(e) {
	return parseInt(e.name.slice(4), 10);
}
function ve(e, t) {
	if (_e(e.hash) !== t) throw he(`SHA-${t}`, "algorithm.hash");
}
function ye(e) {
	switch (e) {
		case "ES256": return "P-256";
		case "ES384": return "P-384";
		case "ES512": return "P-521";
		default: throw Error("unreachable");
	}
}
function be(e, t) {
	if (t && !e.usages.includes(t)) throw TypeError(`CryptoKey does not support this operation, its usages must include ${t}.`);
}
function xe(e, t, n) {
	switch (t) {
		case "HS256":
		case "HS384":
		case "HS512":
			if (!ge(e.algorithm, "HMAC")) throw he("HMAC");
			ve(e.algorithm, parseInt(t.slice(2), 10));
			break;
		case "RS256":
		case "RS384":
		case "RS512":
			if (!ge(e.algorithm, "RSASSA-PKCS1-v1_5")) throw he("RSASSA-PKCS1-v1_5");
			ve(e.algorithm, parseInt(t.slice(2), 10));
			break;
		case "PS256":
		case "PS384":
		case "PS512":
			if (!ge(e.algorithm, "RSA-PSS")) throw he("RSA-PSS");
			ve(e.algorithm, parseInt(t.slice(2), 10));
			break;
		case "Ed25519":
		case "EdDSA":
			if (!ge(e.algorithm, "Ed25519")) throw he("Ed25519");
			break;
		case "ML-DSA-44":
		case "ML-DSA-65":
		case "ML-DSA-87":
			if (!ge(e.algorithm, t)) throw he(t);
			break;
		case "ES256":
		case "ES384":
		case "ES512": {
			if (!ge(e.algorithm, "ECDSA")) throw he("ECDSA");
			let n = ye(t);
			if (e.algorithm.namedCurve !== n) throw he(n, "algorithm.namedCurve");
			break;
		}
		default: throw TypeError("CryptoKey does not support this operation");
	}
	be(e, n);
}
//#endregion
//#region node_modules/.pnpm/jose@6.2.3/node_modules/jose/dist/webapi/lib/invalid_key_input.js
function Se(e, t, ...n) {
	if (n = n.filter(Boolean), n.length > 2) {
		let t = n.pop();
		e += `one of type ${n.join(", ")}, or ${t}.`;
	} else n.length === 2 ? e += `one of type ${n[0]} or ${n[1]}.` : e += `of type ${n[0]}.`;
	return t == null ? e += ` Received ${t}` : typeof t == "function" && t.name ? e += ` Received function ${t.name}` : typeof t == "object" && t && t.constructor?.name && (e += ` Received an instance of ${t.constructor.name}`), e;
}
var Ce = (e, ...t) => Se("Key must be ", e, ...t), we = (e, t, ...n) => Se(`Key for the ${e} algorithm must be `, t, ...n), Te = class extends Error {
	static code = "ERR_JOSE_GENERIC";
	code = "ERR_JOSE_GENERIC";
	constructor(e, t) {
		super(e, t), this.name = this.constructor.name, Error.captureStackTrace?.(this, this.constructor);
	}
}, Ee = class extends Te {
	static code = "ERR_JOSE_NOT_SUPPORTED";
	code = "ERR_JOSE_NOT_SUPPORTED";
}, De = class extends Te {
	static code = "ERR_JWS_INVALID";
	code = "ERR_JWS_INVALID";
}, Oe = class extends Te {
	static code = "ERR_JWT_INVALID";
	code = "ERR_JWT_INVALID";
}, ke = (e) => {
	if (e?.[Symbol.toStringTag] === "CryptoKey") return !0;
	try {
		return e instanceof CryptoKey;
	} catch {
		return !1;
	}
}, Ae = (e) => e?.[Symbol.toStringTag] === "KeyObject", je = (e) => ke(e) || Ae(e);
//#endregion
//#region node_modules/.pnpm/jose@6.2.3/node_modules/jose/dist/webapi/lib/helpers.js
function Me(e, t) {
	if (e) throw TypeError(`${t} can only be called once`);
}
//#endregion
//#region node_modules/.pnpm/jose@6.2.3/node_modules/jose/dist/webapi/lib/type_checks.js
var Ne = (e) => typeof e == "object" && !!e;
function Pe(e) {
	if (!Ne(e) || Object.prototype.toString.call(e) !== "[object Object]") return !1;
	if (Object.getPrototypeOf(e) === null) return !0;
	let t = e;
	for (; Object.getPrototypeOf(t) !== null;) t = Object.getPrototypeOf(t);
	return Object.getPrototypeOf(e) === t;
}
function Fe(...e) {
	let t = e.filter(Boolean);
	if (t.length === 0 || t.length === 1) return !0;
	let n;
	for (let e of t) {
		let t = Object.keys(e);
		if (!n || n.size === 0) {
			n = new Set(t);
			continue;
		}
		for (let e of t) {
			if (n.has(e)) return !1;
			n.add(e);
		}
	}
	return !0;
}
var Ie = (e) => Pe(e) && typeof e.kty == "string", Le = (e) => e.kty !== "oct" && (e.kty === "AKP" && typeof e.priv == "string" || typeof e.d == "string"), Re = (e) => e.kty !== "oct" && e.d === void 0 && e.priv === void 0, ze = (e) => e.kty === "oct" && typeof e.k == "string";
//#endregion
//#region node_modules/.pnpm/jose@6.2.3/node_modules/jose/dist/webapi/lib/signing.js
function Be(e, t) {
	if (e.startsWith("RS") || e.startsWith("PS")) {
		let { modulusLength: n } = t.algorithm;
		if (typeof n != "number" || n < 2048) throw TypeError(`${e} requires key modulusLength to be 2048 bits or larger`);
	}
}
function Ve(e, t) {
	let n = `SHA-${e.slice(-3)}`;
	switch (e) {
		case "HS256":
		case "HS384":
		case "HS512": return {
			hash: n,
			name: "HMAC"
		};
		case "PS256":
		case "PS384":
		case "PS512": return {
			hash: n,
			name: "RSA-PSS",
			saltLength: parseInt(e.slice(-3), 10) >> 3
		};
		case "RS256":
		case "RS384":
		case "RS512": return {
			hash: n,
			name: "RSASSA-PKCS1-v1_5"
		};
		case "ES256":
		case "ES384":
		case "ES512": return {
			hash: n,
			name: "ECDSA",
			namedCurve: t.namedCurve
		};
		case "Ed25519":
		case "EdDSA": return { name: "Ed25519" };
		case "ML-DSA-44":
		case "ML-DSA-65":
		case "ML-DSA-87": return { name: e };
		default: throw new Ee(`alg ${e} is not supported either by JOSE or your javascript runtime`);
	}
}
async function He(e, t, n) {
	if (t instanceof Uint8Array) {
		if (!e.startsWith("HS")) throw TypeError(Ce(t, "CryptoKey", "KeyObject", "JSON Web Key"));
		return crypto.subtle.importKey("raw", t, {
			hash: `SHA-${e.slice(-3)}`,
			name: "HMAC"
		}, !1, [n]);
	}
	return xe(t, e, n), t;
}
async function Ue(e, t, n) {
	let r = await He(e, t, "sign");
	Be(e, r);
	let i = await crypto.subtle.sign(Ve(e, r.algorithm), r, n);
	return new Uint8Array(i);
}
//#endregion
//#region node_modules/.pnpm/jose@6.2.3/node_modules/jose/dist/webapi/lib/jwk_to_key.js
var We = "Invalid or unsupported JWK \"alg\" (Algorithm) Parameter value";
function Ge(e) {
	let t, n;
	switch (e.kty) {
		case "AKP":
			switch (e.alg) {
				case "ML-DSA-44":
				case "ML-DSA-65":
				case "ML-DSA-87":
					t = { name: e.alg }, n = e.priv ? ["sign"] : ["verify"];
					break;
				default: throw new Ee(We);
			}
			break;
		case "RSA":
			switch (e.alg) {
				case "PS256":
				case "PS384":
				case "PS512":
					t = {
						name: "RSA-PSS",
						hash: `SHA-${e.alg.slice(-3)}`
					}, n = e.d ? ["sign"] : ["verify"];
					break;
				case "RS256":
				case "RS384":
				case "RS512":
					t = {
						name: "RSASSA-PKCS1-v1_5",
						hash: `SHA-${e.alg.slice(-3)}`
					}, n = e.d ? ["sign"] : ["verify"];
					break;
				case "RSA-OAEP":
				case "RSA-OAEP-256":
				case "RSA-OAEP-384":
				case "RSA-OAEP-512":
					t = {
						name: "RSA-OAEP",
						hash: `SHA-${parseInt(e.alg.slice(-3), 10) || 1}`
					}, n = e.d ? ["decrypt", "unwrapKey"] : ["encrypt", "wrapKey"];
					break;
				default: throw new Ee(We);
			}
			break;
		case "EC":
			switch (e.alg) {
				case "ES256":
				case "ES384":
				case "ES512":
					t = {
						name: "ECDSA",
						namedCurve: {
							ES256: "P-256",
							ES384: "P-384",
							ES512: "P-521"
						}[e.alg]
					}, n = e.d ? ["sign"] : ["verify"];
					break;
				case "ECDH-ES":
				case "ECDH-ES+A128KW":
				case "ECDH-ES+A192KW":
				case "ECDH-ES+A256KW":
					t = {
						name: "ECDH",
						namedCurve: e.crv
					}, n = e.d ? ["deriveBits"] : [];
					break;
				default: throw new Ee(We);
			}
			break;
		case "OKP":
			switch (e.alg) {
				case "Ed25519":
				case "EdDSA":
					t = { name: "Ed25519" }, n = e.d ? ["sign"] : ["verify"];
					break;
				case "ECDH-ES":
				case "ECDH-ES+A128KW":
				case "ECDH-ES+A192KW":
				case "ECDH-ES+A256KW":
					t = { name: e.crv }, n = e.d ? ["deriveBits"] : [];
					break;
				default: throw new Ee(We);
			}
			break;
		default: throw new Ee("Invalid or unsupported JWK \"kty\" (Key Type) Parameter value");
	}
	return {
		algorithm: t,
		keyUsages: n
	};
}
async function Ke(e) {
	if (!e.alg) throw TypeError("\"alg\" argument is required when \"jwk.alg\" is not present");
	let { algorithm: t, keyUsages: n } = Ge(e), r = { ...e };
	return r.kty !== "AKP" && delete r.alg, delete r.use, crypto.subtle.importKey("jwk", r, t, e.ext ?? !(e.d || e.priv), e.key_ops ?? n);
}
//#endregion
//#region node_modules/.pnpm/jose@6.2.3/node_modules/jose/dist/webapi/lib/normalize_key.js
var qe = "given KeyObject instance cannot be used for this algorithm", Je, Ye = async (e, t, n, r = !1) => {
	Je ||= /* @__PURE__ */ new WeakMap();
	let i = Je.get(e);
	if (i?.[n]) return i[n];
	let a = await Ke({
		...t,
		alg: n
	});
	return r && Object.freeze(e), i ? i[n] = a : Je.set(e, { [n]: a }), a;
}, Xe = (e, t) => {
	Je ||= /* @__PURE__ */ new WeakMap();
	let n = Je.get(e);
	if (n?.[t]) return n[t];
	let r = e.type === "public", i = !!r, a;
	if (e.asymmetricKeyType === "x25519") {
		switch (t) {
			case "ECDH-ES":
			case "ECDH-ES+A128KW":
			case "ECDH-ES+A192KW":
			case "ECDH-ES+A256KW": break;
			default: throw TypeError(qe);
		}
		a = e.toCryptoKey(e.asymmetricKeyType, i, r ? [] : ["deriveBits"]);
	}
	if (e.asymmetricKeyType === "ed25519") {
		if (t !== "EdDSA" && t !== "Ed25519") throw TypeError(qe);
		a = e.toCryptoKey(e.asymmetricKeyType, i, [r ? "verify" : "sign"]);
	}
	switch (e.asymmetricKeyType) {
		case "ml-dsa-44":
		case "ml-dsa-65":
		case "ml-dsa-87":
			if (t !== e.asymmetricKeyType.toUpperCase()) throw TypeError(qe);
			a = e.toCryptoKey(e.asymmetricKeyType, i, [r ? "verify" : "sign"]);
	}
	if (e.asymmetricKeyType === "rsa") {
		let n;
		switch (t) {
			case "RSA-OAEP":
				n = "SHA-1";
				break;
			case "RS256":
			case "PS256":
			case "RSA-OAEP-256":
				n = "SHA-256";
				break;
			case "RS384":
			case "PS384":
			case "RSA-OAEP-384":
				n = "SHA-384";
				break;
			case "RS512":
			case "PS512":
			case "RSA-OAEP-512":
				n = "SHA-512";
				break;
			default: throw TypeError(qe);
		}
		if (t.startsWith("RSA-OAEP")) return e.toCryptoKey({
			name: "RSA-OAEP",
			hash: n
		}, i, r ? ["encrypt"] : ["decrypt"]);
		a = e.toCryptoKey({
			name: t.startsWith("PS") ? "RSA-PSS" : "RSASSA-PKCS1-v1_5",
			hash: n
		}, i, [r ? "verify" : "sign"]);
	}
	if (e.asymmetricKeyType === "ec") {
		let n = new Map([
			["prime256v1", "P-256"],
			["secp384r1", "P-384"],
			["secp521r1", "P-521"]
		]).get(e.asymmetricKeyDetails?.namedCurve);
		if (!n) throw TypeError(qe);
		let o = {
			ES256: "P-256",
			ES384: "P-384",
			ES512: "P-521"
		};
		o[t] && n === o[t] && (a = e.toCryptoKey({
			name: "ECDSA",
			namedCurve: n
		}, i, [r ? "verify" : "sign"])), t.startsWith("ECDH-ES") && (a = e.toCryptoKey({
			name: "ECDH",
			namedCurve: n
		}, i, r ? [] : ["deriveBits"]));
	}
	if (!a) throw TypeError(qe);
	return n ? n[t] = a : Je.set(e, { [t]: a }), a;
};
async function Ze(e, t) {
	if (e instanceof Uint8Array || ke(e)) return e;
	if (Ae(e)) {
		if (e.type === "secret") return e.export();
		if ("toCryptoKey" in e && typeof e.toCryptoKey == "function") try {
			return Xe(e, t);
		} catch (e) {
			if (e instanceof TypeError) throw e;
		}
		return Ye(e, e.export({ format: "jwk" }), t);
	}
	if (Ie(e)) return e.k ? pe(e.k) : Ye(e, e, t, !0);
	throw Error("unreachable");
}
//#endregion
//#region node_modules/.pnpm/jose@6.2.3/node_modules/jose/dist/webapi/lib/validate_crit.js
function Qe(e, t, n, r, i) {
	if (i.crit !== void 0 && r?.crit === void 0) throw new e("\"crit\" (Critical) Header Parameter MUST be integrity protected");
	if (!r || r.crit === void 0) return /* @__PURE__ */ new Set();
	if (!Array.isArray(r.crit) || r.crit.length === 0 || r.crit.some((e) => typeof e != "string" || e.length === 0)) throw new e("\"crit\" (Critical) Header Parameter MUST be an array of non-empty strings when present");
	let a;
	a = n === void 0 ? t : new Map([...Object.entries(n), ...t.entries()]);
	for (let t of r.crit) {
		if (!a.has(t)) throw new Ee(`Extension Header Parameter "${t}" is not recognized`);
		if (i[t] === void 0) throw new e(`Extension Header Parameter "${t}" is missing`);
		if (a.get(t) && r[t] === void 0) throw new e(`Extension Header Parameter "${t}" MUST be integrity protected`);
	}
	return new Set(r.crit);
}
//#endregion
//#region node_modules/.pnpm/jose@6.2.3/node_modules/jose/dist/webapi/lib/check_key_type.js
var $e = (e) => e?.[Symbol.toStringTag], et = (e, t, n) => {
	if (t.use !== void 0) {
		let e;
		switch (n) {
			case "sign":
			case "verify":
				e = "sig";
				break;
			case "encrypt":
			case "decrypt":
				e = "enc";
				break;
		}
		if (t.use !== e) throw TypeError(`Invalid key for this operation, its "use" must be "${e}" when present`);
	}
	if (t.alg !== void 0 && t.alg !== e) throw TypeError(`Invalid key for this operation, its "alg" must be "${e}" when present`);
	if (Array.isArray(t.key_ops)) {
		let r;
		switch (!0) {
			case n === "sign" || n === "verify":
			case e === "dir":
			case e.includes("CBC-HS"):
				r = n;
				break;
			case e.startsWith("PBES2"):
				r = "deriveBits";
				break;
			case /^A\d{3}(?:GCM)?(?:KW)?$/.test(e):
				r = !e.includes("GCM") && e.endsWith("KW") ? n === "encrypt" ? "wrapKey" : "unwrapKey" : n;
				break;
			case n === "encrypt" && e.startsWith("RSA"):
				r = "wrapKey";
				break;
			case n === "decrypt":
				r = e.startsWith("RSA") ? "unwrapKey" : "deriveBits";
				break;
		}
		if (r && t.key_ops?.includes?.(r) === !1) throw TypeError(`Invalid key for this operation, its "key_ops" must include "${r}" when present`);
	}
	return !0;
}, tt = (e, t, n) => {
	if (!(t instanceof Uint8Array)) {
		if (Ie(t)) {
			if (ze(t) && et(e, t, n)) return;
			throw TypeError("JSON Web Key for symmetric algorithms must have JWK \"kty\" (Key Type) equal to \"oct\" and the JWK \"k\" (Key Value) present");
		}
		if (!je(t)) throw TypeError(we(e, t, "CryptoKey", "KeyObject", "JSON Web Key", "Uint8Array"));
		if (t.type !== "secret") throw TypeError(`${$e(t)} instances for symmetric algorithms must be of type "secret"`);
	}
}, nt = (e, t, n) => {
	if (Ie(t)) switch (n) {
		case "decrypt":
		case "sign":
			if (Le(t) && et(e, t, n)) return;
			throw TypeError("JSON Web Key for this operation must be a private JWK");
		case "encrypt":
		case "verify":
			if (Re(t) && et(e, t, n)) return;
			throw TypeError("JSON Web Key for this operation must be a public JWK");
	}
	if (!je(t)) throw TypeError(we(e, t, "CryptoKey", "KeyObject", "JSON Web Key"));
	if (t.type === "secret") throw TypeError(`${$e(t)} instances for asymmetric algorithms must not be of type "secret"`);
	if (t.type === "public") switch (n) {
		case "sign": throw TypeError(`${$e(t)} instances for asymmetric algorithm signing must be of type "private"`);
		case "decrypt": throw TypeError(`${$e(t)} instances for asymmetric algorithm decryption must be of type "private"`);
	}
	if (t.type === "private") switch (n) {
		case "verify": throw TypeError(`${$e(t)} instances for asymmetric algorithm verifying must be of type "public"`);
		case "encrypt": throw TypeError(`${$e(t)} instances for asymmetric algorithm encryption must be of type "public"`);
	}
};
function rt(e, t, n) {
	switch (e.substring(0, 2)) {
		case "A1":
		case "A2":
		case "di":
		case "HS":
		case "PB":
			tt(e, t, n);
			break;
		default: nt(e, t, n);
	}
}
//#endregion
//#region node_modules/.pnpm/jose@6.2.3/node_modules/jose/dist/webapi/lib/jwt_claims_set.js
var it = (e) => Math.floor(e.getTime() / 1e3), at = 60, ot = at * 60, st = ot * 24, ct = st * 7, lt = st * 365.25, ut = /^(\+|\-)? ?(\d+|\d+\.\d+) ?(seconds?|secs?|s|minutes?|mins?|m|hours?|hrs?|h|days?|d|weeks?|w|years?|yrs?|y)(?: (ago|from now))?$/i;
function dt(e) {
	let t = ut.exec(e);
	if (!t || t[4] && t[1]) throw TypeError("Invalid time period format");
	let n = parseFloat(t[2]), r = t[3].toLowerCase(), i;
	switch (r) {
		case "sec":
		case "secs":
		case "second":
		case "seconds":
		case "s":
			i = Math.round(n);
			break;
		case "minute":
		case "minutes":
		case "min":
		case "mins":
		case "m":
			i = Math.round(n * at);
			break;
		case "hour":
		case "hours":
		case "hr":
		case "hrs":
		case "h":
			i = Math.round(n * ot);
			break;
		case "day":
		case "days":
		case "d":
			i = Math.round(n * st);
			break;
		case "week":
		case "weeks":
		case "w":
			i = Math.round(n * ct);
			break;
		default:
			i = Math.round(n * lt);
			break;
	}
	return t[1] === "-" || t[4] === "ago" ? -i : i;
}
function ft(e, t) {
	if (!Number.isFinite(t)) throw TypeError(`Invalid ${e} input`);
	return t;
}
var pt = class {
	#e;
	constructor(e) {
		if (!Pe(e)) throw TypeError("JWT Claims Set MUST be an object");
		this.#e = structuredClone(e);
	}
	data() {
		return se.encode(JSON.stringify(this.#e));
	}
	get iss() {
		return this.#e.iss;
	}
	set iss(e) {
		this.#e.iss = e;
	}
	get sub() {
		return this.#e.sub;
	}
	set sub(e) {
		this.#e.sub = e;
	}
	get aud() {
		return this.#e.aud;
	}
	set aud(e) {
		this.#e.aud = e;
	}
	set jti(e) {
		this.#e.jti = e;
	}
	set nbf(e) {
		typeof e == "number" ? this.#e.nbf = ft("setNotBefore", e) : e instanceof Date ? this.#e.nbf = ft("setNotBefore", it(e)) : this.#e.nbf = it(/* @__PURE__ */ new Date()) + dt(e);
	}
	set exp(e) {
		typeof e == "number" ? this.#e.exp = ft("setExpirationTime", e) : e instanceof Date ? this.#e.exp = ft("setExpirationTime", it(e)) : this.#e.exp = it(/* @__PURE__ */ new Date()) + dt(e);
	}
	set iat(e) {
		e === void 0 ? this.#e.iat = it(/* @__PURE__ */ new Date()) : e instanceof Date ? this.#e.iat = ft("setIssuedAt", it(e)) : typeof e == "string" ? this.#e.iat = ft("setIssuedAt", it(/* @__PURE__ */ new Date()) + dt(e)) : this.#e.iat = ft("setIssuedAt", e);
	}
}, mt = class {
	#e;
	#t;
	#n;
	constructor(e) {
		if (!(e instanceof Uint8Array)) throw TypeError("payload must be an instance of Uint8Array");
		this.#e = e;
	}
	setProtectedHeader(e) {
		return Me(this.#t, "setProtectedHeader"), this.#t = e, this;
	}
	setUnprotectedHeader(e) {
		return Me(this.#n, "setUnprotectedHeader"), this.#n = e, this;
	}
	async sign(e, t) {
		if (!this.#t && !this.#n) throw new De("either setProtectedHeader or setUnprotectedHeader must be called before #sign()");
		if (!Fe(this.#t, this.#n)) throw new De("JWS Protected and JWS Unprotected Header Parameter names must be disjoint");
		let n = {
			...this.#t,
			...this.#n
		}, r = Qe(De, new Map([["b64", !0]]), t?.crit, this.#t, n), i = !0;
		if (r.has("b64") && (i = this.#t.b64, typeof i != "boolean")) throw new De("The \"b64\" (base64url-encode payload) Header Parameter must be a boolean");
		let { alg: a } = n;
		if (typeof a != "string" || !a) throw new De("JWS \"alg\" (Algorithm) Header Parameter missing or invalid");
		rt(a, e, "sign");
		let o, s;
		i ? (o = me(this.#e), s = ue(o)) : (s = this.#e, o = "");
		let c, l;
		this.#t ? (c = me(JSON.stringify(this.#t)), l = ue(c)) : (c = "", l = new Uint8Array());
		let u = le(l, ue("."), s), d = {
			signature: me(await Ue(a, await Ze(e, a), u)),
			payload: o
		};
		return this.#n && (d.header = this.#n), this.#t && (d.protected = c), d;
	}
}, ht = class {
	#e;
	constructor(e) {
		this.#e = new mt(e);
	}
	setProtectedHeader(e) {
		return this.#e.setProtectedHeader(e), this;
	}
	async sign(e, t) {
		let n = await this.#e.sign(e, t);
		if (n.payload === void 0) throw TypeError("use the flattened module for creating JWS with b64: false");
		return `${n.protected}.${n.payload}.${n.signature}`;
	}
}, gt = class {
	#e;
	#t;
	constructor(e = {}) {
		this.#t = new pt(e);
	}
	setIssuer(e) {
		return this.#t.iss = e, this;
	}
	setSubject(e) {
		return this.#t.sub = e, this;
	}
	setAudience(e) {
		return this.#t.aud = e, this;
	}
	setJti(e) {
		return this.#t.jti = e, this;
	}
	setNotBefore(e) {
		return this.#t.nbf = e, this;
	}
	setExpirationTime(e) {
		return this.#t.exp = e, this;
	}
	setIssuedAt(e) {
		return this.#t.iat = e, this;
	}
	setProtectedHeader(e) {
		return this.#e = e, this;
	}
	async sign(e, t) {
		let n = new ht(this.#t.data());
		if (n.setProtectedHeader(this.#e), Array.isArray(this.#e?.crit) && this.#e.crit.includes("b64") && this.#e.b64 === !1) throw new Oe("JWTs MUST NOT use unencoded payload");
		return n.sign(e, t);
	}
}, _t = new m();
async function vt(e, t, n, r, i) {
	let a = {
		video: {
			roomJoin: !0,
			room: n
		},
		metadata: i
	}, o = Math.floor((/* @__PURE__ */ new Date(Date.now() - 1e3 * 900)).getTime() / 1e3);
	if (!e || !t) return _t.error("API Key or Secret is not set. Please configure the LiveKit API Key and Secret"), "";
	let s = await new gt(a).setIssuer(e).setExpirationTime("10h").setJti(r).setSubject(r).setNotBefore(o).setProtectedHeader({ alg: "HS256" }).sign(new TextEncoder().encode(t));
	return _t.debug("AccessToken:", s), s;
}
async function yt(e, t, n, r, i) {
	let a = game.settings?.get("avclient-livekit", "authServer") ?? "https://patreon-auth.tavern.at", o = game.settings?.get(l, "tavernPatreonToken");
	if (!o) return "";
	let s;
	try {
		s = await fetch(`${a}/livekit/token`, {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify({
				id: o,
				room: n,
				userName: r,
				metadata: i
			})
		});
	} catch (e) {
		return _t.error("Error validating Patreon account", e), "";
	}
	if (!s.ok) return _t.error("Error validating Patreon account", await s.json()), "";
	let c;
	try {
		c = await s.text();
	} catch (e) {
		return _t.warn("Error parsing response", e), "";
	}
	return c;
}
async function bt(e, t) {
	let n;
	try {
		n = await fetch(`${e}/validate`, {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify({ id: t })
		});
	} catch (e) {
		_t.error("Error validating authentication account", e);
		let t = "Error validating authentication account";
		return e instanceof Error && (t = e.message), {
			error_id: "",
			status_code: 500,
			error: t
		};
	}
	let r;
	try {
		r = await n.json();
	} catch (e) {
		_t.error("Error parsing authentication response", e);
		let t = "Error parsing authentication response";
		return e instanceof Error && (t = e.message), {
			error_id: "",
			status_code: 500,
			error: t
		};
	}
	return n.ok || _t.error("Error validating authentication account", r), r;
}
//#endregion
//#region src/ui/dom.ts
var xt = "livekit-surface", St = "livekit-tooltip";
function h(e, { className: t, text: n, title: r, attrs: i, children: a } = {}) {
	let o = document.createElement(e);
	t && (o.className = t), n !== void 0 && (o.textContent = n), r && wt(o, r);
	for (let [e, t] of Object.entries(i ?? {})) o.setAttribute(e, t);
	for (let e of a ?? []) e && o.append(e);
	return o;
}
function Ct(e) {
	return e.classList.add(xt), e.dataset.tooltipClass = St, e;
}
function wt(e, t, n) {
	e.dataset.tooltip = t, e.ariaLabel = t, n && (e.dataset.tooltipDirection = n);
}
function Tt(e, t = "") {
	return h("i", {
		className: `fa-solid fa-fw ${e} ${t}`.trim(),
		attrs: { "aria-hidden": "true" }
	});
}
function Et(e, t, n) {
	return Math.min(Math.max(e, t), n);
}
var Dt = 0;
function Ot(e) {
	return Dt += 1, `livekit-${e}-${Dt.toString()}`;
}
//#endregion
//#region src/ui/controls.ts
var g = (e) => game.i18n?.localize(`LIVEKITAVCLIENT.${e}`) ?? e;
function _({ label: e, hint: t, control: n, inline: r = !1 }) {
	let i = n instanceof HTMLElement ? n.matches("input, select, textarea") ? n : n.querySelector("input, select, textarea") : null, a = h(i ? "label" : "span", {
		className: "livekit-setting-label",
		text: e
	}), o = t && h("p", {
		className: "livekit-setting-hint",
		attrs: { id: Ot("hint") },
		children: [t]
	});
	return i && (i.id ||= Ot("control"), a.setAttribute("for", i.id), i.removeAttribute("aria-label"), o && i.setAttribute("aria-describedby", o.id)), h("div", {
		className: `livekit-setting ${r ? "inline" : ""}`.trim(),
		children: [h("div", {
			className: "livekit-setting-text",
			children: [a, o]
		}), n]
	});
}
function kt({ name: e, label: t, options: n, value: r, dtype: i, disabled: a = !1, onChange: o }) {
	let s = h("select", {
		className: "livekit-select",
		attrs: { "aria-label": t },
		children: n.map((e) => {
			let t = h("option", {
				text: e.label,
				attrs: { value: e.value }
			});
			return t.selected = e.value === r, t.disabled = !!e.disabled && e.value !== r, t;
		})
	});
	return e && (s.name = e), i && (s.dataset.dtype = i), s.disabled = a, o && s.addEventListener("change", () => {
		o(s.value);
	}), s;
}
function At({ name: e, value: t, type: n = "text", className: r = "", attrs: i = {} }) {
	return h("input", {
		className: `${n === "number" ? "livekit-number" : "livekit-text"} ${r}`.trim(),
		attrs: {
			type: n,
			name: e,
			value: t,
			spellcheck: "false",
			...i
		}
	});
}
function jt({ name: e, label: t, hint: n, checked: r, disabled: i = !1, onChange: a }) {
	let o = Ot("label"), s = n ? Ot("hint") : void 0, c = h("input", { attrs: {
		type: "checkbox",
		role: "switch",
		"aria-labelledby": o,
		...s ? { "aria-describedby": s } : {}
	} });
	return e && (c.name = e), c.checked = r, c.disabled = i, a && c.addEventListener("change", () => {
		a(c.checked);
	}), h("label", {
		className: `livekit-switch ${i ? "disabled" : ""}`.trim(),
		children: [
			h("span", {
				className: "livekit-setting-text",
				children: [h("span", {
					className: "livekit-setting-label",
					text: t,
					attrs: { id: o }
				}), n && h("span", {
					className: "livekit-setting-hint",
					text: n,
					attrs: { id: s ?? "" }
				})]
			}),
			c,
			h("span", {
				className: "livekit-switch-track",
				attrs: { "aria-hidden": "true" }
			})
		]
	});
}
function Mt({ name: e, value: t, options: n, itemClass: r, onChange: i }) {
	return n.map((n) => {
		let a = h("input", { attrs: {
			type: "radio",
			name: e,
			value: n.value
		} });
		return a.checked = n.value === t, a.disabled = !!n.disabled, i && a.addEventListener("change", () => {
			i(n.value);
		}), h("label", {
			className: r,
			children: [a, h("span", { text: n.label })]
		});
	});
}
function Nt({ name: e, label: t, value: n, options: r, onChange: i }) {
	return h("div", {
		className: "livekit-radio-group",
		attrs: {
			role: "radiogroup",
			"aria-label": t
		},
		children: Mt({
			name: e,
			value: n,
			options: r,
			itemClass: "livekit-radio",
			onChange: i
		})
	});
}
function Pt({ name: e, label: t, value: n, options: r, onChange: i }) {
	return h("div", {
		className: "livekit-segmented",
		attrs: {
			role: "radiogroup",
			"aria-label": t
		},
		children: Mt({
			name: e,
			value: n,
			options: r,
			itemClass: "livekit-segment",
			onChange: i
		})
	});
}
function Ft({ name: e, label: t, min: n, max: r, step: i = 1, value: a, format: o = (e) => e.toString(), onInput: s, onChange: c }) {
	let l = h("input", {
		className: "livekit-slider",
		attrs: {
			type: "range",
			min: n.toString(),
			max: r.toString(),
			step: i.toString(),
			value: a.toString()
		}
	});
	e && (l.name = e);
	let u = h("output", {
		className: "livekit-slider-value",
		text: o(a)
	}), d = () => {
		let e = Number(l.value);
		u.textContent = o(e), l.setAttribute("aria-valuetext", o(e)), l.style.setProperty("--fill", `${((e - n) / (r - n) * 100).toString()}%`);
	};
	return d(), l.addEventListener("input", () => {
		d(), s?.(Number(l.value));
	}), l.addEventListener("change", () => {
		c?.(Number(l.value));
	}), h("label", {
		className: "livekit-slider-field",
		children: [h("span", {
			className: "livekit-slider-header",
			children: [h("span", {
				className: "livekit-setting-label",
				text: t
			}), u]
		}), l]
	});
}
function It() {
	let e = game.keybindings;
	return e?.actions.has("core.pushToTalk") ? e : void 0;
}
function Lt() {
	return It()?.get("core", "pushToTalk");
}
function Rt(e) {
	return It()?.set("core", "pushToTalk", [{
		key: e,
		modifiers: []
	}]) ?? Promise.resolve();
}
function zt(e) {
	return (foundry.helpers?.interaction?.KeyboardManager)?.getKeycodeDisplayString?.(e) ?? e.replace(/^(Key|Digit)/, "");
}
function Bt(e) {
	return e.map((e) => [...e.modifiers ?? [], zt(e.key)].join(" + ")).join(", ") || g("pushToTalkUnbound");
}
function Vt(e, t) {
	let n = h("button", {
		className: "livekit-keybind",
		text: Bt(e),
		attrs: {
			type: "button",
			"aria-live": "polite"
		}
	});
	return n.addEventListener("click", () => {
		n.textContent = g("pushToTalkRecord"), n.classList.add("recording");
		let r = () => {
			window.removeEventListener("keydown", i, { capture: !0 }), n.removeEventListener("blur", a), n.classList.remove("recording");
		}, i = (i) => {
			if (i.preventDefault(), i.stopPropagation(), r(), i.code === "Escape") {
				n.textContent = Bt(e);
				return;
			}
			n.textContent = Bt([{ key: i.code }]), t(i.code);
		}, a = () => {
			r(), n.textContent = Bt(e);
		};
		window.addEventListener("keydown", i, { capture: !0 }), n.addEventListener("blur", a);
	}), n;
}
//#endregion
//#region src/ui/Popover.ts
var Ht = 8, Ut = 6, Wt = class {
	onClose;
	element;
	anchor = null;
	expandedControl = null;
	onPointerDown = (e) => {
		let t = e.target;
		t instanceof Node && (this.element.contains(t) || this.anchor?.contains(t) || this.expandedControl?.contains(t)) || this.close();
	};
	onKeyDown = (e) => {
		e.key === "Escape" && (e.preventDefault(), e.stopPropagation(), this.close());
	};
	constructor(e, t, n = "dialog") {
		this.onClose = t, this.element = Ct(h("div", {
			className: `livekit-popover ${e}`,
			attrs: { role: n }
		}));
	}
	get isOpen() {
		return this.element.isConnected;
	}
	openAt(e, t = e) {
		this.anchor = e, this.setExpandedControl(t), this.show(), this.reposition();
	}
	openAtPoint(e, t, n) {
		this.anchor = null, this.setExpandedControl(n ?? null), this.show();
		let { width: r, height: i } = this.element.getBoundingClientRect();
		this.place(e, t, r, i);
	}
	reposition() {
		if (!this.anchor || !this.isOpen) return;
		let e = this.anchor.getBoundingClientRect(), t = e.top - Ht - Ut, n = window.innerHeight - e.bottom - Ht - Ut;
		this.element.style.removeProperty("--livekit-popover-room");
		let r = t >= this.element.getBoundingClientRect().height || t >= n;
		this.element.style.setProperty("--livekit-popover-room", `${Math.max(r ? t : n, 0).toString()}px`);
		let { width: i, height: a } = this.element.getBoundingClientRect(), o = r ? e.top - a - Ut : e.bottom + Ut;
		this.place(e.left, o, i, a);
	}
	close() {
		if (!this.isOpen) return;
		let e = this.element.contains(document.activeElement);
		document.removeEventListener("pointerdown", this.onPointerDown, !0), document.removeEventListener("keydown", this.onKeyDown, !0), this.element.remove();
		let t = this.expandedControl;
		this.setExpandedControl(null), this.anchor = null, e && t?.isConnected && t.focus({ preventScroll: !0 }), this.onClose?.();
	}
	setExpandedControl(e) {
		this.expandedControl?.hasAttribute("aria-expanded") && this.expandedControl.setAttribute("aria-expanded", "false"), this.expandedControl = e, e instanceof HTMLButtonElement && e.setAttribute("aria-expanded", "true");
	}
	show() {
		this.isOpen || (document.body.append(this.element), document.addEventListener("pointerdown", this.onPointerDown, !0), document.addEventListener("keydown", this.onKeyDown, !0));
	}
	place(e, t, n, r) {
		this.element.style.left = `${Et(e, Ht, window.innerWidth - n - Ht).toString()}px`, this.element.style.top = `${Et(t, Ht, window.innerHeight - r - Ht).toString()}px`;
	}
};
//#endregion
//#region src/ui/buttons.ts
function Gt({ icon: e, label: t, onClick: n, className: r = "", danger: i = !1 }) {
	let a = h("button", {
		className: `livekit-icon-button ${i ? "is-danger" : ""} ${r}`.replace(/\s+/g, " ").trim(),
		title: t,
		attrs: { type: "button" },
		children: [Tt(e)]
	});
	return a.addEventListener("click", (e) => {
		e.preventDefault(), e.stopPropagation(), n(e);
	}), a;
}
function Kt(e, t) {
	t.icon !== void 0 && e.replaceChildren(Tt(t.icon)), t.label !== void 0 && wt(e, t.label), t.active !== void 0 && e.classList.toggle("is-active", t.active), t.off !== void 0 && e.classList.toggle("is-off", t.off), t.slashed !== void 0 && e.classList.toggle("livekit-slashed", t.slashed), t.pressed !== void 0 && e.setAttribute("aria-pressed", String(t.pressed)), t.disabled !== void 0 && (e.disabled = t.disabled);
}
function qt({ label: e, variant: t = "secondary", icon: n, type: r = "button", onClick: i }) {
	let a = h("button", {
		className: t === "link" ? "livekit-link-button" : `livekit-button livekit-button-${t}`,
		attrs: { type: r },
		children: [n, h("span", { text: e })]
	});
	return i && a.addEventListener("click", (e) => {
		e.preventDefault(), i();
	}), a;
}
//#endregion
//#region src/VoiceActivityGate.ts
var Jt = "worklets/voice-activity-gate.js", Yt = "livekit-voice-activity-gate", Xt = class extends Error {
	constructor(e) {
		super("The voice activity gate could not be started", { cause: e }), this.name = "VoiceGateError";
	}
}, Zt = class e {
	node;
	onReport;
	static instances = /* @__PURE__ */ new Set();
	report;
	constructor(t, n) {
		this.node = t, this.onReport = n, t.port.onmessage = (e) => {
			this.report = e.data, this.onReport?.(e.data);
		}, e.instances.add(this);
	}
	static async create(t, { settings: n, onReport: r, analysisOnly: i = !1 }) {
		try {
			return await t.audioWorklet.addModule(ie(Jt)), new e(new AudioWorkletNode(t, Yt, {
				numberOfInputs: 1,
				numberOfOutputs: +!i,
				processorOptions: n
			}), r);
		} catch (e) {
			throw new Xt(e);
		}
	}
	get isOpen() {
		return this.report?.open ?? !1;
	}
	configure(e) {
		this.node.port.postMessage(e);
	}
	destroy() {
		e.instances.delete(this), this.node.port.onmessage = null, this.node.port.close(), this.node.disconnect();
	}
}, Qt = new m("LevelMeter"), $t = -80, en = 0, tn = class {
	element;
	slider;
	fill = h("div", { className: "livekit-meter-fill" });
	stopMetering;
	constructor({ name: e, settings: t, onInput: n, onChange: r }) {
		this.slider = h("input", {
			className: "livekit-meter-threshold",
			attrs: {
				type: "range",
				min: $t.toString(),
				max: en.toString(),
				step: "1",
				value: t.threshold.toString(),
				"aria-label": g("audioNoiseGateThreshold"),
				"aria-valuetext": `${t.threshold.toString()} dB`
			}
		}), e && (this.slider.name = e), this.slider.addEventListener("input", () => {
			this.slider.setAttribute("aria-valuetext", `${this.slider.value} dB`), n?.(Number(this.slider.value));
		}), this.slider.addEventListener("change", () => {
			r?.(Number(this.slider.value));
		}), this.element = h("div", {
			className: "livekit-meter",
			children: [h("div", {
				className: "livekit-meter-track",
				attrs: { "aria-hidden": "true" },
				children: [this.fill]
			}), this.slider]
		}), this.setAuto(t.auto);
	}
	setAuto(e) {
		this.element.classList.toggle("is-auto", e), this.slider.tabIndex = e ? -1 : 0, this.slider.setAttribute("aria-hidden", String(e));
	}
	start(e) {
		this.stop();
		let t = e.audioTrack;
		if (e.voiceGate && t && !t.isMuted) {
			this.stopMetering = e.onVoiceGateReports((e) => {
				this.show(e);
			});
			return;
		}
		let n = t?.mediaStream?.getAudioTracks()[0] ?? t?.mediaStreamTrack;
		n && n.readyState !== "ended" && this.startAnalysis(e, n);
	}
	stop() {
		this.stopMetering?.(), this.stopMetering = void 0, this.show(void 0);
	}
	async startAnalysis(e, t) {
		let n = { stopped: !1 }, r = () => {
			n.stopped = !0;
		};
		this.stopMetering = () => {
			r();
		};
		let i = t.clone();
		i.enabled = !0;
		let a = e.getAudioProcessorContext();
		try {
			let t = await Zt.create(a, {
				settings: e.getVoiceGateSettings(),
				onReport: (e) => {
					this.show(e);
				},
				analysisOnly: !0
			}), o = a.createMediaStreamSource(new MediaStream([i]));
			o.connect(t.node), r = () => {
				o.disconnect(), t.destroy(), i.stop();
			}, n.stopped && r();
		} catch (e) {
			i.stop(), Qt.warn("Unable to measure the microphone level:", e);
		}
	}
	show(e) {
		let t = (Et(e?.db ?? $t, $t, en) - $t) / (en - $t) * 100;
		this.fill.style.width = `${t.toString()}%`, this.fill.classList.toggle("open", e?.open ?? !1);
	}
}, nn = new m("AudioSettingsPopover"), rn = class {
	client;
	popover = new Wt("livekit-audio-settings", () => {
		this.meter?.stop(), this.client.previewVoiceGate();
	});
	meter;
	constructor(e) {
		this.client = e;
	}
	get isOpen() {
		return this.popover.isOpen;
	}
	toggle(e, t = e) {
		this.popover.isOpen ? this.popover.close() : this.open(e, t);
	}
	async open(e, t = e) {
		await this.render(), this.popover.openAt(e, t), this.meter?.start(this.client);
	}
	close() {
		this.popover.close();
	}
	async render() {
		let e = this.popover.isOpen;
		this.meter?.stop();
		let t = await this.renderDevices(), n = qt({
			label: g("advancedSettings"),
			variant: "link",
			onClick: () => {
				this.close(), this.client.avMaster.config.render({ force: !0 }).catch((e) => {
					nn.error("Error opening the A/V settings:", e);
				});
			}
		}), r = Ot("title");
		this.popover.element.setAttribute("aria-labelledby", r);
		let i = [
			h("h3", {
				className: "livekit-popover-title",
				text: g("voiceSettings"),
				attrs: { id: r }
			}),
			t,
			this.renderInputMode(),
			this.renderSensitivity(),
			this.renderNoiseSuppression(),
			h("footer", {
				className: "livekit-popover-footer",
				children: [n]
			})
		];
		this.popover.element.replaceChildren(...i.filter((e) => e !== !1)), this.popover.reposition(), e && this.meter?.start(this.client);
	}
	section(e, ...t) {
		return h("section", {
			className: "livekit-settings-section",
			children: [h("h4", { text: e }), ...t]
		});
	}
	async renderDevices() {
		let e = this.client.liveKitAvClient, [t, n] = await Promise.all([e.getAudioSources(), e.getAudioSinks()]), r = "setSinkId" in HTMLMediaElement.prototype, i = (e, t) => _({
			label: g(e),
			control: kt({
				label: g(e),
				options: an(t, this.client.settings.client[e]),
				value: this.client.settings.client[e],
				onChange: (t) => {
					this.client.settings.set("client", e, t), e === "audioSink" && this.client.userAudioMixer.applyAll();
				}
			})
		});
		return this.section(g("devices"), i("audioSrc", t), r && i("audioSink", n));
	}
	renderInputMode() {
		let e = this.client.settings.client.voice.mode, t = Lt();
		return this.section(g("inputMode"), Pt({
			name: "livekit-voice-mode",
			label: g("inputMode"),
			value: e,
			options: [{
				value: "always",
				label: g("inputModeVoiceActivity")
			}, {
				value: "ptt",
				label: g("inputModePushToTalk")
			}],
			onChange: (e) => {
				this.client.settings.set("client", "voice.mode", e), this.render();
			}
		}), e === "ptt" && !!t && _({
			label: g("pushToTalkKey"),
			inline: !0,
			control: Vt(t, (e) => {
				Rt(e).then(() => this.render()).catch((e) => {
					nn.error("Error setting the push to talk key:", e);
				});
			})
		}));
	}
	renderSensitivity() {
		if (this.client.settings.client.voice.mode !== "always") return this.meter = void 0, !1;
		let e = this.client.getVoiceGateSettings(), t = h("span", {
			className: "livekit-meter-caption",
			text: `${e.threshold.toString()} dB`
		});
		return this.meter = new tn({
			settings: e,
			onInput: (e) => {
				t.textContent = `${e.toString()} dB`, this.client.previewVoiceGate({
					auto: !1,
					threshold: e
				});
			},
			onChange: (e) => {
				game.settings?.set(l, "audioNoiseGateThreshold", e).then(() => {
					this.client.previewVoiceGate();
				}).catch((e) => {
					nn.error("Error saving the input sensitivity:", e);
				});
			}
		}), this.section(g("inputSensitivity"), jt({
			label: g("audioAutoSensitivity"),
			checked: e.auto,
			onChange: (e) => {
				game.settings?.set(l, "audioAutoSensitivity", e).then(() => this.render());
			}
		}), this.meter.element, h("p", {
			className: "livekit-setting-hint",
			text: g(e.auto ? "inputSensitivityAutoHint" : "inputSensitivityHint"),
			children: [!e.auto && t]
		}));
	}
	renderNoiseSuppression() {
		let e = this.client.getNoiseModelOptions(), t = (e) => jt({
			label: g(e),
			checked: game.settings?.get("avclient-livekit", e) ?? !1,
			onChange: (t) => {
				game.settings?.set(l, e, t).then(() => this.render());
			}
		});
		return this.section(g("noiseSuppressionModel"), kt({
			label: g("noiseSuppressionModel"),
			options: on(e),
			value: e.find((e) => e.selected)?.model ?? "none",
			onChange: (e) => {
				this.client.selectNoiseModel(e).then(() => this.render()).catch((e) => {
					nn.error("Error selecting the noise suppression model:", e);
				});
			}
		}), t("audioEchoCancellation"), t("audioAutoGainControl"));
	}
};
function an(e, t) {
	let n = Object.entries(e).map(([e, t]) => ({
		value: e,
		label: t
	}));
	return t && !(t in e) && n.push({
		value: t,
		label: t === "disabled" ? g("deviceDisabled") : t
	}), n;
}
function on(e) {
	return e.map((e) => ({
		value: e.model,
		label: e.detail ? `${e.label} (${e.detail})` : e.label,
		disabled: !e.selectable
	}));
}
//#endregion
//#region src/LiveKitAVConfig.ts
var sn = new m("LiveKitAVConfig");
function cn() {
	return Object.getPrototypeOf(foundry.applications.settings.menus.AVConfig.prototype);
}
var ln = class e extends foundry.applications.settings.menus.AVConfig {
	static DEFAULT_OPTIONS = {
		tag: "form",
		id: "av-config",
		classes: ["livekit-settings-app"],
		window: {
			title: "WEBRTC.Title",
			icon: "fa-solid fa-headset",
			resizable: !0
		},
		position: {
			width: 860,
			height: 640
		},
		form: {
			closeOnSubmit: !1,
			handler: e.#e
		}
	};
	static PARTS = { content: { template: "modules/avclient-livekit/templates/settings.hbs" } };
	static TABS = {};
	data;
	activeSection = "voice";
	meter;
	dirtyTracking = !1;
	get liveKitClient() {
		return game.webrtc?.client._liveKitClient;
	}
	async _prepareContext(e) {
		let t = await cn()._prepareContext.call(this, e), n = game.webrtc?.client, [r, i, a] = await Promise.all([
			n?.getAudioSources() ?? {},
			n?.getAudioSinks() ?? {},
			n?.getVideoSources() ?? {}
		]), o = game.settings?.get("avclient-livekit", "liveKitConnectionSettings") ?? {}, s;
		if (game.user?.isGM && o.serverType === "tavern") {
			let e = game.settings.get(l, "authServer"), t = game.settings.get(l, "tavernPatreonToken");
			e && t && (s = await bt(e, t));
		}
		return this.data = {
			audioSources: r,
			audioSinks: i,
			videoSources: a,
			connectionSettings: o,
			authResponse: s
		}, t;
	}
	async _preparePartContext(e, t, n) {
		return cn()._preparePartContext.call(this, e, t, n);
	}
	_onChangeForm(e, t) {
		cn()._onChangeForm.call(this, e, t);
	}
	async _onRender(e, t) {
		await cn()._onRender.call(this, e, t), this.meter?.stop(), this.liveKitClient?.previewVoiceGate();
		let n = this.element.querySelector("[data-livekit-settings]");
		if (!(n instanceof HTMLElement) || !this.data) return;
		Ct(n);
		let r = game.user?.isGM ?? !1, i = this.sections().filter((e) => r || !e.gmOnly);
		i.some((e) => e.id === this.activeSection) || (this.activeSection = i[0].id);
		let a = /* @__PURE__ */ new Map(), o = /* @__PURE__ */ new Map(), s = h("nav", {
			className: "livekit-settings-nav",
			attrs: { "aria-label": game.i18n?.localize("WEBRTC.Title") ?? "" }
		});
		for (let e of ["user", "world"]) {
			let t = i.filter((t) => t.gmOnly === (e === "world"));
			if (t.length) {
				s.append(h("h3", {
					className: "livekit-settings-nav-header",
					text: g(e === "world" ? "settingsGroupWorld" : "settingsGroupUser")
				}));
				for (let e of t) {
					let t = h("button", {
						className: "livekit-settings-nav-item",
						attrs: { type: "button" },
						children: [Tt(e.icon), h("span", { text: g(`settingsSection.${e.id}`) })]
					});
					t.addEventListener("click", () => {
						this.showSection(e.id, a, o);
					}), a.set(e.id, t), s.append(t);
				}
			}
		}
		let c = h("div", { className: "livekit-settings-content" });
		for (let e of i) {
			let t = h("section", {
				className: "livekit-settings-pane",
				children: [h("h2", { text: g(`settingsSection.${e.id}`) }), ...e.build()]
			});
			o.set(e.id, t), c.append(t);
		}
		let l = h("div", {
			className: "livekit-unsaved-bar",
			attrs: {
				hidden: "",
				role: "status"
			},
			children: [h("span", { text: g("unsavedChanges") }), h("div", {
				className: "livekit-unsaved-actions",
				children: [qt({
					label: g("unsavedReset"),
					variant: "link",
					onClick: () => {
						this.render();
					}
				}), qt({
					label: g("unsavedSave"),
					variant: "primary",
					type: "submit"
				})]
			})]
		});
		if (!this.dirtyTracking) {
			this.dirtyTracking = !0;
			let e = () => {
				let e = this.element.querySelector(".livekit-unsaved-bar");
				e instanceof HTMLElement && (e.hidden = !1);
			};
			this.element.addEventListener("input", e), this.element.addEventListener("change", e);
		}
		n.replaceChildren(s, h("div", {
			className: "livekit-settings-main",
			children: [c, l]
		})), this.showSection(this.activeSection, a, o), this.liveKitClient && this.meter?.start(this.liveKitClient);
	}
	_onClose(e) {
		this.meter?.stop(), this.meter = void 0, this.liveKitClient?.previewVoiceGate(), super._onClose(e);
	}
	showSection(e, t, n) {
		this.activeSection = e;
		for (let [n, r] of t) r.classList.toggle("is-selected", n === e), r.setAttribute("aria-current", n === e ? "page" : "false");
		for (let [t, r] of n) r.hidden = t !== e;
	}
	sections() {
		return [
			{
				id: "voice",
				icon: "fa-microphone",
				gmOnly: !1,
				build: () => this.buildVoice()
			},
			{
				id: "noise",
				icon: "fa-wand-magic-sparkles",
				gmOnly: !1,
				build: () => this.buildNoise()
			},
			{
				id: "video",
				icon: "fa-video",
				gmOnly: !1,
				build: () => this.buildVideo()
			},
			{
				id: "appearance",
				icon: "fa-palette",
				gmOnly: !1,
				build: () => this.buildAppearance()
			},
			{
				id: "advanced",
				icon: "fa-sliders",
				gmOnly: !1,
				build: () => this.buildAdvanced()
			},
			{
				id: "server",
				icon: "fa-server",
				gmOnly: !0,
				build: () => this.buildServer()
			},
			{
				id: "players",
				icon: "fa-users",
				gmOnly: !0,
				build: () => this.buildPlayerOptions()
			},
			{
				id: "troubleshooting",
				icon: "fa-bug",
				gmOnly: !0,
				build: () => this.buildTroubleshooting()
			}
		];
	}
	moduleSwitch(e, { disabled: t = !1, hint: n, label: r } = {}) {
		return jt({
			name: `${l}.${e}`,
			label: r ?? g(e),
			hint: n ?? un(e),
			checked: game.settings?.get(l, e) === !0,
			disabled: t
		});
	}
	clientSwitch(e) {
		return jt({
			name: `core.rtcClientSettings.${e}`,
			label: g(`clientSetting.${e}`),
			hint: un(`clientSetting.${e}`),
			checked: game.webrtc?.settings.client[e] === !0
		});
	}
	group(e, ...t) {
		return h("div", {
			className: "livekit-settings-group",
			children: [h("h4", { text: e }), ...t]
		});
	}
	buildVoice() {
		let e = this.data, t = game.webrtc?.settings.client;
		if (!e || !t) return [];
		let n = (e, n, r) => _({
			label: g(e),
			control: kt({
				name: `core.rtcClientSettings.${e}`,
				label: g(e),
				options: [...an(n, t[e]).filter((e) => e.value !== "disabled"), ...r ? [{
					value: "disabled",
					label: g("deviceDisabled")
				}] : []],
				value: t[e]
			})
		}), r = Lt(), i = h("input", { attrs: {
			type: "hidden",
			name: "livekit.pushToTalkKey",
			value: ""
		} }), a = h("div", {
			className: "livekit-settings-subgroup",
			children: [
				!!r && _({
					label: g("pushToTalkKey"),
					inline: !0,
					control: Vt(r, (e) => {
						i.value = e, i.dispatchEvent(new Event("change", { bubbles: !0 }));
					})
				}),
				i,
				Ft({
					name: "core.rtcClientSettings.voice.pttDelay",
					label: g("pushToTalkDelay"),
					min: 0,
					max: 2e3,
					step: 10,
					value: t.voice.pttDelay,
					format: (e) => `${e.toString()} ms`
				}),
				h("p", {
					className: "livekit-setting-hint livekit-slider-hint",
					text: g("pushToTalkDelayHint")
				})
			]
		}), o = this.liveKitClient?.getVoiceGateSettings() ?? {
			auto: !0,
			threshold: -50
		}, s = h("span", {
			className: "livekit-meter-caption",
			text: `${o.threshold.toString()} dB`
		}), c = h("p", { className: "livekit-setting-hint" }), u = () => {
			this.meter?.setAuto(o.auto), c.replaceChildren(g(o.auto ? "inputSensitivityAutoHint" : "inputSensitivityHint"), o.auto ? "" : s);
		}, d = () => {
			this.liveKitClient?.previewVoiceGate({ ...o }), u();
		};
		this.meter = new tn({
			name: `${l}.audioNoiseGateThreshold`,
			settings: o,
			onInput: (e) => {
				s.textContent = `${e.toString()} dB`, o.threshold = e, d();
			}
		});
		let f = this.moduleSwitch("audioAutoSensitivity");
		f.querySelector("input")?.addEventListener("change", (e) => {
			o.auto = e.currentTarget.checked, d();
		});
		let ee = this.group(g("inputSensitivity"), f, this.meter.element, c);
		u();
		let p = (e) => {
			a.hidden = e !== "ptt", ee.hidden = e !== "always";
		}, m = Nt({
			name: "core.rtcClientSettings.voice.mode",
			label: g("inputMode"),
			value: t.voice.mode,
			options: [{
				value: "always",
				label: g("inputModeVoiceActivity")
			}, {
				value: "ptt",
				label: g("inputModePushToTalk")
			}],
			onChange: p
		});
		return p(t.voice.mode), [
			this.group(g("devices"), n("audioSrc", e.audioSources, !0), "setSinkId" in HTMLMediaElement.prototype && n("audioSink", e.audioSinks, !1)),
			this.group(g("inputMode"), m, a),
			ee
		];
	}
	buildNoise() {
		let e = this.liveKitClient;
		if (!e) return [];
		let t = e.getNoiseModelOptions(), n = !!e.getAudioProcessingConfig().model;
		return [this.group(g("noiseSuppressionModel"), _({
			label: g("noiseSuppressionModel"),
			hint: g("noiseSuppressionModelHint"),
			control: kt({
				name: "livekit.noiseModel",
				label: g("noiseSuppressionModel"),
				options: on(t),
				value: t.find((e) => e.selected)?.model ?? "none"
			})
		}), this.moduleSwitch("audioEchoCancellation"), this.moduleSwitch("audioAutoGainControl"), this.moduleSwitch("audioNoiseSuppression", { hint: n ? g("audioNoiseSuppressionModelActive") : void 0 })), this.group(g("audioQuality"), _({
			label: g("audioQualityPreset"),
			hint: g("audioQualityPresetHint"),
			control: kt({
				name: `${l}.audioQualityPreset`,
				label: g("audioQualityPreset"),
				options: [
					"telephone",
					"speech",
					"music",
					"musicStereo",
					"musicHighQuality",
					"musicHighQualityStereo"
				].map((e) => ({
					value: e,
					label: g(`audioQualityPreset${e.charAt(0).toUpperCase()}${e.slice(1)}`)
				})),
				value: game.settings?.get("avclient-livekit", "audioQualityPreset") ?? "speech"
			})
		}), this.moduleSwitch("audioMusicMode"))];
	}
	buildVideo() {
		let e = this.data, t = game.webrtc?.settings.client;
		return !e || !t ? [] : [this.group(g("devices"), _({
			label: g("videoSrc"),
			control: kt({
				name: "core.rtcClientSettings.videoSrc",
				label: g("videoSrc"),
				options: [...an(e.videoSources, t.videoSrc).filter((e) => e.value !== "disabled"), {
					value: "disabled",
					label: g("deviceDisabled")
				}],
				value: t.videoSrc
			})
		})), this.group(g("videoReceiving"), this.clientSwitch("disableVideo"))];
	}
	buildAppearance() {
		let e = game.webrtc?.settings.client;
		if (!e) return [];
		let t = game.settings?.get("avclient-livekit", "allowDiscordStyleUI") ?? !0;
		return [
			this.group(g("appearanceInterface"), this.moduleSwitch("discordStyleUI", {
				disabled: !t,
				hint: t ? void 0 : g("discordStyleUIDisabledByGM")
			}), this.moduleSwitch("displayConnectionQuality")),
			this.group(g("appearanceDock"), _({
				label: g("clientSetting.dockPosition"),
				control: kt({
					name: "core.rtcClientSettings.dockPosition",
					label: g("clientSetting.dockPosition"),
					options: [
						"top",
						"right",
						"bottom",
						"left"
					].map((e) => ({
						value: e,
						label: g(`dockPosition.${e}`)
					})),
					value: e.dockPosition
				})
			}), _({
				label: g("clientSetting.nameplates"),
				control: kt({
					name: "core.rtcClientSettings.nameplates",
					label: g("clientSetting.nameplates"),
					dtype: "Number",
					options: [
						"off",
						"both",
						"playerOnly",
						"characterOnly"
					].map((e, t) => ({
						value: t.toString(),
						label: g(`nameplates.${e}`)
					})),
					value: String(e.nameplates)
				})
			}), this.clientSwitch("borderColors"), this.clientSwitch("hideDock"), this.clientSwitch("hidePlayerList")),
			!!this.liveKitClient?.dock && this.group(g("appearanceDiscordDock"), _({
				label: g("dockLayoutTitle"),
				control: kt({
					name: "avclient-livekit.dockLayout",
					label: g("dockLayoutTitle"),
					options: [
						"grid",
						"focus",
						"compact"
					].map((e) => ({
						value: e,
						label: g(`dockLayout.${e}`)
					})),
					value: game.settings?.get("avclient-livekit", "dockLayout") ?? "grid"
				})
			}), this.moduleSwitch("dockFollowSpeaker", {
				label: g("dockFollowSpeaker"),
				hint: g("dockFollowSpeakerHint")
			}), jt({
				name: "avclient-livekit.dockFloating.floating",
				label: g("dockFloatingSetting"),
				hint: g("dockFloatingSettingHint"),
				checked: game.settings?.get("avclient-livekit", "dockFloating").floating === !0
			}))
		];
	}
	buildAdvanced() {
		return [this.group(g("advancedConnection"), this.moduleSwitch("useExternalAV"))];
	}
	buildServer() {
		let e = this.data, t = game.webrtc?.settings.world;
		if (!e || !t) return [];
		let n = e.connectionSettings, r = this.liveKitClient?.liveKitServerTypes ?? {}, i = _({
			label: g("avMode"),
			hint: g("avModeHint"),
			control: kt({
				name: "core.rtcWorldSettings.mode",
				label: g("avMode"),
				dtype: "Number",
				options: [
					"disabled",
					"audio",
					"video",
					"audioVideo"
				].map((e, t) => ({
					value: t.toString(),
					label: g(`avModeOption.${e}`)
				})),
				value: String(t.mode)
			})
		}), a = (e, t) => _({
			label: g(`connection.${e}`),
			hint: un(`connection.${e}`),
			control: At({
				type: t,
				name: `${l}.liveKitConnectionSettings.${e}`,
				value: n[e] ?? "",
				attrs: { autocomplete: t === "password" ? "one-time-code" : "off" }
			})
		}), o = h("div", {
			className: "livekit-settings-subgroup",
			children: [
				a("url", "text"),
				a("username", "text"),
				a("password", "password")
			]
		}), s = this.buildTavernAccount(), c = n.serverType, u = (e) => {
			o.hidden = e !== "custom", s.hidden = e !== "tavern", s.classList.toggle("unsaved", c !== "tavern");
		}, d = kt({
			name: `${l}.liveKitConnectionSettings.serverType`,
			label: g("serverType"),
			options: Object.values(r).map((e) => ({
				value: e.key,
				label: game.i18n?.localize(e.label) ?? e.key
			})),
			value: c ?? "custom",
			onChange: u
		});
		return u(c ?? "custom"), [this.group(g("serverGroupAV"), i), this.group(g("serverGroupConnection"), _({
			label: g("serverType"),
			hint: g("serverTypeNotes"),
			control: d
		}), o, s)];
	}
	buildTavernAccount() {
		let e = game.settings?.get("avclient-livekit", "tavernPatreonToken") ?? "", t = game.settings?.get("avclient-livekit", "authServer") ?? "", n = this.data?.authResponse, r = h("p", { className: "livekit-setting-hint" });
		n && "error" in n ? r.textContent = `${g("patreonAccountError")}: ${n.error}` : n && r.append(`${g("patreonAccountNote")}: ${n.vanity ?? n.full_name ?? ""} (`, h("a", {
			text: n.active_tier ?? g("patreonAccountNotMember"),
			attrs: {
				href: "https://www.patreon.com/tavern_at",
				target: "_blank"
			}
		}), ")");
		let i = _({
			label: g("tavernAccountToken"),
			hint: g("tavernAccountTokenHint"),
			control: At({
				type: "password",
				name: `${l}.tavernPatreonToken`,
				value: e
			})
		}), a = h("i", {
			className: "fa-brands fa-patreon",
			attrs: { "aria-hidden": "true" }
		}), o = qt(e ? {
			label: g("tavernAccountLogoutLabel"),
			icon: a,
			onClick: () => {
				this._patreonLogout(t).catch((e) => {
					sn.error("Error logging out of Patreon account", e);
				});
			}
		} : {
			label: g("tavernAccountPatreonLabel"),
			variant: "patreon",
			icon: a,
			onClick: () => {
				this.patreonLogin(t), i.hidden = !1;
			}
		});
		return i.hidden = !0, h("div", {
			className: "livekit-settings-subgroup livekit-tavern",
			children: [
				_({
					label: g("tavernAccountLabel"),
					hint: e ? r : g("tavernAccountPatreonHint"),
					control: o,
					inline: !0
				}),
				h("p", {
					className: "livekit-setting-hint livekit-tavern-unsaved",
					text: g("tavernSaveFirst")
				}),
				i
			]
		});
	}
	buildPlayerOptions() {
		return [this.group(g("playerOptions"), this.moduleSwitch("allowDiscordStyleUI"), this.moduleSwitch("allowKrisp"), _({
			label: g("defaultNoiseModel"),
			hint: g("defaultNoiseModelHint"),
			control: kt({
				name: `${l}.defaultNoiseModel`,
				label: g("defaultNoiseModel"),
				options: [
					"none",
					"speex",
					"rnnoise",
					"gtcrn",
					"krisp"
				].map((e) => ({
					value: e,
					label: g(`noiseSuppressionModel${e.charAt(0).toUpperCase()}${e.slice(1)}`)
				})),
				value: game.settings?.get("avclient-livekit", "defaultNoiseModel") ?? "gtcrn"
			})
		}))];
	}
	buildTroubleshooting() {
		let e = game.settings?.get("avclient-livekit", "debug") ?? !1, t = game.settings?.get("avclient-livekit", "devMode") ?? !1, n = qt({
			label: g("resetRoomButton"),
			variant: "danger",
			onClick: () => {
				game.settings?.set(l, "resetRoom", !0).then(() => {
					ui.notifications?.info(g("resetRoomDone"));
				}).catch((e) => {
					sn.error("Error resetting the meeting room", e);
				});
			}
		}), r = this.moduleSwitch("debug"), i = this.moduleSwitch("liveKitTrace", {
			disabled: !e,
			hint: e ? void 0 : g("liveKitTraceNeedsDebug")
		});
		return r.querySelector("input")?.addEventListener("change", (e) => {
			let t = e.currentTarget.checked, n = i.querySelector("input");
			n && (n.disabled = !t), i.classList.toggle("disabled", !t);
		}), [
			this.group(g("troubleshootingRoom"), _({
				label: g("resetRoom"),
				hint: g("resetRoomHint"),
				control: n,
				inline: !0
			})),
			this.group(g("troubleshootingLogging"), r, i),
			t && this.group(g("troubleshootingDeveloper"), !1, t && this.moduleSwitch("forceTurn"), t && _({
				label: g("authServer"),
				hint: g("authServerHint"),
				control: At({
					name: "avclient-livekit.authServer",
					value: game.settings?.get("avclient-livekit", "authServer") ?? ""
				})
			}))
		];
	}
	patreonLogin(e) {
		if (!game.user?.isGM || !e) {
			sn.error("Auth server is not set");
			return;
		}
		let t = btoa(`{"host": "${window.location.hostname}", "world": "${game.world.id}"}`);
		window.addEventListener("message", (e) => {
			this._patreonLoginListener(e).catch((e) => {
				sn.error("Error logging in to Patreon account", e);
			});
		}, { once: !0 }), window.open(`${e}/auth/patreon?id=${t}&clientRole=participant`, void 0, "width=600,height=800");
	}
	async _patreonLogout(e) {
		if (!game.user?.isGM) return;
		let t = game.settings.get(l, "tavernPatreonToken"), n = await fetch(`${e}/logout`, {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify({ id: t })
		});
		n.ok || (ui.notifications?.error(`${u}.liveKitAccountLogoutError`, { localize: !0 }), sn.warn("Error signing out of Patreon account", n)), t = "", await game.settings.set(l, "tavernPatreonToken", t), ne();
	}
	async _patreonLoginListener(e) {
		if (!game.user?.isGM) return;
		let t = game.settings.get(l, "authServer");
		if (e.origin !== t) return;
		e.preventDefault();
		let n = e.data.id;
		await game.settings.set(l, "tavernPatreonToken", n), ne();
	}
	static async #e(e, t, n) {
		let r = game.webrtc?.settings;
		if (!r) {
			sn.error("WebRTC settings not found");
			return;
		}
		let i = foundry.utils.expandObject(n.object).core, a = foundry.utils.expandObject(n.object)["avclient-livekit"], o = foundry.utils.expandObject(n.object).livekit, s = game.webrtc?.client._liveKitClient, c = s?.getSelectedNoiseModel(), u = [];
		if (game.user?.isGM) {
			let e = foundry.utils.mergeObject(r.world, i.rtcWorldSettings, { inplace: !1 });
			r.world.mode !== e.mode && foundry.applications.settings.SettingsConfig.reloadConfirm({ world: !0 }), u.push(game.settings.set("core", "rtcWorldSettings", e));
		}
		let d = foundry.utils.mergeObject(r.client, i.rtcClientSettings, { inplace: !1 });
		game.settings && u.push(game.settings.set("core", "rtcClientSettings", d)), await Promise.all(u);
		let f = !1, ee = !1;
		for (let [e, t] of Object.entries(a ?? {})) {
			let n = game.settings?.settings.get(`${l}.${e}`);
			if (!n) continue;
			let r = game.settings?.get(n.namespace, n.key, { document: !0 })._source.value;
			if (n.key === "liveKitConnectionSettings" || n.key === "dockFloating") {
				let e = game.settings?.get(n.namespace, n.key);
				t = foundry.utils.mergeObject(e, t, { inplace: !1 });
			}
			if (r === JSON.stringify(t)) continue;
			let i;
			try {
				i = await game.settings?.set(n.namespace, n.key, t, { document: !0 });
			} catch (e) {
				ui.notifications?.error(e);
			}
			r !== i?._source.value && (f ||= (n.scope !== "world" && n.requiresReload) ?? !1, ee ||= (n.scope === "world" && n.requiresReload) ?? !1);
		}
		o?.noiseModel && s && o.noiseModel !== c && await s.selectNoiseModel(o.noiseModel), o?.pushToTalkKey && await Rt(o.pushToTalkKey), (f || ee) && await foundry.applications.settings.SettingsConfig.reloadConfirm({ world: ee }), await this.render();
	}
};
function un(e) {
	let t = `${u}.${e}Hint`, n = game.i18n?.localize(t);
	return n && n !== t ? n : void 0;
}
//#endregion
//#region node_modules/.pnpm/livekit-client@2.19.2_@types+dom-mediacapture-record@1.0.22/node_modules/livekit-client/dist/livekit-client.esm.mjs
function dn(e, t) {
	return t.forEach(function(t) {
		t && typeof t != "string" && !Array.isArray(t) && Object.keys(t).forEach(function(n) {
			if (n !== "default" && !(n in e)) {
				var r = Object.getOwnPropertyDescriptor(t, n);
				Object.defineProperty(e, n, r.get ? r : {
					enumerable: !0,
					get: function() {
						return t[n];
					}
				});
			}
		});
	}), Object.freeze(e);
}
var fn = Object.defineProperty, pn = (e, t, n) => t in e ? fn(e, t, {
	enumerable: !0,
	configurable: !0,
	writable: !0,
	value: n
}) : e[t] = n, mn = (e, t, n) => pn(e, typeof t == "symbol" ? t : t + "", n), v = class {
	constructor() {
		mn(this, "_locking"), mn(this, "_locks"), this._locking = Promise.resolve(), this._locks = 0;
	}
	isLocked() {
		return this._locks > 0;
	}
	lock() {
		this._locks += 1;
		let e, t = new Promise((t) => e = () => {
			--this._locks, t();
		}), n = this._locking.then(() => e);
		return this._locking = this._locking.then(() => t), n;
	}
};
function y(e, t) {
	if (!e) throw Error(t);
}
var hn = 34028234663852886e22, gn = -34028234663852886e22, _n = 4294967295, vn = 2147483647, yn = -2147483648;
function bn(e) {
	if (typeof e != "number") throw Error("invalid int 32: " + typeof e);
	if (!Number.isInteger(e) || e > vn || e < yn) throw Error("invalid int 32: " + e);
}
function xn(e) {
	if (typeof e != "number") throw Error("invalid uint 32: " + typeof e);
	if (!Number.isInteger(e) || e > _n || e < 0) throw Error("invalid uint 32: " + e);
}
function Sn(e) {
	if (typeof e != "number") throw Error("invalid float 32: " + typeof e);
	if (Number.isFinite(e) && (e > hn || e < gn)) throw Error("invalid float 32: " + e);
}
var Cn = Symbol("@bufbuild/protobuf/enum-type");
function wn(e) {
	let t = e[Cn];
	return y(t, "missing enum type on enum object"), t;
}
function Tn(e, t, n, r) {
	e[Cn] = En(t, n.map((t) => ({
		no: t.no,
		name: t.name,
		localName: e[t.no]
	})));
}
function En(e, t, n) {
	let r = Object.create(null), i = Object.create(null), a = [];
	for (let e of t) {
		let t = On(e);
		a.push(t), r[e.name] = t, i[e.no] = t;
	}
	return {
		typeName: e,
		values: a,
		findName(e) {
			return r[e];
		},
		findNumber(e) {
			return i[e];
		}
	};
}
function Dn(e, t, n) {
	let r = {};
	for (let e of t) {
		let t = On(e);
		r[t.localName] = t.no, r[t.no] = t.localName;
	}
	return Tn(r, e, t), r;
}
function On(e) {
	return "localName" in e ? e : Object.assign(Object.assign({}, e), { localName: e.name });
}
var kn = class {
	equals(e) {
		return this.getType().runtime.util.equals(this.getType(), this, e);
	}
	clone() {
		return this.getType().runtime.util.clone(this);
	}
	fromBinary(e, t) {
		let n = this.getType().runtime.bin, r = n.makeReadOptions(t);
		return n.readMessage(this, r.readerFactory(e), e.byteLength, r), this;
	}
	fromJson(e, t) {
		let n = this.getType(), r = n.runtime.json, i = r.makeReadOptions(t);
		return r.readMessage(n, e, i, this), this;
	}
	fromJsonString(e, t) {
		let n;
		try {
			n = JSON.parse(e);
		} catch (e) {
			throw Error(`cannot decode ${this.getType().typeName} from JSON: ${e instanceof Error ? e.message : String(e)}`);
		}
		return this.fromJson(n, t);
	}
	toBinary(e) {
		let t = this.getType().runtime.bin, n = t.makeWriteOptions(e), r = n.writerFactory();
		return t.writeMessage(this, r, n), r.finish();
	}
	toJson(e) {
		let t = this.getType().runtime.json, n = t.makeWriteOptions(e);
		return t.writeMessage(this, n);
	}
	toJsonString(e) {
		let t = this.toJson(e);
		return JSON.stringify(t, null, e?.prettySpaces ?? 0);
	}
	toJSON() {
		return this.toJson({ emitDefaultValues: !0 });
	}
	getType() {
		return Object.getPrototypeOf(this).constructor;
	}
};
function An(e, t, n, r) {
	let i = r?.localName ?? t.substring(t.lastIndexOf(".") + 1), a = { [i]: function(t) {
		e.util.initFields(this), e.util.initPartial(t, this);
	} }[i];
	return Object.setPrototypeOf(a.prototype, new kn()), Object.assign(a, {
		runtime: e,
		typeName: t,
		fields: e.util.newFieldList(n),
		fromBinary(e, t) {
			return new a().fromBinary(e, t);
		},
		fromJson(e, t) {
			return new a().fromJson(e, t);
		},
		fromJsonString(e, t) {
			return new a().fromJsonString(e, t);
		},
		equals(t, n) {
			return e.util.equals(a, t, n);
		}
	}), a;
}
function jn() {
	let e = 0, t = 0;
	for (let n = 0; n < 28; n += 7) {
		let r = this.buf[this.pos++];
		if (e |= (r & 127) << n, !(r & 128)) return this.assertBounds(), [e, t];
	}
	let n = this.buf[this.pos++];
	if (e |= (n & 15) << 28, t = (n & 112) >> 4, !(n & 128)) return this.assertBounds(), [e, t];
	for (let n = 3; n <= 31; n += 7) {
		let r = this.buf[this.pos++];
		if (t |= (r & 127) << n, !(r & 128)) return this.assertBounds(), [e, t];
	}
	throw Error("invalid varint");
}
function Mn(e, t, n) {
	for (let r = 0; r < 28; r += 7) {
		let i = e >>> r, a = !(!(i >>> 7) && t == 0), o = (a ? i | 128 : i) & 255;
		if (n.push(o), !a) return;
	}
	let r = e >>> 28 & 15 | (t & 7) << 4, i = !!(t >> 3);
	if (n.push((i ? r | 128 : r) & 255), i) {
		for (let e = 3; e < 31; e += 7) {
			let r = t >>> e, i = !!(r >>> 7), a = (i ? r | 128 : r) & 255;
			if (n.push(a), !i) return;
		}
		n.push(t >>> 31 & 1);
	}
}
var Nn = 4294967296;
function Pn(e) {
	let t = e[0] === "-";
	t && (e = e.slice(1));
	let n = 1e6, r = 0, i = 0;
	function a(t, a) {
		let o = Number(e.slice(t, a));
		i *= n, r = r * n + o, r >= Nn && (i += r / Nn | 0, r %= Nn);
	}
	return a(-24, -18), a(-18, -12), a(-12, -6), a(-6), t ? zn(r, i) : Rn(r, i);
}
function Fn(e, t) {
	let n = Rn(e, t), r = n.hi & 2147483648;
	r && (n = zn(n.lo, n.hi));
	let i = In(n.lo, n.hi);
	return r ? "-" + i : i;
}
function In(e, t) {
	var n = Ln(e, t);
	if (e = n.lo, t = n.hi, t <= 2097151) return String(Nn * t + e);
	let r = e & 16777215, i = (e >>> 24 | t << 8) & 16777215, a = t >> 16 & 65535, o = r + i * 6777216 + a * 6710656, s = i + a * 8147497, c = a * 2, l = 1e7;
	return o >= l && (s += Math.floor(o / l), o %= l), s >= l && (c += Math.floor(s / l), s %= l), c.toString() + Bn(s) + Bn(o);
}
function Ln(e, t) {
	return {
		lo: e >>> 0,
		hi: t >>> 0
	};
}
function Rn(e, t) {
	return {
		lo: e | 0,
		hi: t | 0
	};
}
function zn(e, t) {
	return t = ~t, e ? e = ~e + 1 : t += 1, Rn(e, t);
}
var Bn = (e) => {
	let t = String(e);
	return "0000000".slice(t.length) + t;
};
function Vn(e, t) {
	if (e >= 0) {
		for (; e > 127;) t.push(e & 127 | 128), e >>>= 7;
		t.push(e);
	} else {
		for (let n = 0; n < 9; n++) t.push(e & 127 | 128), e >>= 7;
		t.push(1);
	}
}
function Hn() {
	let e = this.buf[this.pos++], t = e & 127;
	if (!(e & 128) || (e = this.buf[this.pos++], t |= (e & 127) << 7, !(e & 128)) || (e = this.buf[this.pos++], t |= (e & 127) << 14, !(e & 128)) || (e = this.buf[this.pos++], t |= (e & 127) << 21, !(e & 128))) return this.assertBounds(), t;
	e = this.buf[this.pos++], t |= (e & 15) << 28;
	for (let t = 5; e & 128 && t < 10; t++) e = this.buf[this.pos++];
	if (e & 128) throw Error("invalid varint");
	return this.assertBounds(), t >>> 0;
}
function Un() {
	let e = /* @__PURE__ */ new DataView(/* @__PURE__ */ new ArrayBuffer(8));
	if (typeof BigInt == "function" && typeof e.getBigInt64 == "function" && typeof e.getBigUint64 == "function" && typeof e.setBigInt64 == "function" && typeof e.setBigUint64 == "function" && (typeof process != "object" || typeof process.env != "object" || process.env.BUF_BIGINT_DISABLE !== "1")) {
		let t = BigInt("-9223372036854775808"), n = BigInt("9223372036854775807"), r = BigInt("0"), i = BigInt("18446744073709551615");
		return {
			zero: BigInt(0),
			supported: !0,
			parse(e) {
				let r = typeof e == "bigint" ? e : BigInt(e);
				if (r > n || r < t) throw Error(`int64 invalid: ${e}`);
				return r;
			},
			uParse(e) {
				let t = typeof e == "bigint" ? e : BigInt(e);
				if (t > i || t < r) throw Error(`uint64 invalid: ${e}`);
				return t;
			},
			enc(t) {
				return e.setBigInt64(0, this.parse(t), !0), {
					lo: e.getInt32(0, !0),
					hi: e.getInt32(4, !0)
				};
			},
			uEnc(t) {
				return e.setBigInt64(0, this.uParse(t), !0), {
					lo: e.getInt32(0, !0),
					hi: e.getInt32(4, !0)
				};
			},
			dec(t, n) {
				return e.setInt32(0, t, !0), e.setInt32(4, n, !0), e.getBigInt64(0, !0);
			},
			uDec(t, n) {
				return e.setInt32(0, t, !0), e.setInt32(4, n, !0), e.getBigUint64(0, !0);
			}
		};
	}
	let t = (e) => y(/^-?[0-9]+$/.test(e), `int64 invalid: ${e}`), n = (e) => y(/^[0-9]+$/.test(e), `uint64 invalid: ${e}`);
	return {
		zero: "0",
		supported: !1,
		parse(e) {
			return typeof e != "string" && (e = e.toString()), t(e), e;
		},
		uParse(e) {
			return typeof e != "string" && (e = e.toString()), n(e), e;
		},
		enc(e) {
			return typeof e != "string" && (e = e.toString()), t(e), Pn(e);
		},
		uEnc(e) {
			return typeof e != "string" && (e = e.toString()), n(e), Pn(e);
		},
		dec(e, t) {
			return Fn(e, t);
		},
		uDec(e, t) {
			return In(e, t);
		}
	};
}
var b = Un(), x;
(function(e) {
	e[e.DOUBLE = 1] = "DOUBLE", e[e.FLOAT = 2] = "FLOAT", e[e.INT64 = 3] = "INT64", e[e.UINT64 = 4] = "UINT64", e[e.INT32 = 5] = "INT32", e[e.FIXED64 = 6] = "FIXED64", e[e.FIXED32 = 7] = "FIXED32", e[e.BOOL = 8] = "BOOL", e[e.STRING = 9] = "STRING", e[e.BYTES = 12] = "BYTES", e[e.UINT32 = 13] = "UINT32", e[e.SFIXED32 = 15] = "SFIXED32", e[e.SFIXED64 = 16] = "SFIXED64", e[e.SINT32 = 17] = "SINT32", e[e.SINT64 = 18] = "SINT64";
})(x ||= {});
var Wn;
(function(e) {
	e[e.BIGINT = 0] = "BIGINT", e[e.STRING = 1] = "STRING";
})(Wn ||= {});
function Gn(e, t, n) {
	if (t === n) return !0;
	if (e == x.BYTES) {
		if (!(t instanceof Uint8Array) || !(n instanceof Uint8Array) || t.length !== n.length) return !1;
		for (let e = 0; e < t.length; e++) if (t[e] !== n[e]) return !1;
		return !0;
	}
	switch (e) {
		case x.UINT64:
		case x.FIXED64:
		case x.INT64:
		case x.SFIXED64:
		case x.SINT64: return t == n;
	}
	return !1;
}
function Kn(e, t) {
	switch (e) {
		case x.BOOL: return !1;
		case x.UINT64:
		case x.FIXED64:
		case x.INT64:
		case x.SFIXED64:
		case x.SINT64: return t == 0 ? b.zero : "0";
		case x.DOUBLE:
		case x.FLOAT: return 0;
		case x.BYTES: return new Uint8Array();
		case x.STRING: return "";
		default: return 0;
	}
}
function qn(e, t) {
	switch (e) {
		case x.BOOL: return t === !1;
		case x.STRING: return t === "";
		case x.BYTES: return t instanceof Uint8Array && !t.byteLength;
		default: return t == 0;
	}
}
function Jn(e, t) {
	(t == null || t > e.length) && (t = e.length);
	for (var n = 0, r = Array(t); n < t; n++) r[n] = e[n];
	return r;
}
function Yn(e) {
	if (Array.isArray(e)) return e;
}
function S(e, t, n) {
	return (t = $n(t)) in e ? Object.defineProperty(e, t, {
		value: n,
		enumerable: !0,
		configurable: !0,
		writable: !0
	}) : e[t] = n, e;
}
function Xn(e, t) {
	var n = e == null ? null : typeof Symbol < "u" && e[Symbol.iterator] || e["@@iterator"];
	if (n != null) {
		var r, i, a, o, s = [], c = !0, l = !1;
		try {
			if (a = (n = n.call(e)).next, t === 0) {
				if (Object(n) !== n) return;
				c = !1;
			} else for (; !(c = (r = a.call(n)).done) && (s.push(r.value), s.length !== t); c = !0);
		} catch (e) {
			l = !0, i = e;
		} finally {
			try {
				if (!c && n.return != null && (o = n.return(), Object(o) !== o)) return;
			} finally {
				if (l) throw i;
			}
		}
		return s;
	}
}
function Zn() {
	throw TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function C(e, t) {
	return Yn(e) || Xn(e, t) || er(e, t) || Zn();
}
function Qn(e, t) {
	if (typeof e != "object" || !e) return e;
	var n = e[Symbol.toPrimitive];
	if (n !== void 0) {
		var r = n.call(e, t);
		if (typeof r != "object") return r;
		throw TypeError("@@toPrimitive must return a primitive value.");
	}
	return (t === "string" ? String : Number)(e);
}
function $n(e) {
	var t = Qn(e, "string");
	return typeof t == "symbol" ? t : t + "";
}
function er(e, t) {
	if (e) {
		if (typeof e == "string") return Jn(e, t);
		var n = {}.toString.call(e).slice(8, -1);
		return n === "Object" && e.constructor && (n = e.constructor.name), n === "Map" || n === "Set" ? Array.from(e) : n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? Jn(e, t) : void 0;
	}
}
var w;
(function(e) {
	e[e.Varint = 0] = "Varint", e[e.Bit64 = 1] = "Bit64", e[e.LengthDelimited = 2] = "LengthDelimited", e[e.StartGroup = 3] = "StartGroup", e[e.EndGroup = 4] = "EndGroup", e[e.Bit32 = 5] = "Bit32";
})(w ||= {});
var tr = class {
	constructor(e) {
		this.stack = [], this.textEncoder = e ?? new TextEncoder(), this.chunks = [], this.buf = [];
	}
	finish() {
		this.chunks.push(new Uint8Array(this.buf));
		let e = 0;
		for (let t = 0; t < this.chunks.length; t++) e += this.chunks[t].length;
		let t = new Uint8Array(e), n = 0;
		for (let e = 0; e < this.chunks.length; e++) t.set(this.chunks[e], n), n += this.chunks[e].length;
		return this.chunks = [], t;
	}
	fork() {
		return this.stack.push({
			chunks: this.chunks,
			buf: this.buf
		}), this.chunks = [], this.buf = [], this;
	}
	join() {
		let e = this.finish(), t = this.stack.pop();
		if (!t) throw Error("invalid state, fork stack empty");
		return this.chunks = t.chunks, this.buf = t.buf, this.uint32(e.byteLength), this.raw(e);
	}
	tag(e, t) {
		return this.uint32((e << 3 | t) >>> 0);
	}
	raw(e) {
		return this.buf.length && (this.chunks.push(new Uint8Array(this.buf)), this.buf = []), this.chunks.push(e), this;
	}
	uint32(e) {
		for (xn(e); e > 127;) this.buf.push(e & 127 | 128), e >>>= 7;
		return this.buf.push(e), this;
	}
	int32(e) {
		return bn(e), Vn(e, this.buf), this;
	}
	bool(e) {
		return this.buf.push(+!!e), this;
	}
	bytes(e) {
		return this.uint32(e.byteLength), this.raw(e);
	}
	string(e) {
		let t = this.textEncoder.encode(e);
		return this.uint32(t.byteLength), this.raw(t);
	}
	float(e) {
		Sn(e);
		let t = new Uint8Array(4);
		return new DataView(t.buffer).setFloat32(0, e, !0), this.raw(t);
	}
	double(e) {
		let t = new Uint8Array(8);
		return new DataView(t.buffer).setFloat64(0, e, !0), this.raw(t);
	}
	fixed32(e) {
		xn(e);
		let t = new Uint8Array(4);
		return new DataView(t.buffer).setUint32(0, e, !0), this.raw(t);
	}
	sfixed32(e) {
		bn(e);
		let t = new Uint8Array(4);
		return new DataView(t.buffer).setInt32(0, e, !0), this.raw(t);
	}
	sint32(e) {
		return bn(e), e = (e << 1 ^ e >> 31) >>> 0, Vn(e, this.buf), this;
	}
	sfixed64(e) {
		let t = new Uint8Array(8), n = new DataView(t.buffer), r = b.enc(e);
		return n.setInt32(0, r.lo, !0), n.setInt32(4, r.hi, !0), this.raw(t);
	}
	fixed64(e) {
		let t = new Uint8Array(8), n = new DataView(t.buffer), r = b.uEnc(e);
		return n.setInt32(0, r.lo, !0), n.setInt32(4, r.hi, !0), this.raw(t);
	}
	int64(e) {
		let t = b.enc(e);
		return Mn(t.lo, t.hi, this.buf), this;
	}
	sint64(e) {
		let t = b.enc(e), n = t.hi >> 31;
		return Mn(t.lo << 1 ^ n, (t.hi << 1 | t.lo >>> 31) ^ n, this.buf), this;
	}
	uint64(e) {
		let t = b.uEnc(e);
		return Mn(t.lo, t.hi, this.buf), this;
	}
}, nr = class {
	constructor(e, t) {
		this.varint64 = jn, this.uint32 = Hn, this.buf = e, this.len = e.length, this.pos = 0, this.view = new DataView(e.buffer, e.byteOffset, e.byteLength), this.textDecoder = t ?? new TextDecoder();
	}
	tag() {
		let e = this.uint32(), t = e >>> 3, n = e & 7;
		if (t <= 0 || n < 0 || n > 5) throw Error("illegal tag: field no " + t + " wire type " + n);
		return [t, n];
	}
	skip(e, t) {
		let n = this.pos;
		switch (e) {
			case w.Varint:
				for (; this.buf[this.pos++] & 128;);
				break;
			case w.Bit64: this.pos += 4;
			case w.Bit32:
				this.pos += 4;
				break;
			case w.LengthDelimited:
				let n = this.uint32();
				this.pos += n;
				break;
			case w.StartGroup:
				for (;;) {
					let e = C(this.tag(), 2), n = e[0], r = e[1];
					if (r === w.EndGroup) {
						if (t !== void 0 && n !== t) throw Error("invalid end group tag");
						break;
					}
					this.skip(r, n);
				}
				break;
			default: throw Error("cant skip wire type " + e);
		}
		return this.assertBounds(), this.buf.subarray(n, this.pos);
	}
	assertBounds() {
		if (this.pos > this.len) throw RangeError("premature EOF");
	}
	int32() {
		return this.uint32() | 0;
	}
	sint32() {
		let e = this.uint32();
		return e >>> 1 ^ -(e & 1);
	}
	int64() {
		return b.dec(...this.varint64());
	}
	uint64() {
		return b.uDec(...this.varint64());
	}
	sint64() {
		let e = C(this.varint64(), 2), t = e[0], n = e[1], r = -(t & 1);
		return t = (t >>> 1 | (n & 1) << 31) ^ r, n = n >>> 1 ^ r, b.dec(t, n);
	}
	bool() {
		let e = C(this.varint64(), 2), t = e[0], n = e[1];
		return t !== 0 || n !== 0;
	}
	fixed32() {
		return this.view.getUint32((this.pos += 4) - 4, !0);
	}
	sfixed32() {
		return this.view.getInt32((this.pos += 4) - 4, !0);
	}
	fixed64() {
		return b.uDec(this.sfixed32(), this.sfixed32());
	}
	sfixed64() {
		return b.dec(this.sfixed32(), this.sfixed32());
	}
	float() {
		return this.view.getFloat32((this.pos += 4) - 4, !0);
	}
	double() {
		return this.view.getFloat64((this.pos += 8) - 8, !0);
	}
	bytes() {
		let e = this.uint32(), t = this.pos;
		return this.pos += e, this.assertBounds(), this.buf.subarray(t, t + e);
	}
	string() {
		return this.textDecoder.decode(this.bytes());
	}
};
function rr(e, t, n, r) {
	let i;
	return {
		typeName: t,
		extendee: n,
		get field() {
			if (!i) {
				let n = typeof r == "function" ? r() : r;
				n.name = t.split(".").pop(), n.jsonName = `[${t}]`, i = e.util.newFieldList([n]).list()[0];
			}
			return i;
		},
		runtime: e
	};
}
function ir(e) {
	let t = e.field.localName, n = Object.create(null);
	return n[t] = ar(e), [n, () => n[t]];
}
function ar(e) {
	let t = e.field;
	if (t.repeated) return [];
	if (t.default !== void 0) return t.default;
	switch (t.kind) {
		case "enum": return t.T.values[0].no;
		case "scalar": return Kn(t.T, t.L);
		case "message":
			let e = t.T, n = new e();
			return e.fieldWrapper ? e.fieldWrapper.unwrapField(n) : n;
		case "map": throw "map fields are not allowed to be extensions";
	}
}
function or(e, t) {
	if (!t.repeated && (t.kind == "enum" || t.kind == "scalar")) {
		for (let n = e.length - 1; n >= 0; --n) if (e[n].no == t.no) return [e[n]];
		return [];
	}
	return e.filter((e) => e.no === t.no);
}
var sr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".split(""), cr = [];
for (let e = 0; e < sr.length; e++) cr[sr[e].charCodeAt(0)] = e;
cr[45] = sr.indexOf("+"), cr[95] = sr.indexOf("/");
var lr = {
	dec(e) {
		let t = e.length * 3 / 4;
		e[e.length - 2] == "=" ? t -= 2 : e[e.length - 1] == "=" && --t;
		let n = new Uint8Array(t), r = 0, i = 0, a, o = 0;
		for (let t = 0; t < e.length; t++) {
			if (a = cr[e.charCodeAt(t)], a === void 0) switch (e[t]) {
				case "=": i = 0;
				case "\n":
				case "\r":
				case "	":
				case " ": continue;
				default: throw Error("invalid base64 string.");
			}
			switch (i) {
				case 0:
					o = a, i = 1;
					break;
				case 1:
					n[r++] = o << 2 | (a & 48) >> 4, o = a, i = 2;
					break;
				case 2:
					n[r++] = (o & 15) << 4 | (a & 60) >> 2, o = a, i = 3;
					break;
				case 3:
					n[r++] = (o & 3) << 6 | a, i = 0;
					break;
			}
		}
		if (i == 1) throw Error("invalid base64 string.");
		return n.subarray(0, r);
	},
	enc(e) {
		let t = "", n = 0, r, i = 0;
		for (let a = 0; a < e.length; a++) switch (r = e[a], n) {
			case 0:
				t += sr[r >> 2], i = (r & 3) << 4, n = 1;
				break;
			case 1:
				t += sr[i | r >> 4], i = (r & 15) << 2, n = 2;
				break;
			case 2:
				t += sr[i | r >> 6], t += sr[r & 63], n = 0;
				break;
		}
		return n && (t += sr[i], t += "=", n == 1 && (t += "=")), t;
	}
};
function ur(e, t, n) {
	pr(t, e);
	let r = t.runtime.bin.makeReadOptions(n), i = or(e.getType().runtime.bin.listUnknownFields(e), t.field), a = C(ir(t), 2), o = a[0], s = a[1];
	for (let e of i) t.runtime.bin.readField(o, r.readerFactory(e.data), t.field, e.wireType, r);
	return s();
}
function dr(e, t, n, r) {
	pr(t, e);
	let i = t.runtime.bin.makeReadOptions(r), a = t.runtime.bin.makeWriteOptions(r);
	if (fr(e, t)) {
		let n = e.getType().runtime.bin.listUnknownFields(e).filter((e) => e.no != t.field.no);
		e.getType().runtime.bin.discardUnknownFields(e);
		for (let t of n) e.getType().runtime.bin.onUnknownField(e, t.no, t.wireType, t.data);
	}
	let o = a.writerFactory(), s = t.field;
	!s.opt && !s.repeated && (s.kind == "enum" || s.kind == "scalar") && (s = Object.assign(Object.assign({}, t.field), { opt: !0 })), t.runtime.bin.writeField(s, n, o, a);
	let c = i.readerFactory(o.finish());
	for (; c.pos < c.len;) {
		let t = C(c.tag(), 2), n = t[0], r = t[1], i = c.skip(r, n);
		e.getType().runtime.bin.onUnknownField(e, n, r, i);
	}
}
function fr(e, t) {
	let n = e.getType();
	return t.extendee.typeName === n.typeName && !!n.runtime.bin.listUnknownFields(e).find((e) => e.no == t.field.no);
}
function pr(e, t) {
	y(e.extendee.typeName == t.getType().typeName, `extension ${e.typeName} can only be applied to message ${e.extendee.typeName}`);
}
function mr(e, t) {
	let n = e.localName;
	if (e.repeated) return t[n].length > 0;
	if (e.oneof) return t[e.oneof.localName].case === n;
	switch (e.kind) {
		case "enum":
		case "scalar": return e.opt || e.req ? t[n] !== void 0 : e.kind == "enum" ? t[n] !== e.T.values[0].no : !qn(e.T, t[n]);
		case "message": return t[n] !== void 0;
		case "map": return Object.keys(t[n]).length > 0;
	}
}
function hr(e, t) {
	let n = e.localName, r = !e.opt && !e.req;
	if (e.repeated) t[n] = [];
	else if (e.oneof) t[e.oneof.localName] = { case: void 0 };
	else switch (e.kind) {
		case "map":
			t[n] = {};
			break;
		case "enum":
			t[n] = r ? e.T.values[0].no : void 0;
			break;
		case "scalar":
			t[n] = r ? Kn(e.T, e.L) : void 0;
			break;
		case "message":
			t[n] = void 0;
			break;
	}
}
function gr(e, t) {
	if (typeof e != "object" || !e || !Object.getOwnPropertyNames(kn.prototype).every((t) => t in e && typeof e[t] == "function")) return !1;
	let n = e.getType();
	return n === null || typeof n != "function" || !("typeName" in n) || typeof n.typeName != "string" ? !1 : t === void 0 ? !0 : n.typeName == t.typeName;
}
function _r(e, t) {
	return gr(t) || !e.fieldWrapper ? t : e.fieldWrapper.wrapField(t);
}
x.DOUBLE, x.FLOAT, x.INT64, x.UINT64, x.INT32, x.UINT32, x.BOOL, x.STRING, x.BYTES;
var vr = { ignoreUnknownFields: !1 }, yr = {
	emitDefaultValues: !1,
	enumAsInteger: !1,
	useProtoFieldName: !1,
	prettySpaces: 0
};
function br(e) {
	return e ? Object.assign(Object.assign({}, vr), e) : vr;
}
function xr(e) {
	return e ? Object.assign(Object.assign({}, yr), e) : yr;
}
var Sr = Symbol(), Cr = Symbol();
function wr() {
	return {
		makeReadOptions: br,
		makeWriteOptions: xr,
		readMessage(e, t, n, r) {
			if (t == null || Array.isArray(t) || typeof t != "object") throw Error(`cannot decode message ${e.typeName} from JSON: ${Tr(t)}`);
			r ??= new e();
			let i = /* @__PURE__ */ new Map(), a = n.typeRegistry;
			for (let s of Object.entries(t)) {
				var o = C(s, 2);
				let t = o[0], c = o[1], l = e.fields.findJsonName(t);
				if (l) {
					if (l.oneof) {
						if (c === null && l.kind == "scalar") continue;
						let n = i.get(l.oneof);
						if (n !== void 0) throw Error(`cannot decode message ${e.typeName} from JSON: multiple keys for oneof "${l.oneof.name}" present: "${n}", "${t}"`);
						i.set(l.oneof, t);
					}
					Er(r, c, l, n, e);
				} else {
					let i = !1;
					if (a?.findExtension && t.startsWith("[") && t.endsWith("]")) {
						let o = a.findExtension(t.substring(1, t.length - 1));
						if (o && o.extendee.typeName == e.typeName) {
							i = !0;
							let e = C(ir(o), 2), t = e[0], a = e[1];
							Er(t, c, o.field, n, o), dr(r, o, a(), n);
						}
					}
					if (!i && !n.ignoreUnknownFields) throw Error(`cannot decode message ${e.typeName} from JSON: key "${t}" is unknown`);
				}
			}
			return r;
		},
		writeMessage(e, t) {
			let n = e.getType(), r = {}, i;
			try {
				for (i of n.fields.byNumber()) {
					if (!mr(i, e)) {
						if (i.req) throw "required field not set";
						if (!t.emitDefaultValues || !Ar(i)) continue;
					}
					let n = i.oneof ? e[i.oneof.localName].value : e[i.localName], a = jr(i, n, t);
					a !== void 0 && (r[t.useProtoFieldName ? i.name : i.jsonName] = a);
				}
				let a = t.typeRegistry;
				if (a?.findExtensionFor) for (let i of n.runtime.bin.listUnknownFields(e)) {
					let o = a.findExtensionFor(n.typeName, i.no);
					if (o && fr(e, o)) {
						let n = ur(e, o, t), i = jr(o.field, n, t);
						i !== void 0 && (r[o.field.jsonName] = i);
					}
				}
			} catch (e) {
				let t = i ? `cannot encode field ${n.typeName}.${i.name} to JSON` : `cannot encode message ${n.typeName} to JSON`, r = e instanceof Error ? e.message : String(e);
				throw Error(t + (r.length > 0 ? `: ${r}` : ""));
			}
			return r;
		},
		readScalar(e, t, n) {
			return Or(e, t, n ?? Wn.BIGINT, !0);
		},
		writeScalar(e, t, n) {
			if (t !== void 0 && (n || qn(e, t))) return Nr(e, t);
		},
		debug: Tr
	};
}
function Tr(e) {
	if (e === null) return "null";
	switch (typeof e) {
		case "object": return Array.isArray(e) ? "array" : "object";
		case "string": return e.length > 100 ? "string" : `"${e.split("\"").join("\\\"")}"`;
		default: return String(e);
	}
}
function Er(e, t, n, r, i) {
	let a = n.localName;
	if (n.repeated) {
		if (y(n.kind != "map"), t === null) return;
		if (!Array.isArray(t)) throw Error(`cannot decode field ${i.typeName}.${n.name} from JSON: ${Tr(t)}`);
		let o = e[a];
		for (let e of t) {
			if (e === null) throw Error(`cannot decode field ${i.typeName}.${n.name} from JSON: ${Tr(e)}`);
			switch (n.kind) {
				case "message":
					o.push(n.T.fromJson(e, r));
					break;
				case "enum":
					let t = kr(n.T, e, r.ignoreUnknownFields, !0);
					t !== Cr && o.push(t);
					break;
				case "scalar":
					try {
						o.push(Or(n.T, e, n.L, !0));
					} catch (t) {
						let r = `cannot decode field ${i.typeName}.${n.name} from JSON: ${Tr(e)}`;
						throw t instanceof Error && t.message.length > 0 && (r += `: ${t.message}`), Error(r);
					}
					break;
			}
		}
	} else if (n.kind == "map") {
		if (t === null) return;
		if (typeof t != "object" || Array.isArray(t)) throw Error(`cannot decode field ${i.typeName}.${n.name} from JSON: ${Tr(t)}`);
		let s = e[a];
		for (let e of Object.entries(t)) {
			var o = C(e, 2);
			let a = o[0], c = o[1];
			if (c === null) throw Error(`cannot decode field ${i.typeName}.${n.name} from JSON: map value null`);
			let l;
			try {
				l = Dr(n.K, a);
			} catch (e) {
				let r = `cannot decode map key for field ${i.typeName}.${n.name} from JSON: ${Tr(t)}`;
				throw e instanceof Error && e.message.length > 0 && (r += `: ${e.message}`), Error(r);
			}
			switch (n.V.kind) {
				case "message":
					s[l] = n.V.T.fromJson(c, r);
					break;
				case "enum":
					let e = kr(n.V.T, c, r.ignoreUnknownFields, !0);
					e !== Cr && (s[l] = e);
					break;
				case "scalar":
					try {
						s[l] = Or(n.V.T, c, Wn.BIGINT, !0);
					} catch (e) {
						let r = `cannot decode map value for field ${i.typeName}.${n.name} from JSON: ${Tr(t)}`;
						throw e instanceof Error && e.message.length > 0 && (r += `: ${e.message}`), Error(r);
					}
					break;
			}
		}
	} else switch (n.oneof && (e = e[n.oneof.localName] = { case: a }, a = "value"), n.kind) {
		case "message":
			let o = n.T;
			if (t === null && o.typeName != "google.protobuf.Value") return;
			let s = e[a];
			gr(s) ? s.fromJson(t, r) : (e[a] = s = o.fromJson(t, r), o.fieldWrapper && !n.oneof && (e[a] = o.fieldWrapper.unwrapField(s)));
			break;
		case "enum":
			let c = kr(n.T, t, r.ignoreUnknownFields, !1);
			switch (c) {
				case Sr:
					hr(n, e);
					break;
				case Cr: break;
				default:
					e[a] = c;
					break;
			}
			break;
		case "scalar":
			try {
				let r = Or(n.T, t, n.L, !1);
				switch (r) {
					case Sr:
						hr(n, e);
						break;
					default:
						e[a] = r;
						break;
				}
			} catch (e) {
				let r = `cannot decode field ${i.typeName}.${n.name} from JSON: ${Tr(t)}`;
				throw e instanceof Error && e.message.length > 0 && (r += `: ${e.message}`), Error(r);
			}
			break;
	}
}
function Dr(e, t) {
	if (e === x.BOOL) switch (t) {
		case "true":
			t = !0;
			break;
		case "false":
			t = !1;
			break;
	}
	return Or(e, t, Wn.BIGINT, !0).toString();
}
function Or(e, t, n, r) {
	if (t === null) return r ? Kn(e, n) : Sr;
	switch (e) {
		case x.DOUBLE:
		case x.FLOAT:
			if (t === "NaN") return NaN;
			if (t === "Infinity") return Infinity;
			if (t === "-Infinity") return -Infinity;
			if (t === "" || typeof t == "string" && t.trim().length !== t.length || typeof t != "string" && typeof t != "number") break;
			let r = Number(t);
			if (Number.isNaN(r) || !Number.isFinite(r)) break;
			return e == x.FLOAT && Sn(r), r;
		case x.INT32:
		case x.FIXED32:
		case x.SFIXED32:
		case x.SINT32:
		case x.UINT32:
			let i;
			if (typeof t == "number" ? i = t : typeof t == "string" && t.length > 0 && t.trim().length === t.length && (i = Number(t)), i === void 0) break;
			return e == x.UINT32 || e == x.FIXED32 ? xn(i) : bn(i), i;
		case x.INT64:
		case x.SFIXED64:
		case x.SINT64:
			if (typeof t != "number" && typeof t != "string") break;
			let a = b.parse(t);
			return n ? a.toString() : a;
		case x.FIXED64:
		case x.UINT64:
			if (typeof t != "number" && typeof t != "string") break;
			let o = b.uParse(t);
			return n ? o.toString() : o;
		case x.BOOL:
			if (typeof t != "boolean") break;
			return t;
		case x.STRING:
			if (typeof t != "string") break;
			return t;
		case x.BYTES:
			if (t === "") return new Uint8Array();
			if (typeof t != "string") break;
			return lr.dec(t);
	}
	throw Error();
}
function kr(e, t, n, r) {
	if (t === null) return e.typeName == "google.protobuf.NullValue" ? 0 : r ? e.values[0].no : Sr;
	switch (typeof t) {
		case "number":
			if (Number.isInteger(t)) return t;
			break;
		case "string":
			let r = e.findName(t);
			if (r !== void 0) return r.no;
			if (n) return Cr;
			break;
	}
	throw Error(`cannot decode enum ${e.typeName} from JSON: ${Tr(t)}`);
}
function Ar(e) {
	return e.repeated || e.kind == "map" ? !0 : !(e.oneof || e.kind == "message" || e.opt || e.req);
}
function jr(e, t, n) {
	if (e.kind == "map") {
		y(typeof t == "object" && !!t);
		let o = {}, s = Object.entries(t);
		switch (e.V.kind) {
			case "scalar":
				for (let t of s) {
					var r = C(t, 2);
					let n = r[0], i = r[1];
					o[n.toString()] = Nr(e.V.T, i);
				}
				break;
			case "message":
				for (let e of s) {
					var i = C(e, 2);
					let t = i[0], r = i[1];
					o[t.toString()] = r.toJson(n);
				}
				break;
			case "enum":
				let t = e.V.T;
				for (let e of s) {
					var a = C(e, 2);
					let r = a[0], i = a[1];
					o[r.toString()] = Mr(t, i, n.enumAsInteger);
				}
				break;
		}
		return n.emitDefaultValues || s.length > 0 ? o : void 0;
	}
	if (e.repeated) {
		y(Array.isArray(t));
		let r = [];
		switch (e.kind) {
			case "scalar":
				for (let n = 0; n < t.length; n++) r.push(Nr(e.T, t[n]));
				break;
			case "enum":
				for (let i = 0; i < t.length; i++) r.push(Mr(e.T, t[i], n.enumAsInteger));
				break;
			case "message":
				for (let e = 0; e < t.length; e++) r.push(t[e].toJson(n));
				break;
		}
		return n.emitDefaultValues || r.length > 0 ? r : void 0;
	}
	switch (e.kind) {
		case "scalar": return Nr(e.T, t);
		case "enum": return Mr(e.T, t, n.enumAsInteger);
		case "message": return _r(e.T, t).toJson(n);
	}
}
function Mr(e, t, n) {
	return y(typeof t == "number"), e.typeName == "google.protobuf.NullValue" ? null : n ? t : e.findNumber(t)?.name ?? t;
}
function Nr(e, t) {
	switch (e) {
		case x.INT32:
		case x.SFIXED32:
		case x.SINT32:
		case x.FIXED32:
		case x.UINT32: return y(typeof t == "number"), t;
		case x.FLOAT:
		case x.DOUBLE: return y(typeof t == "number"), Number.isNaN(t) ? "NaN" : t === Infinity ? "Infinity" : t === -Infinity ? "-Infinity" : t;
		case x.STRING: return y(typeof t == "string"), t;
		case x.BOOL: return y(typeof t == "boolean"), t;
		case x.UINT64:
		case x.FIXED64:
		case x.INT64:
		case x.SFIXED64:
		case x.SINT64: return y(typeof t == "bigint" || typeof t == "string" || typeof t == "number"), t.toString();
		case x.BYTES: return y(t instanceof Uint8Array), lr.enc(t);
	}
}
var Pr = Symbol("@bufbuild/protobuf/unknown-fields"), Fr = {
	readUnknownFields: !0,
	readerFactory: (e) => new nr(e)
}, Ir = {
	writeUnknownFields: !0,
	writerFactory: () => new tr()
};
function Lr(e) {
	return e ? Object.assign(Object.assign({}, Fr), e) : Fr;
}
function Rr(e) {
	return e ? Object.assign(Object.assign({}, Ir), e) : Ir;
}
function zr() {
	return {
		makeReadOptions: Lr,
		makeWriteOptions: Rr,
		listUnknownFields(e) {
			return e[Pr] ?? [];
		},
		discardUnknownFields(e) {
			delete e[Pr];
		},
		writeUnknownFields(e, t) {
			let n = e[Pr];
			if (n) for (let e of n) t.tag(e.no, e.wireType).raw(e.data);
		},
		onUnknownField(e, t, n, r) {
			let i = e;
			Array.isArray(i[Pr]) || (i[Pr] = []), i[Pr].push({
				no: t,
				wireType: n,
				data: r
			});
		},
		readMessage(e, t, n, r, i) {
			let a = e.getType(), o = i ? t.len : t.pos + n, s, c;
			for (; t.pos < o;) {
				var l = C(t.tag(), 2);
				if (s = l[0], c = l[1], i === !0 && c == w.EndGroup) break;
				let n = a.fields.find(s);
				if (!n) {
					let n = t.skip(c, s);
					r.readUnknownFields && this.onUnknownField(e, s, c, n);
					continue;
				}
				Br(e, t, n, c, r);
			}
			if (i && (c != w.EndGroup || s !== n)) throw Error("invalid end group tag");
		},
		readField: Br,
		writeMessage(e, t, n) {
			let r = e.getType();
			for (let i of r.fields.byNumber()) {
				if (!mr(i, e)) {
					if (i.req) throw Error(`cannot encode field ${r.typeName}.${i.name} to binary: required field not set`);
					continue;
				}
				Gr(i, i.oneof ? e[i.oneof.localName].value : e[i.localName], t, n);
			}
			return n.writeUnknownFields && this.writeUnknownFields(e, t), t;
		},
		writeField(e, t, n, r) {
			t !== void 0 && Gr(e, t, n, r);
		}
	};
}
function Br(e, t, n, r, i) {
	let a = n.repeated, o = n.localName;
	switch (n.oneof && (e = e[n.oneof.localName], e.case != o && delete e.value, e.case = o, o = "value"), n.kind) {
		case "scalar":
		case "enum":
			let s = n.kind == "enum" ? x.INT32 : n.T, c = Wr;
			if (n.kind == "scalar" && n.L > 0 && (c = Ur), a) {
				let n = e[o];
				if (r == w.LengthDelimited && s != x.STRING && s != x.BYTES) {
					let e = t.uint32() + t.pos;
					for (; t.pos < e;) n.push(c(t, s));
				} else n.push(c(t, s));
			} else e[o] = c(t, s);
			break;
		case "message":
			let l = n.T;
			a ? e[o].push(Vr(t, new l(), i, n)) : gr(e[o]) ? Vr(t, e[o], i, n) : (e[o] = Vr(t, new l(), i, n), l.fieldWrapper && !n.oneof && !n.repeated && (e[o] = l.fieldWrapper.unwrapField(e[o])));
			break;
		case "map":
			let u = C(Hr(n, t, i), 2), d = u[0], f = u[1];
			e[o][d] = f;
			break;
	}
}
function Vr(e, t, n, r) {
	let i = t.getType().runtime.bin, a = r?.delimited;
	return i.readMessage(t, e, a ? r.no : e.uint32(), n, a), t;
}
function Hr(e, t, n) {
	let r = t.uint32(), i = t.pos + r, a, o;
	for (; t.pos < i;) switch (C(t.tag(), 1)[0]) {
		case 1:
			a = Wr(t, e.K);
			break;
		case 2:
			switch (e.V.kind) {
				case "scalar":
					o = Wr(t, e.V.T);
					break;
				case "enum":
					o = t.int32();
					break;
				case "message":
					o = Vr(t, new e.V.T(), n, void 0);
					break;
			}
			break;
	}
	if (a === void 0 && (a = Kn(e.K, Wn.BIGINT)), typeof a != "string" && typeof a != "number" && (a = a.toString()), o === void 0) switch (e.V.kind) {
		case "scalar":
			o = Kn(e.V.T, Wn.BIGINT);
			break;
		case "enum":
			o = e.V.T.values[0].no;
			break;
		case "message":
			o = new e.V.T();
			break;
	}
	return [a, o];
}
function Ur(e, t) {
	let n = Wr(e, t);
	return typeof n == "bigint" ? n.toString() : n;
}
function Wr(e, t) {
	switch (t) {
		case x.STRING: return e.string();
		case x.BOOL: return e.bool();
		case x.DOUBLE: return e.double();
		case x.FLOAT: return e.float();
		case x.INT32: return e.int32();
		case x.INT64: return e.int64();
		case x.UINT64: return e.uint64();
		case x.FIXED64: return e.fixed64();
		case x.BYTES: return e.bytes();
		case x.FIXED32: return e.fixed32();
		case x.SFIXED32: return e.sfixed32();
		case x.SFIXED64: return e.sfixed64();
		case x.SINT64: return e.sint64();
		case x.UINT32: return e.uint32();
		case x.SINT32: return e.sint32();
	}
}
function Gr(e, t, n, r) {
	y(t !== void 0);
	let i = e.repeated;
	switch (e.kind) {
		case "scalar":
		case "enum":
			let o = e.kind == "enum" ? x.INT32 : e.T;
			if (i) if (y(Array.isArray(t)), e.packed) Yr(n, o, e.no, t);
			else for (let r of t) Jr(n, o, e.no, r);
			else Jr(n, o, e.no, t);
			break;
		case "message":
			if (i) {
				y(Array.isArray(t));
				for (let i of t) qr(n, r, e, i);
			} else qr(n, r, e, t);
			break;
		case "map":
			y(typeof t == "object" && !!t);
			for (let i of Object.entries(t)) {
				var a = C(i, 2);
				let t = a[0], o = a[1];
				Kr(n, r, e, t, o);
			}
			break;
	}
}
function Kr(e, t, n, r, i) {
	e.tag(n.no, w.LengthDelimited), e.fork();
	let a = r;
	switch (n.K) {
		case x.INT32:
		case x.FIXED32:
		case x.UINT32:
		case x.SFIXED32:
		case x.SINT32:
			a = Number.parseInt(r);
			break;
		case x.BOOL:
			y(r == "true" || r == "false"), a = r == "true";
			break;
	}
	switch (Jr(e, n.K, 1, a), n.V.kind) {
		case "scalar":
			Jr(e, n.V.T, 2, i);
			break;
		case "enum":
			Jr(e, x.INT32, 2, i);
			break;
		case "message":
			y(i !== void 0), e.tag(2, w.LengthDelimited).bytes(i.toBinary(t));
			break;
	}
	e.join();
}
function qr(e, t, n, r) {
	let i = _r(n.T, r);
	n.delimited ? e.tag(n.no, w.StartGroup).raw(i.toBinary(t)).tag(n.no, w.EndGroup) : e.tag(n.no, w.LengthDelimited).bytes(i.toBinary(t));
}
function Jr(e, t, n, r) {
	y(r !== void 0);
	let i = C(Xr(t), 2), a = i[0], o = i[1];
	e.tag(n, a)[o](r);
}
function Yr(e, t, n, r) {
	if (!r.length) return;
	e.tag(n, w.LengthDelimited).fork();
	let i = C(Xr(t), 2)[1];
	for (let t = 0; t < r.length; t++) e[i](r[t]);
	e.join();
}
function Xr(e) {
	let t = w.Varint;
	switch (e) {
		case x.BYTES:
		case x.STRING:
			t = w.LengthDelimited;
			break;
		case x.DOUBLE:
		case x.FIXED64:
		case x.SFIXED64:
			t = w.Bit64;
			break;
		case x.FIXED32:
		case x.SFIXED32:
		case x.FLOAT:
			t = w.Bit32;
			break;
	}
	let n = x[e].toLowerCase();
	return [t, n];
}
function Zr() {
	return {
		setEnumType: Tn,
		initPartial(e, t) {
			if (e === void 0) return;
			let n = t.getType();
			for (let i of n.fields.byMember()) {
				let n = i.localName, a = t, o = e;
				if (o[n] != null) switch (i.kind) {
					case "oneof":
						let e = o[n].case;
						if (e === void 0) continue;
						let t = i.findField(e), s = o[n].value;
						t && t.kind == "message" && !gr(s, t.T) ? s = new t.T(s) : t && t.kind === "scalar" && t.T === x.BYTES && (s = $r(s)), a[n] = {
							case: e,
							value: s
						};
						break;
					case "scalar":
					case "enum":
						let c = o[n];
						i.T === x.BYTES && (c = i.repeated ? c.map($r) : $r(c)), a[n] = c;
						break;
					case "map":
						switch (i.V.kind) {
							case "scalar":
							case "enum":
								if (i.V.T === x.BYTES) for (let e of Object.entries(o[n])) {
									var r = C(e, 2);
									let t = r[0], i = r[1];
									a[n][t] = $r(i);
								}
								else Object.assign(a[n], o[n]);
								break;
							case "message":
								let e = i.V.T;
								for (let t of Object.keys(o[n])) {
									let r = o[n][t];
									e.fieldWrapper || (r = new e(r)), a[n][t] = r;
								}
								break;
						}
						break;
					case "message":
						let l = i.T;
						if (i.repeated) a[n] = o[n].map((e) => gr(e, l) ? e : new l(e));
						else {
							let e = o[n];
							l.fieldWrapper ? l.typeName === "google.protobuf.BytesValue" ? a[n] = $r(e) : a[n] = e : a[n] = gr(e, l) ? e : new l(e);
						}
						break;
				}
			}
		},
		equals(e, t, n) {
			return t === n ? !0 : !t || !n ? !1 : e.fields.byMember().every((e) => {
				let r = t[e.localName], i = n[e.localName];
				if (e.repeated) {
					if (r.length !== i.length) return !1;
					switch (e.kind) {
						case "message": return r.every((t, n) => e.T.equals(t, i[n]));
						case "scalar": return r.every((t, n) => Gn(e.T, t, i[n]));
						case "enum": return r.every((e, t) => Gn(x.INT32, e, i[t]));
					}
					throw Error(`repeated cannot contain ${e.kind}`);
				}
				switch (e.kind) {
					case "message":
						let t = r, n = i;
						return e.T.fieldWrapper && (t !== void 0 && !gr(t) && (t = e.T.fieldWrapper.wrapField(t)), n !== void 0 && !gr(n) && (n = e.T.fieldWrapper.wrapField(n))), e.T.equals(t, n);
					case "enum": return Gn(x.INT32, r, i);
					case "scalar": return Gn(e.T, r, i);
					case "oneof":
						if (r.case !== i.case) return !1;
						let a = e.findField(r.case);
						if (a === void 0) return !0;
						switch (a.kind) {
							case "message": return a.T.equals(r.value, i.value);
							case "enum": return Gn(x.INT32, r.value, i.value);
							case "scalar": return Gn(a.T, r.value, i.value);
						}
						throw Error(`oneof cannot contain ${a.kind}`);
					case "map":
						let o = Object.keys(r).concat(Object.keys(i));
						switch (e.V.kind) {
							case "message":
								let t = e.V.T;
								return o.every((e) => t.equals(r[e], i[e]));
							case "enum": return o.every((e) => Gn(x.INT32, r[e], i[e]));
							case "scalar":
								let n = e.V.T;
								return o.every((e) => Gn(n, r[e], i[e]));
						}
						break;
				}
			});
		},
		clone(e) {
			let t = e.getType(), n = new t(), r = n;
			for (let n of t.fields.byMember()) {
				let t = e[n.localName], a;
				if (n.repeated) a = t.map(Qr);
				else if (n.kind == "map") {
					a = r[n.localName];
					for (let e of Object.entries(t)) {
						var i = C(e, 2);
						let t = i[0], n = i[1];
						a[t] = Qr(n);
					}
				} else a = n.kind == "oneof" ? n.findField(t.case) ? {
					case: t.case,
					value: Qr(t.value)
				} : { case: void 0 } : Qr(t);
				r[n.localName] = a;
			}
			for (let n of t.runtime.bin.listUnknownFields(e)) t.runtime.bin.onUnknownField(r, n.no, n.wireType, n.data);
			return n;
		}
	};
}
function Qr(e) {
	if (e === void 0) return e;
	if (gr(e)) return e.clone();
	if (e instanceof Uint8Array) {
		let t = new Uint8Array(e.byteLength);
		return t.set(e), t;
	}
	return e;
}
function $r(e) {
	return e instanceof Uint8Array ? e : new Uint8Array(e);
}
function ei(e, t, n) {
	return {
		syntax: e,
		json: wr(),
		bin: zr(),
		util: Object.assign(Object.assign({}, Zr()), {
			newFieldList: t,
			initFields: n
		}),
		makeMessageType(e, t, n) {
			return An(this, e, t, n);
		},
		makeEnum: Dn,
		makeEnumType: En,
		getEnumType: wn,
		makeExtension(e, t, n) {
			return rr(this, e, t, n);
		}
	};
}
var ti = class {
	constructor(e, t) {
		this._fields = e, this._normalizer = t;
	}
	findJsonName(e) {
		if (!this.jsonNames) {
			let e = {};
			for (let t of this.list()) e[t.jsonName] = e[t.name] = t;
			this.jsonNames = e;
		}
		return this.jsonNames[e];
	}
	find(e) {
		if (!this.numbers) {
			let e = {};
			for (let t of this.list()) e[t.no] = t;
			this.numbers = e;
		}
		return this.numbers[e];
	}
	list() {
		return this.all ||= this._normalizer(this._fields), this.all;
	}
	byNumber() {
		return this.numbersAsc ||= this.list().concat().sort((e, t) => e.no - t.no), this.numbersAsc;
	}
	byMember() {
		if (!this.members) {
			this.members = [];
			let e = this.members, t;
			for (let n of this.list()) n.oneof ? n.oneof !== t && (t = n.oneof, e.push(t)) : e.push(n);
		}
		return this.members;
	}
};
function ni(e, t) {
	let n = ai(e);
	return t ? n : di(li(n));
}
function ri(e) {
	return ni(e, !1);
}
var ii = ai;
function ai(e) {
	let t = !1, n = [];
	for (let r = 0; r < e.length; r++) {
		let i = e.charAt(r);
		switch (i) {
			case "_":
				t = !0;
				break;
			case "0":
			case "1":
			case "2":
			case "3":
			case "4":
			case "5":
			case "6":
			case "7":
			case "8":
			case "9":
				n.push(i), t = !1;
				break;
			default:
				t && (t = !1, i = i.toUpperCase()), n.push(i);
				break;
		}
	}
	return n.join("");
}
var oi = new Set([
	"constructor",
	"toString",
	"toJSON",
	"valueOf"
]), si = new Set([
	"getType",
	"clone",
	"equals",
	"fromBinary",
	"fromJson",
	"fromJsonString",
	"toBinary",
	"toJson",
	"toJsonString",
	"toObject"
]), ci = (e) => `${e}\$`, li = (e) => si.has(e) ? ci(e) : e, di = (e) => oi.has(e) ? ci(e) : e, fi = class {
	constructor(e) {
		this.kind = "oneof", this.repeated = !1, this.packed = !1, this.opt = !1, this.req = !1, this.default = void 0, this.fields = [], this.name = e, this.localName = ri(e);
	}
	addField(e) {
		y(e.oneof === this, `field ${e.name} not one of ${this.name}`), this.fields.push(e);
	}
	findField(e) {
		if (!this._lookup) {
			this._lookup = Object.create(null);
			for (let e = 0; e < this.fields.length; e++) this._lookup[this.fields[e].localName] = this.fields[e];
		}
		return this._lookup[e];
	}
};
function pi(e, t) {
	let n = [], r;
	for (let t of typeof e == "function" ? e() : e) {
		let e = t;
		if (e.localName = ni(t.name, t.oneof !== void 0), e.jsonName = t.jsonName ?? ii(t.name), e.repeated = t.repeated ?? !1, t.kind == "scalar" && (e.L = t.L ?? Wn.BIGINT), e.delimited = t.delimited ?? !1, e.req = t.req ?? !1, e.opt = t.opt ?? !1, t.packed === void 0 && (e.packed = t.kind == "enum" || t.kind == "scalar" && t.T != x.BYTES && t.T != x.STRING), t.oneof !== void 0) {
			let n = typeof t.oneof == "string" ? t.oneof : t.oneof.name;
			(!r || r.name != n) && (r = new fi(n)), e.oneof = r, r.addField(e);
		}
		n.push(e);
	}
	return n;
}
var T = ei("proto3", (e) => new ti(e, (e) => pi(e)), (e) => {
	for (let t of e.getType().fields.byMember()) {
		if (t.opt) continue;
		let n = t.localName, r = e;
		if (t.repeated) {
			r[n] = [];
			continue;
		}
		switch (t.kind) {
			case "oneof":
				r[n] = { case: void 0 };
				break;
			case "enum":
				r[n] = 0;
				break;
			case "map":
				r[n] = {};
				break;
			case "scalar":
				r[n] = Kn(t.T, t.L);
				break;
		}
	}
}), mi = class e extends kn {
	constructor(e) {
		super(), this.seconds = b.zero, this.nanos = 0, T.util.initPartial(e, this);
	}
	fromJson(e, t) {
		if (typeof e != "string") throw Error(`cannot decode google.protobuf.Timestamp from JSON: ${T.json.debug(e)}`);
		let n = e.match(/^([0-9]{4})-([0-9]{2})-([0-9]{2})T([0-9]{2}):([0-9]{2}):([0-9]{2})(?:Z|\.([0-9]{3,9})Z|([+-][0-9][0-9]:[0-9][0-9]))$/);
		if (!n) throw Error("cannot decode google.protobuf.Timestamp from JSON: invalid RFC 3339 string");
		let r = Date.parse(n[1] + "-" + n[2] + "-" + n[3] + "T" + n[4] + ":" + n[5] + ":" + n[6] + (n[8] ? n[8] : "Z"));
		if (Number.isNaN(r)) throw Error("cannot decode google.protobuf.Timestamp from JSON: invalid RFC 3339 string");
		if (r < Date.parse("0001-01-01T00:00:00Z") || r > Date.parse("9999-12-31T23:59:59Z")) throw Error("cannot decode message google.protobuf.Timestamp from JSON: must be from 0001-01-01T00:00:00Z to 9999-12-31T23:59:59Z inclusive");
		return this.seconds = b.parse(r / 1e3), this.nanos = 0, n[7] && (this.nanos = parseInt("1" + n[7] + "0".repeat(9 - n[7].length)) - 1e9), this;
	}
	toJson(e) {
		let t = Number(this.seconds) * 1e3;
		if (t < Date.parse("0001-01-01T00:00:00Z") || t > Date.parse("9999-12-31T23:59:59Z")) throw Error("cannot encode google.protobuf.Timestamp to JSON: must be from 0001-01-01T00:00:00Z to 9999-12-31T23:59:59Z inclusive");
		if (this.nanos < 0) throw Error("cannot encode google.protobuf.Timestamp to JSON: nanos must not be negative");
		let n = "Z";
		if (this.nanos > 0) {
			let e = (this.nanos + 1e9).toString().substring(1);
			n = e.substring(3) === "000000" ? "." + e.substring(0, 3) + "Z" : e.substring(6) === "000" ? "." + e.substring(0, 6) + "Z" : "." + e + "Z";
		}
		return new Date(t).toISOString().replace(".000Z", n);
	}
	toDate() {
		return new Date(Number(this.seconds) * 1e3 + Math.ceil(this.nanos / 1e6));
	}
	static now() {
		return e.fromDate(/* @__PURE__ */ new Date());
	}
	static fromDate(t) {
		let n = t.getTime();
		return new e({
			seconds: b.parse(Math.floor(n / 1e3)),
			nanos: n % 1e3 * 1e6
		});
	}
	static fromBinary(t, n) {
		return new e().fromBinary(t, n);
	}
	static fromJson(t, n) {
		return new e().fromJson(t, n);
	}
	static fromJsonString(t, n) {
		return new e().fromJsonString(t, n);
	}
	static equals(t, n) {
		return T.util.equals(e, t, n);
	}
};
mi.runtime = T, mi.typeName = "google.protobuf.Timestamp", mi.fields = T.util.newFieldList(() => [{
	no: 1,
	name: "seconds",
	kind: "scalar",
	T: 3
}, {
	no: 2,
	name: "nanos",
	kind: "scalar",
	T: 5
}]);
var hi = /* @__PURE__ */ T.makeMessageType("livekit.MetricsBatch", () => [
	{
		no: 1,
		name: "timestamp_ms",
		kind: "scalar",
		T: 3
	},
	{
		no: 2,
		name: "normalized_timestamp",
		kind: "message",
		T: mi
	},
	{
		no: 3,
		name: "str_data",
		kind: "scalar",
		T: 9,
		repeated: !0
	},
	{
		no: 4,
		name: "time_series",
		kind: "message",
		T: gi,
		repeated: !0
	},
	{
		no: 5,
		name: "events",
		kind: "message",
		T: vi,
		repeated: !0
	}
]), gi = /* @__PURE__ */ T.makeMessageType("livekit.TimeSeriesMetric", () => [
	{
		no: 1,
		name: "label",
		kind: "scalar",
		T: 13
	},
	{
		no: 2,
		name: "participant_identity",
		kind: "scalar",
		T: 13
	},
	{
		no: 3,
		name: "track_sid",
		kind: "scalar",
		T: 13
	},
	{
		no: 4,
		name: "samples",
		kind: "message",
		T: _i,
		repeated: !0
	},
	{
		no: 5,
		name: "rid",
		kind: "scalar",
		T: 13
	}
]), _i = /* @__PURE__ */ T.makeMessageType("livekit.MetricSample", () => [
	{
		no: 1,
		name: "timestamp_ms",
		kind: "scalar",
		T: 3
	},
	{
		no: 2,
		name: "normalized_timestamp",
		kind: "message",
		T: mi
	},
	{
		no: 3,
		name: "value",
		kind: "scalar",
		T: 2
	}
]), vi = /* @__PURE__ */ T.makeMessageType("livekit.EventMetric", () => [
	{
		no: 1,
		name: "label",
		kind: "scalar",
		T: 13
	},
	{
		no: 2,
		name: "participant_identity",
		kind: "scalar",
		T: 13
	},
	{
		no: 3,
		name: "track_sid",
		kind: "scalar",
		T: 13
	},
	{
		no: 4,
		name: "start_timestamp_ms",
		kind: "scalar",
		T: 3
	},
	{
		no: 5,
		name: "end_timestamp_ms",
		kind: "scalar",
		T: 3,
		opt: !0
	},
	{
		no: 6,
		name: "normalized_start_timestamp",
		kind: "message",
		T: mi
	},
	{
		no: 7,
		name: "normalized_end_timestamp",
		kind: "message",
		T: mi,
		opt: !0
	},
	{
		no: 8,
		name: "metadata",
		kind: "scalar",
		T: 9
	},
	{
		no: 9,
		name: "rid",
		kind: "scalar",
		T: 13
	}
]), yi = /* @__PURE__ */ T.makeEnum("livekit.BackupCodecPolicy", [
	{
		no: 0,
		name: "PREFER_REGRESSION"
	},
	{
		no: 1,
		name: "SIMULCAST"
	},
	{
		no: 2,
		name: "REGRESSION"
	}
]), bi = /* @__PURE__ */ T.makeEnum("livekit.TrackType", [
	{
		no: 0,
		name: "AUDIO"
	},
	{
		no: 1,
		name: "VIDEO"
	},
	{
		no: 2,
		name: "DATA"
	}
]), E = /* @__PURE__ */ T.makeEnum("livekit.TrackSource", [
	{
		no: 0,
		name: "UNKNOWN"
	},
	{
		no: 1,
		name: "CAMERA"
	},
	{
		no: 2,
		name: "MICROPHONE"
	},
	{
		no: 3,
		name: "SCREEN_SHARE"
	},
	{
		no: 4,
		name: "SCREEN_SHARE_AUDIO"
	}
]), xi = /* @__PURE__ */ T.makeEnum("livekit.VideoQuality", [
	{
		no: 0,
		name: "LOW"
	},
	{
		no: 1,
		name: "MEDIUM"
	},
	{
		no: 2,
		name: "HIGH"
	},
	{
		no: 3,
		name: "OFF"
	}
]), Si = /* @__PURE__ */ T.makeEnum("livekit.ConnectionQuality", [
	{
		no: 0,
		name: "POOR"
	},
	{
		no: 1,
		name: "GOOD"
	},
	{
		no: 2,
		name: "EXCELLENT"
	},
	{
		no: 3,
		name: "LOST"
	}
]), Ci = /* @__PURE__ */ T.makeEnum("livekit.ClientConfigSetting", [
	{
		no: 0,
		name: "UNSET"
	},
	{
		no: 1,
		name: "DISABLED"
	},
	{
		no: 2,
		name: "ENABLED"
	}
]), wi = /* @__PURE__ */ T.makeEnum("livekit.DisconnectReason", [
	{
		no: 0,
		name: "UNKNOWN_REASON"
	},
	{
		no: 1,
		name: "CLIENT_INITIATED"
	},
	{
		no: 2,
		name: "DUPLICATE_IDENTITY"
	},
	{
		no: 3,
		name: "SERVER_SHUTDOWN"
	},
	{
		no: 4,
		name: "PARTICIPANT_REMOVED"
	},
	{
		no: 5,
		name: "ROOM_DELETED"
	},
	{
		no: 6,
		name: "STATE_MISMATCH"
	},
	{
		no: 7,
		name: "JOIN_FAILURE"
	},
	{
		no: 8,
		name: "MIGRATION"
	},
	{
		no: 9,
		name: "SIGNAL_CLOSE"
	},
	{
		no: 10,
		name: "ROOM_CLOSED"
	},
	{
		no: 11,
		name: "USER_UNAVAILABLE"
	},
	{
		no: 12,
		name: "USER_REJECTED"
	},
	{
		no: 13,
		name: "SIP_TRUNK_FAILURE"
	},
	{
		no: 14,
		name: "CONNECTION_TIMEOUT"
	},
	{
		no: 15,
		name: "MEDIA_FAILURE"
	},
	{
		no: 16,
		name: "AGENT_ERROR"
	}
]), Ti = /* @__PURE__ */ T.makeEnum("livekit.ReconnectReason", [
	{
		no: 0,
		name: "RR_UNKNOWN"
	},
	{
		no: 1,
		name: "RR_SIGNAL_DISCONNECTED"
	},
	{
		no: 2,
		name: "RR_PUBLISHER_FAILED"
	},
	{
		no: 3,
		name: "RR_SUBSCRIBER_FAILED"
	},
	{
		no: 4,
		name: "RR_SWITCH_CANDIDATE"
	}
]), Ei = /* @__PURE__ */ T.makeEnum("livekit.SubscriptionError", [
	{
		no: 0,
		name: "SE_UNKNOWN"
	},
	{
		no: 1,
		name: "SE_CODEC_UNSUPPORTED"
	},
	{
		no: 2,
		name: "SE_TRACK_NOTFOUND"
	}
]), D = /* @__PURE__ */ T.makeEnum("livekit.AudioTrackFeature", [
	{
		no: 0,
		name: "TF_STEREO"
	},
	{
		no: 1,
		name: "TF_NO_DTX"
	},
	{
		no: 2,
		name: "TF_AUTO_GAIN_CONTROL"
	},
	{
		no: 3,
		name: "TF_ECHO_CANCELLATION"
	},
	{
		no: 4,
		name: "TF_NOISE_SUPPRESSION"
	},
	{
		no: 5,
		name: "TF_ENHANCED_NOISE_CANCELLATION"
	},
	{
		no: 6,
		name: "TF_PRECONNECT_BUFFER"
	}
]), Di = /* @__PURE__ */ T.makeEnum("livekit.PacketTrailerFeature", [{
	no: 0,
	name: "PTF_USER_TIMESTAMP"
}, {
	no: 1,
	name: "PTF_FRAME_ID"
}]), Oi = /* @__PURE__ */ T.makeMessageType("livekit.Room", () => [
	{
		no: 1,
		name: "sid",
		kind: "scalar",
		T: 9
	},
	{
		no: 2,
		name: "name",
		kind: "scalar",
		T: 9
	},
	{
		no: 3,
		name: "empty_timeout",
		kind: "scalar",
		T: 13
	},
	{
		no: 14,
		name: "departure_timeout",
		kind: "scalar",
		T: 13
	},
	{
		no: 4,
		name: "max_participants",
		kind: "scalar",
		T: 13
	},
	{
		no: 5,
		name: "creation_time",
		kind: "scalar",
		T: 3
	},
	{
		no: 15,
		name: "creation_time_ms",
		kind: "scalar",
		T: 3
	},
	{
		no: 6,
		name: "turn_password",
		kind: "scalar",
		T: 9
	},
	{
		no: 7,
		name: "enabled_codecs",
		kind: "message",
		T: ki,
		repeated: !0
	},
	{
		no: 8,
		name: "metadata",
		kind: "scalar",
		T: 9
	},
	{
		no: 9,
		name: "num_participants",
		kind: "scalar",
		T: 13
	},
	{
		no: 11,
		name: "num_publishers",
		kind: "scalar",
		T: 13
	},
	{
		no: 10,
		name: "active_recording",
		kind: "scalar",
		T: 8
	},
	{
		no: 13,
		name: "version",
		kind: "message",
		T: da
	}
]), ki = /* @__PURE__ */ T.makeMessageType("livekit.Codec", () => [{
	no: 1,
	name: "mime",
	kind: "scalar",
	T: 9
}, {
	no: 2,
	name: "fmtp_line",
	kind: "scalar",
	T: 9
}]), Ai = /* @__PURE__ */ T.makeMessageType("livekit.ParticipantPermission", () => [
	{
		no: 1,
		name: "can_subscribe",
		kind: "scalar",
		T: 8
	},
	{
		no: 2,
		name: "can_publish",
		kind: "scalar",
		T: 8
	},
	{
		no: 3,
		name: "can_publish_data",
		kind: "scalar",
		T: 8
	},
	{
		no: 9,
		name: "can_publish_sources",
		kind: "enum",
		T: T.getEnumType(E),
		repeated: !0
	},
	{
		no: 7,
		name: "hidden",
		kind: "scalar",
		T: 8
	},
	{
		no: 8,
		name: "recorder",
		kind: "scalar",
		T: 8
	},
	{
		no: 10,
		name: "can_update_metadata",
		kind: "scalar",
		T: 8
	},
	{
		no: 11,
		name: "agent",
		kind: "scalar",
		T: 8
	},
	{
		no: 12,
		name: "can_subscribe_metrics",
		kind: "scalar",
		T: 8
	},
	{
		no: 13,
		name: "can_manage_agent_session",
		kind: "scalar",
		T: 8
	}
]), ji = /* @__PURE__ */ T.makeMessageType("livekit.ParticipantInfo", () => [
	{
		no: 1,
		name: "sid",
		kind: "scalar",
		T: 9
	},
	{
		no: 2,
		name: "identity",
		kind: "scalar",
		T: 9
	},
	{
		no: 3,
		name: "state",
		kind: "enum",
		T: T.getEnumType(Mi)
	},
	{
		no: 4,
		name: "tracks",
		kind: "message",
		T: Ii,
		repeated: !0
	},
	{
		no: 5,
		name: "metadata",
		kind: "scalar",
		T: 9
	},
	{
		no: 6,
		name: "joined_at",
		kind: "scalar",
		T: 3
	},
	{
		no: 17,
		name: "joined_at_ms",
		kind: "scalar",
		T: 3
	},
	{
		no: 9,
		name: "name",
		kind: "scalar",
		T: 9
	},
	{
		no: 10,
		name: "version",
		kind: "scalar",
		T: 13
	},
	{
		no: 11,
		name: "permission",
		kind: "message",
		T: Ai
	},
	{
		no: 12,
		name: "region",
		kind: "scalar",
		T: 9
	},
	{
		no: 13,
		name: "is_publisher",
		kind: "scalar",
		T: 8
	},
	{
		no: 14,
		name: "kind",
		kind: "enum",
		T: T.getEnumType(Ni)
	},
	{
		no: 15,
		name: "attributes",
		kind: "map",
		K: 9,
		V: {
			kind: "scalar",
			T: 9
		}
	},
	{
		no: 16,
		name: "disconnect_reason",
		kind: "enum",
		T: T.getEnumType(wi)
	},
	{
		no: 18,
		name: "kind_details",
		kind: "enum",
		T: T.getEnumType(Pi),
		repeated: !0
	},
	{
		no: 19,
		name: "data_tracks",
		kind: "message",
		T: Li,
		repeated: !0
	},
	{
		no: 20,
		name: "client_protocol",
		kind: "scalar",
		T: 5
	}
]), Mi = /* @__PURE__ */ T.makeEnum("livekit.ParticipantInfo.State", [
	{
		no: 0,
		name: "JOINING"
	},
	{
		no: 1,
		name: "JOINED"
	},
	{
		no: 2,
		name: "ACTIVE"
	},
	{
		no: 3,
		name: "DISCONNECTED"
	}
]), Ni = /* @__PURE__ */ T.makeEnum("livekit.ParticipantInfo.Kind", [
	{
		no: 0,
		name: "STANDARD"
	},
	{
		no: 1,
		name: "INGRESS"
	},
	{
		no: 2,
		name: "EGRESS"
	},
	{
		no: 3,
		name: "SIP"
	},
	{
		no: 4,
		name: "AGENT"
	},
	{
		no: 7,
		name: "CONNECTOR"
	},
	{
		no: 8,
		name: "BRIDGE"
	}
]), Pi = /* @__PURE__ */ T.makeEnum("livekit.ParticipantInfo.KindDetail", [
	{
		no: 0,
		name: "CLOUD_AGENT"
	},
	{
		no: 1,
		name: "FORWARDED"
	},
	{
		no: 2,
		name: "CONNECTOR_WHATSAPP"
	},
	{
		no: 3,
		name: "CONNECTOR_TWILIO"
	},
	{
		no: 4,
		name: "BRIDGE_RTSP"
	}
]), O = /* @__PURE__ */ T.makeEnum("livekit.Encryption.Type", [
	{
		no: 0,
		name: "NONE"
	},
	{
		no: 1,
		name: "GCM"
	},
	{
		no: 2,
		name: "CUSTOM"
	}
]), Fi = /* @__PURE__ */ T.makeMessageType("livekit.SimulcastCodecInfo", () => [
	{
		no: 1,
		name: "mime_type",
		kind: "scalar",
		T: 9
	},
	{
		no: 2,
		name: "mid",
		kind: "scalar",
		T: 9
	},
	{
		no: 3,
		name: "cid",
		kind: "scalar",
		T: 9
	},
	{
		no: 4,
		name: "layers",
		kind: "message",
		T: zi,
		repeated: !0
	},
	{
		no: 5,
		name: "video_layer_mode",
		kind: "enum",
		T: T.getEnumType(Bi)
	},
	{
		no: 6,
		name: "sdp_cid",
		kind: "scalar",
		T: 9
	}
]), Ii = /* @__PURE__ */ T.makeMessageType("livekit.TrackInfo", () => [
	{
		no: 1,
		name: "sid",
		kind: "scalar",
		T: 9
	},
	{
		no: 2,
		name: "type",
		kind: "enum",
		T: T.getEnumType(bi)
	},
	{
		no: 3,
		name: "name",
		kind: "scalar",
		T: 9
	},
	{
		no: 4,
		name: "muted",
		kind: "scalar",
		T: 8
	},
	{
		no: 5,
		name: "width",
		kind: "scalar",
		T: 13
	},
	{
		no: 6,
		name: "height",
		kind: "scalar",
		T: 13
	},
	{
		no: 7,
		name: "simulcast",
		kind: "scalar",
		T: 8
	},
	{
		no: 8,
		name: "disable_dtx",
		kind: "scalar",
		T: 8
	},
	{
		no: 9,
		name: "source",
		kind: "enum",
		T: T.getEnumType(E)
	},
	{
		no: 10,
		name: "layers",
		kind: "message",
		T: zi,
		repeated: !0
	},
	{
		no: 11,
		name: "mime_type",
		kind: "scalar",
		T: 9
	},
	{
		no: 12,
		name: "mid",
		kind: "scalar",
		T: 9
	},
	{
		no: 13,
		name: "codecs",
		kind: "message",
		T: Fi,
		repeated: !0
	},
	{
		no: 14,
		name: "stereo",
		kind: "scalar",
		T: 8
	},
	{
		no: 15,
		name: "disable_red",
		kind: "scalar",
		T: 8
	},
	{
		no: 16,
		name: "encryption",
		kind: "enum",
		T: T.getEnumType(O)
	},
	{
		no: 17,
		name: "stream",
		kind: "scalar",
		T: 9
	},
	{
		no: 18,
		name: "version",
		kind: "message",
		T: da
	},
	{
		no: 19,
		name: "audio_features",
		kind: "enum",
		T: T.getEnumType(D),
		repeated: !0
	},
	{
		no: 20,
		name: "backup_codec_policy",
		kind: "enum",
		T: T.getEnumType(yi)
	},
	{
		no: 21,
		name: "packet_trailer_features",
		kind: "enum",
		T: T.getEnumType(Di),
		repeated: !0
	}
]), Li = /* @__PURE__ */ T.makeMessageType("livekit.DataTrackInfo", () => [
	{
		no: 1,
		name: "pub_handle",
		kind: "scalar",
		T: 13
	},
	{
		no: 2,
		name: "sid",
		kind: "scalar",
		T: 9
	},
	{
		no: 3,
		name: "name",
		kind: "scalar",
		T: 9
	},
	{
		no: 4,
		name: "encryption",
		kind: "enum",
		T: T.getEnumType(O)
	}
]), Ri = /* @__PURE__ */ T.makeMessageType("livekit.DataTrackSubscriptionOptions", () => [{
	no: 1,
	name: "target_fps",
	kind: "scalar",
	T: 13,
	opt: !0
}]), zi = /* @__PURE__ */ T.makeMessageType("livekit.VideoLayer", () => [
	{
		no: 1,
		name: "quality",
		kind: "enum",
		T: T.getEnumType(xi)
	},
	{
		no: 2,
		name: "width",
		kind: "scalar",
		T: 13
	},
	{
		no: 3,
		name: "height",
		kind: "scalar",
		T: 13
	},
	{
		no: 4,
		name: "bitrate",
		kind: "scalar",
		T: 13
	},
	{
		no: 5,
		name: "ssrc",
		kind: "scalar",
		T: 13
	},
	{
		no: 6,
		name: "spatial_layer",
		kind: "scalar",
		T: 5
	},
	{
		no: 7,
		name: "rid",
		kind: "scalar",
		T: 9
	},
	{
		no: 8,
		name: "repair_ssrc",
		kind: "scalar",
		T: 13
	}
]), Bi = /* @__PURE__ */ T.makeEnum("livekit.VideoLayer.Mode", [
	{
		no: 0,
		name: "MODE_UNUSED"
	},
	{
		no: 1,
		name: "ONE_SPATIAL_LAYER_PER_STREAM"
	},
	{
		no: 2,
		name: "MULTIPLE_SPATIAL_LAYERS_PER_STREAM"
	},
	{
		no: 3,
		name: "ONE_SPATIAL_LAYER_PER_STREAM_INCOMPLETE_RTCP_SR"
	}
]), Vi = /* @__PURE__ */ T.makeMessageType("livekit.DataPacket", () => [
	{
		no: 1,
		name: "kind",
		kind: "enum",
		T: T.getEnumType(Hi)
	},
	{
		no: 4,
		name: "participant_identity",
		kind: "scalar",
		T: 9
	},
	{
		no: 5,
		name: "destination_identities",
		kind: "scalar",
		T: 9,
		repeated: !0
	},
	{
		no: 2,
		name: "user",
		kind: "message",
		T: qi,
		oneof: "value"
	},
	{
		no: 3,
		name: "speaker",
		kind: "message",
		T: Gi,
		oneof: "value"
	},
	{
		no: 6,
		name: "sip_dtmf",
		kind: "message",
		T: Ji,
		oneof: "value"
	},
	{
		no: 7,
		name: "transcription",
		kind: "message",
		T: Yi,
		oneof: "value"
	},
	{
		no: 8,
		name: "metrics",
		kind: "message",
		T: hi,
		oneof: "value"
	},
	{
		no: 9,
		name: "chat_message",
		kind: "message",
		T: Zi,
		oneof: "value"
	},
	{
		no: 10,
		name: "rpc_request",
		kind: "message",
		T: Qi,
		oneof: "value"
	},
	{
		no: 11,
		name: "rpc_ack",
		kind: "message",
		T: $i,
		oneof: "value"
	},
	{
		no: 12,
		name: "rpc_response",
		kind: "message",
		T: ea,
		oneof: "value"
	},
	{
		no: 13,
		name: "stream_header",
		kind: "message",
		T: ha,
		oneof: "value"
	},
	{
		no: 14,
		name: "stream_chunk",
		kind: "message",
		T: ga,
		oneof: "value"
	},
	{
		no: 15,
		name: "stream_trailer",
		kind: "message",
		T: _a,
		oneof: "value"
	},
	{
		no: 18,
		name: "encrypted_packet",
		kind: "message",
		T: Ui,
		oneof: "value"
	},
	{
		no: 16,
		name: "sequence",
		kind: "scalar",
		T: 13
	},
	{
		no: 17,
		name: "participant_sid",
		kind: "scalar",
		T: 9
	}
]), Hi = /* @__PURE__ */ T.makeEnum("livekit.DataPacket.Kind", [{
	no: 0,
	name: "RELIABLE"
}, {
	no: 1,
	name: "LOSSY"
}]), Ui = /* @__PURE__ */ T.makeMessageType("livekit.EncryptedPacket", () => [
	{
		no: 1,
		name: "encryption_type",
		kind: "enum",
		T: T.getEnumType(O)
	},
	{
		no: 2,
		name: "iv",
		kind: "scalar",
		T: 12
	},
	{
		no: 3,
		name: "key_index",
		kind: "scalar",
		T: 13
	},
	{
		no: 4,
		name: "encrypted_value",
		kind: "scalar",
		T: 12
	}
]), Wi = /* @__PURE__ */ T.makeMessageType("livekit.EncryptedPacketPayload", () => [
	{
		no: 1,
		name: "user",
		kind: "message",
		T: qi,
		oneof: "value"
	},
	{
		no: 3,
		name: "chat_message",
		kind: "message",
		T: Zi,
		oneof: "value"
	},
	{
		no: 4,
		name: "rpc_request",
		kind: "message",
		T: Qi,
		oneof: "value"
	},
	{
		no: 5,
		name: "rpc_ack",
		kind: "message",
		T: $i,
		oneof: "value"
	},
	{
		no: 6,
		name: "rpc_response",
		kind: "message",
		T: ea,
		oneof: "value"
	},
	{
		no: 7,
		name: "stream_header",
		kind: "message",
		T: ha,
		oneof: "value"
	},
	{
		no: 8,
		name: "stream_chunk",
		kind: "message",
		T: ga,
		oneof: "value"
	},
	{
		no: 9,
		name: "stream_trailer",
		kind: "message",
		T: _a,
		oneof: "value"
	}
]), Gi = /* @__PURE__ */ T.makeMessageType("livekit.ActiveSpeakerUpdate", () => [{
	no: 1,
	name: "speakers",
	kind: "message",
	T: Ki,
	repeated: !0
}]), Ki = /* @__PURE__ */ T.makeMessageType("livekit.SpeakerInfo", () => [
	{
		no: 1,
		name: "sid",
		kind: "scalar",
		T: 9
	},
	{
		no: 2,
		name: "level",
		kind: "scalar",
		T: 2
	},
	{
		no: 3,
		name: "active",
		kind: "scalar",
		T: 8
	}
]), qi = /* @__PURE__ */ T.makeMessageType("livekit.UserPacket", () => [
	{
		no: 1,
		name: "participant_sid",
		kind: "scalar",
		T: 9
	},
	{
		no: 5,
		name: "participant_identity",
		kind: "scalar",
		T: 9
	},
	{
		no: 2,
		name: "payload",
		kind: "scalar",
		T: 12
	},
	{
		no: 3,
		name: "destination_sids",
		kind: "scalar",
		T: 9,
		repeated: !0
	},
	{
		no: 6,
		name: "destination_identities",
		kind: "scalar",
		T: 9,
		repeated: !0
	},
	{
		no: 4,
		name: "topic",
		kind: "scalar",
		T: 9,
		opt: !0
	},
	{
		no: 8,
		name: "id",
		kind: "scalar",
		T: 9,
		opt: !0
	},
	{
		no: 9,
		name: "start_time",
		kind: "scalar",
		T: 4,
		opt: !0
	},
	{
		no: 10,
		name: "end_time",
		kind: "scalar",
		T: 4,
		opt: !0
	},
	{
		no: 11,
		name: "nonce",
		kind: "scalar",
		T: 12
	}
]), Ji = /* @__PURE__ */ T.makeMessageType("livekit.SipDTMF", () => [{
	no: 3,
	name: "code",
	kind: "scalar",
	T: 13
}, {
	no: 4,
	name: "digit",
	kind: "scalar",
	T: 9
}]), Yi = /* @__PURE__ */ T.makeMessageType("livekit.Transcription", () => [
	{
		no: 2,
		name: "transcribed_participant_identity",
		kind: "scalar",
		T: 9
	},
	{
		no: 3,
		name: "track_id",
		kind: "scalar",
		T: 9
	},
	{
		no: 4,
		name: "segments",
		kind: "message",
		T: Xi,
		repeated: !0
	}
]), Xi = /* @__PURE__ */ T.makeMessageType("livekit.TranscriptionSegment", () => [
	{
		no: 1,
		name: "id",
		kind: "scalar",
		T: 9
	},
	{
		no: 2,
		name: "text",
		kind: "scalar",
		T: 9
	},
	{
		no: 3,
		name: "start_time",
		kind: "scalar",
		T: 4
	},
	{
		no: 4,
		name: "end_time",
		kind: "scalar",
		T: 4
	},
	{
		no: 5,
		name: "final",
		kind: "scalar",
		T: 8
	},
	{
		no: 6,
		name: "language",
		kind: "scalar",
		T: 9
	}
]), Zi = /* @__PURE__ */ T.makeMessageType("livekit.ChatMessage", () => [
	{
		no: 1,
		name: "id",
		kind: "scalar",
		T: 9
	},
	{
		no: 2,
		name: "timestamp",
		kind: "scalar",
		T: 3
	},
	{
		no: 3,
		name: "edit_timestamp",
		kind: "scalar",
		T: 3,
		opt: !0
	},
	{
		no: 4,
		name: "message",
		kind: "scalar",
		T: 9
	},
	{
		no: 5,
		name: "deleted",
		kind: "scalar",
		T: 8
	},
	{
		no: 6,
		name: "generated",
		kind: "scalar",
		T: 8
	}
]), Qi = /* @__PURE__ */ T.makeMessageType("livekit.RpcRequest", () => [
	{
		no: 1,
		name: "id",
		kind: "scalar",
		T: 9
	},
	{
		no: 2,
		name: "method",
		kind: "scalar",
		T: 9
	},
	{
		no: 3,
		name: "payload",
		kind: "scalar",
		T: 9
	},
	{
		no: 4,
		name: "response_timeout_ms",
		kind: "scalar",
		T: 13
	},
	{
		no: 5,
		name: "version",
		kind: "scalar",
		T: 13
	},
	{
		no: 6,
		name: "compressed_payload",
		kind: "scalar",
		T: 12
	}
]), $i = /* @__PURE__ */ T.makeMessageType("livekit.RpcAck", () => [{
	no: 1,
	name: "request_id",
	kind: "scalar",
	T: 9
}]), ea = /* @__PURE__ */ T.makeMessageType("livekit.RpcResponse", () => [
	{
		no: 1,
		name: "request_id",
		kind: "scalar",
		T: 9
	},
	{
		no: 2,
		name: "payload",
		kind: "scalar",
		T: 9,
		oneof: "value"
	},
	{
		no: 3,
		name: "error",
		kind: "message",
		T: ta,
		oneof: "value"
	},
	{
		no: 4,
		name: "compressed_payload",
		kind: "scalar",
		T: 12,
		oneof: "value"
	}
]), ta = /* @__PURE__ */ T.makeMessageType("livekit.RpcError", () => [
	{
		no: 1,
		name: "code",
		kind: "scalar",
		T: 13
	},
	{
		no: 2,
		name: "message",
		kind: "scalar",
		T: 9
	},
	{
		no: 3,
		name: "data",
		kind: "scalar",
		T: 9
	}
]), na = /* @__PURE__ */ T.makeMessageType("livekit.ParticipantTracks", () => [{
	no: 1,
	name: "participant_sid",
	kind: "scalar",
	T: 9
}, {
	no: 2,
	name: "track_sids",
	kind: "scalar",
	T: 9,
	repeated: !0
}]), ra = /* @__PURE__ */ T.makeMessageType("livekit.ServerInfo", () => [
	{
		no: 1,
		name: "edition",
		kind: "enum",
		T: T.getEnumType(ia)
	},
	{
		no: 2,
		name: "version",
		kind: "scalar",
		T: 9
	},
	{
		no: 3,
		name: "protocol",
		kind: "scalar",
		T: 5
	},
	{
		no: 4,
		name: "region",
		kind: "scalar",
		T: 9
	},
	{
		no: 5,
		name: "node_id",
		kind: "scalar",
		T: 9
	},
	{
		no: 6,
		name: "debug_info",
		kind: "scalar",
		T: 9
	},
	{
		no: 7,
		name: "agent_protocol",
		kind: "scalar",
		T: 5
	}
]), ia = /* @__PURE__ */ T.makeEnum("livekit.ServerInfo.Edition", [{
	no: 0,
	name: "Standard"
}, {
	no: 1,
	name: "Cloud"
}]), aa = /* @__PURE__ */ T.makeMessageType("livekit.ClientInfo", () => [
	{
		no: 1,
		name: "sdk",
		kind: "enum",
		T: T.getEnumType(oa)
	},
	{
		no: 2,
		name: "version",
		kind: "scalar",
		T: 9
	},
	{
		no: 3,
		name: "protocol",
		kind: "scalar",
		T: 5
	},
	{
		no: 4,
		name: "os",
		kind: "scalar",
		T: 9
	},
	{
		no: 5,
		name: "os_version",
		kind: "scalar",
		T: 9
	},
	{
		no: 6,
		name: "device_model",
		kind: "scalar",
		T: 9
	},
	{
		no: 7,
		name: "browser",
		kind: "scalar",
		T: 9
	},
	{
		no: 8,
		name: "browser_version",
		kind: "scalar",
		T: 9
	},
	{
		no: 9,
		name: "address",
		kind: "scalar",
		T: 9
	},
	{
		no: 10,
		name: "network",
		kind: "scalar",
		T: 9
	},
	{
		no: 11,
		name: "other_sdks",
		kind: "scalar",
		T: 9
	},
	{
		no: 12,
		name: "client_protocol",
		kind: "scalar",
		T: 5
	},
	{
		no: 13,
		name: "capabilities",
		kind: "enum",
		T: T.getEnumType(sa),
		repeated: !0
	}
]), oa = /* @__PURE__ */ T.makeEnum("livekit.ClientInfo.SDK", [
	{
		no: 0,
		name: "UNKNOWN"
	},
	{
		no: 1,
		name: "JS"
	},
	{
		no: 2,
		name: "SWIFT"
	},
	{
		no: 3,
		name: "ANDROID"
	},
	{
		no: 4,
		name: "FLUTTER"
	},
	{
		no: 5,
		name: "GO"
	},
	{
		no: 6,
		name: "UNITY"
	},
	{
		no: 7,
		name: "REACT_NATIVE"
	},
	{
		no: 8,
		name: "RUST"
	},
	{
		no: 9,
		name: "PYTHON"
	},
	{
		no: 10,
		name: "CPP"
	},
	{
		no: 11,
		name: "UNITY_WEB"
	},
	{
		no: 12,
		name: "NODE"
	},
	{
		no: 13,
		name: "UNREAL"
	},
	{
		no: 14,
		name: "ESP32"
	}
]), sa = /* @__PURE__ */ T.makeEnum("livekit.ClientInfo.Capability", [{
	no: 0,
	name: "CAP_UNUSED"
}, {
	no: 1,
	name: "CAP_PACKET_TRAILER"
}]), ca = /* @__PURE__ */ T.makeMessageType("livekit.ClientConfiguration", () => [
	{
		no: 1,
		name: "video",
		kind: "message",
		T: la
	},
	{
		no: 2,
		name: "screen",
		kind: "message",
		T: la
	},
	{
		no: 3,
		name: "resume_connection",
		kind: "enum",
		T: T.getEnumType(Ci)
	},
	{
		no: 4,
		name: "disabled_codecs",
		kind: "message",
		T: ua
	},
	{
		no: 5,
		name: "force_relay",
		kind: "enum",
		T: T.getEnumType(Ci)
	}
]), la = /* @__PURE__ */ T.makeMessageType("livekit.VideoConfiguration", () => [{
	no: 1,
	name: "hardware_encoder",
	kind: "enum",
	T: T.getEnumType(Ci)
}]), ua = /* @__PURE__ */ T.makeMessageType("livekit.DisabledCodecs", () => [{
	no: 1,
	name: "codecs",
	kind: "message",
	T: ki,
	repeated: !0
}, {
	no: 2,
	name: "publish",
	kind: "message",
	T: ki,
	repeated: !0
}]), da = /* @__PURE__ */ T.makeMessageType("livekit.TimedVersion", () => [{
	no: 1,
	name: "unix_micro",
	kind: "scalar",
	T: 3
}, {
	no: 2,
	name: "ticks",
	kind: "scalar",
	T: 5
}]), fa = /* @__PURE__ */ T.makeEnum("livekit.DataStream.OperationType", [
	{
		no: 0,
		name: "CREATE"
	},
	{
		no: 1,
		name: "UPDATE"
	},
	{
		no: 2,
		name: "DELETE"
	},
	{
		no: 3,
		name: "REACTION"
	}
]), pa = /* @__PURE__ */ T.makeMessageType("livekit.DataStream.TextHeader", () => [
	{
		no: 1,
		name: "operation_type",
		kind: "enum",
		T: T.getEnumType(fa)
	},
	{
		no: 2,
		name: "version",
		kind: "scalar",
		T: 5
	},
	{
		no: 3,
		name: "reply_to_stream_id",
		kind: "scalar",
		T: 9
	},
	{
		no: 4,
		name: "attached_stream_ids",
		kind: "scalar",
		T: 9,
		repeated: !0
	},
	{
		no: 5,
		name: "generated",
		kind: "scalar",
		T: 8
	}
], { localName: "DataStream_TextHeader" }), ma = /* @__PURE__ */ T.makeMessageType("livekit.DataStream.ByteHeader", () => [{
	no: 1,
	name: "name",
	kind: "scalar",
	T: 9
}], { localName: "DataStream_ByteHeader" }), ha = /* @__PURE__ */ T.makeMessageType("livekit.DataStream.Header", () => [
	{
		no: 1,
		name: "stream_id",
		kind: "scalar",
		T: 9
	},
	{
		no: 2,
		name: "timestamp",
		kind: "scalar",
		T: 3
	},
	{
		no: 3,
		name: "topic",
		kind: "scalar",
		T: 9
	},
	{
		no: 4,
		name: "mime_type",
		kind: "scalar",
		T: 9
	},
	{
		no: 5,
		name: "total_length",
		kind: "scalar",
		T: 4,
		opt: !0
	},
	{
		no: 7,
		name: "encryption_type",
		kind: "enum",
		T: T.getEnumType(O)
	},
	{
		no: 8,
		name: "attributes",
		kind: "map",
		K: 9,
		V: {
			kind: "scalar",
			T: 9
		}
	},
	{
		no: 9,
		name: "text_header",
		kind: "message",
		T: pa,
		oneof: "content_header"
	},
	{
		no: 10,
		name: "byte_header",
		kind: "message",
		T: ma,
		oneof: "content_header"
	}
], { localName: "DataStream_Header" }), ga = /* @__PURE__ */ T.makeMessageType("livekit.DataStream.Chunk", () => [
	{
		no: 1,
		name: "stream_id",
		kind: "scalar",
		T: 9
	},
	{
		no: 2,
		name: "chunk_index",
		kind: "scalar",
		T: 4
	},
	{
		no: 3,
		name: "content",
		kind: "scalar",
		T: 12
	},
	{
		no: 4,
		name: "version",
		kind: "scalar",
		T: 5
	},
	{
		no: 5,
		name: "iv",
		kind: "scalar",
		T: 12,
		opt: !0
	}
], { localName: "DataStream_Chunk" }), _a = /* @__PURE__ */ T.makeMessageType("livekit.DataStream.Trailer", () => [
	{
		no: 1,
		name: "stream_id",
		kind: "scalar",
		T: 9
	},
	{
		no: 2,
		name: "reason",
		kind: "scalar",
		T: 9
	},
	{
		no: 3,
		name: "attributes",
		kind: "map",
		K: 9,
		V: {
			kind: "scalar",
			T: 9
		}
	}
], { localName: "DataStream_Trailer" }), va = /* @__PURE__ */ T.makeMessageType("livekit.SubscribedAudioCodec", () => [{
	no: 1,
	name: "codec",
	kind: "scalar",
	T: 9
}, {
	no: 2,
	name: "enabled",
	kind: "scalar",
	T: 8
}]), ya = /* @__PURE__ */ T.makeEnum("livekit.SignalTarget", [{
	no: 0,
	name: "PUBLISHER"
}, {
	no: 1,
	name: "SUBSCRIBER"
}]), ba = /* @__PURE__ */ T.makeEnum("livekit.StreamState", [{
	no: 0,
	name: "ACTIVE"
}, {
	no: 1,
	name: "PAUSED"
}]), xa = /* @__PURE__ */ T.makeEnum("livekit.CandidateProtocol", [
	{
		no: 0,
		name: "UDP"
	},
	{
		no: 1,
		name: "TCP"
	},
	{
		no: 2,
		name: "TLS"
	}
]), Sa = /* @__PURE__ */ T.makeMessageType("livekit.SignalRequest", () => [
	{
		no: 1,
		name: "offer",
		kind: "message",
		T: Ra,
		oneof: "message"
	},
	{
		no: 2,
		name: "answer",
		kind: "message",
		T: Ra,
		oneof: "message"
	},
	{
		no: 3,
		name: "trickle",
		kind: "message",
		T: Ma,
		oneof: "message"
	},
	{
		no: 4,
		name: "add_track",
		kind: "message",
		T: Ta,
		oneof: "message"
	},
	{
		no: 5,
		name: "mute",
		kind: "message",
		T: Na,
		oneof: "message"
	},
	{
		no: 6,
		name: "subscription",
		kind: "message",
		T: Ba,
		oneof: "message"
	},
	{
		no: 7,
		name: "track_setting",
		kind: "message",
		T: Ua,
		oneof: "message"
	},
	{
		no: 8,
		name: "leave",
		kind: "message",
		T: Ka,
		oneof: "message"
	},
	{
		no: 10,
		name: "update_layers",
		kind: "message",
		T: Ja,
		oneof: "message"
	},
	{
		no: 11,
		name: "subscription_permission",
		kind: "message",
		T: co,
		oneof: "message"
	},
	{
		no: 12,
		name: "sync_state",
		kind: "message",
		T: fo,
		oneof: "message"
	},
	{
		no: 13,
		name: "simulate",
		kind: "message",
		T: ho,
		oneof: "message"
	},
	{
		no: 14,
		name: "ping",
		kind: "scalar",
		T: 3,
		oneof: "message"
	},
	{
		no: 15,
		name: "update_metadata",
		kind: "message",
		T: Ya,
		oneof: "message"
	},
	{
		no: 16,
		name: "ping_req",
		kind: "message",
		T: go,
		oneof: "message"
	},
	{
		no: 17,
		name: "update_audio_track",
		kind: "message",
		T: Wa,
		oneof: "message"
	},
	{
		no: 18,
		name: "update_video_track",
		kind: "message",
		T: Ga,
		oneof: "message"
	},
	{
		no: 19,
		name: "publish_data_track_request",
		kind: "message",
		T: Ea,
		oneof: "message"
	},
	{
		no: 20,
		name: "unpublish_data_track_request",
		kind: "message",
		T: Oa,
		oneof: "message"
	},
	{
		no: 21,
		name: "update_data_subscription",
		kind: "message",
		T: Va,
		oneof: "message"
	}
]), Ca = /* @__PURE__ */ T.makeMessageType("livekit.SignalResponse", () => [
	{
		no: 1,
		name: "join",
		kind: "message",
		T: Pa,
		oneof: "message"
	},
	{
		no: 2,
		name: "answer",
		kind: "message",
		T: Ra,
		oneof: "message"
	},
	{
		no: 3,
		name: "offer",
		kind: "message",
		T: Ra,
		oneof: "message"
	},
	{
		no: 4,
		name: "trickle",
		kind: "message",
		T: Ma,
		oneof: "message"
	},
	{
		no: 5,
		name: "update",
		kind: "message",
		T: za,
		oneof: "message"
	},
	{
		no: 6,
		name: "track_published",
		kind: "message",
		T: Ia,
		oneof: "message"
	},
	{
		no: 8,
		name: "leave",
		kind: "message",
		T: Ka,
		oneof: "message"
	},
	{
		no: 9,
		name: "mute",
		kind: "message",
		T: Na,
		oneof: "message"
	},
	{
		no: 10,
		name: "speakers_changed",
		kind: "message",
		T: Za,
		oneof: "message"
	},
	{
		no: 11,
		name: "room_update",
		kind: "message",
		T: Qa,
		oneof: "message"
	},
	{
		no: 12,
		name: "connection_quality",
		kind: "message",
		T: eo,
		oneof: "message"
	},
	{
		no: 13,
		name: "stream_state_update",
		kind: "message",
		T: no,
		oneof: "message"
	},
	{
		no: 14,
		name: "subscribed_quality_update",
		kind: "message",
		T: ao,
		oneof: "message"
	},
	{
		no: 15,
		name: "subscription_permission_update",
		kind: "message",
		T: lo,
		oneof: "message"
	},
	{
		no: 16,
		name: "refresh_token",
		kind: "scalar",
		T: 9,
		oneof: "message"
	},
	{
		no: 17,
		name: "track_unpublished",
		kind: "message",
		T: La,
		oneof: "message"
	},
	{
		no: 18,
		name: "pong",
		kind: "scalar",
		T: 3,
		oneof: "message"
	},
	{
		no: 19,
		name: "reconnect",
		kind: "message",
		T: Fa,
		oneof: "message"
	},
	{
		no: 20,
		name: "pong_resp",
		kind: "message",
		T: _o,
		oneof: "message"
	},
	{
		no: 21,
		name: "subscription_response",
		kind: "message",
		T: bo,
		oneof: "message"
	},
	{
		no: 22,
		name: "request_response",
		kind: "message",
		T: xo,
		oneof: "message"
	},
	{
		no: 23,
		name: "track_subscribed",
		kind: "message",
		T: Co,
		oneof: "message"
	},
	{
		no: 24,
		name: "room_moved",
		kind: "message",
		T: uo,
		oneof: "message"
	},
	{
		no: 25,
		name: "media_sections_requirement",
		kind: "message",
		T: Oo,
		oneof: "message"
	},
	{
		no: 26,
		name: "subscribed_audio_codec_update",
		kind: "message",
		T: oo,
		oneof: "message"
	},
	{
		no: 27,
		name: "publish_data_track_response",
		kind: "message",
		T: Da,
		oneof: "message"
	},
	{
		no: 28,
		name: "unpublish_data_track_response",
		kind: "message",
		T: ka,
		oneof: "message"
	},
	{
		no: 29,
		name: "data_track_subscriber_handles",
		kind: "message",
		T: Aa,
		oneof: "message"
	}
]), wa = /* @__PURE__ */ T.makeMessageType("livekit.SimulcastCodec", () => [
	{
		no: 1,
		name: "codec",
		kind: "scalar",
		T: 9
	},
	{
		no: 2,
		name: "cid",
		kind: "scalar",
		T: 9
	},
	{
		no: 4,
		name: "layers",
		kind: "message",
		T: zi,
		repeated: !0
	},
	{
		no: 5,
		name: "video_layer_mode",
		kind: "enum",
		T: T.getEnumType(Bi)
	}
]), Ta = /* @__PURE__ */ T.makeMessageType("livekit.AddTrackRequest", () => [
	{
		no: 1,
		name: "cid",
		kind: "scalar",
		T: 9
	},
	{
		no: 2,
		name: "name",
		kind: "scalar",
		T: 9
	},
	{
		no: 3,
		name: "type",
		kind: "enum",
		T: T.getEnumType(bi)
	},
	{
		no: 4,
		name: "width",
		kind: "scalar",
		T: 13
	},
	{
		no: 5,
		name: "height",
		kind: "scalar",
		T: 13
	},
	{
		no: 6,
		name: "muted",
		kind: "scalar",
		T: 8
	},
	{
		no: 7,
		name: "disable_dtx",
		kind: "scalar",
		T: 8
	},
	{
		no: 8,
		name: "source",
		kind: "enum",
		T: T.getEnumType(E)
	},
	{
		no: 9,
		name: "layers",
		kind: "message",
		T: zi,
		repeated: !0
	},
	{
		no: 10,
		name: "simulcast_codecs",
		kind: "message",
		T: wa,
		repeated: !0
	},
	{
		no: 11,
		name: "sid",
		kind: "scalar",
		T: 9
	},
	{
		no: 12,
		name: "stereo",
		kind: "scalar",
		T: 8
	},
	{
		no: 13,
		name: "disable_red",
		kind: "scalar",
		T: 8
	},
	{
		no: 14,
		name: "encryption",
		kind: "enum",
		T: T.getEnumType(O)
	},
	{
		no: 15,
		name: "stream",
		kind: "scalar",
		T: 9
	},
	{
		no: 16,
		name: "backup_codec_policy",
		kind: "enum",
		T: T.getEnumType(yi)
	},
	{
		no: 17,
		name: "audio_features",
		kind: "enum",
		T: T.getEnumType(D),
		repeated: !0
	},
	{
		no: 18,
		name: "packet_trailer_features",
		kind: "enum",
		T: T.getEnumType(Di),
		repeated: !0
	}
]), Ea = /* @__PURE__ */ T.makeMessageType("livekit.PublishDataTrackRequest", () => [
	{
		no: 1,
		name: "pub_handle",
		kind: "scalar",
		T: 13
	},
	{
		no: 2,
		name: "name",
		kind: "scalar",
		T: 9
	},
	{
		no: 3,
		name: "encryption",
		kind: "enum",
		T: T.getEnumType(O)
	}
]), Da = /* @__PURE__ */ T.makeMessageType("livekit.PublishDataTrackResponse", () => [{
	no: 1,
	name: "info",
	kind: "message",
	T: Li
}]), Oa = /* @__PURE__ */ T.makeMessageType("livekit.UnpublishDataTrackRequest", () => [{
	no: 1,
	name: "pub_handle",
	kind: "scalar",
	T: 13
}]), ka = /* @__PURE__ */ T.makeMessageType("livekit.UnpublishDataTrackResponse", () => [{
	no: 1,
	name: "info",
	kind: "message",
	T: Li
}]), Aa = /* @__PURE__ */ T.makeMessageType("livekit.DataTrackSubscriberHandles", () => [{
	no: 1,
	name: "sub_handles",
	kind: "map",
	K: 13,
	V: {
		kind: "message",
		T: ja
	}
}]), ja = /* @__PURE__ */ T.makeMessageType("livekit.DataTrackSubscriberHandles.PublishedDataTrack", () => [
	{
		no: 1,
		name: "publisher_identity",
		kind: "scalar",
		T: 9
	},
	{
		no: 2,
		name: "publisher_sid",
		kind: "scalar",
		T: 9
	},
	{
		no: 3,
		name: "track_sid",
		kind: "scalar",
		T: 9
	}
], { localName: "DataTrackSubscriberHandles_PublishedDataTrack" }), Ma = /* @__PURE__ */ T.makeMessageType("livekit.TrickleRequest", () => [
	{
		no: 1,
		name: "candidateInit",
		kind: "scalar",
		T: 9
	},
	{
		no: 2,
		name: "target",
		kind: "enum",
		T: T.getEnumType(ya)
	},
	{
		no: 3,
		name: "final",
		kind: "scalar",
		T: 8
	}
]), Na = /* @__PURE__ */ T.makeMessageType("livekit.MuteTrackRequest", () => [{
	no: 1,
	name: "sid",
	kind: "scalar",
	T: 9
}, {
	no: 2,
	name: "muted",
	kind: "scalar",
	T: 8
}]), Pa = /* @__PURE__ */ T.makeMessageType("livekit.JoinResponse", () => [
	{
		no: 1,
		name: "room",
		kind: "message",
		T: Oi
	},
	{
		no: 2,
		name: "participant",
		kind: "message",
		T: ji
	},
	{
		no: 3,
		name: "other_participants",
		kind: "message",
		T: ji,
		repeated: !0
	},
	{
		no: 4,
		name: "server_version",
		kind: "scalar",
		T: 9
	},
	{
		no: 5,
		name: "ice_servers",
		kind: "message",
		T: Xa,
		repeated: !0
	},
	{
		no: 6,
		name: "subscriber_primary",
		kind: "scalar",
		T: 8
	},
	{
		no: 7,
		name: "alternative_url",
		kind: "scalar",
		T: 9
	},
	{
		no: 8,
		name: "client_configuration",
		kind: "message",
		T: ca
	},
	{
		no: 9,
		name: "server_region",
		kind: "scalar",
		T: 9
	},
	{
		no: 10,
		name: "ping_timeout",
		kind: "scalar",
		T: 5
	},
	{
		no: 11,
		name: "ping_interval",
		kind: "scalar",
		T: 5
	},
	{
		no: 12,
		name: "server_info",
		kind: "message",
		T: ra
	},
	{
		no: 13,
		name: "sif_trailer",
		kind: "scalar",
		T: 12
	},
	{
		no: 14,
		name: "enabled_publish_codecs",
		kind: "message",
		T: ki,
		repeated: !0
	},
	{
		no: 15,
		name: "fast_publish",
		kind: "scalar",
		T: 8
	}
]), Fa = /* @__PURE__ */ T.makeMessageType("livekit.ReconnectResponse", () => [
	{
		no: 1,
		name: "ice_servers",
		kind: "message",
		T: Xa,
		repeated: !0
	},
	{
		no: 2,
		name: "client_configuration",
		kind: "message",
		T: ca
	},
	{
		no: 3,
		name: "server_info",
		kind: "message",
		T: ra
	},
	{
		no: 4,
		name: "last_message_seq",
		kind: "scalar",
		T: 13
	}
]), Ia = /* @__PURE__ */ T.makeMessageType("livekit.TrackPublishedResponse", () => [{
	no: 1,
	name: "cid",
	kind: "scalar",
	T: 9
}, {
	no: 2,
	name: "track",
	kind: "message",
	T: Ii
}]), La = /* @__PURE__ */ T.makeMessageType("livekit.TrackUnpublishedResponse", () => [{
	no: 1,
	name: "track_sid",
	kind: "scalar",
	T: 9
}]), Ra = /* @__PURE__ */ T.makeMessageType("livekit.SessionDescription", () => [
	{
		no: 1,
		name: "type",
		kind: "scalar",
		T: 9
	},
	{
		no: 2,
		name: "sdp",
		kind: "scalar",
		T: 9
	},
	{
		no: 3,
		name: "id",
		kind: "scalar",
		T: 13
	},
	{
		no: 4,
		name: "mid_to_track_id",
		kind: "map",
		K: 9,
		V: {
			kind: "scalar",
			T: 9
		}
	}
]), za = /* @__PURE__ */ T.makeMessageType("livekit.ParticipantUpdate", () => [{
	no: 1,
	name: "participants",
	kind: "message",
	T: ji,
	repeated: !0
}]), Ba = /* @__PURE__ */ T.makeMessageType("livekit.UpdateSubscription", () => [
	{
		no: 1,
		name: "track_sids",
		kind: "scalar",
		T: 9,
		repeated: !0
	},
	{
		no: 2,
		name: "subscribe",
		kind: "scalar",
		T: 8
	},
	{
		no: 3,
		name: "participant_tracks",
		kind: "message",
		T: na,
		repeated: !0
	}
]), Va = /* @__PURE__ */ T.makeMessageType("livekit.UpdateDataSubscription", () => [{
	no: 1,
	name: "updates",
	kind: "message",
	T: Ha,
	repeated: !0
}]), Ha = /* @__PURE__ */ T.makeMessageType("livekit.UpdateDataSubscription.Update", () => [
	{
		no: 1,
		name: "track_sid",
		kind: "scalar",
		T: 9
	},
	{
		no: 2,
		name: "subscribe",
		kind: "scalar",
		T: 8
	},
	{
		no: 3,
		name: "options",
		kind: "message",
		T: Ri
	}
], { localName: "UpdateDataSubscription_Update" }), Ua = /* @__PURE__ */ T.makeMessageType("livekit.UpdateTrackSettings", () => [
	{
		no: 1,
		name: "track_sids",
		kind: "scalar",
		T: 9,
		repeated: !0
	},
	{
		no: 3,
		name: "disabled",
		kind: "scalar",
		T: 8
	},
	{
		no: 4,
		name: "quality",
		kind: "enum",
		T: T.getEnumType(xi)
	},
	{
		no: 5,
		name: "width",
		kind: "scalar",
		T: 13
	},
	{
		no: 6,
		name: "height",
		kind: "scalar",
		T: 13
	},
	{
		no: 7,
		name: "fps",
		kind: "scalar",
		T: 13
	},
	{
		no: 8,
		name: "priority",
		kind: "scalar",
		T: 13
	}
]), Wa = /* @__PURE__ */ T.makeMessageType("livekit.UpdateLocalAudioTrack", () => [{
	no: 1,
	name: "track_sid",
	kind: "scalar",
	T: 9
}, {
	no: 2,
	name: "features",
	kind: "enum",
	T: T.getEnumType(D),
	repeated: !0
}]), Ga = /* @__PURE__ */ T.makeMessageType("livekit.UpdateLocalVideoTrack", () => [
	{
		no: 1,
		name: "track_sid",
		kind: "scalar",
		T: 9
	},
	{
		no: 2,
		name: "width",
		kind: "scalar",
		T: 13
	},
	{
		no: 3,
		name: "height",
		kind: "scalar",
		T: 13
	}
]), Ka = /* @__PURE__ */ T.makeMessageType("livekit.LeaveRequest", () => [
	{
		no: 1,
		name: "can_reconnect",
		kind: "scalar",
		T: 8
	},
	{
		no: 2,
		name: "reason",
		kind: "enum",
		T: T.getEnumType(wi)
	},
	{
		no: 3,
		name: "action",
		kind: "enum",
		T: T.getEnumType(qa)
	},
	{
		no: 4,
		name: "regions",
		kind: "message",
		T: vo
	}
]), qa = /* @__PURE__ */ T.makeEnum("livekit.LeaveRequest.Action", [
	{
		no: 0,
		name: "DISCONNECT"
	},
	{
		no: 1,
		name: "RESUME"
	},
	{
		no: 2,
		name: "RECONNECT"
	}
]), Ja = /* @__PURE__ */ T.makeMessageType("livekit.UpdateVideoLayers", () => [{
	no: 1,
	name: "track_sid",
	kind: "scalar",
	T: 9
}, {
	no: 2,
	name: "layers",
	kind: "message",
	T: zi,
	repeated: !0
}]), Ya = /* @__PURE__ */ T.makeMessageType("livekit.UpdateParticipantMetadata", () => [
	{
		no: 1,
		name: "metadata",
		kind: "scalar",
		T: 9
	},
	{
		no: 2,
		name: "name",
		kind: "scalar",
		T: 9
	},
	{
		no: 3,
		name: "attributes",
		kind: "map",
		K: 9,
		V: {
			kind: "scalar",
			T: 9
		}
	},
	{
		no: 4,
		name: "request_id",
		kind: "scalar",
		T: 13
	}
]), Xa = /* @__PURE__ */ T.makeMessageType("livekit.ICEServer", () => [
	{
		no: 1,
		name: "urls",
		kind: "scalar",
		T: 9,
		repeated: !0
	},
	{
		no: 2,
		name: "username",
		kind: "scalar",
		T: 9
	},
	{
		no: 3,
		name: "credential",
		kind: "scalar",
		T: 9
	}
]), Za = /* @__PURE__ */ T.makeMessageType("livekit.SpeakersChanged", () => [{
	no: 1,
	name: "speakers",
	kind: "message",
	T: Ki,
	repeated: !0
}]), Qa = /* @__PURE__ */ T.makeMessageType("livekit.RoomUpdate", () => [{
	no: 1,
	name: "room",
	kind: "message",
	T: Oi
}]), $a = /* @__PURE__ */ T.makeMessageType("livekit.ConnectionQualityInfo", () => [
	{
		no: 1,
		name: "participant_sid",
		kind: "scalar",
		T: 9
	},
	{
		no: 2,
		name: "quality",
		kind: "enum",
		T: T.getEnumType(Si)
	},
	{
		no: 3,
		name: "score",
		kind: "scalar",
		T: 2
	}
]), eo = /* @__PURE__ */ T.makeMessageType("livekit.ConnectionQualityUpdate", () => [{
	no: 1,
	name: "updates",
	kind: "message",
	T: $a,
	repeated: !0
}]), to = /* @__PURE__ */ T.makeMessageType("livekit.StreamStateInfo", () => [
	{
		no: 1,
		name: "participant_sid",
		kind: "scalar",
		T: 9
	},
	{
		no: 2,
		name: "track_sid",
		kind: "scalar",
		T: 9
	},
	{
		no: 3,
		name: "state",
		kind: "enum",
		T: T.getEnumType(ba)
	}
]), no = /* @__PURE__ */ T.makeMessageType("livekit.StreamStateUpdate", () => [{
	no: 1,
	name: "stream_states",
	kind: "message",
	T: to,
	repeated: !0
}]), ro = /* @__PURE__ */ T.makeMessageType("livekit.SubscribedQuality", () => [{
	no: 1,
	name: "quality",
	kind: "enum",
	T: T.getEnumType(xi)
}, {
	no: 2,
	name: "enabled",
	kind: "scalar",
	T: 8
}]), io = /* @__PURE__ */ T.makeMessageType("livekit.SubscribedCodec", () => [{
	no: 1,
	name: "codec",
	kind: "scalar",
	T: 9
}, {
	no: 2,
	name: "qualities",
	kind: "message",
	T: ro,
	repeated: !0
}]), ao = /* @__PURE__ */ T.makeMessageType("livekit.SubscribedQualityUpdate", () => [
	{
		no: 1,
		name: "track_sid",
		kind: "scalar",
		T: 9
	},
	{
		no: 2,
		name: "subscribed_qualities",
		kind: "message",
		T: ro,
		repeated: !0
	},
	{
		no: 3,
		name: "subscribed_codecs",
		kind: "message",
		T: io,
		repeated: !0
	}
]), oo = /* @__PURE__ */ T.makeMessageType("livekit.SubscribedAudioCodecUpdate", () => [{
	no: 1,
	name: "track_sid",
	kind: "scalar",
	T: 9
}, {
	no: 2,
	name: "subscribed_audio_codecs",
	kind: "message",
	T: va,
	repeated: !0
}]), so = /* @__PURE__ */ T.makeMessageType("livekit.TrackPermission", () => [
	{
		no: 1,
		name: "participant_sid",
		kind: "scalar",
		T: 9
	},
	{
		no: 2,
		name: "all_tracks",
		kind: "scalar",
		T: 8
	},
	{
		no: 3,
		name: "track_sids",
		kind: "scalar",
		T: 9,
		repeated: !0
	},
	{
		no: 4,
		name: "participant_identity",
		kind: "scalar",
		T: 9
	}
]), co = /* @__PURE__ */ T.makeMessageType("livekit.SubscriptionPermission", () => [{
	no: 1,
	name: "all_participants",
	kind: "scalar",
	T: 8
}, {
	no: 2,
	name: "track_permissions",
	kind: "message",
	T: so,
	repeated: !0
}]), lo = /* @__PURE__ */ T.makeMessageType("livekit.SubscriptionPermissionUpdate", () => [
	{
		no: 1,
		name: "participant_sid",
		kind: "scalar",
		T: 9
	},
	{
		no: 2,
		name: "track_sid",
		kind: "scalar",
		T: 9
	},
	{
		no: 3,
		name: "allowed",
		kind: "scalar",
		T: 8
	}
]), uo = /* @__PURE__ */ T.makeMessageType("livekit.RoomMovedResponse", () => [
	{
		no: 1,
		name: "room",
		kind: "message",
		T: Oi
	},
	{
		no: 2,
		name: "token",
		kind: "scalar",
		T: 9
	},
	{
		no: 3,
		name: "participant",
		kind: "message",
		T: ji
	},
	{
		no: 4,
		name: "other_participants",
		kind: "message",
		T: ji,
		repeated: !0
	}
]), fo = /* @__PURE__ */ T.makeMessageType("livekit.SyncState", () => [
	{
		no: 1,
		name: "answer",
		kind: "message",
		T: Ra
	},
	{
		no: 2,
		name: "subscription",
		kind: "message",
		T: Ba
	},
	{
		no: 3,
		name: "publish_tracks",
		kind: "message",
		T: Ia,
		repeated: !0
	},
	{
		no: 4,
		name: "data_channels",
		kind: "message",
		T: mo,
		repeated: !0
	},
	{
		no: 5,
		name: "offer",
		kind: "message",
		T: Ra
	},
	{
		no: 6,
		name: "track_sids_disabled",
		kind: "scalar",
		T: 9,
		repeated: !0
	},
	{
		no: 7,
		name: "datachannel_receive_states",
		kind: "message",
		T: po,
		repeated: !0
	},
	{
		no: 8,
		name: "publish_data_tracks",
		kind: "message",
		T: Da,
		repeated: !0
	}
]), po = /* @__PURE__ */ T.makeMessageType("livekit.DataChannelReceiveState", () => [{
	no: 1,
	name: "publisher_sid",
	kind: "scalar",
	T: 9
}, {
	no: 2,
	name: "last_seq",
	kind: "scalar",
	T: 13
}]), mo = /* @__PURE__ */ T.makeMessageType("livekit.DataChannelInfo", () => [
	{
		no: 1,
		name: "label",
		kind: "scalar",
		T: 9
	},
	{
		no: 2,
		name: "id",
		kind: "scalar",
		T: 13
	},
	{
		no: 3,
		name: "target",
		kind: "enum",
		T: T.getEnumType(ya)
	}
]), ho = /* @__PURE__ */ T.makeMessageType("livekit.SimulateScenario", () => [
	{
		no: 1,
		name: "speaker_update",
		kind: "scalar",
		T: 5,
		oneof: "scenario"
	},
	{
		no: 2,
		name: "node_failure",
		kind: "scalar",
		T: 8,
		oneof: "scenario"
	},
	{
		no: 3,
		name: "migration",
		kind: "scalar",
		T: 8,
		oneof: "scenario"
	},
	{
		no: 4,
		name: "server_leave",
		kind: "scalar",
		T: 8,
		oneof: "scenario"
	},
	{
		no: 5,
		name: "switch_candidate_protocol",
		kind: "enum",
		T: T.getEnumType(xa),
		oneof: "scenario"
	},
	{
		no: 6,
		name: "subscriber_bandwidth",
		kind: "scalar",
		T: 3,
		oneof: "scenario"
	},
	{
		no: 7,
		name: "disconnect_signal_on_resume",
		kind: "scalar",
		T: 8,
		oneof: "scenario"
	},
	{
		no: 8,
		name: "disconnect_signal_on_resume_no_messages",
		kind: "scalar",
		T: 8,
		oneof: "scenario"
	},
	{
		no: 9,
		name: "leave_request_full_reconnect",
		kind: "scalar",
		T: 8,
		oneof: "scenario"
	}
]), go = /* @__PURE__ */ T.makeMessageType("livekit.Ping", () => [{
	no: 1,
	name: "timestamp",
	kind: "scalar",
	T: 3
}, {
	no: 2,
	name: "rtt",
	kind: "scalar",
	T: 3
}]), _o = /* @__PURE__ */ T.makeMessageType("livekit.Pong", () => [{
	no: 1,
	name: "last_ping_timestamp",
	kind: "scalar",
	T: 3
}, {
	no: 2,
	name: "timestamp",
	kind: "scalar",
	T: 3
}]), vo = /* @__PURE__ */ T.makeMessageType("livekit.RegionSettings", () => [{
	no: 1,
	name: "regions",
	kind: "message",
	T: yo,
	repeated: !0
}]), yo = /* @__PURE__ */ T.makeMessageType("livekit.RegionInfo", () => [
	{
		no: 1,
		name: "region",
		kind: "scalar",
		T: 9
	},
	{
		no: 2,
		name: "url",
		kind: "scalar",
		T: 9
	},
	{
		no: 3,
		name: "distance",
		kind: "scalar",
		T: 3
	}
]), bo = /* @__PURE__ */ T.makeMessageType("livekit.SubscriptionResponse", () => [{
	no: 1,
	name: "track_sid",
	kind: "scalar",
	T: 9
}, {
	no: 2,
	name: "err",
	kind: "enum",
	T: T.getEnumType(Ei)
}]), xo = /* @__PURE__ */ T.makeMessageType("livekit.RequestResponse", () => [
	{
		no: 1,
		name: "request_id",
		kind: "scalar",
		T: 13
	},
	{
		no: 2,
		name: "reason",
		kind: "enum",
		T: T.getEnumType(So)
	},
	{
		no: 3,
		name: "message",
		kind: "scalar",
		T: 9
	},
	{
		no: 4,
		name: "trickle",
		kind: "message",
		T: Ma,
		oneof: "request"
	},
	{
		no: 5,
		name: "add_track",
		kind: "message",
		T: Ta,
		oneof: "request"
	},
	{
		no: 6,
		name: "mute",
		kind: "message",
		T: Na,
		oneof: "request"
	},
	{
		no: 7,
		name: "update_metadata",
		kind: "message",
		T: Ya,
		oneof: "request"
	},
	{
		no: 8,
		name: "update_audio_track",
		kind: "message",
		T: Wa,
		oneof: "request"
	},
	{
		no: 9,
		name: "update_video_track",
		kind: "message",
		T: Ga,
		oneof: "request"
	},
	{
		no: 10,
		name: "publish_data_track",
		kind: "message",
		T: Ea,
		oneof: "request"
	},
	{
		no: 11,
		name: "unpublish_data_track",
		kind: "message",
		T: Oa,
		oneof: "request"
	}
]), So = /* @__PURE__ */ T.makeEnum("livekit.RequestResponse.Reason", [
	{
		no: 0,
		name: "OK"
	},
	{
		no: 1,
		name: "NOT_FOUND"
	},
	{
		no: 2,
		name: "NOT_ALLOWED"
	},
	{
		no: 3,
		name: "LIMIT_EXCEEDED"
	},
	{
		no: 4,
		name: "QUEUED"
	},
	{
		no: 5,
		name: "UNSUPPORTED_TYPE"
	},
	{
		no: 6,
		name: "UNCLASSIFIED_ERROR"
	},
	{
		no: 7,
		name: "INVALID_HANDLE"
	},
	{
		no: 8,
		name: "INVALID_NAME"
	},
	{
		no: 9,
		name: "DUPLICATE_HANDLE"
	},
	{
		no: 10,
		name: "DUPLICATE_NAME"
	}
]), Co = /* @__PURE__ */ T.makeMessageType("livekit.TrackSubscribed", () => [{
	no: 1,
	name: "track_sid",
	kind: "scalar",
	T: 9
}]), wo = /* @__PURE__ */ T.makeMessageType("livekit.ConnectionSettings", () => [
	{
		no: 1,
		name: "auto_subscribe",
		kind: "scalar",
		T: 8
	},
	{
		no: 2,
		name: "adaptive_stream",
		kind: "scalar",
		T: 8
	},
	{
		no: 3,
		name: "subscriber_allow_pause",
		kind: "scalar",
		T: 8,
		opt: !0
	},
	{
		no: 4,
		name: "disable_ice_lite",
		kind: "scalar",
		T: 8
	},
	{
		no: 5,
		name: "auto_subscribe_data_track",
		kind: "scalar",
		T: 8,
		opt: !0
	}
]), To = /* @__PURE__ */ T.makeMessageType("livekit.JoinRequest", () => [
	{
		no: 1,
		name: "client_info",
		kind: "message",
		T: aa
	},
	{
		no: 2,
		name: "connection_settings",
		kind: "message",
		T: wo
	},
	{
		no: 3,
		name: "metadata",
		kind: "scalar",
		T: 9
	},
	{
		no: 4,
		name: "participant_attributes",
		kind: "map",
		K: 9,
		V: {
			kind: "scalar",
			T: 9
		}
	},
	{
		no: 5,
		name: "add_track_requests",
		kind: "message",
		T: Ta,
		repeated: !0
	},
	{
		no: 6,
		name: "publisher_offer",
		kind: "message",
		T: Ra
	},
	{
		no: 7,
		name: "reconnect",
		kind: "scalar",
		T: 8
	},
	{
		no: 8,
		name: "reconnect_reason",
		kind: "enum",
		T: T.getEnumType(Ti)
	},
	{
		no: 9,
		name: "participant_sid",
		kind: "scalar",
		T: 9
	},
	{
		no: 10,
		name: "sync_state",
		kind: "message",
		T: fo
	}
]), Eo = /* @__PURE__ */ T.makeMessageType("livekit.WrappedJoinRequest", () => [{
	no: 1,
	name: "compression",
	kind: "enum",
	T: T.getEnumType(Do)
}, {
	no: 2,
	name: "join_request",
	kind: "scalar",
	T: 12
}]), Do = /* @__PURE__ */ T.makeEnum("livekit.WrappedJoinRequest.Compression", [{
	no: 0,
	name: "NONE"
}, {
	no: 1,
	name: "GZIP"
}]), Oo = /* @__PURE__ */ T.makeMessageType("livekit.MediaSectionsRequirement", () => [{
	no: 1,
	name: "num_audios",
	kind: "scalar",
	T: 13
}, {
	no: 2,
	name: "num_videos",
	kind: "scalar",
	T: 13
}]);
function ko(e) {
	return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default") ? e.default : e;
}
var Ao = { exports: {} }, jo = Ao.exports, Mo;
function No() {
	return Mo ? Ao.exports : (Mo = 1, (function(e) {
		(function(t, n) {
			e.exports ? e.exports = n() : t.log = n();
		})(jo, function() {
			var e = function() {}, t = "undefined", n = typeof window !== t && typeof window.navigator !== t && /Trident\/|MSIE /.test(window.navigator.userAgent), r = [
				"trace",
				"debug",
				"info",
				"warn",
				"error"
			], i = {}, a = null;
			function o(e, t) {
				var n = e[t];
				if (typeof n.bind == "function") return n.bind(e);
				try {
					return Function.prototype.bind.call(n, e);
				} catch {
					return function() {
						return Function.prototype.apply.apply(n, [e, arguments]);
					};
				}
			}
			function s() {
				console.log && (console.log.apply ? console.log.apply(console, arguments) : Function.prototype.apply.apply(console.log, [console, arguments])), console.trace && console.trace();
			}
			function c(r) {
				return r === "debug" && (r = "log"), typeof console === t ? !1 : r === "trace" && n ? s : console[r] === void 0 ? console.log === void 0 ? e : o(console, "log") : o(console, r);
			}
			function l() {
				for (var n = this.getLevel(), i = 0; i < r.length; i++) {
					var a = r[i];
					this[a] = i < n ? e : this.methodFactory(a, n, this.name);
				}
				if (this.log = this.debug, typeof console === t && n < this.levels.SILENT) return "No console available for logging";
			}
			function u(e) {
				return function() {
					typeof console !== t && (l.call(this), this[e].apply(this, arguments));
				};
			}
			function d(e, t, n) {
				return c(e) || u.apply(this, arguments);
			}
			function f(e, n) {
				var o = this, s, c, u, f = "loglevel";
				typeof e == "string" ? f += ":" + e : typeof e == "symbol" && (f = void 0);
				function ee(e) {
					var n = (r[e] || "silent").toUpperCase();
					if (!(typeof window === t || !f)) {
						try {
							window.localStorage[f] = n;
							return;
						} catch {}
						try {
							window.document.cookie = encodeURIComponent(f) + "=" + n + ";";
						} catch {}
					}
				}
				function p() {
					var e;
					if (!(typeof window === t || !f)) {
						try {
							e = window.localStorage[f];
						} catch {}
						if (typeof e === t) try {
							var n = window.document.cookie, r = encodeURIComponent(f), i = n.indexOf(r + "=");
							i !== -1 && (e = /^([^;]+)/.exec(n.slice(i + r.length + 1))[1]);
						} catch {}
						return o.levels[e] === void 0 && (e = void 0), e;
					}
				}
				function m() {
					if (!(typeof window === t || !f)) {
						try {
							window.localStorage.removeItem(f);
						} catch {}
						try {
							window.document.cookie = encodeURIComponent(f) + "=; expires=Thu, 01 Jan 1970 00:00:00 UTC";
						} catch {}
					}
				}
				function te(e) {
					var t = e;
					if (typeof t == "string" && o.levels[t.toUpperCase()] !== void 0 && (t = o.levels[t.toUpperCase()]), typeof t == "number" && t >= 0 && t <= o.levels.SILENT) return t;
					throw TypeError("log.setLevel() called with invalid level: " + e);
				}
				o.name = e, o.levels = {
					TRACE: 0,
					DEBUG: 1,
					INFO: 2,
					WARN: 3,
					ERROR: 4,
					SILENT: 5
				}, o.methodFactory = n || d, o.getLevel = function() {
					return u ?? c ?? s;
				}, o.setLevel = function(e, t) {
					return u = te(e), t !== !1 && ee(u), l.call(o);
				}, o.setDefaultLevel = function(e) {
					c = te(e), p() || o.setLevel(e, !1);
				}, o.resetLevel = function() {
					u = null, m(), l.call(o);
				}, o.enableAll = function(e) {
					o.setLevel(o.levels.TRACE, e);
				}, o.disableAll = function(e) {
					o.setLevel(o.levels.SILENT, e);
				}, o.rebuild = function() {
					if (a !== o && (s = te(a.getLevel())), l.call(o), a === o) for (var e in i) i[e].rebuild();
				}, s = te(a ? a.getLevel() : "WARN");
				var ne = p();
				ne != null && (u = te(ne)), l.call(o);
			}
			a = new f(), a.getLogger = function(e) {
				if (typeof e != "symbol" && typeof e != "string" || e === "") throw TypeError("You must supply a name when creating a logger.");
				var t = i[e];
				return t ||= i[e] = new f(e, a.methodFactory), t;
			};
			var ee = typeof window === t ? void 0 : window.log;
			return a.noConflict = function() {
				return typeof window !== t && window.log === a && (window.log = ee), a;
			}, a.getLoggers = function() {
				return i;
			}, a.default = a, a;
		});
	})(Ao), Ao.exports);
}
var Po = No(), Fo;
(function(e) {
	e[e.trace = 0] = "trace", e[e.debug = 1] = "debug", e[e.info = 2] = "info", e[e.warn = 3] = "warn", e[e.error = 4] = "error", e[e.silent = 5] = "silent";
})(Fo ||= {});
var k;
(function(e) {
	e.Default = "livekit", e.Room = "livekit-room", e.TokenSource = "livekit-token-source", e.Participant = "livekit-participant", e.Track = "livekit-track", e.Publication = "livekit-track-publication", e.Engine = "livekit-engine", e.Signal = "livekit-signal", e.PCManager = "livekit-pc-manager", e.PCTransport = "livekit-pc-transport", e.E2EE = "lk-e2ee", e.DataTracks = "livekit-data-tracks";
})(k ||= {});
var A = Po.getLogger(k.Default), Io = Object.values(k).map((e) => Po.getLogger(e));
A.setDefaultLevel(Fo.info);
function Lo(e, t) {
	let n = Po.getLogger(e);
	return n.setDefaultLevel(A.getLevel()), t ? Ro(n, t) : n;
}
function Ro(e, t) {
	let n = (n) => (r, i) => {
		let a = t(), o = a || i ? Object.assign(Object.assign({}, a), i) : void 0;
		e[n](r, o);
	}, r = Object.create(e);
	return r.trace = n("trace"), r.debug = n("debug"), r.info = n("info"), r.warn = n("warn"), r.error = n("error"), r;
}
function zo(e, t) {
	if (t) Po.getLogger(t).setLevel(e);
	else for (let t of Io) t.setLevel(e);
}
var Bo = Po.getLogger(k.E2EE), Vo = 7e3, Ho = [
	0,
	300,
	4 * 300,
	9 * 300,
	16 * 300,
	Vo,
	Vo,
	Vo,
	Vo,
	Vo
], Uo = class {
	constructor(e) {
		this._retryDelays = e === void 0 ? Ho : [...e];
	}
	nextRetryDelayInMs(e) {
		if (e.retryCount >= this._retryDelays.length) return null;
		let t = this._retryDelays[e.retryCount];
		return e.retryCount <= 1 ? t : t + Math.random() * 1e3;
	}
};
function Wo(e, t) {
	var n = {};
	for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && t.indexOf(r) < 0 && (n[r] = e[r]);
	if (e != null && typeof Object.getOwnPropertySymbols == "function") for (var i = 0, r = Object.getOwnPropertySymbols(e); i < r.length; i++) t.indexOf(r[i]) < 0 && Object.prototype.propertyIsEnumerable.call(e, r[i]) && (n[r[i]] = e[r[i]]);
	return n;
}
function j(e, t, n, r) {
	function i(e) {
		return e instanceof n ? e : new n(function(t) {
			t(e);
		});
	}
	return new (n ||= Promise)(function(n, a) {
		function o(e) {
			try {
				c(r.next(e));
			} catch (e) {
				a(e);
			}
		}
		function s(e) {
			try {
				c(r.throw(e));
			} catch (e) {
				a(e);
			}
		}
		function c(e) {
			e.done ? n(e.value) : i(e.value).then(o, s);
		}
		c((r = r.apply(e, t || [])).next());
	});
}
function Go(e) {
	var t = typeof Symbol == "function" && Symbol.iterator, n = t && e[t], r = 0;
	if (n) return n.call(e);
	if (e && typeof e.length == "number") return { next: function() {
		return e && r >= e.length && (e = void 0), {
			value: e && e[r++],
			done: !e
		};
	} };
	throw TypeError(t ? "Object is not iterable." : "Symbol.iterator is not defined.");
}
function Ko(e) {
	return this instanceof Ko ? (this.v = e, this) : new Ko(e);
}
function qo(e, t, n) {
	if (!Symbol.asyncIterator) throw TypeError("Symbol.asyncIterator is not defined.");
	var r = n.apply(e, t || []), i, a = [];
	return i = Object.create((typeof AsyncIterator == "function" ? AsyncIterator : Object).prototype), s("next"), s("throw"), s("return", o), i[Symbol.asyncIterator] = function() {
		return this;
	}, i;
	function o(e) {
		return function(t) {
			return Promise.resolve(t).then(e, d);
		};
	}
	function s(e, t) {
		r[e] && (i[e] = function(t) {
			return new Promise(function(n, r) {
				a.push([
					e,
					t,
					n,
					r
				]) > 1 || c(e, t);
			});
		}, t && (i[e] = t(i[e])));
	}
	function c(e, t) {
		try {
			l(r[e](t));
		} catch (e) {
			f(a[0][3], e);
		}
	}
	function l(e) {
		e.value instanceof Ko ? Promise.resolve(e.value.v).then(u, d) : f(a[0][2], e);
	}
	function u(e) {
		c("next", e);
	}
	function d(e) {
		c("throw", e);
	}
	function f(e, t) {
		e(t), a.shift(), a.length && c(a[0][0], a[0][1]);
	}
}
function Jo(e) {
	var t, n;
	return t = {}, r("next"), r("throw", function(e) {
		throw e;
	}), r("return"), t[Symbol.iterator] = function() {
		return this;
	}, t;
	function r(r, i) {
		t[r] = e[r] ? function(t) {
			return (n = !n) ? {
				value: Ko(e[r](t)),
				done: !1
			} : i ? i(t) : t;
		} : i;
	}
}
function Yo(e) {
	if (!Symbol.asyncIterator) throw TypeError("Symbol.asyncIterator is not defined.");
	var t = e[Symbol.asyncIterator], n;
	return t ? t.call(e) : (e = typeof Go == "function" ? Go(e) : e[Symbol.iterator](), n = {}, r("next"), r("throw"), r("return"), n[Symbol.asyncIterator] = function() {
		return this;
	}, n);
	function r(t) {
		n[t] = e[t] && function(n) {
			return new Promise(function(r, a) {
				n = e[t](n), i(r, a, n.done, n.value);
			});
		};
	}
	function i(e, t, n, r) {
		Promise.resolve(r).then(function(t) {
			e({
				value: t,
				done: n
			});
		}, t);
	}
}
var Xo = { exports: {} }, Zo;
function Qo() {
	if (Zo) return Xo.exports;
	Zo = 1;
	var e = typeof Reflect == "object" ? Reflect : null, t = e && typeof e.apply == "function" ? e.apply : function(e, t, n) {
		return Function.prototype.apply.call(e, t, n);
	}, n = e && typeof e.ownKeys == "function" ? e.ownKeys : Object.getOwnPropertySymbols ? function(e) {
		return Object.getOwnPropertyNames(e).concat(Object.getOwnPropertySymbols(e));
	} : function(e) {
		return Object.getOwnPropertyNames(e);
	};
	function r(e) {
		console && console.warn && console.warn(e);
	}
	var i = Number.isNaN || function(e) {
		return e !== e;
	};
	function a() {
		a.init.call(this);
	}
	Xo.exports = a, Xo.exports.once = ne, a.EventEmitter = a, a.prototype._events = void 0, a.prototype._eventsCount = 0, a.prototype._maxListeners = void 0;
	var o = 10;
	function s(e) {
		if (typeof e != "function") throw TypeError("The \"listener\" argument must be of type Function. Received type " + typeof e);
	}
	Object.defineProperty(a, "defaultMaxListeners", {
		enumerable: !0,
		get: function() {
			return o;
		},
		set: function(e) {
			if (typeof e != "number" || e < 0 || i(e)) throw RangeError("The value of \"defaultMaxListeners\" is out of range. It must be a non-negative number. Received " + e + ".");
			o = e;
		}
	}), a.init = function() {
		(this._events === void 0 || this._events === Object.getPrototypeOf(this)._events) && (this._events = Object.create(null), this._eventsCount = 0), this._maxListeners = this._maxListeners || void 0;
	}, a.prototype.setMaxListeners = function(e) {
		if (typeof e != "number" || e < 0 || i(e)) throw RangeError("The value of \"n\" is out of range. It must be a non-negative number. Received " + e + ".");
		return this._maxListeners = e, this;
	};
	function c(e) {
		return e._maxListeners === void 0 ? a.defaultMaxListeners : e._maxListeners;
	}
	a.prototype.getMaxListeners = function() {
		return c(this);
	}, a.prototype.emit = function(e) {
		for (var n = [], r = 1; r < arguments.length; r++) n.push(arguments[r]);
		var i = e === "error", a = this._events;
		if (a !== void 0) i &&= a.error === void 0;
		else if (!i) return !1;
		if (i) {
			var o;
			if (n.length > 0 && (o = n[0]), o instanceof Error) throw o;
			var s = /* @__PURE__ */ Error("Unhandled error." + (o ? " (" + o.message + ")" : ""));
			throw s.context = o, s;
		}
		var c = a[e];
		if (c === void 0) return !1;
		if (typeof c == "function") t(c, this, n);
		else for (var l = c.length, u = p(c, l), r = 0; r < l; ++r) t(u[r], this, n);
		return !0;
	};
	function l(e, t, n, i) {
		var a, o, l;
		if (s(n), o = e._events, o === void 0 ? (o = e._events = Object.create(null), e._eventsCount = 0) : (o.newListener !== void 0 && (e.emit("newListener", t, n.listener ? n.listener : n), o = e._events), l = o[t]), l === void 0) l = o[t] = n, ++e._eventsCount;
		else if (typeof l == "function" ? l = o[t] = i ? [n, l] : [l, n] : i ? l.unshift(n) : l.push(n), a = c(e), a > 0 && l.length > a && !l.warned) {
			l.warned = !0;
			var u = /* @__PURE__ */ Error("Possible EventEmitter memory leak detected. " + l.length + " " + String(t) + " listeners added. Use emitter.setMaxListeners() to increase limit");
			u.name = "MaxListenersExceededWarning", u.emitter = e, u.type = t, u.count = l.length, r(u);
		}
		return e;
	}
	a.prototype.addListener = function(e, t) {
		return l(this, e, t, !1);
	}, a.prototype.on = a.prototype.addListener, a.prototype.prependListener = function(e, t) {
		return l(this, e, t, !0);
	};
	function u() {
		if (!this.fired) return this.target.removeListener(this.type, this.wrapFn), this.fired = !0, arguments.length === 0 ? this.listener.call(this.target) : this.listener.apply(this.target, arguments);
	}
	function d(e, t, n) {
		var r = {
			fired: !1,
			wrapFn: void 0,
			target: e,
			type: t,
			listener: n
		}, i = u.bind(r);
		return i.listener = n, r.wrapFn = i, i;
	}
	a.prototype.once = function(e, t) {
		return s(t), this.on(e, d(this, e, t)), this;
	}, a.prototype.prependOnceListener = function(e, t) {
		return s(t), this.prependListener(e, d(this, e, t)), this;
	}, a.prototype.removeListener = function(e, t) {
		var n, r, i, a, o;
		if (s(t), r = this._events, r === void 0 || (n = r[e], n === void 0)) return this;
		if (n === t || n.listener === t) --this._eventsCount === 0 ? this._events = Object.create(null) : (delete r[e], r.removeListener && this.emit("removeListener", e, n.listener || t));
		else if (typeof n != "function") {
			for (i = -1, a = n.length - 1; a >= 0; a--) if (n[a] === t || n[a].listener === t) {
				o = n[a].listener, i = a;
				break;
			}
			if (i < 0) return this;
			i === 0 ? n.shift() : m(n, i), n.length === 1 && (r[e] = n[0]), r.removeListener !== void 0 && this.emit("removeListener", e, o || t);
		}
		return this;
	}, a.prototype.off = a.prototype.removeListener, a.prototype.removeAllListeners = function(e) {
		var t, n = this._events, r;
		if (n === void 0) return this;
		if (n.removeListener === void 0) return arguments.length === 0 ? (this._events = Object.create(null), this._eventsCount = 0) : n[e] !== void 0 && (--this._eventsCount === 0 ? this._events = Object.create(null) : delete n[e]), this;
		if (arguments.length === 0) {
			var i = Object.keys(n), a;
			for (r = 0; r < i.length; ++r) a = i[r], a !== "removeListener" && this.removeAllListeners(a);
			return this.removeAllListeners("removeListener"), this._events = Object.create(null), this._eventsCount = 0, this;
		}
		if (t = n[e], typeof t == "function") this.removeListener(e, t);
		else if (t !== void 0) for (r = t.length - 1; r >= 0; r--) this.removeListener(e, t[r]);
		return this;
	};
	function f(e, t, n) {
		var r = e._events;
		if (r === void 0) return [];
		var i = r[t];
		return i === void 0 ? [] : typeof i == "function" ? n ? [i.listener || i] : [i] : n ? te(i) : p(i, i.length);
	}
	a.prototype.listeners = function(e) {
		return f(this, e, !0);
	}, a.prototype.rawListeners = function(e) {
		return f(this, e, !1);
	}, a.listenerCount = function(e, t) {
		return typeof e.listenerCount == "function" ? e.listenerCount(t) : ee.call(e, t);
	}, a.prototype.listenerCount = ee;
	function ee(e) {
		var t = this._events;
		if (t !== void 0) {
			var n = t[e];
			if (typeof n == "function") return 1;
			if (n !== void 0) return n.length;
		}
		return 0;
	}
	a.prototype.eventNames = function() {
		return this._eventsCount > 0 ? n(this._events) : [];
	};
	function p(e, t) {
		for (var n = Array(t), r = 0; r < t; ++r) n[r] = e[r];
		return n;
	}
	function m(e, t) {
		for (; t + 1 < e.length; t++) e[t] = e[t + 1];
		e.pop();
	}
	function te(e) {
		for (var t = Array(e.length), n = 0; n < t.length; ++n) t[n] = e[n].listener || e[n];
		return t;
	}
	function ne(e, t) {
		return new Promise(function(n, r) {
			function i(n) {
				e.removeListener(t, a), r(n);
			}
			function a() {
				typeof e.removeListener == "function" && e.removeListener("error", i), n([].slice.call(arguments));
			}
			ie(e, t, a, { once: !0 }), t !== "error" && re(e, i, { once: !0 });
		});
	}
	function re(e, t, n) {
		typeof e.on == "function" && ie(e, "error", t, n);
	}
	function ie(e, t, n, r) {
		if (typeof e.on == "function") r.once ? e.once(t, n) : e.on(t, n);
		else if (typeof e.addEventListener == "function") e.addEventListener(t, function i(a) {
			r.once && e.removeEventListener(t, i), n(a);
		});
		else throw TypeError("The \"emitter\" argument must be of type EventEmitter. Received type " + typeof e);
	}
	return Xo.exports;
}
var $o = Qo(), es = /*@__PURE__*/ ko($o), ts = !0, ns = !0;
function rs(e, t, n) {
	let r = e.match(t);
	return r && r.length >= n && parseFloat(r[n], 10);
}
function is(e, t, n) {
	if (!e.RTCPeerConnection) return;
	if (!Object.getOwnPropertyDescriptor(EventTarget.prototype, "addEventListener").writable) {
		ss("Unable to polyfill events");
		return;
	}
	let r = e.RTCPeerConnection.prototype, i = r.addEventListener;
	r.addEventListener = function(e, r) {
		if (e !== t) return i.apply(this, arguments);
		let a = (e) => {
			let t = n(e);
			t && (r.handleEvent ? r.handleEvent(t) : r(t));
		};
		return this._eventMap = this._eventMap || {}, this._eventMap[t] || (this._eventMap[t] = /* @__PURE__ */ new Map()), this._eventMap[t].set(r, a), i.apply(this, [e, a]);
	};
	let a = r.removeEventListener;
	r.removeEventListener = function(e, n) {
		if (e !== t || !this._eventMap || !this._eventMap[t] || !this._eventMap[t].has(n)) return a.apply(this, arguments);
		let r = this._eventMap[t].get(n);
		return this._eventMap[t].delete(n), this._eventMap[t].size === 0 && delete this._eventMap[t], Object.keys(this._eventMap).length === 0 && delete this._eventMap, a.apply(this, [e, r]);
	}, Object.defineProperty(r, "on" + t, {
		get() {
			return this["_on" + t];
		},
		set(e) {
			this["_on" + t] && (this.removeEventListener(t, this["_on" + t]), delete this["_on" + t]), e && this.addEventListener(t, this["_on" + t] = e);
		},
		enumerable: !0,
		configurable: !0
	});
}
function as(e) {
	return typeof e == "boolean" ? (ts = e, e ? "adapter.js logging disabled" : "adapter.js logging enabled") : /* @__PURE__ */ Error("Argument type: " + typeof e + ". Please use a boolean.");
}
function os(e) {
	return typeof e == "boolean" ? (ns = !e, "adapter.js deprecation warnings " + (e ? "disabled" : "enabled")) : /* @__PURE__ */ Error("Argument type: " + typeof e + ". Please use a boolean.");
}
function ss() {
	if (typeof window == "object") {
		if (ts) return;
		typeof console < "u" && typeof console.log == "function" && console.log.apply(console, arguments);
	}
}
function cs(e, t) {
	ns && console.warn(e + " is deprecated, please use " + t + " instead.");
}
function ls(e) {
	let t = {
		browser: null,
		version: null
	};
	if (e === void 0 || !e.navigator || !e.navigator.userAgent) return t.browser = "Not a browser.", t;
	let n = e.navigator;
	if (n.userAgentData && n.userAgentData.brands) {
		let e = n.userAgentData.brands.find((e) => e.brand === "Chromium");
		if (e) return {
			browser: "chrome",
			version: parseInt(e.version, 10)
		};
	}
	if (n.mozGetUserMedia) t.browser = "firefox", t.version = parseInt(rs(n.userAgent, /Firefox\/(\d+)\./, 1));
	else if (n.webkitGetUserMedia || e.isSecureContext === !1 && e.webkitRTCPeerConnection) t.browser = "chrome", t.version = parseInt(rs(n.userAgent, /Chrom(e|ium)\/(\d+)\./, 2)) || null;
	else if (e.RTCPeerConnection && n.userAgent.match(/AppleWebKit\/(\d+)\./)) t.browser = "safari", t.version = parseInt(rs(n.userAgent, /AppleWebKit\/(\d+)\./, 1)), t.supportsUnifiedPlan = e.RTCRtpTransceiver && "currentDirection" in e.RTCRtpTransceiver.prototype, t._safariVersion = rs(n.userAgent, /Version\/(\d+(\.?\d+))/, 1);
	else return t.browser = "Not a supported browser.", t;
	return t;
}
function us(e) {
	return Object.prototype.toString.call(e) === "[object Object]";
}
function ds(e) {
	return us(e) ? Object.keys(e).reduce(function(t, n) {
		let r = us(e[n]), i = r ? ds(e[n]) : e[n], a = r && !Object.keys(i).length;
		return i === void 0 || a ? t : Object.assign(t, { [n]: i });
	}, {}) : e;
}
function fs(e, t, n) {
	!t || n.has(t.id) || (n.set(t.id, t), Object.keys(t).forEach((r) => {
		r.endsWith("Id") ? fs(e, e.get(t[r]), n) : r.endsWith("Ids") && t[r].forEach((t) => {
			fs(e, e.get(t), n);
		});
	}));
}
function ps(e, t, n) {
	let r = n ? "outbound-rtp" : "inbound-rtp", i = /* @__PURE__ */ new Map();
	if (t === null) return i;
	let a = [];
	return e.forEach((e) => {
		e.type === "track" && e.trackIdentifier === t.id && a.push(e);
	}), a.forEach((t) => {
		e.forEach((n) => {
			n.type === r && n.trackId === t.id && fs(e, n, i);
		});
	}), i;
}
var ms = ss;
function hs(e, t) {
	let n = e && e.navigator;
	if (!n.mediaDevices) return;
	let r = function(e) {
		if (typeof e != "object" || e.mandatory || e.optional) return e;
		let t = {};
		return Object.keys(e).forEach((n) => {
			if (n === "require" || n === "advanced" || n === "mediaSource") return;
			let r = typeof e[n] == "object" ? e[n] : { ideal: e[n] };
			r.exact !== void 0 && typeof r.exact == "number" && (r.min = r.max = r.exact);
			let i = function(e, t) {
				return e ? e + t.charAt(0).toUpperCase() + t.slice(1) : t === "deviceId" ? "sourceId" : t;
			};
			if (r.ideal !== void 0) {
				t.optional = t.optional || [];
				let e = {};
				typeof r.ideal == "number" ? (e[i("min", n)] = r.ideal, t.optional.push(e), e = {}, e[i("max", n)] = r.ideal, t.optional.push(e)) : (e[i("", n)] = r.ideal, t.optional.push(e));
			}
			r.exact !== void 0 && typeof r.exact != "number" ? (t.mandatory = t.mandatory || {}, t.mandatory[i("", n)] = r.exact) : ["min", "max"].forEach((e) => {
				r[e] !== void 0 && (t.mandatory = t.mandatory || {}, t.mandatory[i(e, n)] = r[e]);
			});
		}), e.advanced && (t.optional = (t.optional || []).concat(e.advanced)), t;
	}, i = function(e, i) {
		if (t.version >= 61) return i(e);
		if (e = JSON.parse(JSON.stringify(e)), e && typeof e.audio == "object") {
			let t = function(e, t, n) {
				t in e && !(n in e) && (e[n] = e[t], delete e[t]);
			};
			e = JSON.parse(JSON.stringify(e)), t(e.audio, "autoGainControl", "googAutoGainControl"), t(e.audio, "noiseSuppression", "googNoiseSuppression"), e.audio = r(e.audio);
		}
		if (e && typeof e.video == "object") {
			let a = e.video.facingMode;
			a &&= typeof a == "object" ? a : { ideal: a };
			let o = t.version < 66;
			if (a && (a.exact === "user" || a.exact === "environment" || a.ideal === "user" || a.ideal === "environment") && !(n.mediaDevices.getSupportedConstraints && n.mediaDevices.getSupportedConstraints().facingMode && !o)) {
				delete e.video.facingMode;
				let t;
				if (a.exact === "environment" || a.ideal === "environment" ? t = ["back", "rear"] : (a.exact === "user" || a.ideal === "user") && (t = ["front"]), t) return n.mediaDevices.enumerateDevices().then((n) => {
					n = n.filter((e) => e.kind === "videoinput");
					let o = n.find((e) => t.some((t) => e.label.toLowerCase().includes(t)));
					return !o && n.length && t.includes("back") && (o = n[n.length - 1]), o && (e.video.deviceId = a.exact ? { exact: o.deviceId } : { ideal: o.deviceId }), e.video = r(e.video), ms("chrome: " + JSON.stringify(e)), i(e);
				});
			}
			e.video = r(e.video);
		}
		return ms("chrome: " + JSON.stringify(e)), i(e);
	}, a = function(e) {
		return t.version >= 64 ? e : {
			name: {
				PermissionDeniedError: "NotAllowedError",
				PermissionDismissedError: "NotAllowedError",
				InvalidStateError: "NotAllowedError",
				DevicesNotFoundError: "NotFoundError",
				ConstraintNotSatisfiedError: "OverconstrainedError",
				TrackStartError: "NotReadableError",
				MediaDeviceFailedDueToShutdown: "NotAllowedError",
				MediaDeviceKillSwitchOn: "NotAllowedError",
				TabCaptureError: "AbortError",
				ScreenCaptureError: "AbortError",
				DeviceCaptureError: "AbortError"
			}[e.name] || e.name,
			message: e.message,
			constraint: e.constraint || e.constraintName,
			toString() {
				return this.name + (this.message && ": ") + this.message;
			}
		};
	};
	if (n.getUserMedia = function(e, t, r) {
		i(e, (e) => {
			n.webkitGetUserMedia(e, t, (e) => {
				r && r(a(e));
			});
		});
	}.bind(n), n.mediaDevices.getUserMedia) {
		let e = n.mediaDevices.getUserMedia.bind(n.mediaDevices);
		n.mediaDevices.getUserMedia = function(t) {
			return i(t, (t) => e(t).then((e) => {
				if (t.audio && !e.getAudioTracks().length || t.video && !e.getVideoTracks().length) throw e.getTracks().forEach((e) => {
					e.stop();
				}), new DOMException("", "NotFoundError");
				return e;
			}, (e) => Promise.reject(a(e))));
		};
	}
}
function gs(e) {
	e.MediaStream = e.MediaStream || e.webkitMediaStream;
}
function _s(e, t) {
	if (!(t.version > 102)) if (typeof e == "object" && e.RTCPeerConnection && !("ontrack" in e.RTCPeerConnection.prototype)) {
		Object.defineProperty(e.RTCPeerConnection.prototype, "ontrack", {
			get() {
				return this._ontrack;
			},
			set(e) {
				this._ontrack && this.removeEventListener("track", this._ontrack), this.addEventListener("track", this._ontrack = e);
			},
			enumerable: !0,
			configurable: !0
		});
		let t = e.RTCPeerConnection.prototype.setRemoteDescription;
		e.RTCPeerConnection.prototype.setRemoteDescription = function() {
			return this._ontrackpoly || (this._ontrackpoly = (t) => {
				t.stream.addEventListener("addtrack", (n) => {
					let r;
					r = e.RTCPeerConnection.prototype.getReceivers ? this.getReceivers().find((e) => e.track && e.track.id === n.track.id) : { track: n.track };
					let i = new Event("track");
					i.track = n.track, i.receiver = r, i.transceiver = { receiver: r }, i.streams = [t.stream], this.dispatchEvent(i);
				}), t.stream.getTracks().forEach((n) => {
					let r;
					r = e.RTCPeerConnection.prototype.getReceivers ? this.getReceivers().find((e) => e.track && e.track.id === n.id) : { track: n };
					let i = new Event("track");
					i.track = n, i.receiver = r, i.transceiver = { receiver: r }, i.streams = [t.stream], this.dispatchEvent(i);
				});
			}, this.addEventListener("addstream", this._ontrackpoly)), t.apply(this, arguments);
		};
	} else is(e, "track", (e) => (e.transceiver || Object.defineProperty(e, "transceiver", { value: { receiver: e.receiver } }), e));
}
function vs(e) {
	if (typeof e == "object" && e.RTCPeerConnection && !("getSenders" in e.RTCPeerConnection.prototype) && "createDTMFSender" in e.RTCPeerConnection.prototype) {
		let t = function(e, t) {
			return {
				track: t,
				get dtmf() {
					return this._dtmf === void 0 && (t.kind === "audio" ? this._dtmf = e.createDTMFSender(t) : this._dtmf = null), this._dtmf;
				},
				_pc: e
			};
		};
		if (!e.RTCPeerConnection.prototype.getSenders) {
			e.RTCPeerConnection.prototype.getSenders = function() {
				return this._senders = this._senders || [], this._senders.slice();
			};
			let n = e.RTCPeerConnection.prototype.addTrack;
			e.RTCPeerConnection.prototype.addTrack = function(e, r) {
				let i = n.apply(this, arguments);
				return i || (i = t(this, e), this._senders.push(i)), i;
			};
			let r = e.RTCPeerConnection.prototype.removeTrack;
			e.RTCPeerConnection.prototype.removeTrack = function(e) {
				r.apply(this, arguments);
				let t = this._senders.indexOf(e);
				t !== -1 && this._senders.splice(t, 1);
			};
		}
		let n = e.RTCPeerConnection.prototype.addStream;
		e.RTCPeerConnection.prototype.addStream = function(e) {
			this._senders = this._senders || [], n.apply(this, [e]), e.getTracks().forEach((e) => {
				this._senders.push(t(this, e));
			});
		};
		let r = e.RTCPeerConnection.prototype.removeStream;
		e.RTCPeerConnection.prototype.removeStream = function(e) {
			this._senders = this._senders || [], r.apply(this, [e]), e.getTracks().forEach((e) => {
				let t = this._senders.find((t) => t.track === e);
				t && this._senders.splice(this._senders.indexOf(t), 1);
			});
		};
	} else if (typeof e == "object" && e.RTCPeerConnection && "getSenders" in e.RTCPeerConnection.prototype && "createDTMFSender" in e.RTCPeerConnection.prototype && e.RTCRtpSender && !("dtmf" in e.RTCRtpSender.prototype)) {
		let t = e.RTCPeerConnection.prototype.getSenders;
		e.RTCPeerConnection.prototype.getSenders = function() {
			let e = t.apply(this, []);
			return e.forEach((e) => e._pc = this), e;
		}, Object.defineProperty(e.RTCRtpSender.prototype, "dtmf", { get() {
			return this._dtmf === void 0 && (this.track.kind === "audio" ? this._dtmf = this._pc.createDTMFSender(this.track) : this._dtmf = null), this._dtmf;
		} });
	}
}
function ys(e, t) {
	if (t.version >= 67 || !(typeof e == "object" && e.RTCPeerConnection && e.RTCRtpSender && e.RTCRtpReceiver)) return;
	if (!("getStats" in e.RTCRtpSender.prototype)) {
		let t = e.RTCPeerConnection.prototype.getSenders;
		t && (e.RTCPeerConnection.prototype.getSenders = function() {
			let e = t.apply(this, []);
			return e.forEach((e) => e._pc = this), e;
		});
		let n = e.RTCPeerConnection.prototype.addTrack;
		n && (e.RTCPeerConnection.prototype.addTrack = function() {
			let e = n.apply(this, arguments);
			return e._pc = this, e;
		}), e.RTCRtpSender.prototype.getStats = function() {
			let e = this;
			return this._pc.getStats().then((t) => ps(t, e.track, !0));
		};
	}
	if (!("getStats" in e.RTCRtpReceiver.prototype)) {
		let t = e.RTCPeerConnection.prototype.getReceivers;
		t && (e.RTCPeerConnection.prototype.getReceivers = function() {
			let e = t.apply(this, []);
			return e.forEach((e) => e._pc = this), e;
		}), is(e, "track", (e) => (e.receiver._pc = e.srcElement, e)), e.RTCRtpReceiver.prototype.getStats = function() {
			let e = this;
			return this._pc.getStats().then((t) => ps(t, e.track, !1));
		};
	}
	if (!("getStats" in e.RTCRtpSender.prototype && "getStats" in e.RTCRtpReceiver.prototype)) return;
	let n = e.RTCPeerConnection.prototype.getStats;
	e.RTCPeerConnection.prototype.getStats = function() {
		if (arguments.length > 0 && arguments[0] instanceof e.MediaStreamTrack) {
			let e = arguments[0], t, n, r;
			return this.getSenders().forEach((n) => {
				n.track === e && (t ? r = !0 : t = n);
			}), this.getReceivers().forEach((t) => (t.track === e && (n ? r = !0 : n = t), t.track === e)), r || t && n ? Promise.reject(new DOMException("There are more than one sender or receiver for the track.", "InvalidAccessError")) : t ? t.getStats() : n ? n.getStats() : Promise.reject(new DOMException("There is no sender or receiver for the track.", "InvalidAccessError"));
		}
		return n.apply(this, arguments);
	};
}
function bs(e) {
	e.RTCPeerConnection.prototype.getLocalStreams = function() {
		return this._shimmedLocalStreams = this._shimmedLocalStreams || {}, Object.keys(this._shimmedLocalStreams).map((e) => this._shimmedLocalStreams[e][0]);
	};
	let t = e.RTCPeerConnection.prototype.addTrack;
	e.RTCPeerConnection.prototype.addTrack = function(e, n) {
		if (!n) return t.apply(this, arguments);
		this._shimmedLocalStreams = this._shimmedLocalStreams || {};
		let r = t.apply(this, arguments);
		return this._shimmedLocalStreams[n.id] ? this._shimmedLocalStreams[n.id].indexOf(r) === -1 && this._shimmedLocalStreams[n.id].push(r) : this._shimmedLocalStreams[n.id] = [n, r], r;
	};
	let n = e.RTCPeerConnection.prototype.addStream;
	e.RTCPeerConnection.prototype.addStream = function(e) {
		this._shimmedLocalStreams = this._shimmedLocalStreams || {}, e.getTracks().forEach((e) => {
			if (this.getSenders().find((t) => t.track === e)) throw new DOMException("Track already exists.", "InvalidAccessError");
		});
		let t = this.getSenders();
		n.apply(this, arguments);
		let r = this.getSenders().filter((e) => t.indexOf(e) === -1);
		this._shimmedLocalStreams[e.id] = [e].concat(r);
	};
	let r = e.RTCPeerConnection.prototype.removeStream;
	e.RTCPeerConnection.prototype.removeStream = function(e) {
		return this._shimmedLocalStreams = this._shimmedLocalStreams || {}, delete this._shimmedLocalStreams[e.id], r.apply(this, arguments);
	};
	let i = e.RTCPeerConnection.prototype.removeTrack;
	e.RTCPeerConnection.prototype.removeTrack = function(e) {
		return this._shimmedLocalStreams = this._shimmedLocalStreams || {}, e && Object.keys(this._shimmedLocalStreams).forEach((t) => {
			let n = this._shimmedLocalStreams[t].indexOf(e);
			n !== -1 && this._shimmedLocalStreams[t].splice(n, 1), this._shimmedLocalStreams[t].length === 1 && delete this._shimmedLocalStreams[t];
		}), i.apply(this, arguments);
	};
}
function xs(e, t) {
	if (!e.RTCPeerConnection) return;
	if (e.RTCPeerConnection.prototype.addTrack && t.version >= 65) return bs(e);
	let n = e.RTCPeerConnection.prototype.getLocalStreams;
	e.RTCPeerConnection.prototype.getLocalStreams = function() {
		let e = n.apply(this);
		return this._reverseStreams = this._reverseStreams || {}, e.map((e) => this._reverseStreams[e.id]);
	};
	let r = e.RTCPeerConnection.prototype.addStream;
	e.RTCPeerConnection.prototype.addStream = function(t) {
		if (this._streams = this._streams || {}, this._reverseStreams = this._reverseStreams || {}, t.getTracks().forEach((e) => {
			if (this.getSenders().find((t) => t.track === e)) throw new DOMException("Track already exists.", "InvalidAccessError");
		}), !this._reverseStreams[t.id]) {
			let n = new e.MediaStream(t.getTracks());
			this._streams[t.id] = n, this._reverseStreams[n.id] = t, t = n;
		}
		r.apply(this, [t]);
	};
	let i = e.RTCPeerConnection.prototype.removeStream;
	e.RTCPeerConnection.prototype.removeStream = function(e) {
		this._streams = this._streams || {}, this._reverseStreams = this._reverseStreams || {}, i.apply(this, [this._streams[e.id] || e]), delete this._reverseStreams[this._streams[e.id] ? this._streams[e.id].id : e.id], delete this._streams[e.id];
	}, e.RTCPeerConnection.prototype.addTrack = function(t, n) {
		if (this.signalingState === "closed") throw new DOMException("The RTCPeerConnection's signalingState is 'closed'.", "InvalidStateError");
		let r = [].slice.call(arguments, 1);
		if (r.length !== 1 || !r[0].getTracks().find((e) => e === t)) throw new DOMException("The adapter.js addTrack polyfill only supports a single  stream which is associated with the specified track.", "NotSupportedError");
		if (this.getSenders().find((e) => e.track === t)) throw new DOMException("Track already exists.", "InvalidAccessError");
		this._streams = this._streams || {}, this._reverseStreams = this._reverseStreams || {};
		let i = this._streams[n.id];
		if (i) i.addTrack(t), Promise.resolve().then(() => {
			this.dispatchEvent(new Event("negotiationneeded"));
		});
		else {
			let r = new e.MediaStream([t]);
			this._streams[n.id] = r, this._reverseStreams[r.id] = n, this.addStream(r);
		}
		return this.getSenders().find((e) => e.track === t);
	};
	function a(e, t) {
		let n = t.sdp;
		return Object.keys(e._reverseStreams || []).forEach((t) => {
			let r = e._reverseStreams[t], i = e._streams[r.id];
			n = n.replace(new RegExp(i.id, "g"), r.id);
		}), new RTCSessionDescription({
			type: t.type,
			sdp: n
		});
	}
	function o(e, t) {
		let n = t.sdp;
		return Object.keys(e._reverseStreams || []).forEach((t) => {
			let r = e._reverseStreams[t], i = e._streams[r.id];
			n = n.replace(new RegExp(r.id, "g"), i.id);
		}), new RTCSessionDescription({
			type: t.type,
			sdp: n
		});
	}
	["createOffer", "createAnswer"].forEach(function(t) {
		let n = e.RTCPeerConnection.prototype[t], r = { [t]() {
			let e = arguments;
			return arguments.length && typeof arguments[0] == "function" ? n.apply(this, [
				(t) => {
					let n = a(this, t);
					e[0].apply(null, [n]);
				},
				(t) => {
					e[1] && e[1].apply(null, t);
				},
				arguments[2]
			]) : n.apply(this, arguments).then((e) => a(this, e));
		} };
		e.RTCPeerConnection.prototype[t] = r[t];
	});
	let s = e.RTCPeerConnection.prototype.setLocalDescription;
	e.RTCPeerConnection.prototype.setLocalDescription = function() {
		return !arguments.length || !arguments[0].type || (arguments[0] = o(this, arguments[0])), s.apply(this, arguments);
	};
	let c = Object.getOwnPropertyDescriptor(e.RTCPeerConnection.prototype, "localDescription");
	Object.defineProperty(e.RTCPeerConnection.prototype, "localDescription", { get() {
		let e = c.get.apply(this);
		return e.type === "" ? e : a(this, e);
	} }), e.RTCPeerConnection.prototype.removeTrack = function(e) {
		if (this.signalingState === "closed") throw new DOMException("The RTCPeerConnection's signalingState is 'closed'.", "InvalidStateError");
		if (!e._pc) throw new DOMException("Argument 1 of RTCPeerConnection.removeTrack does not implement interface RTCRtpSender.", "TypeError");
		if (e._pc !== this) throw new DOMException("Sender was not created by this connection.", "InvalidAccessError");
		this._streams = this._streams || {};
		let t;
		Object.keys(this._streams).forEach((n) => {
			this._streams[n].getTracks().find((t) => e.track === t) && (t = this._streams[n]);
		}), t && (t.getTracks().length === 1 ? this.removeStream(this._reverseStreams[t.id]) : t.removeTrack(e.track), this.dispatchEvent(new Event("negotiationneeded")));
	};
}
function Ss(e, t) {
	!e.RTCPeerConnection && e.webkitRTCPeerConnection && (e.RTCPeerConnection = e.webkitRTCPeerConnection), e.RTCPeerConnection && t.version < 53 && [
		"setLocalDescription",
		"setRemoteDescription",
		"addIceCandidate"
	].forEach(function(t) {
		let n = e.RTCPeerConnection.prototype[t], r = { [t]() {
			return arguments[0] = new (t === "addIceCandidate" ? e.RTCIceCandidate : e.RTCSessionDescription)(arguments[0]), n.apply(this, arguments);
		} };
		e.RTCPeerConnection.prototype[t] = r[t];
	});
}
function Cs(e, t) {
	t.version > 102 || is(e, "negotiationneeded", (e) => {
		let n = e.target;
		if (!((t.version < 72 || n.getConfiguration && n.getConfiguration().sdpSemantics === "plan-b") && n.signalingState !== "stable")) return e;
	});
}
var ws = /*#__PURE__*/ Object.freeze({
	__proto__: null,
	fixNegotiationNeeded: Cs,
	shimAddTrackRemoveTrack: xs,
	shimAddTrackRemoveTrackWithNative: bs,
	shimGetSendersWithDtmf: vs,
	shimGetUserMedia: hs,
	shimMediaStream: gs,
	shimOnTrack: _s,
	shimPeerConnection: Ss,
	shimSenderReceiverGetStats: ys
});
function Ts(e, t) {
	let n = e && e.navigator, r = e && e.MediaStreamTrack;
	if (n.getUserMedia = function(e, t, r) {
		cs("navigator.getUserMedia", "navigator.mediaDevices.getUserMedia"), n.mediaDevices.getUserMedia(e).then(t, r);
	}, !(t.version > 55 && "autoGainControl" in n.mediaDevices.getSupportedConstraints())) {
		let e = function(e, t, n) {
			t in e && !(n in e) && (e[n] = e[t], delete e[t]);
		}, t = n.mediaDevices.getUserMedia.bind(n.mediaDevices);
		if (n.mediaDevices.getUserMedia = function(n) {
			return typeof n == "object" && typeof n.audio == "object" && (n = JSON.parse(JSON.stringify(n)), e(n.audio, "autoGainControl", "mozAutoGainControl"), e(n.audio, "noiseSuppression", "mozNoiseSuppression")), t(n);
		}, r && r.prototype.getSettings) {
			let t = r.prototype.getSettings;
			r.prototype.getSettings = function() {
				let n = t.apply(this, arguments);
				return e(n, "mozAutoGainControl", "autoGainControl"), e(n, "mozNoiseSuppression", "noiseSuppression"), n;
			};
		}
		if (r && r.prototype.applyConstraints) {
			let t = r.prototype.applyConstraints;
			r.prototype.applyConstraints = function(n) {
				return this.kind === "audio" && typeof n == "object" && (n = JSON.parse(JSON.stringify(n)), e(n, "autoGainControl", "mozAutoGainControl"), e(n, "noiseSuppression", "mozNoiseSuppression")), t.apply(this, [n]);
			};
		}
	}
}
function Es(e, t) {
	e.navigator.mediaDevices && "getDisplayMedia" in e.navigator.mediaDevices || e.navigator.mediaDevices && (e.navigator.mediaDevices.getDisplayMedia = function(n) {
		if (!(n && n.video)) {
			let e = new DOMException("getDisplayMedia without video constraints is undefined");
			return e.name = "NotFoundError", e.code = 8, Promise.reject(e);
		}
		return n.video === !0 ? n.video = { mediaSource: t } : n.video.mediaSource = t, e.navigator.mediaDevices.getUserMedia(n);
	});
}
function Ds(e) {
	typeof e == "object" && e.RTCTrackEvent && "receiver" in e.RTCTrackEvent.prototype && !("transceiver" in e.RTCTrackEvent.prototype) && Object.defineProperty(e.RTCTrackEvent.prototype, "transceiver", { get() {
		return { receiver: this.receiver };
	} });
}
function Os(e, t) {
	typeof e != "object" || !(e.RTCPeerConnection || e.mozRTCPeerConnection) || (!e.RTCPeerConnection && e.mozRTCPeerConnection && (e.RTCPeerConnection = e.mozRTCPeerConnection), t.version < 53 && [
		"setLocalDescription",
		"setRemoteDescription",
		"addIceCandidate"
	].forEach(function(t) {
		let n = e.RTCPeerConnection.prototype[t], r = { [t]() {
			return arguments[0] = new (t === "addIceCandidate" ? e.RTCIceCandidate : e.RTCSessionDescription)(arguments[0]), n.apply(this, arguments);
		} };
		e.RTCPeerConnection.prototype[t] = r[t];
	}));
}
function ks(e, t) {
	if (typeof e != "object" || !(e.RTCPeerConnection || e.mozRTCPeerConnection) || t.version >= 151) return;
	let n = {
		inboundrtp: "inbound-rtp",
		outboundrtp: "outbound-rtp",
		candidatepair: "candidate-pair",
		localcandidate: "local-candidate",
		remotecandidate: "remote-candidate"
	}, r = e.RTCPeerConnection.prototype.getStats;
	e.RTCPeerConnection.prototype.getStats = function() {
		let e = Array.prototype.slice.call(arguments), i = e[0], a = e[1], o = e[2];
		return this.signalingState === "closed" ? Promise.resolve(/* @__PURE__ */ new Map()) : r.apply(this, [i || null]).then((e) => {
			if (t.version < 53 && !a) try {
				e.forEach((e) => {
					e.type = n[e.type] || e.type;
				});
			} catch (t) {
				if (t.name !== "TypeError") throw t;
				e.forEach((t, r) => {
					e.set(r, Object.assign({}, t, { type: n[t.type] || t.type }));
				});
			}
			return e;
		}).then(a, o);
	};
}
function As(e) {
	if (!(typeof e == "object" && e.RTCPeerConnection && e.RTCRtpSender) || e.RTCRtpSender && "getStats" in e.RTCRtpSender.prototype) return;
	let t = e.RTCPeerConnection.prototype.getSenders;
	t && (e.RTCPeerConnection.prototype.getSenders = function() {
		let e = t.apply(this, []);
		return e.forEach((e) => e._pc = this), e;
	});
	let n = e.RTCPeerConnection.prototype.addTrack;
	n && (e.RTCPeerConnection.prototype.addTrack = function() {
		let e = n.apply(this, arguments);
		return e._pc = this, e;
	}), e.RTCRtpSender.prototype.getStats = function() {
		return this.track ? this._pc.getStats(this.track) : Promise.resolve(/* @__PURE__ */ new Map());
	};
}
function js(e) {
	if (!(typeof e == "object" && e.RTCPeerConnection && e.RTCRtpSender) || e.RTCRtpSender && "getStats" in e.RTCRtpReceiver.prototype) return;
	let t = e.RTCPeerConnection.prototype.getReceivers;
	t && (e.RTCPeerConnection.prototype.getReceivers = function() {
		let e = t.apply(this, []);
		return e.forEach((e) => e._pc = this), e;
	}), is(e, "track", (e) => (e.receiver._pc = e.srcElement, e)), e.RTCRtpReceiver.prototype.getStats = function() {
		return this._pc.getStats(this.track);
	};
}
function Ms(e) {
	!e.RTCPeerConnection || "removeStream" in e.RTCPeerConnection.prototype || (e.RTCPeerConnection.prototype.removeStream = function(e) {
		cs("removeStream", "removeTrack"), this.getSenders().forEach((t) => {
			t.track && e.getTracks().includes(t.track) && this.removeTrack(t);
		});
	});
}
function Ns(e) {
	e.DataChannel && !e.RTCDataChannel && (e.RTCDataChannel = e.DataChannel);
}
function Ps(e) {
	if (!(typeof e == "object" && e.RTCPeerConnection)) return;
	let t = e.RTCPeerConnection.prototype.addTransceiver;
	t && (e.RTCPeerConnection.prototype.addTransceiver = function() {
		this.setParametersPromises = [];
		let e = arguments[1] && arguments[1].sendEncodings;
		e === void 0 && (e = []), e = [...e];
		let n = e.length > 0;
		n && e.forEach((e) => {
			if ("rid" in e && !/^[a-z0-9]{0,16}$/i.test(e.rid)) throw TypeError("Invalid RID value provided.");
			if ("scaleResolutionDownBy" in e && !(parseFloat(e.scaleResolutionDownBy) >= 1)) throw RangeError("scale_resolution_down_by must be >= 1.0");
			if ("maxFramerate" in e && !(parseFloat(e.maxFramerate) >= 0)) throw RangeError("max_framerate must be >= 0.0");
		});
		let r = t.apply(this, arguments);
		if (n) {
			let t = r.sender, n = t.getParameters();
			(!("encodings" in n) || n.encodings.length === 1 && Object.keys(n.encodings[0]).length === 0) && (n.encodings = e, t.sendEncodings = e, this.setParametersPromises.push(t.setParameters(n).then(() => {
				delete t.sendEncodings;
			}).catch(() => {
				delete t.sendEncodings;
			})));
		}
		return r;
	});
}
function Fs(e) {
	if (!(typeof e == "object" && e.RTCRtpSender)) return;
	let t = e.RTCRtpSender.prototype.getParameters;
	t && (e.RTCRtpSender.prototype.getParameters = function() {
		let e = t.apply(this, arguments);
		return "encodings" in e || (e.encodings = [].concat(this.sendEncodings || [{}])), e;
	});
}
function Is(e) {
	if (!(typeof e == "object" && e.RTCPeerConnection)) return;
	let t = e.RTCPeerConnection.prototype.createOffer;
	e.RTCPeerConnection.prototype.createOffer = function() {
		return this.setParametersPromises && this.setParametersPromises.length ? Promise.all(this.setParametersPromises).then(() => t.apply(this, arguments)).finally(() => {
			this.setParametersPromises = [];
		}) : t.apply(this, arguments);
	};
}
function Ls(e) {
	if (!(typeof e == "object" && e.RTCPeerConnection)) return;
	let t = e.RTCPeerConnection.prototype.createAnswer;
	e.RTCPeerConnection.prototype.createAnswer = function() {
		return this.setParametersPromises && this.setParametersPromises.length ? Promise.all(this.setParametersPromises).then(() => t.apply(this, arguments)).finally(() => {
			this.setParametersPromises = [];
		}) : t.apply(this, arguments);
	};
}
var Rs = /*#__PURE__*/ Object.freeze({
	__proto__: null,
	shimAddTransceiver: Ps,
	shimCreateAnswer: Ls,
	shimCreateOffer: Is,
	shimGetDisplayMedia: Es,
	shimGetParameters: Fs,
	shimGetStats: ks,
	shimGetUserMedia: Ts,
	shimOnTrack: Ds,
	shimPeerConnection: Os,
	shimRTCDataChannel: Ns,
	shimReceiverGetStats: js,
	shimRemoveStream: Ms,
	shimSenderGetStats: As
});
function zs(e) {
	if (!(typeof e != "object" || !e.RTCPeerConnection)) {
		if ("getLocalStreams" in e.RTCPeerConnection.prototype || (e.RTCPeerConnection.prototype.getLocalStreams = function() {
			return this._localStreams ||= [], this._localStreams;
		}), !("addStream" in e.RTCPeerConnection.prototype)) {
			let t = e.RTCPeerConnection.prototype.addTrack;
			e.RTCPeerConnection.prototype.addStream = function(e) {
				this._localStreams ||= [], this._localStreams.includes(e) || this._localStreams.push(e), e.getAudioTracks().forEach((n) => t.call(this, n, e)), e.getVideoTracks().forEach((n) => t.call(this, n, e));
			}, e.RTCPeerConnection.prototype.addTrack = function(e) {
				var n = [...arguments].slice(1);
				return n && n.forEach((e) => {
					this._localStreams ? this._localStreams.includes(e) || this._localStreams.push(e) : this._localStreams = [e];
				}), t.apply(this, arguments);
			};
		}
		"removeStream" in e.RTCPeerConnection.prototype || (e.RTCPeerConnection.prototype.removeStream = function(e) {
			this._localStreams ||= [];
			let t = this._localStreams.indexOf(e);
			if (t === -1) return;
			this._localStreams.splice(t, 1);
			let n = e.getTracks();
			this.getSenders().forEach((e) => {
				n.includes(e.track) && this.removeTrack(e);
			});
		});
	}
}
function Bs(e) {
	if (!(typeof e != "object" || !e.RTCPeerConnection) && ("getRemoteStreams" in e.RTCPeerConnection.prototype || (e.RTCPeerConnection.prototype.getRemoteStreams = function() {
		return this._remoteStreams ? this._remoteStreams : [];
	}), !("onaddstream" in e.RTCPeerConnection.prototype))) {
		Object.defineProperty(e.RTCPeerConnection.prototype, "onaddstream", {
			get() {
				return this._onaddstream;
			},
			set(e) {
				this._onaddstream && (this.removeEventListener("addstream", this._onaddstream), this.removeEventListener("track", this._onaddstreampoly)), this.addEventListener("addstream", this._onaddstream = e), this.addEventListener("track", this._onaddstreampoly = (e) => {
					e.streams.forEach((e) => {
						if (this._remoteStreams ||= [], this._remoteStreams.includes(e)) return;
						this._remoteStreams.push(e);
						let t = new Event("addstream");
						t.stream = e, this.dispatchEvent(t);
					});
				});
			}
		});
		let t = e.RTCPeerConnection.prototype.setRemoteDescription;
		e.RTCPeerConnection.prototype.setRemoteDescription = function() {
			let e = this;
			return this._onaddstreampoly || this.addEventListener("track", this._onaddstreampoly = function(t) {
				t.streams.forEach((t) => {
					if (e._remoteStreams ||= [], e._remoteStreams.indexOf(t) >= 0) return;
					e._remoteStreams.push(t);
					let n = new Event("addstream");
					n.stream = t, e.dispatchEvent(n);
				});
			}), t.apply(e, arguments);
		};
	}
}
function Vs(e) {
	if (typeof e != "object" || !e.RTCPeerConnection) return;
	let t = e.RTCPeerConnection.prototype, n = t.createOffer, r = t.createAnswer, i = t.setLocalDescription, a = t.setRemoteDescription, o = t.addIceCandidate;
	t.createOffer = function(e, t) {
		let r = arguments.length >= 2 ? arguments[2] : arguments[0], i = n.apply(this, [r]);
		return t ? (i.then(e, t), Promise.resolve()) : i;
	}, t.createAnswer = function(e, t) {
		let n = arguments.length >= 2 ? arguments[2] : arguments[0], i = r.apply(this, [n]);
		return t ? (i.then(e, t), Promise.resolve()) : i;
	};
	let s = function(e, t, n) {
		let r = i.apply(this, [e]);
		return n ? (r.then(t, n), Promise.resolve()) : r;
	};
	t.setLocalDescription = s, s = function(e, t, n) {
		let r = a.apply(this, [e]);
		return n ? (r.then(t, n), Promise.resolve()) : r;
	}, t.setRemoteDescription = s, s = function(e, t, n) {
		let r = o.apply(this, [e]);
		return n ? (r.then(t, n), Promise.resolve()) : r;
	}, t.addIceCandidate = s;
}
function Hs(e) {
	let t = e && e.navigator;
	if (t.mediaDevices && t.mediaDevices.getUserMedia) {
		let e = t.mediaDevices, n = e.getUserMedia.bind(e);
		t.mediaDevices.getUserMedia = (e) => n(Us(e));
	}
	!t.getUserMedia && t.mediaDevices && t.mediaDevices.getUserMedia && (t.getUserMedia = function(e, n, r) {
		t.mediaDevices.getUserMedia(e).then(n, r);
	}.bind(t));
}
function Us(e) {
	return e && e.video !== void 0 ? Object.assign({}, e, { video: ds(e.video) }) : e;
}
function Ws(e) {
	if (!e.RTCPeerConnection) return;
	let t = e.RTCPeerConnection;
	e.RTCPeerConnection = function(e, n) {
		if (e && e.iceServers) {
			let t = [];
			for (let n = 0; n < e.iceServers.length; n++) {
				let r = e.iceServers[n];
				r.urls === void 0 && r.url ? (cs("RTCIceServer.url", "RTCIceServer.urls"), r = JSON.parse(JSON.stringify(r)), r.urls = r.url, delete r.url, t.push(r)) : t.push(e.iceServers[n]);
			}
			e.iceServers = t;
		}
		return new t(e, n);
	}, e.RTCPeerConnection.prototype = t.prototype, "generateCertificate" in t && Object.defineProperty(e.RTCPeerConnection, "generateCertificate", { get() {
		return t.generateCertificate;
	} });
}
function Gs(e) {
	typeof e == "object" && e.RTCTrackEvent && "receiver" in e.RTCTrackEvent.prototype && !("transceiver" in e.RTCTrackEvent.prototype) && Object.defineProperty(e.RTCTrackEvent.prototype, "transceiver", { get() {
		return { receiver: this.receiver };
	} });
}
function Ks(e) {
	let t = e.RTCPeerConnection.prototype.createOffer;
	e.RTCPeerConnection.prototype.createOffer = function(e) {
		if (e) {
			e.offerToReceiveAudio !== void 0 && (e.offerToReceiveAudio = !!e.offerToReceiveAudio);
			let t = this.getTransceivers().find((e) => e.receiver.track.kind === "audio");
			e.offerToReceiveAudio === !1 && t ? t.direction === "sendrecv" ? t.setDirection ? t.setDirection("sendonly") : t.direction = "sendonly" : t.direction === "recvonly" && (t.setDirection ? t.setDirection("inactive") : t.direction = "inactive") : e.offerToReceiveAudio === !0 && !t && this.addTransceiver("audio", { direction: "recvonly" }), e.offerToReceiveVideo !== void 0 && (e.offerToReceiveVideo = !!e.offerToReceiveVideo);
			let n = this.getTransceivers().find((e) => e.receiver.track.kind === "video");
			e.offerToReceiveVideo === !1 && n ? n.direction === "sendrecv" ? n.setDirection ? n.setDirection("sendonly") : n.direction = "sendonly" : n.direction === "recvonly" && (n.setDirection ? n.setDirection("inactive") : n.direction = "inactive") : e.offerToReceiveVideo === !0 && !n && this.addTransceiver("video", { direction: "recvonly" });
		}
		return t.apply(this, arguments);
	};
}
function qs(e) {
	typeof e != "object" || e.AudioContext || (e.AudioContext = e.webkitAudioContext);
}
var Js = /*#__PURE__*/ Object.freeze({
	__proto__: null,
	shimAudioContext: qs,
	shimCallbacksAPI: Vs,
	shimConstraints: Us,
	shimCreateOfferLegacy: Ks,
	shimGetUserMedia: Hs,
	shimLocalStreamsAPI: zs,
	shimRTCIceServerUrls: Ws,
	shimRemoteStreamsAPI: Bs,
	shimTrackEventTransceiver: Gs
}), Ys = { exports: {} }, Xs;
function Zs() {
	return Xs ? Ys.exports : (Xs = 1, (function(e) {
		let t = {};
		t.generateIdentifier = function() {
			return Math.random().toString(36).substring(2, 12);
		}, t.localCName = t.generateIdentifier(), t.splitLines = function(e) {
			return e.trim().split("\n").map((e) => e.trim());
		}, t.splitSections = function(e) {
			return e.split("\nm=").map((e, t) => (t > 0 ? "m=" + e : e).trim() + "\r\n");
		}, t.getDescription = function(e) {
			let n = t.splitSections(e);
			return n && n[0];
		}, t.getMediaSections = function(e) {
			let n = t.splitSections(e);
			return n.shift(), n;
		}, t.matchPrefix = function(e, n) {
			return t.splitLines(e).filter((e) => e.indexOf(n) === 0);
		}, t.parseCandidate = function(e) {
			let t;
			t = e.indexOf("a=candidate:") === 0 ? e.substring(12).split(" ") : e.substring(10).split(" ");
			let n = {
				foundation: t[0],
				component: {
					1: "rtp",
					2: "rtcp"
				}[t[1]] || t[1],
				protocol: t[2].toLowerCase(),
				priority: parseInt(t[3], 10),
				ip: t[4],
				address: t[4],
				port: parseInt(t[5], 10),
				type: t[7]
			};
			for (let e = 8; e < t.length; e += 2) switch (t[e]) {
				case "raddr":
					n.relatedAddress = t[e + 1];
					break;
				case "rport":
					n.relatedPort = parseInt(t[e + 1], 10);
					break;
				case "tcptype":
					n.tcpType = t[e + 1];
					break;
				case "ufrag":
					n.ufrag = t[e + 1], n.usernameFragment = t[e + 1];
					break;
				default:
					n[t[e]] === void 0 && (n[t[e]] = t[e + 1]);
					break;
			}
			return n;
		}, t.writeCandidate = function(e) {
			let t = [];
			t.push(e.foundation);
			let n = e.component;
			n === "rtp" ? t.push(1) : n === "rtcp" ? t.push(2) : t.push(n), t.push(e.protocol.toUpperCase()), t.push(e.priority), t.push(e.address || e.ip), t.push(e.port);
			let r = e.type;
			return t.push("typ"), t.push(r), r !== "host" && e.relatedAddress && e.relatedPort !== void 0 && (t.push("raddr"), t.push(e.relatedAddress), t.push("rport"), t.push(e.relatedPort)), e.tcpType && e.protocol.toLowerCase() === "tcp" && (t.push("tcptype"), t.push(e.tcpType)), (e.usernameFragment || e.ufrag) && (t.push("ufrag"), t.push(e.usernameFragment || e.ufrag)), "candidate:" + t.join(" ");
		}, t.parseIceOptions = function(e) {
			return e.substring(14).split(" ");
		}, t.parseRtpMap = function(e) {
			let t = e.substring(9).split(" "), n = { payloadType: parseInt(t.shift(), 10) };
			return t = t[0].split("/"), n.name = t[0], n.clockRate = parseInt(t[1], 10), n.channels = t.length === 3 ? parseInt(t[2], 10) : 1, n.numChannels = n.channels, n;
		}, t.writeRtpMap = function(e) {
			let t = e.payloadType;
			e.preferredPayloadType !== void 0 && (t = e.preferredPayloadType);
			let n = e.channels || e.numChannels || 1;
			return "a=rtpmap:" + t + " " + e.name + "/" + e.clockRate + (n === 1 ? "" : "/" + n) + "\r\n";
		}, t.parseExtmap = function(e) {
			let t = e.substring(9).split(" ");
			return {
				id: parseInt(t[0], 10),
				direction: t[0].indexOf("/") > 0 ? t[0].split("/")[1] : "sendrecv",
				uri: t[1],
				attributes: t.slice(2).join(" ")
			};
		}, t.writeExtmap = function(e) {
			return "a=extmap:" + (e.id || e.preferredId) + (e.direction && e.direction !== "sendrecv" ? "/" + e.direction : "") + " " + e.uri + (e.attributes ? " " + e.attributes : "") + "\r\n";
		}, t.parseFmtp = function(e) {
			let t = {}, n, r = e.substring(e.indexOf(" ") + 1).split(";");
			for (let e = 0; e < r.length; e++) n = r[e].trim().split("="), t[n[0].trim()] = n[1];
			return t;
		}, t.writeFmtp = function(e) {
			let t = "", n = e.payloadType;
			if (e.preferredPayloadType !== void 0 && (n = e.preferredPayloadType), e.parameters && Object.keys(e.parameters).length) {
				let r = [];
				Object.keys(e.parameters).forEach((t) => {
					e.parameters[t] === void 0 ? r.push(t) : r.push(t + "=" + e.parameters[t]);
				}), t += "a=fmtp:" + n + " " + r.join(";") + "\r\n";
			}
			return t;
		}, t.parseRtcpFb = function(e) {
			let t = e.substring(e.indexOf(" ") + 1).split(" ");
			return {
				type: t.shift(),
				parameter: t.join(" ")
			};
		}, t.writeRtcpFb = function(e) {
			let t = "", n = e.payloadType;
			return e.preferredPayloadType !== void 0 && (n = e.preferredPayloadType), e.rtcpFeedback && e.rtcpFeedback.length && e.rtcpFeedback.forEach((e) => {
				t += "a=rtcp-fb:" + n + " " + e.type + (e.parameter && e.parameter.length ? " " + e.parameter : "") + "\r\n";
			}), t;
		}, t.parseSsrcMedia = function(e) {
			let t = e.indexOf(" "), n = { ssrc: parseInt(e.substring(7, t), 10) }, r = e.indexOf(":", t);
			return r > -1 ? (n.attribute = e.substring(t + 1, r), n.value = e.substring(r + 1)) : n.attribute = e.substring(t + 1), n;
		}, t.parseSsrcGroup = function(e) {
			let t = e.substring(13).split(" ");
			return {
				semantics: t.shift(),
				ssrcs: t.map((e) => parseInt(e, 10))
			};
		}, t.getMid = function(e) {
			let n = t.matchPrefix(e, "a=mid:")[0];
			if (n) return n.substring(6);
		}, t.parseFingerprint = function(e) {
			let t = e.substring(14).split(" ");
			return {
				algorithm: t[0].toLowerCase(),
				value: t[1].toUpperCase()
			};
		}, t.getDtlsParameters = function(e, n) {
			return {
				role: "auto",
				fingerprints: t.matchPrefix(e + n, "a=fingerprint:").map(t.parseFingerprint)
			};
		}, t.writeDtlsParameters = function(e, t) {
			let n = "a=setup:" + t + "\r\n";
			return e.fingerprints.forEach((e) => {
				n += "a=fingerprint:" + e.algorithm + " " + e.value + "\r\n";
			}), n;
		}, t.parseCryptoLine = function(e) {
			let t = e.substring(9).split(" ");
			return {
				tag: parseInt(t[0], 10),
				cryptoSuite: t[1],
				keyParams: t[2],
				sessionParams: t.slice(3)
			};
		}, t.writeCryptoLine = function(e) {
			return "a=crypto:" + e.tag + " " + e.cryptoSuite + " " + (typeof e.keyParams == "object" ? t.writeCryptoKeyParams(e.keyParams) : e.keyParams) + (e.sessionParams ? " " + e.sessionParams.join(" ") : "") + "\r\n";
		}, t.parseCryptoKeyParams = function(e) {
			if (e.indexOf("inline:") !== 0) return null;
			let t = e.substring(7).split("|");
			return {
				keyMethod: "inline",
				keySalt: t[0],
				lifeTime: t[1],
				mkiValue: t[2] ? t[2].split(":")[0] : void 0,
				mkiLength: t[2] ? t[2].split(":")[1] : void 0
			};
		}, t.writeCryptoKeyParams = function(e) {
			return e.keyMethod + ":" + e.keySalt + (e.lifeTime ? "|" + e.lifeTime : "") + (e.mkiValue && e.mkiLength ? "|" + e.mkiValue + ":" + e.mkiLength : "");
		}, t.getCryptoParameters = function(e, n) {
			return t.matchPrefix(e + n, "a=crypto:").map(t.parseCryptoLine);
		}, t.getIceParameters = function(e, n) {
			let r = t.matchPrefix(e + n, "a=ice-ufrag:")[0], i = t.matchPrefix(e + n, "a=ice-pwd:")[0];
			return r && i ? {
				usernameFragment: r.substring(12),
				password: i.substring(10)
			} : null;
		}, t.writeIceParameters = function(e) {
			let t = "a=ice-ufrag:" + e.usernameFragment + "\r\na=ice-pwd:" + e.password + "\r\n";
			return e.iceLite && (t += "a=ice-lite\r\n"), t;
		}, t.parseRtpParameters = function(e) {
			let n = {
				codecs: [],
				headerExtensions: [],
				fecMechanisms: [],
				rtcp: []
			}, r = t.splitLines(e)[0].split(" ");
			n.profile = r[2];
			for (let i = 3; i < r.length; i++) {
				let a = r[i], o = t.matchPrefix(e, "a=rtpmap:" + a + " ")[0];
				if (o) {
					let r = t.parseRtpMap(o), i = t.matchPrefix(e, "a=fmtp:" + a + " ");
					switch (r.parameters = i.length ? t.parseFmtp(i[0]) : {}, r.rtcpFeedback = t.matchPrefix(e, "a=rtcp-fb:" + a + " ").map(t.parseRtcpFb), n.codecs.push(r), r.name.toUpperCase()) {
						case "RED":
						case "ULPFEC":
							n.fecMechanisms.push(r.name.toUpperCase());
							break;
					}
				}
			}
			t.matchPrefix(e, "a=extmap:").forEach((e) => {
				n.headerExtensions.push(t.parseExtmap(e));
			});
			let i = t.matchPrefix(e, "a=rtcp-fb:* ").map(t.parseRtcpFb);
			return n.codecs.forEach((e) => {
				i.forEach((t) => {
					e.rtcpFeedback.find((e) => e.type === t.type && e.parameter === t.parameter) || e.rtcpFeedback.push(t);
				});
			}), n;
		}, t.writeRtpDescription = function(e, n) {
			let r = "";
			r += "m=" + e + " ", r += n.codecs.length > 0 ? "9" : "0", r += " " + (n.profile || "UDP/TLS/RTP/SAVPF") + " ", r += n.codecs.map((e) => e.preferredPayloadType === void 0 ? e.payloadType : e.preferredPayloadType).join(" ") + "\r\n", r += "c=IN IP4 0.0.0.0\r\n", r += "a=rtcp:9 IN IP4 0.0.0.0\r\n", n.codecs.forEach((e) => {
				r += t.writeRtpMap(e), r += t.writeFmtp(e), r += t.writeRtcpFb(e);
			});
			let i = 0;
			return n.codecs.forEach((e) => {
				e.maxptime > i && (i = e.maxptime);
			}), i > 0 && (r += "a=maxptime:" + i + "\r\n"), n.headerExtensions && n.headerExtensions.forEach((e) => {
				r += t.writeExtmap(e);
			}), r;
		}, t.parseRtpEncodingParameters = function(e) {
			let n = [], r = t.parseRtpParameters(e), i = r.fecMechanisms.indexOf("RED") !== -1, a = r.fecMechanisms.indexOf("ULPFEC") !== -1, o = t.matchPrefix(e, "a=ssrc:").map((e) => t.parseSsrcMedia(e)).filter((e) => e.attribute === "cname"), s = o.length > 0 && o[0].ssrc, c, l = t.matchPrefix(e, "a=ssrc-group:FID").map((e) => e.substring(17).split(" ").map((e) => parseInt(e, 10)));
			l.length > 0 && l[0].length > 1 && l[0][0] === s && (c = l[0][1]), r.codecs.forEach((e) => {
				if (e.name.toUpperCase() === "RTX" && e.parameters.apt) {
					let t = {
						ssrc: s,
						codecPayloadType: parseInt(e.parameters.apt, 10)
					};
					s && c && (t.rtx = { ssrc: c }), n.push(t), i && (t = JSON.parse(JSON.stringify(t)), t.fec = {
						ssrc: s,
						mechanism: a ? "red+ulpfec" : "red"
					}, n.push(t));
				}
			}), n.length === 0 && s && n.push({ ssrc: s });
			let u = t.matchPrefix(e, "b=");
			return u.length && (u = u[0].indexOf("b=TIAS:") === 0 ? parseInt(u[0].substring(7), 10) : u[0].indexOf("b=AS:") === 0 ? parseInt(u[0].substring(5), 10) * 1e3 * .95 - 2e3 * 8 : void 0, n.forEach((e) => {
				e.maxBitrate = u;
			})), n;
		}, t.parseRtcpParameters = function(e) {
			let n = {}, r = t.matchPrefix(e, "a=ssrc:").map((e) => t.parseSsrcMedia(e)).filter((e) => e.attribute === "cname")[0];
			r && (n.cname = r.value, n.ssrc = r.ssrc);
			let i = t.matchPrefix(e, "a=rtcp-rsize");
			return n.reducedSize = i.length > 0, n.compound = i.length === 0, n.mux = t.matchPrefix(e, "a=rtcp-mux").length > 0, n;
		}, t.writeRtcpParameters = function(e) {
			let t = "";
			return e.reducedSize && (t += "a=rtcp-rsize\r\n"), e.mux && (t += "a=rtcp-mux\r\n"), e.ssrc !== void 0 && e.cname && (t += "a=ssrc:" + e.ssrc + " cname:" + e.cname + "\r\n"), t;
		}, t.parseMsid = function(e) {
			let n, r = t.matchPrefix(e, "a=msid:");
			if (r.length === 1) return n = r[0].substring(7).split(" "), {
				stream: n[0],
				track: n[1]
			};
			let i = t.matchPrefix(e, "a=ssrc:").map((e) => t.parseSsrcMedia(e)).filter((e) => e.attribute === "msid");
			if (i.length > 0) return n = i[0].value.split(" "), {
				stream: n[0],
				track: n[1]
			};
		}, t.parseSctpDescription = function(e) {
			let n = t.parseMLine(e), r = t.matchPrefix(e, "a=max-message-size:"), i;
			r.length > 0 && (i = parseInt(r[0].substring(19), 10)), isNaN(i) && (i = 65536);
			let a = t.matchPrefix(e, "a=sctp-port:");
			if (a.length > 0) return {
				port: parseInt(a[0].substring(12), 10),
				protocol: n.fmt,
				maxMessageSize: i
			};
			let o = t.matchPrefix(e, "a=sctpmap:");
			if (o.length > 0) {
				let e = o[0].substring(10).split(" ");
				return {
					port: parseInt(e[0], 10),
					protocol: e[1],
					maxMessageSize: i
				};
			}
		}, t.writeSctpDescription = function(e, t) {
			let n = [];
			return n = e.protocol === "DTLS/SCTP" ? [
				"m=" + e.kind + " 9 " + e.protocol + " " + t.port + "\r\n",
				"c=IN IP4 0.0.0.0\r\n",
				"a=sctpmap:" + t.port + " " + t.protocol + " 65535\r\n"
			] : [
				"m=" + e.kind + " 9 " + e.protocol + " " + t.protocol + "\r\n",
				"c=IN IP4 0.0.0.0\r\n",
				"a=sctp-port:" + t.port + "\r\n"
			], t.maxMessageSize !== void 0 && n.push("a=max-message-size:" + t.maxMessageSize + "\r\n"), n.join("");
		}, t.generateSessionId = function() {
			return Math.random().toString().substr(2, 22);
		}, t.writeSessionBoilerplate = function(e, n, r) {
			let i, a = n === void 0 ? 2 : n;
			return i = e || t.generateSessionId(), "v=0\r\no=" + (r || "thisisadapterortc") + " " + i + " " + a + " IN IP4 127.0.0.1\r\ns=-\r\nt=0 0\r\n";
		}, t.getDirection = function(e, n) {
			let r = t.splitLines(e);
			for (let e = 0; e < r.length; e++) switch (r[e]) {
				case "a=sendrecv":
				case "a=sendonly":
				case "a=recvonly":
				case "a=inactive": return r[e].substring(2);
			}
			return n ? t.getDirection(n) : "sendrecv";
		}, t.getKind = function(e) {
			return t.splitLines(e)[0].split(" ")[0].substring(2);
		}, t.isRejected = function(e) {
			return e.split(" ", 2)[1] === "0";
		}, t.parseMLine = function(e) {
			let n = t.splitLines(e)[0].substring(2).split(" ");
			return {
				kind: n[0],
				port: parseInt(n[1], 10),
				protocol: n[2],
				fmt: n.slice(3).join(" ")
			};
		}, t.parseOLine = function(e) {
			let n = t.matchPrefix(e, "o=")[0].substring(2).split(" ");
			return {
				username: n[0],
				sessionId: n[1],
				sessionVersion: parseInt(n[2], 10),
				netType: n[3],
				addressType: n[4],
				address: n[5]
			};
		}, t.isValidSDP = function(e) {
			if (typeof e != "string" || e.length === 0) return !1;
			let n = t.splitLines(e);
			for (let e = 0; e < n.length; e++) if (n[e].length < 2 || n[e].charAt(1) !== "=") return !1;
			return !0;
		}, e.exports = t;
	})(Ys), Ys.exports);
}
var Qs = Zs(), $s = /*@__PURE__*/ ko(Qs), ec = /*#__PURE__*/ dn({
	__proto__: null,
	default: $s
}, [Qs]);
function tc(e) {
	if (!e.RTCIceCandidate || e.RTCIceCandidate && "foundation" in e.RTCIceCandidate.prototype) return;
	let t = e.RTCIceCandidate;
	e.RTCIceCandidate = function(e) {
		if (typeof e == "object" && e.candidate && e.candidate.indexOf("a=") === 0 && (e = JSON.parse(JSON.stringify(e)), e.candidate = e.candidate.substring(2)), e.candidate && e.candidate.length) {
			let n = new t(e), r = $s.parseCandidate(e.candidate);
			for (let e in r) e in n || Object.defineProperty(n, e, { value: r[e] });
			return n.toJSON = function() {
				return {
					candidate: n.candidate,
					sdpMid: n.sdpMid,
					sdpMLineIndex: n.sdpMLineIndex,
					usernameFragment: n.usernameFragment
				};
			}, n;
		}
		return new t(e);
	}, e.RTCIceCandidate.prototype = t.prototype, is(e, "icecandidate", (t) => (t.candidate && Object.defineProperty(t, "candidate", {
		value: new e.RTCIceCandidate(t.candidate),
		writable: "false"
	}), t));
}
function nc(e) {
	!e.RTCIceCandidate || e.RTCIceCandidate && "relayProtocol" in e.RTCIceCandidate.prototype || is(e, "icecandidate", (e) => {
		if (e.candidate) {
			let t = $s.parseCandidate(e.candidate.candidate);
			t.type === "relay" && (e.candidate.relayProtocol = {
				0: "tls",
				1: "tcp",
				2: "udp"
			}[t.priority >> 24]);
		}
		return e;
	});
}
function rc(e, t) {
	if (!e.RTCPeerConnection) return;
	"sctp" in e.RTCPeerConnection.prototype || Object.defineProperty(e.RTCPeerConnection.prototype, "sctp", { get() {
		return this._sctp === void 0 ? null : this._sctp;
	} });
	let n = function(e) {
		if (!e || !e.sdp) return !1;
		let t = $s.splitSections(e.sdp);
		return t.shift(), t.some((e) => {
			let t = $s.parseMLine(e);
			return t && t.kind === "application" && t.protocol.indexOf("SCTP") !== -1;
		});
	}, r = function(e) {
		let t = e.sdp.match(/mozilla...THIS_IS_SDPARTA-(\d+)/);
		if (t === null || t.length < 2) return -1;
		let n = parseInt(t[1], 10);
		return n === n ? n : -1;
	}, i = function(e) {
		let n = 65536;
		return t.browser === "firefox" && (n = t.version < 57 ? e === -1 ? 16384 : 2147483637 : t.version < 60 ? t.version === 57 ? 65535 : 65536 : 2147483637), n;
	}, a = function(e, n) {
		let r = 65536;
		t.browser === "firefox" && t.version === 57 && (r = 65535);
		let i = $s.matchPrefix(e.sdp, "a=max-message-size:");
		return i.length > 0 ? r = parseInt(i[0].substring(19), 10) : t.browser === "firefox" && n !== -1 && (r = 2147483637), r;
	}, o = e.RTCPeerConnection.prototype.setRemoteDescription;
	e.RTCPeerConnection.prototype.setRemoteDescription = function() {
		if (this._sctp = null, t.browser === "chrome" && t.version >= 76 && this.getConfiguration().sdpSemantics === "plan-b" && Object.defineProperty(this, "sctp", {
			get() {
				return this._sctp === void 0 ? null : this._sctp;
			},
			enumerable: !0,
			configurable: !0
		}), n(arguments[0])) {
			let e = r(arguments[0]), t = i(e), n = a(arguments[0], e), o;
			o = t === 0 && n === 0 ? Infinity : t === 0 || n === 0 ? Math.max(t, n) : Math.min(t, n);
			let s = {};
			Object.defineProperty(s, "maxMessageSize", { get() {
				return o;
			} }), this._sctp = s;
		}
		return o.apply(this, arguments);
	};
}
function ic(e, t) {
	if (!(e.RTCPeerConnection && "createDataChannel" in e.RTCPeerConnection.prototype) || t.browser === "chrome" && t.version > 149 || t.browser === "firefox" && t.version > 60) return;
	function n(e, t) {
		let n = e.send;
		e.send = function() {
			let r = arguments[0], i = r.length || r.size || r.byteLength;
			if (e.readyState === "open" && t.sctp && i > t.sctp.maxMessageSize) throw TypeError("Message too large (can send a maximum of " + t.sctp.maxMessageSize + " bytes)");
			return n.apply(e, arguments);
		};
	}
	let r = e.RTCPeerConnection.prototype.createDataChannel;
	e.RTCPeerConnection.prototype.createDataChannel = function() {
		let e = r.apply(this, arguments);
		return n(e, this), e;
	}, is(e, "datachannel", (e) => (n(e.channel, e.target), e));
}
function ac(e) {
	if (!e.RTCPeerConnection || "connectionState" in e.RTCPeerConnection.prototype) return;
	let t = e.RTCPeerConnection.prototype;
	Object.defineProperty(t, "connectionState", {
		get() {
			return {
				completed: "connected",
				checking: "connecting"
			}[this.iceConnectionState] || this.iceConnectionState;
		},
		enumerable: !0,
		configurable: !0
	}), Object.defineProperty(t, "onconnectionstatechange", {
		get() {
			return this._onconnectionstatechange || null;
		},
		set(e) {
			this._onconnectionstatechange && (this.removeEventListener("connectionstatechange", this._onconnectionstatechange), delete this._onconnectionstatechange), e && this.addEventListener("connectionstatechange", this._onconnectionstatechange = e);
		},
		enumerable: !0,
		configurable: !0
	}), ["setLocalDescription", "setRemoteDescription"].forEach((e) => {
		let n = t[e];
		t[e] = function() {
			return this._connectionstatechangepoly || (this._connectionstatechangepoly = (e) => {
				let t = e.target;
				if (t._lastConnectionState !== t.connectionState) {
					t._lastConnectionState = t.connectionState;
					let n = new Event("connectionstatechange", e);
					t.dispatchEvent(n);
				}
				return e;
			}, this.addEventListener("iceconnectionstatechange", this._connectionstatechangepoly)), n.apply(this, arguments);
		};
	});
}
function oc(e, t) {
	if (!e.RTCPeerConnection || t.browser === "chrome" && t.version >= 71 || t.browser === "safari" && t._safariVersion >= 13.1) return;
	let n = e.RTCPeerConnection.prototype.setRemoteDescription;
	e.RTCPeerConnection.prototype.setRemoteDescription = function(t) {
		if (t && t.sdp && t.sdp.indexOf("\na=extmap-allow-mixed") !== -1) {
			let n = t.sdp.split("\n").filter((e) => e.trim() !== "a=extmap-allow-mixed").join("\n");
			e.RTCSessionDescription && t instanceof e.RTCSessionDescription ? arguments[0] = new e.RTCSessionDescription({
				type: t.type,
				sdp: n
			}) : t.sdp = n;
		}
		return n.apply(this, arguments);
	};
}
function sc(e, t) {
	if (!(e.RTCPeerConnection && e.RTCPeerConnection.prototype)) return;
	let n = e.RTCPeerConnection.prototype.addIceCandidate;
	!n || n.length === 0 || (e.RTCPeerConnection.prototype.addIceCandidate = function() {
		return arguments[0] ? (t.browser === "chrome" && t.version < 78 || t.browser === "firefox" && t.version < 68 || t.browser === "safari") && arguments[0] && arguments[0].candidate === "" ? Promise.resolve() : n.apply(this, arguments) : (arguments[1] && arguments[1].apply(null), Promise.resolve());
	});
}
function cc(e, t) {
	if (!(e.RTCPeerConnection && e.RTCPeerConnection.prototype)) return;
	let n = e.RTCPeerConnection.prototype.setLocalDescription;
	!n || n.length === 0 || (e.RTCPeerConnection.prototype.setLocalDescription = function() {
		let e = arguments[0] || {};
		if (typeof e != "object" || e.type && e.sdp) return n.apply(this, arguments);
		if (e = {
			type: e.type,
			sdp: e.sdp
		}, !e.type) switch (this.signalingState) {
			case "stable":
			case "have-local-offer":
			case "have-remote-pranswer":
				e.type = "offer";
				break;
			default:
				e.type = "answer";
				break;
		}
		return e.sdp || e.type !== "offer" && e.type !== "answer" ? n.apply(this, [e]) : (e.type === "offer" ? this.createOffer : this.createAnswer).apply(this).then((e) => n.apply(this, [e]));
	});
}
var lc = /*#__PURE__*/ Object.freeze({
	__proto__: null,
	removeExtmapAllowMixed: oc,
	shimAddIceCandidateNullOrEmpty: sc,
	shimConnectionState: ac,
	shimMaxMessageSize: rc,
	shimParameterlessSetLocalDescription: cc,
	shimRTCIceCandidate: tc,
	shimRTCIceCandidateRelayProtocol: nc,
	shimSendThrowTypeError: ic
});
function uc() {
	let e = (arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {}).window, t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {
		shimChrome: !0,
		shimFirefox: !0,
		shimSafari: !0
	}, n = ss, r = ls(e), i = {
		browserDetails: r,
		commonShim: lc,
		extractVersion: rs,
		disableLog: as,
		disableWarnings: os,
		sdp: ec
	};
	switch (r.browser) {
		case "chrome":
			if (!ws || !Ss || !t.shimChrome) return n("Chrome shim is not included in this adapter release."), i;
			if (r.version === null) return n("Chrome shim can not determine version, not shimming."), i;
			n("adapter.js shimming chrome."), i.browserShim = ws, sc(e, r), cc(e), hs(e, r), gs(e), Ss(e, r), _s(e, r), xs(e, r), vs(e), ys(e, r), Cs(e, r), tc(e), nc(e), ac(e), rc(e, r), ic(e, r), oc(e, r);
			break;
		case "firefox":
			if (!Rs || !Os || !t.shimFirefox) return n("Firefox shim is not included in this adapter release."), i;
			n("adapter.js shimming firefox."), i.browserShim = Rs, sc(e, r), cc(e), Ts(e, r), Os(e, r), ks(e, r), Ds(e), Ms(e), As(e), js(e), Ns(e), Ps(e), Fs(e), Is(e), Ls(e), tc(e), ac(e), rc(e, r), ic(e, r);
			break;
		case "safari":
			if (!Js || !t.shimSafari) return n("Safari shim is not included in this adapter release."), i;
			n("adapter.js shimming safari."), i.browserShim = Js, sc(e, r), cc(e), Ws(e), Ks(e), Vs(e), zs(e), Bs(e), Gs(e), Hs(e), qs(e), tc(e), nc(e), rc(e, r), ic(e, r), oc(e, r);
			break;
		default:
			n("Unsupported browser!");
			break;
	}
	return i;
}
uc({ window: typeof window > "u" ? void 0 : window });
var dc, fc, pc = class extends (fc = Promise) {
	constructor(e) {
		super(e);
	}
	catch(e) {
		return super.catch(e);
	}
	static reject(e) {
		return super.reject(e);
	}
	static all(e) {
		return super.all(e);
	}
	static race(e) {
		return super.race(e);
	}
};
dc = pc, pc.resolve = (e) => Reflect.get(fc, "resolve", dc).call(dc, e);
var mc = /version\/(\d+(\.?_?\d+)+)/i, hc;
function gc(e) {
	let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !0;
	if (e === void 0 && typeof navigator > "u") return;
	let n = (e ?? navigator.userAgent).toLowerCase();
	return (hc === void 0 || t) && (hc = _c.find((e) => e.test.test(n))?.describe(n)), hc;
}
var _c = [
	{
		test: /firefox|iceweasel|fxios/i,
		describe(e) {
			return {
				name: "Firefox",
				version: vc(/(?:firefox|iceweasel|fxios)[\s/](\d+(\.?_?\d+)+)/i, e),
				os: e.toLowerCase().includes("fxios") ? "iOS" : void 0,
				osVersion: yc(e)
			};
		}
	},
	{
		test: /chrom|crios|crmo/i,
		describe(e) {
			return {
				name: "Chrome",
				version: vc(/(?:chrome|chromium|crios|crmo)\/(\d+(\.?_?\d+)+)/i, e),
				os: e.toLowerCase().includes("crios") ? "iOS" : void 0,
				osVersion: yc(e)
			};
		}
	},
	{
		test: /safari|applewebkit/i,
		describe(e) {
			return {
				name: "Safari",
				version: vc(mc, e),
				os: e.includes("mobile/") ? "iOS" : "macOS",
				osVersion: yc(e)
			};
		}
	}
];
function vc(e, t) {
	let n = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : 1, r = t.match(e);
	return r && r.length >= n && r[n] || "";
}
function yc(e) {
	return e.includes("mac os") ? vc(/\(.+?(\d+_\d+(:?_\d+)?)/, e, 1).replace(/_/g, ".") : void 0;
}
var bc = "2.19.2", xc = class extends Error {
	constructor(e, t, n) {
		super(t || "an error has occurred"), this.name = "LiveKitError", this.code = e, n?.cause !== void 0 && (this.cause = n?.cause);
	}
}, Sc = class extends xc {}, M;
(function(e) {
	e[e.NotAllowed = 0] = "NotAllowed", e[e.ServerUnreachable = 1] = "ServerUnreachable", e[e.InternalError = 2] = "InternalError", e[e.Cancelled = 3] = "Cancelled", e[e.LeaveRequest = 4] = "LeaveRequest", e[e.Timeout = 5] = "Timeout", e[e.WebSocket = 6] = "WebSocket", e[e.ServiceNotFound = 7] = "ServiceNotFound";
})(M ||= {});
var N = class e extends Sc {
	constructor(e, t, n, r) {
		super(1, e), this.name = "ConnectionError", this.status = n, this.reason = t, this.context = r, this.reasonName = M[t];
	}
	static notAllowed(t, n, r) {
		return new e(t, M.NotAllowed, n, r);
	}
	static timeout(t) {
		return new e(t, M.Timeout);
	}
	static leaveRequest(t, n) {
		return new e(t, M.LeaveRequest, void 0, n);
	}
	static internal(t, n) {
		return new e(t, M.InternalError, void 0, n);
	}
	static cancelled(t) {
		return new e(t, M.Cancelled);
	}
	static serverUnreachable(t, n) {
		return new e(t, M.ServerUnreachable, n);
	}
	static websocket(t, n, r) {
		return new e(t, M.WebSocket, n, r);
	}
	static serviceNotFound(t, n) {
		return new e(t, M.ServiceNotFound, void 0, n);
	}
}, Cc = class extends xc {
	constructor(e) {
		super(21, e ?? "device is unsupported"), this.name = "DeviceUnsupportedError";
	}
}, wc = class extends xc {
	constructor(e) {
		super(20, e ?? "track is invalid"), this.name = "TrackInvalidError";
	}
}, Tc = class extends xc {
	constructor(e) {
		super(10, e ?? "unsupported server"), this.name = "UnsupportedServer";
	}
}, P = class extends xc {
	constructor(e) {
		super(12, e ?? "unexpected connection state"), this.name = "UnexpectedConnectionState";
	}
}, Ec = class extends xc {
	constructor(e) {
		super(13, e ?? "unable to negotiate"), this.name = "NegotiationError";
	}
}, Dc = class extends xc {
	constructor(e, t) {
		super(15, e), this.name = "PublishTrackError", this.status = t;
	}
}, Oc = class extends Sc {
	constructor(e, t) {
		super(15, e), this.name = "SignalRequestError", this.reason = t, this.reasonName = typeof t == "string" ? t : So[t];
	}
}, kc;
(function(e) {
	e[e.AlreadyOpened = 0] = "AlreadyOpened", e[e.AbnormalEnd = 1] = "AbnormalEnd", e[e.DecodeFailed = 2] = "DecodeFailed", e[e.LengthExceeded = 3] = "LengthExceeded", e[e.Incomplete = 4] = "Incomplete", e[e.HandlerAlreadyRegistered = 7] = "HandlerAlreadyRegistered", e[e.EncryptionTypeMismatch = 8] = "EncryptionTypeMismatch";
})(kc ||= {});
var Ac = class extends Sc {
	constructor(e, t) {
		super(16, e), this.name = "DataStreamError", this.reason = t, this.reasonName = kc[t];
	}
}, jc = class extends xc {
	constructor(e) {
		super(18, e), this.name = "SignalReconnectError";
	}
}, Mc;
(function(e) {
	e.PermissionDenied = "PermissionDenied", e.NotFound = "NotFound", e.DeviceInUse = "DeviceInUse", e.Other = "Other";
})(Mc ||= {}), (function(e) {
	function t(t) {
		if (t && "name" in t) return t.name === "NotFoundError" || t.name === "DevicesNotFoundError" ? e.NotFound : t.name === "NotAllowedError" || t.name === "PermissionDeniedError" ? e.PermissionDenied : t.name === "NotReadableError" || t.name === "TrackStartError" ? e.DeviceInUse : e.Other;
	}
	e.getFailure = t;
})(Mc ||= {});
var F = class {};
F.setTimeout = function() {
	return setTimeout(...arguments);
}, F.setInterval = function() {
	return setInterval(...arguments);
}, F.clearTimeout = function() {
	return clearTimeout(...arguments);
}, F.clearInterval = function() {
	return clearInterval(...arguments);
};
var I;
(function(e) {
	e.Connected = "connected", e.Reconnecting = "reconnecting", e.SignalReconnecting = "signalReconnecting", e.Reconnected = "reconnected", e.Disconnected = "disconnected", e.ConnectionStateChanged = "connectionStateChanged", e.Moved = "moved", e.MediaDevicesChanged = "mediaDevicesChanged", e.ParticipantConnected = "participantConnected", e.ParticipantDisconnected = "participantDisconnected", e.TrackPublished = "trackPublished", e.TrackSubscribed = "trackSubscribed", e.TrackSubscriptionFailed = "trackSubscriptionFailed", e.TrackUnpublished = "trackUnpublished", e.TrackUnsubscribed = "trackUnsubscribed", e.TrackMuted = "trackMuted", e.TrackUnmuted = "trackUnmuted", e.LocalTrackPublished = "localTrackPublished", e.LocalTrackUnpublished = "localTrackUnpublished", e.LocalAudioSilenceDetected = "localAudioSilenceDetected", e.ActiveSpeakersChanged = "activeSpeakersChanged", e.ParticipantMetadataChanged = "participantMetadataChanged", e.ParticipantNameChanged = "participantNameChanged", e.ParticipantAttributesChanged = "participantAttributesChanged", e.ParticipantActive = "participantActive", e.RoomMetadataChanged = "roomMetadataChanged", e.DataReceived = "dataReceived", e.SipDTMFReceived = "sipDTMFReceived", e.TranscriptionReceived = "transcriptionReceived", e.ConnectionQualityChanged = "connectionQualityChanged", e.TrackStreamStateChanged = "trackStreamStateChanged", e.TrackSubscriptionPermissionChanged = "trackSubscriptionPermissionChanged", e.TrackSubscriptionStatusChanged = "trackSubscriptionStatusChanged", e.AudioPlaybackStatusChanged = "audioPlaybackChanged", e.VideoPlaybackStatusChanged = "videoPlaybackChanged", e.MediaDevicesError = "mediaDevicesError", e.ParticipantPermissionsChanged = "participantPermissionsChanged", e.SignalConnected = "signalConnected", e.RecordingStatusChanged = "recordingStatusChanged", e.ParticipantEncryptionStatusChanged = "participantEncryptionStatusChanged", e.EncryptionError = "encryptionError", e.DCBufferStatusChanged = "dcBufferStatusChanged", e.ActiveDeviceChanged = "activeDeviceChanged", e.ChatMessage = "chatMessage", e.LocalTrackSubscribed = "localTrackSubscribed", e.MetricsReceived = "metricsReceived", e.DataTrackPublished = "dataTrackPublished", e.DataTrackUnpublished = "dataTrackUnpublished", e.LocalDataTrackPublished = "localDataTrackPublished", e.LocalDataTrackUnpublished = "localDataTrackUnpublished";
})(I ||= {});
var L;
(function(e) {
	e.TrackPublished = "trackPublished", e.TrackSubscribed = "trackSubscribed", e.TrackSubscriptionFailed = "trackSubscriptionFailed", e.TrackUnpublished = "trackUnpublished", e.TrackUnsubscribed = "trackUnsubscribed", e.TrackMuted = "trackMuted", e.TrackUnmuted = "trackUnmuted", e.LocalTrackPublished = "localTrackPublished", e.LocalTrackUnpublished = "localTrackUnpublished", e.LocalTrackCpuConstrained = "localTrackCpuConstrained", e.LocalSenderCreated = "localSenderCreated", e.ParticipantMetadataChanged = "participantMetadataChanged", e.ParticipantNameChanged = "participantNameChanged", e.DataReceived = "dataReceived", e.SipDTMFReceived = "sipDTMFReceived", e.TranscriptionReceived = "transcriptionReceived", e.IsSpeakingChanged = "isSpeakingChanged", e.ConnectionQualityChanged = "connectionQualityChanged", e.TrackStreamStateChanged = "trackStreamStateChanged", e.TrackSubscriptionPermissionChanged = "trackSubscriptionPermissionChanged", e.TrackSubscriptionStatusChanged = "trackSubscriptionStatusChanged", e.TrackCpuConstrained = "trackCpuConstrained", e.MediaDevicesError = "mediaDevicesError", e.AudioStreamAcquired = "audioStreamAcquired", e.ParticipantPermissionsChanged = "participantPermissionsChanged", e.PCTrackAdded = "pcTrackAdded", e.AttributesChanged = "attributesChanged", e.LocalTrackSubscribed = "localTrackSubscribed", e.ChatMessage = "chatMessage", e.Active = "active";
})(L ||= {});
var R;
(function(e) {
	e.TransportsCreated = "transportsCreated", e.Connected = "connected", e.Disconnected = "disconnected", e.Resuming = "resuming", e.Resumed = "resumed", e.Restarting = "restarting", e.Restarted = "restarted", e.SignalResumed = "signalResumed", e.SignalRestarted = "signalRestarted", e.Closing = "closing", e.MediaTrackAdded = "mediaTrackAdded", e.ActiveSpeakersUpdate = "activeSpeakersUpdate", e.DataPacketReceived = "dataPacketReceived", e.RTPVideoMapUpdate = "rtpVideoMapUpdate", e.DCBufferStatusChanged = "dcBufferStatusChanged", e.ParticipantUpdate = "participantUpdate", e.RoomUpdate = "roomUpdate", e.SpeakersChanged = "speakersChanged", e.StreamStateChanged = "streamStateChanged", e.ConnectionQualityUpdate = "connectionQualityUpdate", e.SubscriptionError = "subscriptionError", e.SubscriptionPermissionUpdate = "subscriptionPermissionUpdate", e.RemoteMute = "remoteMute", e.SubscribedQualityUpdate = "subscribedQualityUpdate", e.LocalTrackUnpublished = "localTrackUnpublished", e.LocalTrackSubscribed = "localTrackSubscribed", e.Offline = "offline", e.SignalRequestResponse = "signalRequestResponse", e.SignalConnected = "signalConnected", e.RoomMoved = "roomMoved", e.PublishDataTrackResponse = "publishDataTrackResponse", e.UnPublishDataTrackResponse = "unPublishDataTrackResponse", e.DataTrackSubscriberHandles = "dataTrackSubscriberHandles", e.DataTrackPacketReceived = "dataTrackPacketReceived", e.Joined = "joined", e.TokenRefreshed = "tokenRefreshed", e.ServerRegionsReported = "serverRegionsReported";
})(R ||= {});
var z;
(function(e) {
	e.Message = "message", e.Muted = "muted", e.Unmuted = "unmuted", e.Restarted = "restarted", e.Ended = "ended", e.Subscribed = "subscribed", e.Unsubscribed = "unsubscribed", e.CpuConstrained = "cpuConstrained", e.UpdateSettings = "updateSettings", e.UpdateSubscription = "updateSubscription", e.AudioPlaybackStarted = "audioPlaybackStarted", e.AudioPlaybackFailed = "audioPlaybackFailed", e.AudioSilenceDetected = "audioSilenceDetected", e.VisibilityChanged = "visibilityChanged", e.VideoDimensionsChanged = "videoDimensionsChanged", e.VideoPlaybackStarted = "videoPlaybackStarted", e.VideoPlaybackFailed = "videoPlaybackFailed", e.ElementAttached = "elementAttached", e.ElementDetached = "elementDetached", e.UpstreamPaused = "upstreamPaused", e.UpstreamResumed = "upstreamResumed", e.SubscriptionPermissionChanged = "subscriptionPermissionChanged", e.SubscriptionStatusChanged = "subscriptionStatusChanged", e.SubscriptionFailed = "subscriptionFailed", e.TrackProcessorUpdate = "trackProcessorUpdate", e.AudioTrackFeatureUpdate = "audioTrackFeatureUpdate", e.TranscriptionReceived = "transcriptionReceived", e.TimeSyncUpdate = "timeSyncUpdate", e.PreConnectBufferFlushed = "preConnectBufferFlushed";
})(z ||= {});
function Nc(e) {
	return e === void 0 ? e : typeof structuredClone == "function" ? typeof e == "object" && e ? structuredClone(Object.assign({}, e)) : structuredClone(e) : JSON.parse(JSON.stringify(e));
}
var B = class {
	constructor(e, t, n, r, i) {
		if (typeof e == "object") this.width = e.width, this.height = e.height, this.aspectRatio = e.aspectRatio, this.encoding = {
			maxBitrate: e.maxBitrate,
			maxFramerate: e.maxFramerate,
			priority: e.priority
		};
		else if (t !== void 0 && n !== void 0) this.width = e, this.height = t, this.aspectRatio = e / t, this.encoding = {
			maxBitrate: n,
			maxFramerate: r,
			priority: i
		};
		else throw TypeError("Unsupported options: provide at least width, height and maxBitrate");
	}
	get resolution() {
		return {
			width: this.width,
			height: this.height,
			frameRate: this.encoding.maxFramerate,
			aspectRatio: this.aspectRatio
		};
	}
}, Pc = ["vp8", "h264"], Fc = [
	"vp8",
	"h264",
	"vp9",
	"av1",
	"h265"
];
function Ic(e) {
	return !!Pc.find((t) => t === e);
}
var Lc = Ic, Rc;
(function(e) {
	e[e.PREFER_REGRESSION = 0] = "PREFER_REGRESSION", e[e.SIMULCAST = 1] = "SIMULCAST", e[e.REGRESSION = 2] = "REGRESSION";
})(Rc ||= {});
var zc;
(function(e) {
	e.telephone = { maxBitrate: 12e3 }, e.speech = { maxBitrate: 24e3 }, e.music = { maxBitrate: 48e3 }, e.musicStereo = { maxBitrate: 64e3 }, e.musicHighQuality = { maxBitrate: 96e3 }, e.musicHighQualityStereo = { maxBitrate: 128e3 };
})(zc ||= {});
var Bc = {
	h90: new B(160, 90, 9e4, 20),
	h180: new B(320, 180, 16e4, 20),
	h216: new B(384, 216, 18e4, 20),
	h360: new B(640, 360, 45e4, 20),
	h540: new B(960, 540, 8e5, 25),
	h720: new B(1280, 720, 17e5, 30),
	h1080: new B(1920, 1080, 3e6, 30),
	h1440: new B(2560, 1440, 5e6, 30),
	h2160: new B(3840, 2160, 8e6, 30)
}, Vc = {
	h120: new B(160, 120, 7e4, 20),
	h180: new B(240, 180, 125e3, 20),
	h240: new B(320, 240, 14e4, 20),
	h360: new B(480, 360, 33e4, 20),
	h480: new B(640, 480, 5e5, 20),
	h540: new B(720, 540, 6e5, 25),
	h720: new B(960, 720, 13e5, 30),
	h1080: new B(1440, 1080, 23e5, 30),
	h1440: new B(1920, 1440, 38e5, 30)
}, Hc = {
	h360fps3: new B(640, 360, 2e5, 3, "medium"),
	h360fps15: new B(640, 360, 4e5, 15, "medium"),
	h720fps5: new B(1280, 720, 8e5, 5, "medium"),
	h720fps15: new B(1280, 720, 15e5, 15, "medium"),
	h720fps30: new B(1280, 720, 2e6, 30, "medium"),
	h1080fps15: new B(1920, 1080, 25e5, 15, "medium"),
	h1080fps30: new B(1920, 1080, 5e6, 30, "medium"),
	original: new B(0, 0, 7e6, 30, "medium")
};
function Uc(e, t, n) {
	var r, i;
	let a = tl(e ?? {}), o = a.optionsWithoutProcessor, s = a.audioProcessor, c = a.videoProcessor, l = t?.processor, u = n?.processor, d = o ?? {};
	return d.audio === !0 && (d.audio = {}), d.video === !0 && (d.video = {}), d.audio && (Wc(d.audio, t), (r = d.audio).deviceId ?? (r.deviceId = { ideal: "default" }), (s || l) && (d.audio.processor = s ?? l)), d.video && (Wc(d.video, n), (i = d.video).deviceId ?? (i.deviceId = { ideal: "default" }), (c || u) && (d.video.processor = c ?? u)), d;
}
function Wc(e, t) {
	return Object.keys(t).forEach((n) => {
		e[n] === void 0 && (e[n] = t[n]);
	}), e;
}
function Gc(e) {
	var t, n;
	let r = {};
	if (e.video) if (typeof e.video == "object") {
		let n = {}, i = n, a = e.video;
		Object.keys(a).forEach((e) => {
			switch (e) {
				case "resolution":
					Wc(i, a.resolution);
					break;
				default: i[e] = a[e];
			}
		}), r.video = n, (t = r.video).deviceId ?? (t.deviceId = { ideal: "default" });
	} else r.video = e.video ? { deviceId: { ideal: "default" } } : !1;
	else r.video = !1;
	return e.audio ? typeof e.audio == "object" ? (r.audio = e.audio, (n = r.audio).deviceId ?? (n.deviceId = { ideal: "default" })) : r.audio = { deviceId: { ideal: "default" } } : r.audio = !1, r;
}
function Kc(e) {
	return j(this, arguments, void 0, function(e) {
		let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 200;
		return function* () {
			let n = qc();
			if (n) {
				let r = n.createAnalyser();
				r.fftSize = 2048;
				let i = r.frequencyBinCount, a = new Uint8Array(i);
				n.createMediaStreamSource(new MediaStream([e.mediaStreamTrack])).connect(r), yield pl(t), r.getByteTimeDomainData(a);
				let o = a.some((e) => e !== 128 && e !== 0);
				return n.close(), !o;
			}
			return !1;
		}();
	});
}
function qc() {
	let e = typeof window < "u" && (window.AudioContext || window.webkitAudioContext);
	if (e) {
		let t = new e({ latencyHint: "interactive" });
		if (t.state === "suspended" && typeof window < "u" && window.document?.body) {
			let e = () => j(this, void 0, void 0, function* () {
				var n;
				try {
					t.state === "suspended" && (yield t.resume());
				} catch (e) {
					console.warn("Error trying to auto-resume audio context", e);
				} finally {
					(n = window.document.body) == null || n.removeEventListener("click", e);
				}
			});
			t.addEventListener("statechange", () => {
				var n;
				t.state === "closed" && ((n = window.document.body) == null || n.removeEventListener("click", e));
			}), window.document.body.addEventListener("click", e);
		}
		return t;
	}
}
function Jc(e) {
	return e === "audioinput" ? H.Source.Microphone : e === "videoinput" ? H.Source.Camera : H.Source.Unknown;
}
function Yc(e) {
	if (e === H.Source.Microphone) return "audioinput";
	if (e === H.Source.Camera) return "videoinput";
}
function Xc(e) {
	let t = e.video ?? !0;
	return e.resolution && e.resolution.width > 0 && e.resolution.height > 0 && (t = typeof t == "boolean" ? {} : t, t = wl() ? Object.assign(Object.assign({}, t), {
		width: { max: e.resolution.width },
		height: { max: e.resolution.height },
		frameRate: e.resolution.frameRate
	}) : Object.assign(Object.assign({}, t), {
		width: { ideal: e.resolution.width },
		height: { ideal: e.resolution.height },
		frameRate: e.resolution.frameRate
	})), {
		audio: e.audio ?? !1,
		video: t,
		controller: e.controller,
		selfBrowserSurface: e.selfBrowserSurface,
		surfaceSwitching: e.surfaceSwitching,
		systemAudio: e.systemAudio,
		preferCurrentTab: e.preferCurrentTab
	};
}
function Zc(e) {
	return e.split("/")[1].toLowerCase();
}
function Qc(e) {
	let t = [];
	return e.forEach((e) => {
		e.track !== void 0 && t.push(new Ia({
			cid: e.track.mediaStreamID,
			track: e.trackInfo
		}));
	}), t;
}
function V(e) {
	return "mediaStreamTrack" in e ? {
		trackID: e.sid,
		source: e.source,
		muted: e.isMuted,
		enabled: e.mediaStreamTrack.enabled,
		kind: e.kind,
		streamID: e.mediaStreamID,
		streamTrackID: e.mediaStreamTrack.id
	} : {
		trackID: e.trackSid,
		enabled: e.isEnabled,
		muted: e.isMuted,
		trackInfo: Object.assign({
			mimeType: e.mimeType,
			name: e.trackName,
			encrypted: e.isEncrypted,
			kind: e.kind,
			source: e.source
		}, e.track ? V(e.track) : {})
	};
}
function $c() {
	return typeof RTCRtpReceiver < "u" && typeof RTCRtpReceiver.prototype.getSynchronizationSources == "function";
}
function el(e, t) {
	e === void 0 && (e = {}), t === void 0 && (t = {});
	let n = [...Object.keys(t), ...Object.keys(e)], r = {};
	for (let i of n) e[i] !== t[i] && (r[i] = t[i] ?? "");
	return r;
}
function tl(e) {
	let t = Object.assign({}, e), n, r;
	return typeof t.audio == "object" && t.audio.processor && (n = t.audio.processor, t.audio = Object.assign(Object.assign({}, t.audio), { processor: void 0 })), typeof t.video == "object" && t.video.processor && (r = t.video.processor, t.video = Object.assign(Object.assign({}, t.video), { processor: void 0 })), {
		audioProcessor: n,
		videoProcessor: r,
		optionsWithoutProcessor: Nc(t)
	};
}
function nl(e) {
	switch (e) {
		case E.CAMERA: return H.Source.Camera;
		case E.MICROPHONE: return H.Source.Microphone;
		case E.SCREEN_SHARE: return H.Source.ScreenShare;
		case E.SCREEN_SHARE_AUDIO: return H.Source.ScreenShareAudio;
		default: return H.Source.Unknown;
	}
}
function rl(e, t) {
	return e.width * e.height < t.width * t.height;
}
function il(e, t) {
	return e.layers?.find((e) => e.quality === t);
}
var al = 5e3, ol = [], sl;
(function(e) {
	e[e.LOW = 0] = "LOW", e[e.MEDIUM = 1] = "MEDIUM", e[e.HIGH = 2] = "HIGH";
})(sl ||= {});
var H = class e extends $o.EventEmitter {
	get streamState() {
		return this._streamState;
	}
	setStreamState(e) {
		this._streamState = e;
	}
	constructor(t, n) {
		let r = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
		super(), this.attachedElements = [], this.isMuted = !1, this._streamState = e.StreamState.Active, this.isInBackground = !1, this._currentBitrate = 0, this.log = A, this.appVisibilityChangedListener = () => {
			this.backgroundTimeout && clearTimeout(this.backgroundTimeout), document.visibilityState === "hidden" ? this.backgroundTimeout = setTimeout(() => this.handleAppVisibilityChanged(), al) : this.handleAppVisibilityChanged();
		}, this.log = Lo(r.loggerName ?? k.Track), this.loggerContextCb = r.loggerContextCb, this.setMaxListeners(100), this.kind = n, this._mediaStreamTrack = t, this._mediaStreamID = t.id, this.source = e.Source.Unknown;
	}
	get logContext() {
		return Object.assign(Object.assign({}, this.loggerContextCb?.call(this)), V(this));
	}
	get currentBitrate() {
		return this._currentBitrate;
	}
	get mediaStreamTrack() {
		return this._mediaStreamTrack;
	}
	get mediaStreamID() {
		return this._mediaStreamID;
	}
	attach(t) {
		let n = "audio";
		this.kind === e.Kind.Video && (n = "video"), this.attachedElements.length === 0 && this.kind === e.Kind.Video && this.addAppVisibilityListener(), t || (n === "audio" && (ol.forEach((e) => {
			e.parentElement === null && !t && (t = e);
		}), t && ol.splice(ol.indexOf(t), 1)), t ||= document.createElement(n)), this.attachedElements.includes(t) || this.attachedElements.push(t), cl(this.mediaStreamTrack, t);
		let r = t.srcObject.getTracks(), i = r.some((e) => e.kind === "audio");
		return t.play().then(() => {
			this.emit(i ? z.AudioPlaybackStarted : z.VideoPlaybackStarted);
		}).catch((e) => {
			e.name === "NotAllowedError" ? this.emit(i ? z.AudioPlaybackFailed : z.VideoPlaybackFailed, e) : e.name === "AbortError" ? A.debug(`${i ? "audio" : "video"} playback aborted, likely due to new play request`) : A.warn(`could not playback ${i ? "audio" : "video"}`, e), i && t && r.some((e) => e.kind === "video") && e.name === "NotAllowedError" && (t.muted = !0, t.play().catch(() => {}));
		}), this.emit(z.ElementAttached, t), t;
	}
	detach(e) {
		try {
			if (e) {
				ll(this.mediaStreamTrack, e);
				let t = this.attachedElements.indexOf(e);
				return t >= 0 && (this.attachedElements.splice(t, 1), this.recycleElement(e), this.emit(z.ElementDetached, e)), e;
			}
			let t = [];
			return this.attachedElements.forEach((e) => {
				ll(this.mediaStreamTrack, e), t.push(e), this.recycleElement(e), this.emit(z.ElementDetached, e);
			}), this.attachedElements = [], t;
		} finally {
			this.attachedElements.length === 0 && this.removeAppVisibilityListener();
		}
	}
	stop() {
		this.stopMonitor(), this._mediaStreamTrack.stop();
	}
	enable() {
		this._mediaStreamTrack.enabled = !0;
	}
	disable() {
		this._mediaStreamTrack.enabled = !1;
	}
	stopMonitor() {
		this.monitorInterval && clearInterval(this.monitorInterval), this.timeSyncHandle && cancelAnimationFrame(this.timeSyncHandle);
	}
	updateLoggerOptions(e) {
		e.loggerName && (this.log = Lo(e.loggerName)), e.loggerContextCb && (this.loggerContextCb = e.loggerContextCb);
	}
	recycleElement(e) {
		if (e instanceof HTMLAudioElement) {
			let t = !0;
			e.pause(), ol.forEach((e) => {
				e.parentElement || (t = !1);
			}), t && ol.push(e);
		}
	}
	handleAppVisibilityChanged() {
		return j(this, void 0, void 0, function* () {
			this.isInBackground = document.visibilityState === "hidden", !this.isInBackground && this.kind === e.Kind.Video && setTimeout(() => this.attachedElements.forEach((e) => e.play().catch(() => {})), 0);
		});
	}
	addAppVisibilityListener() {
		Al() ? (this.isInBackground = document.visibilityState === "hidden", document.addEventListener("visibilitychange", this.appVisibilityChangedListener)) : this.isInBackground = !1;
	}
	removeAppVisibilityListener() {
		Al() && document.removeEventListener("visibilitychange", this.appVisibilityChangedListener);
	}
};
function cl(e, t) {
	let n;
	n = t.srcObject instanceof MediaStream ? t.srcObject : new MediaStream();
	let r;
	r = e.kind === "audio" ? n.getAudioTracks() : n.getVideoTracks(), r.includes(e) || (r.forEach((e) => {
		n.removeTrack(e);
	}), n.addTrack(e)), (!wl() || !(t instanceof HTMLVideoElement)) && (t.autoplay = !0), t.muted = n.getAudioTracks().length === 0, t instanceof HTMLVideoElement && (t.playsInline = !0), t.srcObject !== n && (t.srcObject = n, (wl() || xl()) && t instanceof HTMLVideoElement && setTimeout(() => {
		t.srcObject = n, t.play().catch(() => {});
	}, 0));
}
function ll(e, t) {
	if (t.srcObject instanceof MediaStream) {
		let n = t.srcObject;
		n.removeTrack(e), n.getTracks().length > 0 ? t.srcObject = n : t.srcObject = null;
	}
}
(function(e) {
	let t;
	(function(e) {
		e.Audio = "audio", e.Video = "video", e.Unknown = "unknown";
	})(t = e.Kind ||= {});
	let n;
	(function(e) {
		e.Camera = "camera", e.Microphone = "microphone", e.ScreenShare = "screen_share", e.ScreenShareAudio = "screen_share_audio", e.Unknown = "unknown";
	})(n = e.Source ||= {});
	let r;
	(function(e) {
		e.Active = "active", e.Paused = "paused", e.Unknown = "unknown";
	})(r = e.StreamState ||= {});
	function i(e) {
		switch (e) {
			case t.Audio: return bi.AUDIO;
			case t.Video: return bi.VIDEO;
			default: return bi.DATA;
		}
	}
	e.kindToProto = i;
	function a(e) {
		switch (e) {
			case bi.AUDIO: return t.Audio;
			case bi.VIDEO: return t.Video;
			default: return t.Unknown;
		}
	}
	e.kindFromProto = a;
	function o(e) {
		switch (e) {
			case n.Camera: return E.CAMERA;
			case n.Microphone: return E.MICROPHONE;
			case n.ScreenShare: return E.SCREEN_SHARE;
			case n.ScreenShareAudio: return E.SCREEN_SHARE_AUDIO;
			default: return E.UNKNOWN;
		}
	}
	e.sourceToProto = o;
	function s(e) {
		switch (e) {
			case E.CAMERA: return n.Camera;
			case E.MICROPHONE: return n.Microphone;
			case E.SCREEN_SHARE: return n.ScreenShare;
			case E.SCREEN_SHARE_AUDIO: return n.ScreenShareAudio;
			default: return n.Unknown;
		}
	}
	e.sourceFromProto = s;
	function c(e) {
		switch (e) {
			case ba.ACTIVE: return r.Active;
			case ba.PAUSED: return r.Paused;
			default: return r.Unknown;
		}
	}
	e.streamStateFromProto = c;
})(H ||= {});
var ul = "|", dl = "https://aomediacodec.github.io/av1-rtp-spec/#dependency-descriptor-rtp-header-extension";
function fl(e) {
	let t = e.split(ul);
	return t.length > 1 ? [t[0], e.substr(t[0].length + 1)] : [e, ""];
}
function pl(e) {
	return new pc((t) => F.setTimeout(t, e));
}
function ml() {
	return "addTransceiver" in RTCPeerConnection.prototype;
}
function hl() {
	return "addTrack" in RTCPeerConnection.prototype;
}
function gl() {
	if (!("getCapabilities" in RTCRtpSender) || wl() || xl()) return !1;
	let e = RTCRtpSender.getCapabilities("video"), t = !1;
	if (e) {
		for (let n of e.codecs) if (n.mimeType.toLowerCase() === "video/av1") {
			t = !0;
			break;
		}
	}
	return t;
}
function _l() {
	if (!("getCapabilities" in RTCRtpSender) || xl()) return !1;
	if (wl()) {
		let e = gc();
		if (e?.version && Ll(e.version, "16") < 0 || e?.os === "iOS" && e?.osVersion && Ll(e.osVersion, "16") < 0) return !1;
	}
	let e = RTCRtpSender.getCapabilities("video"), t = !1;
	if (e) {
		for (let n of e.codecs) if (n.mimeType.toLowerCase() === "video/vp9") {
			t = !0;
			break;
		}
	}
	return t;
}
function vl(e) {
	return e === "av1" || e === "vp9";
}
function yl(e) {
	return !document || Tl() ? !1 : (e ||= document.createElement("audio"), "setSinkId" in e);
}
function bl() {
	return typeof RTCPeerConnection > "u" ? !1 : ml() || hl();
}
function xl() {
	return gc()?.name === "Firefox";
}
function Sl() {
	let e = gc();
	return !!e && e.name === "Chrome" && e.os !== "iOS";
}
function Cl() {
	return typeof window < "u" && window.RTCRtpScriptTransform !== void 0 && !Sl();
}
function wl() {
	return gc()?.name === "Safari";
}
function Tl() {
	let e = gc();
	return e?.name === "Safari" || e?.os === "iOS";
}
function El() {
	let e = gc();
	return e?.name === "Safari" && e.version.startsWith("17.") || e?.os === "iOS" && !!e?.osVersion && Ll(e.osVersion, "17") >= 0;
}
function Dl(e) {
	return e ||= gc(), e?.name === "Safari" && Ll(e.version, "18.3") > 0 || e?.os === "iOS" && !!e?.osVersion && Ll(e.osVersion, "18.3") > 0;
}
function Ol() {
	return Al() ? navigator.userAgentData?.mobile ?? /Tablet|iPad|Mobile|Android|BlackBerry/.test(navigator.userAgent) : !1;
}
function kl() {
	let e = gc(), t = "17.2";
	if (e) return e.name !== "Safari" && e.os !== "iOS" || e.os === "iOS" && e.osVersion && Ll(e.osVersion, t) >= 0 ? !0 : e.name === "Safari" && Ll(e.version, t) >= 0;
}
function Al() {
	return typeof document < "u";
}
function jl() {
	return navigator.product == "ReactNative";
}
function Ml(e) {
	return e.hostname.endsWith(".livekit.cloud") || e.hostname.endsWith(".livekit.run");
}
function Nl(e) {
	return Ml(e) ? e.hostname.split(".")[0] : null;
}
function Pl() {
	if (global && global.LiveKitReactNativeGlobal) return global.LiveKitReactNativeGlobal;
}
function Fl() {
	if (!jl()) return;
	let e = Pl();
	if (e) return e.platform;
}
function Il() {
	if (Al()) return window.devicePixelRatio;
	if (jl()) {
		let e = Pl();
		if (e) return e.devicePixelRatio;
	}
	return 1;
}
function Ll(e, t) {
	let n = e.split("."), r = t.split("."), i = Math.min(n.length, r.length);
	for (let e = 0; e < i; ++e) {
		let t = parseInt(n[e], 10), a = parseInt(r[e], 10);
		if (t > a) return 1;
		if (t < a) return -1;
		if (e === i - 1 && t === a) return 0;
	}
	return e === "" && t !== "" ? -1 : t === "" ? 1 : n.length == r.length ? 0 : n.length < r.length ? -1 : 1;
}
function Rl(e) {
	for (let t of e) t.target.handleResize(t);
}
function zl(e) {
	for (let t of e) t.target.handleVisibilityChanged(t);
}
var Bl = null, Vl = () => (Bl ||= new ResizeObserver(Rl), Bl), Hl = null, Ul = () => (Hl ||= new IntersectionObserver(zl, {
	root: null,
	rootMargin: "0px"
}), Hl);
function Wl(e) {
	let t = new aa({
		capabilities: e,
		sdk: oa.JS,
		protocol: 17,
		clientProtocol: 1,
		version: bc
	});
	return jl() && (t.os = Fl() ?? ""), t;
}
function Gl() {
	let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : 16, t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 16, n = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : !1, r = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : !1, i = document.createElement("canvas");
	i.width = e, i.height = t;
	let a = i.getContext("2d");
	a?.fillRect(0, 0, i.width, i.height), r && a && (a.beginPath(), a.arc(e / 2, t / 2, 50, 0, Math.PI * 2, !0), a.closePath(), a.fillStyle = "grey", a.fill());
	let o = C(i.captureStream().getTracks(), 1)[0];
	if (!o) throw Error("Could not get empty media stream video track");
	return o.enabled = n, o;
}
var Kl;
function ql() {
	if (!Kl) {
		let e = new AudioContext(), t = e.createOscillator(), n = e.createGain();
		n.gain.setValueAtTime(0, 0);
		let r = e.createMediaStreamDestination();
		if (t.connect(n), n.connect(r), t.start(), Kl = C(r.stream.getAudioTracks(), 1)[0], !Kl) throw Error("Could not get empty media stream audio track");
		Kl.enabled = !1;
	}
	return Kl.clone();
}
var U = class {
	get isResolved() {
		return this._isResolved;
	}
	constructor(e, t) {
		this._isResolved = !1, this.onFinally = t, this.promise = new Promise((t, n) => j(this, void 0, void 0, function* () {
			this.resolve = t, this.reject = n, e && (yield e(t, n));
		})).finally(() => {
			var e;
			this._isResolved = !0, (e = this.onFinally) == null || e.call(this);
		});
	}
};
function Jl(e) {
	return Fc.includes(e);
}
function Yl(e) {
	if (typeof e == "string" || typeof e == "number") return e;
	if (Array.isArray(e)) return e[0];
	if (e.exact !== void 0) return Array.isArray(e.exact) ? e.exact[0] : e.exact;
	if (e.ideal !== void 0) return Array.isArray(e.ideal) ? e.ideal[0] : e.ideal;
	throw Error("could not unwrap constraint");
}
function Xl(e) {
	return e.startsWith("http") ? e.replace(/^(http)/, "ws") : e;
}
function Zl(e) {
	return e.startsWith("ws") ? e.replace(/^(ws)/, "http") : e;
}
function Ql(e, t) {
	return e.segments.map((e) => {
		let n = e.id, r = e.text, i = e.language, a = e.startTime, o = e.endTime, s = e.final, c = t.get(n) ?? Date.now(), l = Date.now();
		return s ? t.delete(n) : t.set(n, c), {
			id: n,
			text: r,
			startTime: Number.parseInt(a.toString()),
			endTime: Number.parseInt(o.toString()),
			final: s,
			language: i,
			firstReceivedTime: c,
			lastReceivedTime: l
		};
	});
}
function $l(e) {
	let t = e.id, n = e.timestamp, r = e.message, i = e.editTimestamp;
	return {
		id: t,
		timestamp: Number.parseInt(n.toString()),
		editTimestamp: i ? Number.parseInt(i.toString()) : void 0,
		message: r
	};
}
function eu(e) {
	switch (e.reason) {
		case M.LeaveRequest: return e.context;
		case M.Cancelled: return wi.CLIENT_INITIATED;
		case M.NotAllowed: return wi.USER_REJECTED;
		case M.ServerUnreachable: return wi.JOIN_FAILURE;
		default: return wi.UNKNOWN_REASON;
	}
}
function tu(e) {
	return e === void 0 ? void 0 : Number(e);
}
function nu(e) {
	return e === void 0 ? void 0 : BigInt(e);
}
function ru(e) {
	return !!e && !(e instanceof MediaStreamTrack) && e.isLocal;
}
function iu(e) {
	return !!e && e.kind == H.Kind.Audio;
}
function au(e) {
	return !!e && e.kind == H.Kind.Video;
}
function ou(e) {
	return ru(e) && au(e);
}
function su(e) {
	return ru(e) && iu(e);
}
function cu(e) {
	return !!e && !e.isLocal;
}
function lu(e) {
	return !!e && !e.isLocal;
}
function uu(e) {
	return cu(e) && au(e);
}
function du(e) {
	return e.isLocal;
}
function fu(e, t) {
	let n = [], r = new TextEncoder().encode(e);
	for (; r.length > t;) {
		let e = t;
		for (; e > 0;) {
			let t = r[e];
			if (t !== void 0 && (t & 192) != 128) break;
			e--;
		}
		n.push(r.slice(0, e)), r = r.slice(e);
	}
	return r.length > 0 && n.push(r), n;
}
function pu(e) {
	let t = e.get("Cache-Control");
	if (t) {
		let e = t.match(/(?:^|[,\s])max-age=(\d+)/)?.[1];
		if (e) return parseInt(e, 10);
	}
}
function mu() {
	return typeof CompressionStream < "u";
}
function hu() {
	return mu() && !xl();
}
function gu(e, t) {
	let n = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : !1, r = _u(e, t);
	return n ? r : bu(r, "v1");
}
function _u(e, t) {
	let n = new URL(Xl(e));
	return t.forEach((e, t) => {
		n.searchParams.set(t, e);
	}), bu(n, "rtc");
}
function vu(e) {
	return bu(new URL(Zl(e)), "validate");
}
function yu(e) {
	return e.endsWith("/") ? e : `${e}/`;
}
function bu(e, t) {
	return e.pathname = `${yu(e.pathname)}${t}`, e;
}
function xu(e) {
	if (typeof e == "string") return Ca.fromJson(JSON.parse(e), { ignoreUnknownFields: !0 });
	if (e instanceof ArrayBuffer) return Ca.fromBinary(new Uint8Array(e));
	throw Error(`could not decode websocket message: ${typeof e}`);
}
function Su(e) {
	let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "Unknown reason";
	if (!(e instanceof AbortSignal)) return t;
	let n = e.reason;
	switch (typeof n) {
		case "string": return n;
		case "object": return n instanceof Error ? n.message : t;
		default: return "toString" in n ? n.toString() : t;
	}
}
var Cu = "lk_e2ee", wu;
(function(e) {
	e.SetKey = "setKey", e.RatchetRequest = "ratchetRequest", e.KeyRatcheted = "keyRatcheted";
})(wu ||= {});
var Tu;
(function(e) {
	e.KeyRatcheted = "keyRatcheted";
})(Tu ||= {});
var Eu;
(function(e) {
	e.ParticipantEncryptionStatusChanged = "participantEncryptionStatusChanged", e.EncryptionError = "encryptionError";
})(Eu ||= {});
var Du;
(function(e) {
	e.Error = "cryptorError";
})(Du ||= {});
function Ou() {
	return Au() || ku();
}
function ku() {
	return typeof window < "u" && window.RTCRtpScriptTransform !== void 0;
}
function Au() {
	return typeof window < "u" && window.RTCRtpSender !== void 0 && window.RTCRtpSender.prototype.createEncodedStreams !== void 0;
}
function ju(e) {
	if (e.value?.case !== "sipDtmf" && e.value?.case !== "metrics" && e.value?.case !== "speaker" && e.value?.case !== "transcription" && e.value?.case !== "encryptedPacket") return new Wi({ value: e.value });
}
$o.EventEmitter;
var Mu;
(function(e) {
	e[e.InvalidKey = 0] = "InvalidKey", e[e.MissingKey = 1] = "MissingKey", e[e.InternalError = 2] = "InternalError";
})(Mu ||= {});
function Nu() {
	return Cl();
}
function Pu(e) {
	return !!e?.worker && (Au() || Nu());
}
function Fu(e) {
	return !!(e?.timestamp || e?.frameId);
}
function Iu(e) {
	let t = [];
	return e?.timestamp && t.push(Di.PTF_USER_TIMESTAMP), e?.frameId && t.push(Di.PTF_FRAME_ID), t;
}
function Lu(e) {
	if (!e || e.length === 0) return;
	let t = {};
	return e.includes(Di.PTF_USER_TIMESTAMP) && (t.timestamp = !0), e.includes(Di.PTF_FRAME_ID) && (t.frameId = !0), t.timestamp || t.frameId ? t : void 0;
}
function Ru(e) {
	let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 50, n = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {}, r, i = n.isImmediate ?? !1, a = n.callback ?? !1, o = n.maxWait, s = Date.now(), c = [];
	function l() {
		if (o !== void 0) {
			let e = Date.now() - s;
			if (e + t >= o) return o - e;
		}
		return t;
	}
	let u = function() {
		var t = [...arguments];
		let n = this;
		return new Promise((o, u) => {
			let d = function() {
				if (r = void 0, s = Date.now(), !i) {
					let r = e.apply(n, t);
					a && a(r), c.forEach((e) => {
						let t = e.resolve;
						return t(r);
					}), c = [];
				}
			}, f = i && r === void 0;
			if (r !== void 0 && F.clearTimeout(r), r = F.setTimeout(d, l()), f) {
				let r = e.apply(n, t);
				return a && a(r), o(r);
			}
			c.push({
				resolve: o,
				reject: u
			});
		});
	};
	return u.cancel = function(e) {
		r !== void 0 && F.clearTimeout(r), c.forEach((t) => {
			let n = t.reject;
			return n(e);
		}), c = [];
	}, u;
}
var zu = 2e3;
function Bu(e, t) {
	if (!t) return 0;
	let n, r;
	return "bytesReceived" in e ? (n = e.bytesReceived, r = t.bytesReceived) : "bytesSent" in e && (n = e.bytesSent, r = t.bytesSent), n === void 0 || r === void 0 || e.timestamp === void 0 || t.timestamp === void 0 ? 0 : (n - r) * 8 * 1e3 / (e.timestamp - t.timestamp);
}
var Vu = class extends H {
	constructor(e, t, n, r, i) {
		super(e, n, i), this.sid = t, this.receiver = r;
	}
	get isLocal() {
		return !1;
	}
	setMuted(e) {
		this.isMuted !== e && (this.isMuted = e, this._mediaStreamTrack.enabled = !e, this.emit(e ? z.Muted : z.Unmuted, this));
	}
	setMediaStream(e) {
		this.mediaStream = e;
		let t = (n) => {
			n.track === this._mediaStreamTrack && (e.removeEventListener("removetrack", t), this.receiver && "playoutDelayHint" in this.receiver && (this.receiver.playoutDelayHint = void 0), this.receiver = void 0, this._currentBitrate = 0, this.emit(z.Ended, this));
		};
		e.addEventListener("removetrack", t);
	}
	start() {
		this.startMonitor(), super.enable();
	}
	stop() {
		this.stopMonitor(), super.disable();
	}
	getRTCStatsReport() {
		return j(this, void 0, void 0, function* () {
			if (this.receiver?.getStats) return yield this.receiver.getStats();
		});
	}
	setPlayoutDelay(e) {
		this.receiver ? "playoutDelayHint" in this.receiver ? this.receiver.playoutDelayHint = e : this.log.warn("Playout delay not supported in this browser") : this.log.warn("Cannot set playout delay, track already ended");
	}
	getPlayoutDelay() {
		if (this.receiver) {
			if ("playoutDelayHint" in this.receiver) return this.receiver.playoutDelayHint;
			this.log.warn("Playout delay not supported in this browser");
		} else this.log.warn("Cannot get playout delay, track already ended");
		return 0;
	}
	startMonitor() {
		this.monitorInterval ||= setInterval(() => this.monitorReceiver(), zu), $c() && this.registerTimeSyncUpdate();
	}
	registerTimeSyncUpdate() {
		let e = () => {
			this.timeSyncHandle = requestAnimationFrame(() => e());
			let t = this.receiver?.getSynchronizationSources()[0];
			if (t) {
				let e = t.timestamp, n = t.rtpTimestamp;
				n && this.rtpTimestamp !== n && (this.emit(z.TimeSyncUpdate, {
					timestamp: e,
					rtpTimestamp: n
				}), this.rtpTimestamp = n);
			}
		};
		e();
	}
}, Hu = 100, Uu = class extends Vu {
	constructor(e, t, n, r, i) {
		super(e, t, H.Kind.Video, n, i), this.elementInfos = [], this.monitorReceiver = () => j(this, void 0, void 0, function* () {
			if (!this.receiver) {
				this._currentBitrate = 0;
				return;
			}
			let e = yield this.getReceiverStats();
			e && this.prevStats && this.receiver && (this._currentBitrate = Bu(e, this.prevStats)), this.prevStats = e;
		}), this.debouncedHandleResize = Ru(() => {
			this.updateDimensions();
		}, Hu), this.adaptiveStreamSettings = r;
	}
	get isAdaptiveStream() {
		return this.adaptiveStreamSettings !== void 0;
	}
	lookupFrameMetadata(e) {
		let t = e.rtpTimestamp;
		return this.packetTrailerExtractor?.lookupMetadata(t);
	}
	setStreamState(e) {
		super.setStreamState(e), this.log.debug("setStreamState", e), this.isAdaptiveStream && e === H.StreamState.Active && this.updateVisibility();
	}
	get mediaStreamTrack() {
		return this._mediaStreamTrack;
	}
	setMuted(e) {
		super.setMuted(e), this.attachedElements.forEach((t) => {
			e ? ll(this._mediaStreamTrack, t) : cl(this._mediaStreamTrack, t);
		});
	}
	attach(e) {
		if (e ? super.attach(e) : e = super.attach(), this.adaptiveStreamSettings && this.elementInfos.find((t) => t.element === e) === void 0) {
			let t = new Wu(e);
			this.observeElementInfo(t);
		}
		return e;
	}
	observeElementInfo(e) {
		this.adaptiveStreamSettings && this.elementInfos.find((t) => t === e) === void 0 ? (e.handleResize = () => {
			this.debouncedHandleResize();
		}, e.handleVisibilityChanged = () => {
			this.updateVisibility();
		}, this.elementInfos.push(e), e.observe(), this.debouncedHandleResize(), this.updateVisibility()) : this.log.warn("visibility resize observer not triggered", this.logContext);
	}
	stopObservingElementInfo(e) {
		if (!this.isAdaptiveStream) {
			this.log.warn("stopObservingElementInfo ignored", this.logContext);
			return;
		}
		let t = this.elementInfos.filter((t) => t === e);
		for (let e of t) e.stopObserving();
		this.elementInfos = this.elementInfos.filter((t) => t !== e), this.updateVisibility(), this.debouncedHandleResize();
	}
	detach(e) {
		if (e) return this.stopObservingElement(e), super.detach(e);
		let t = super.detach();
		for (let e of t) this.stopObservingElement(e);
		return t;
	}
	getDecoderImplementation() {
		return this.prevStats?.decoderImplementation;
	}
	getReceiverStats() {
		return j(this, void 0, void 0, function* () {
			if (!this.receiver || !this.receiver.getStats) return;
			let e = yield this.receiver.getStats(), t, n = "", r = /* @__PURE__ */ new Map();
			return e.forEach((e) => {
				e.type === "inbound-rtp" ? (n = e.codecId, t = {
					type: "video",
					streamId: e.id,
					framesDecoded: e.framesDecoded,
					framesDropped: e.framesDropped,
					framesReceived: e.framesReceived,
					packetsReceived: e.packetsReceived,
					packetsLost: e.packetsLost,
					frameWidth: e.frameWidth,
					frameHeight: e.frameHeight,
					pliCount: e.pliCount,
					firCount: e.firCount,
					nackCount: e.nackCount,
					jitter: e.jitter,
					timestamp: e.timestamp,
					bytesReceived: e.bytesReceived,
					decoderImplementation: e.decoderImplementation
				}) : e.type === "codec" && r.set(e.id, e);
			}), t && n !== "" && r.get(n) && (t.mimeType = r.get(n).mimeType), t;
		});
	}
	stopObservingElement(e) {
		let t = this.elementInfos.filter((t) => t.element === e);
		for (let e of t) this.stopObservingElementInfo(e);
	}
	handleAppVisibilityChanged() {
		let e = Object.create(null, { handleAppVisibilityChanged: { get: () => super.handleAppVisibilityChanged } });
		return j(this, void 0, void 0, function* () {
			yield e.handleAppVisibilityChanged.call(this), this.isAdaptiveStream && this.updateVisibility();
		});
	}
	updateVisibility(e) {
		let t = this.elementInfos.reduce((e, t) => Math.max(e, t.visibilityChangedAt || 0), 0), n = this.adaptiveStreamSettings?.pauseVideoInBackground ?? !0 ? this.isInBackground : !1, r = this.elementInfos.some((e) => e.pictureInPicture), i = this.elementInfos.some((e) => e.visible) && !n || r;
		if (!(this.lastVisible === i && !e)) {
			if (!i && Date.now() - t < Hu) {
				F.setTimeout(() => {
					this.updateVisibility();
				}, Hu);
				return;
			}
			this.lastVisible = i, this.emit(z.VisibilityChanged, i, this);
		}
	}
	updateDimensions() {
		let e = 0, t = 0, n = this.getPixelDensity();
		for (let r of this.elementInfos) {
			let i = r.width() * n, a = r.height() * n;
			i + a > e + t && (e = i, t = a);
		}
		this.lastDimensions?.width === e && this.lastDimensions?.height === t || (this.lastDimensions = {
			width: e,
			height: t
		}, this.emit(z.VideoDimensionsChanged, this.lastDimensions, this));
	}
	getPixelDensity() {
		let e = this.adaptiveStreamSettings?.pixelDensity;
		return e === "screen" ? Il() : e || (Il() > 2 ? 2 : 1);
	}
}, Wu = class {
	get visible() {
		return this.isPiP || this.isIntersecting;
	}
	get pictureInPicture() {
		return this.isPiP;
	}
	constructor(e, t) {
		this.onVisibilityChanged = (e) => {
			var t;
			let n = e.target, r = e.isIntersecting;
			n === this.element && (this.isIntersecting = r, this.isPiP = Gu(this.element), this.visibilityChangedAt = Date.now(), (t = this.handleVisibilityChanged) == null || t.call(this));
		}, this.onEnterPiP = () => {
			var e;
			(e = window.documentPictureInPicture?.window) == null || e.addEventListener("pagehide", this.onLeavePiP), queueMicrotask(() => {
				requestAnimationFrame(() => {
					var e;
					this.isPiP = Gu(this.element), (e = this.handleVisibilityChanged) == null || e.call(this);
				});
			});
		}, this.onLeavePiP = () => {
			var e;
			this.isPiP = Gu(this.element), (e = this.handleVisibilityChanged) == null || e.call(this);
		}, this.element = e, this.isIntersecting = t ?? Ku(e), this.isPiP = Al() && Gu(e), this.visibilityChangedAt = 0;
	}
	width() {
		return this.element.clientWidth;
	}
	height() {
		return this.element.clientHeight;
	}
	observe() {
		var e, t;
		this.isIntersecting = Ku(this.element), this.isPiP = Gu(this.element), this.element.handleResize = () => {
			var e;
			(e = this.handleResize) == null || e.call(this);
		}, this.element.handleVisibilityChanged = this.onVisibilityChanged, Ul().observe(this.element), Vl().observe(this.element), this.element.addEventListener("enterpictureinpicture", this.onEnterPiP), this.element.addEventListener("leavepictureinpicture", this.onLeavePiP), (e = window.documentPictureInPicture) == null || e.addEventListener("enter", this.onEnterPiP), (t = window.documentPictureInPicture?.window) == null || t.addEventListener("pagehide", this.onLeavePiP);
	}
	stopObserving() {
		var e, t, n, r;
		(e = Ul()) == null || e.unobserve(this.element), (t = Vl()) == null || t.unobserve(this.element), this.element.removeEventListener("enterpictureinpicture", this.onEnterPiP), this.element.removeEventListener("leavepictureinpicture", this.onLeavePiP), (n = window.documentPictureInPicture) == null || n.removeEventListener("enter", this.onEnterPiP), (r = window.documentPictureInPicture?.window) == null || r.removeEventListener("pagehide", this.onLeavePiP);
	}
};
function Gu(e) {
	return document.pictureInPictureElement === e ? !0 : window.documentPictureInPicture?.window ? Ku(e, window.documentPictureInPicture?.window) : !1;
}
function Ku(e, t) {
	let n = t || window, r = e.offsetTop, i = e.offsetLeft, a = e.offsetWidth, o = e.offsetHeight, s = e.hidden, c = getComputedStyle(e).display;
	for (; e.offsetParent;) e = e.offsetParent, r += e.offsetTop, i += e.offsetLeft;
	return r < n.pageYOffset + n.innerHeight && i < n.pageXOffset + n.innerWidth && r + o > n.pageYOffset && i + a > n.pageXOffset && !s && c !== "none";
}
var qu = class extends $o.EventEmitter {
	constructor(e, t) {
		super(), this.decryptDataRequests = /* @__PURE__ */ new Map(), this.encryptDataRequests = /* @__PURE__ */ new Map(), this.onWorkerMessage = (e) => {
			let t = e.data, n = t.kind, r = t.data;
			switch (n) {
				case "error":
					if (A.error(r.error.message), r.uuid) {
						let e = this.decryptDataRequests.get(r.uuid);
						if (e?.reject) {
							e.reject(r.error);
							break;
						}
						let t = this.encryptDataRequests.get(r.uuid);
						if (t?.reject) {
							t.reject(r.error);
							break;
						}
					}
					this.emit(Eu.EncryptionError, r.error, r.participantIdentity);
					break;
				case "initAck":
					r.enabled && this.keyProvider.getKeys().forEach((e) => {
						this.postKey(e, !1);
					});
					break;
				case "enable":
					if (r.enabled && this.keyProvider.getKeys().forEach((e) => {
						this.postKey(e, !1);
					}), this.encryptionEnabled !== r.enabled && r.participantIdentity === this.room?.localParticipant.identity) this.emit(Eu.ParticipantEncryptionStatusChanged, r.enabled, this.room.localParticipant), this.encryptionEnabled = r.enabled;
					else if (r.participantIdentity) {
						let e = this.room?.getParticipantByIdentity(r.participantIdentity);
						if (!e) throw TypeError(`couldn't set encryption status, participant not found${r.participantIdentity}`);
						this.emit(Eu.ParticipantEncryptionStatusChanged, r.enabled, e);
					}
					break;
				case "ratchetKey":
					this.keyProvider.emit(wu.KeyRatcheted, r.ratchetResult, r.participantIdentity, r.keyIndex);
					break;
				case "decryptDataResponse":
					let e = this.decryptDataRequests.get(r.uuid);
					e?.resolve && e.resolve(r);
					break;
				case "encryptDataResponse":
					let t = this.encryptDataRequests.get(r.uuid);
					t?.resolve && t.resolve(r);
					break;
				case "packetTrailerMetadata":
					this.handlePacketTrailerMetadata(r.trackId, r.rtpTimestamp, r.ssrc, r.metadata);
					break;
			}
		}, this.onWorkerError = (e) => {
			A.error("e2ee worker encountered an error:", { error: e.error }), this.emit(Eu.EncryptionError, e.error, void 0);
		}, this.keyProvider = e.keyProvider, this.worker = e.worker, this.encryptionEnabled = !1, this.dataChannelEncryptionEnabled = t;
	}
	get isEnabled() {
		return this.encryptionEnabled;
	}
	get isDataChannelEncryptionEnabled() {
		return this.isEnabled && this.dataChannelEncryptionEnabled;
	}
	setup(e) {
		if (!Ou()) throw new Cc("tried to setup end-to-end encryption on an unsupported browser");
		if (A.info("setting up e2ee"), e !== this.room) {
			this.room = e, this.setupEventListeners(e, this.keyProvider);
			let t = {
				kind: "init",
				data: {
					keyProviderOptions: this.keyProvider.getOptions(),
					loglevel: Bo.getLevel()
				}
			};
			this.worker && (A.info("initializing worker", { worker: this.worker }), this.worker.onmessage = this.onWorkerMessage, this.worker.onerror = this.onWorkerError, this.worker.postMessage(t));
		}
	}
	setParticipantCryptorEnabled(e, t) {
		A.debug(`set e2ee to ${e} for participant ${t}`), this.postEnable(e, t);
	}
	setSifTrailer(e) {
		!e || e.length === 0 ? A.warn("ignoring server sent trailer as it's empty") : this.postSifTrailer(e);
	}
	handlePacketTrailerMetadata(e, t, n, r) {
		if (this.room) {
			for (let i of [this.room.localParticipant, ...this.room.remoteParticipants.values()]) for (let a of i.trackPublications.values()) if (a.track && a.track.mediaStreamID === e && a.track instanceof Uu && a.track.packetTrailerExtractor) {
				a.track.packetTrailerExtractor.storeMetadata(t, n, r);
				return;
			}
		}
	}
	setupEngine(e) {
		e.on(R.RTPVideoMapUpdate, (e) => {
			this.postRTPMap(e);
		});
	}
	setupEventListeners(e, t) {
		e.on(I.TrackPublished, (e, t) => this.setParticipantCryptorEnabled(e.trackInfo.encryption !== O.NONE, t.identity)), e.on(I.ConnectionStateChanged, (t) => {
			t === X.Connected && e.remoteParticipants.forEach((e) => {
				e.trackPublications.forEach((t) => {
					this.setParticipantCryptorEnabled(t.trackInfo.encryption !== O.NONE, e.identity);
				});
			});
		}).on(I.TrackUnsubscribed, (e, t, n) => {
			var r;
			let i = {
				kind: "removeTransform",
				data: {
					participantIdentity: n.identity,
					trackId: e.mediaStreamID
				}
			};
			(r = this.worker) == null || r.postMessage(i);
		}).on(I.TrackSubscribed, (e, t, n) => {
			this.setupE2EEReceiver(e, n.identity, t.trackInfo);
		}).on(I.SignalConnected, () => {
			if (!this.room) throw TypeError("expected room to be present on signal connect");
			let e = t.getLatestManuallySetKeyIndex();
			t.getKeys().forEach((t) => {
				this.postKey(t, e === (t.keyIndex ?? 0));
			}), this.setParticipantCryptorEnabled(this.room.localParticipant.isE2EEEnabled, this.room.localParticipant.identity);
		}), e.localParticipant.on(L.LocalSenderCreated, (e, t) => j(this, void 0, void 0, function* () {
			this.setupE2EESender(t, e);
		})), e.localParticipant.on(L.LocalTrackPublished, (e) => {
			if (!au(e.track) || !Tl()) return;
			let t = {
				kind: "updateCodec",
				data: {
					trackId: e.track.mediaStreamID,
					codec: Zc(e.trackInfo.codecs[0].mimeType),
					participantIdentity: this.room.localParticipant.identity,
					hasPacketTrailer: !1
				}
			};
			this.worker.postMessage(t);
		}), t.on(wu.SetKey, (e, t) => this.postKey(e, t ?? !0)).on(wu.RatchetRequest, (e, t) => this.postRatchetRequest(e, t));
	}
	encryptData(e) {
		return j(this, void 0, void 0, function* () {
			if (!this.worker) throw Error("could not encrypt data, worker is missing");
			let t = crypto.randomUUID(), n = {
				kind: "encryptDataRequest",
				data: {
					uuid: t,
					payload: e,
					participantIdentity: this.room.localParticipant.identity
				}
			}, r = new U();
			return r.onFinally = () => {
				this.encryptDataRequests.delete(t);
			}, this.encryptDataRequests.set(t, r), this.worker.postMessage(n), r.promise;
		});
	}
	handleEncryptedData(e, t, n, r) {
		if (!this.worker) throw Error("could not handle encrypted data, worker is missing");
		let i = crypto.randomUUID(), a = {
			kind: "decryptDataRequest",
			data: {
				uuid: i,
				payload: e,
				iv: t,
				participantIdentity: n,
				keyIndex: r
			}
		}, o = new U();
		return o.onFinally = () => {
			this.decryptDataRequests.delete(i);
		}, this.decryptDataRequests.set(i, o), this.worker.postMessage(a), o.promise;
	}
	postRatchetRequest(e, t) {
		if (!this.worker) throw Error("could not ratchet key, worker is missing");
		let n = {
			kind: "ratchetRequest",
			data: {
				participantIdentity: e,
				keyIndex: t
			}
		};
		this.worker.postMessage(n);
	}
	postKey(e, t) {
		let n = e.key, r = e.participantIdentity, i = e.keyIndex;
		if (!this.worker) throw Error("could not set key, worker is missing");
		let a = {
			kind: "setKey",
			data: {
				participantIdentity: r,
				isPublisher: r === this.room?.localParticipant.identity,
				key: n,
				keyIndex: i,
				updateCurrentKeyIndex: t
			}
		};
		this.worker.postMessage(a);
	}
	postEnable(e, t) {
		if (this.worker) {
			let n = {
				kind: "enable",
				data: {
					enabled: e,
					participantIdentity: t
				}
			};
			this.worker.postMessage(n);
		} else throw ReferenceError("failed to enable e2ee, worker is not ready");
	}
	postRTPMap(e) {
		if (!this.worker) throw TypeError("could not post rtp map, worker is missing");
		if (!this.room?.localParticipant.identity) throw TypeError("could not post rtp map, local participant identity is missing");
		let t = {
			kind: "setRTPMap",
			data: {
				map: e,
				participantIdentity: this.room.localParticipant.identity
			}
		};
		this.worker.postMessage(t);
	}
	postSifTrailer(e) {
		if (!this.worker) throw Error("could not post SIF trailer, worker is missing");
		let t = {
			kind: "setSifTrailer",
			data: { trailer: e }
		};
		this.worker.postMessage(t);
	}
	setupE2EEReceiver(e, t, n) {
		if (!e.receiver) return;
		if (!n?.mimeType || n.mimeType === "") throw TypeError("MimeType missing from trackInfo, cannot set up E2EE cryptor");
		let r = e.kind === "video" && !!n.packetTrailerFeatures && n.packetTrailerFeatures.length > 0;
		this.handleReceiver(e.receiver, e.mediaStreamID, t, e.kind === "video" ? Zc(n.mimeType) : void 0, r);
	}
	setupE2EESender(e, t) {
		if (!ru(e) || !t) {
			t || A.warn("early return because sender is not ready");
			return;
		}
		this.handleSender(t, e.mediaStreamID, void 0, au(e) ? e.publishOptions?.packetTrailer : void 0);
	}
	handleReceiver(e, t, n, r, i) {
		return j(this, void 0, void 0, function* () {
			if (this.worker) {
				if (Cl()) {
					let a = {
						kind: "decode",
						participantIdentity: n,
						trackId: t,
						codec: r,
						hasPacketTrailer: i
					};
					e.transform = new RTCRtpScriptTransform(this.worker, a);
				} else {
					if (Cu in e && r) {
						let e = {
							kind: "updateCodec",
							data: {
								trackId: t,
								codec: r,
								participantIdentity: n,
								hasPacketTrailer: i
							}
						};
						this.worker.postMessage(e);
						return;
					}
					let a = e.writableStream, o = e.readableStream;
					if (!a || !o) {
						let t = e.createEncodedStreams();
						e.writableStream = t.writable, a = t.writable, e.readableStream = t.readable, o = t.readable;
					}
					let s = {
						kind: "decode",
						data: {
							readableStream: o,
							writableStream: a,
							trackId: t,
							codec: r,
							participantIdentity: n,
							isReuse: Cu in e,
							hasPacketTrailer: i
						}
					};
					this.worker.postMessage(s, [o, a]);
				}
				e[Cu] = !0;
			}
		});
	}
	handleSender(e, t, n, r) {
		if (!(Cu in e || !this.worker)) {
			if (!this.room?.localParticipant.identity || this.room.localParticipant.identity === "") throw TypeError("local identity needs to be known in order to set up encrypted sender");
			if (Cl()) {
				A.info("initialize script transform");
				let i = {
					kind: "encode",
					participantIdentity: this.room.localParticipant.identity,
					trackId: t,
					codec: n,
					hasPacketTrailer: Fu(r),
					packetTrailer: r
				};
				e.transform = new RTCRtpScriptTransform(this.worker, i);
			} else {
				A.info("initialize encoded streams");
				let i = e.createEncodedStreams(), a = {
					kind: "encode",
					data: {
						readableStream: i.readable,
						writableStream: i.writable,
						codec: n,
						trackId: t,
						participantIdentity: this.room.localParticipant.identity,
						isReuse: !1,
						hasPacketTrailer: Fu(r),
						packetTrailer: r
					}
				};
				this.worker.postMessage(a, [i.readable, i.writable]);
			}
			e[Cu] = !0;
		}
	}
}, Ju = 300, Yu = class {
	constructor() {
		this.metadataMap = /* @__PURE__ */ new Map(), this.activeSsrc = 0;
	}
	storeMetadata(e, t, n) {
		for (this.activeSsrc !== 0 && this.activeSsrc !== t && this.metadataMap.clear(), this.activeSsrc = t; this.metadataMap.size >= Ju;) {
			let e = this.metadataMap.keys().next().value;
			this.metadataMap.delete(e);
		}
		this.metadataMap.set(e, n);
	}
	lookupMetadata(e) {
		return this.metadataMap.get(e);
	}
	dispose() {
		this.metadataMap.clear(), this.activeSsrc = 0;
	}
}, Xu = class {
	constructor(e) {
		this.extractors = /* @__PURE__ */ new Map(), this.workerPipelines = /* @__PURE__ */ new Map(), this.onWorkerMessage = (e) => {
			let t = e.data;
			if (t.kind === "metadata") {
				let e = this.extractors.get(t.data.trackId);
				e && e.storeMetadata(t.data.rtpTimestamp, t.data.ssrc, t.data.metadata);
			}
		}, this.onWorkerError = (e) => {
			A.error("packet trailer worker encountered an error:", { error: e.error });
		}, this.worker = e?.worker;
	}
	setup(e) {
		e !== this.room && (this.room = e, this.worker && (this.worker.onmessage = this.onWorkerMessage, this.worker.onerror = this.onWorkerError, this.worker.postMessage({ kind: "init" })), e.on(I.TrackSubscribed, (e, t, n) => {
			e.kind === "video" && this.setupReceiver(e, t.trackInfo);
		}).on(I.TrackUnsubscribed, (e) => {
			this.teardownTrack(e);
		}).on(I.Disconnected, () => {
			this.cleanup();
		}));
	}
	setupReceiver(e, t) {
		let n = e.receiver;
		if (!n) return;
		if (!(t?.packetTrailerFeatures && t.packetTrailerFeatures.length > 0)) {
			this.room?.hasE2EESetup || this.setupPassthroughReceiver(n, e.mediaStreamID);
			return;
		}
		if (!Pu(this.worker ? { worker: this.worker } : void 0) && !this.room?.hasE2EESetup) {
			A.warn("packet trailer transform not supported; skipping extraction");
			return;
		}
		let r = new Yu(), i = e.mediaStreamID;
		this.extractors.set(i, r), e.packetTrailerExtractor = r, !this.room?.hasE2EESetup && this.setupWorkerReceiver(n, i, !0);
	}
	setupPassthroughReceiver(e, t) {
		if (Nu()) {
			"transform" in e && (e.transform = null);
			return;
		}
		if (this.worker && Pu({ worker: this.worker }) && !this.workerPipelines.has(e)) {
			this.setupWorkerReceiver(e, t, !1);
			return;
		}
		this.worker && this.workerPipelines.has(e) && this.setupWorkerReceiver(e, t, !1);
	}
	setupWorkerReceiver(e, t) {
		let n = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : !0, r = this.worker;
		if (!r) return;
		if (Nu()) {
			e.transform = new RTCRtpScriptTransform(r, {
				kind: "decode",
				trackId: t
			});
			return;
		}
		let i = this.workerPipelines.get(e);
		if (i) {
			let a = {
				kind: "updateTrackId",
				data: {
					oldTrackId: i,
					newTrackId: t,
					hasPacketTrailer: n
				}
			};
			r.postMessage(a), this.workerPipelines.set(e, t);
			return;
		}
		if (!("createEncodedStreams" in e)) {
			A.warn("createEncodedStreams not supported");
			return;
		}
		let a;
		try {
			a = e.createEncodedStreams();
		} catch (e) {
			A.warn("failed to create encoded streams", { error: e });
			return;
		}
		let o = {
			kind: "decode",
			data: {
				readableStream: a.readable,
				writableStream: a.writable,
				trackId: t,
				hasPacketTrailer: n
			}
		};
		r.postMessage(o, [a.readable, a.writable]), this.workerPipelines.set(e, t);
	}
	teardownTrack(e) {
		let t = e.mediaStreamID, n = this.extractors.get(t);
		n && (n.dispose(), this.extractors.delete(t)), e instanceof Uu && (e.packetTrailerExtractor = void 0);
	}
	cleanup() {
		var e;
		for (let e of this.extractors.values()) e.dispose();
		this.extractors.clear(), this.workerPipelines.clear(), (e = this.worker) == null || e.terminate();
	}
}, Zu = 500, Qu = 15e3, $u = class e {
	constructor() {
		this.failedConnectionAttempts = /* @__PURE__ */ new Map(), this.backOffPromises = /* @__PURE__ */ new Map();
	}
	static getInstance() {
		return this._instance ||= new e(), this._instance;
	}
	addFailedConnectionAttempt(e) {
		let t = Nl(new URL(e));
		if (!t) return;
		let n = this.failedConnectionAttempts.get(t) ?? 0;
		this.failedConnectionAttempts.set(t, n + 1), this.backOffPromises.set(t, pl(Math.min(Zu * 2 ** n, Qu)));
	}
	getBackOffPromise(e) {
		let t = new URL(e), n = t && Nl(t);
		return n && this.backOffPromises.get(n) || Promise.resolve();
	}
	resetFailedConnectionAttempts(e) {
		let t = new URL(e), n = t && Nl(t);
		n && (this.failedConnectionAttempts.set(n, 0), this.backOffPromises.set(n, Promise.resolve()));
	}
	resetAll() {
		this.backOffPromises.clear(), this.failedConnectionAttempts.clear();
	}
};
$u._instance = null;
var ed = "default", td = class e {
	constructor() {
		this._previousDevices = [];
	}
	static getInstance() {
		return this.instance === void 0 && (this.instance = new e()), this.instance;
	}
	get previousDevices() {
		return this._previousDevices;
	}
	getDevices(t) {
		return j(this, arguments, void 0, function(t) {
			var n = this;
			let r = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !0;
			return function* () {
				if (e.userMediaPromiseMap?.size > 0) {
					A.debug("awaiting getUserMedia promise");
					try {
						t ? yield e.userMediaPromiseMap.get(t) : yield Promise.all(e.userMediaPromiseMap.values());
					} catch {
						A.warn("error waiting for media permissons");
					}
				}
				let i = yield navigator.mediaDevices.enumerateDevices();
				if (r && !(wl() && n.hasDeviceInUse(t)) && (i.filter((e) => e.kind === t).length === 0 || i.some((e) => {
					let n = e.label === "", r = t ? e.kind === t : !0;
					return n && r;
				}))) {
					let e = {
						video: t !== "audioinput" && t !== "audiooutput",
						audio: t !== "videoinput" && { deviceId: { ideal: "default" } }
					}, n = yield navigator.mediaDevices.getUserMedia(e);
					i = yield navigator.mediaDevices.enumerateDevices(), n.getTracks().forEach((e) => {
						e.stop();
					});
				}
				return n._previousDevices = i, t && (i = i.filter((e) => e.kind === t)), i;
			}();
		});
	}
	normalizeDeviceId(e, t, n) {
		return j(this, void 0, void 0, function* () {
			if (t !== ed) return t;
			let r = yield this.getDevices(e), i = r.find((e) => e.deviceId === ed);
			if (!i) {
				A.warn("could not reliably determine default device");
				return;
			}
			let a = r.find((e) => e.deviceId !== ed && e.groupId === (n ?? i.groupId));
			if (!a) {
				A.warn("could not reliably determine default device");
				return;
			}
			return a?.deviceId;
		});
	}
	hasDeviceInUse(t) {
		return t ? e.userMediaPromiseMap.has(t) : e.userMediaPromiseMap.size > 0;
	}
};
td.mediaDeviceKinds = [
	"audioinput",
	"audiooutput",
	"videoinput"
], td.userMediaPromiseMap = /* @__PURE__ */ new Map();
var nd = 65535, rd = 4294967295, id = class e {
	static u16(t) {
		return new e(t, nd);
	}
	static u32(t) {
		return new e(t, rd);
	}
	constructor(e, t) {
		if (this.value = e, e < 0) throw Error("WrapAroundUnsignedInt: cannot faithfully represent an integer smaller than 0");
		if (t > 2 ** 53 - 1) throw Error("WrapAroundUnsignedInt: cannot faithfully represent an integer bigger than MAX_SAFE_INTEGER.");
		this.maxSize = t, this.clamp();
	}
	clamp() {
		for (; this.value > this.maxSize;) this.value -= this.maxSize + 1;
		for (; this.value < 0;) this.value += this.maxSize + 1;
	}
	clone() {
		return new e(this.value, this.maxSize);
	}
	update(e) {
		this.value = e(this.value), this.clamp();
	}
	increment() {
		let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : 1;
		this.update((t) => t + e);
	}
	decrement() {
		let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : 1;
		this.update((t) => t - e);
	}
	getThenIncrement() {
		let t = this.value;
		return this.increment(), new e(t, this.maxSize);
	}
	isBefore(e) {
		let t = this.value >>> 0, n = (e.value >>> 0) - t >>> 0;
		return n !== 0 && n < this.maxSize + 1;
	}
}, ad = class e {
	static fromRtpTicks(t) {
		return new e(t, 9e4);
	}
	static rtpRandom() {
		let t = Math.round(Math.random() * rd);
		return e.fromRtpTicks(t);
	}
	constructor(e, t) {
		this.timestamp = id.u32(e), this.rateInHz = t;
	}
	asTicks() {
		return this.timestamp.value;
	}
	clone() {
		return new e(this.timestamp.value, this.rateInHz);
	}
	wrappingAdd(e) {
		this.timestamp.increment(e);
	}
	isBefore(e) {
		return this.timestamp.isBefore(e.timestamp);
	}
}, od = class e {
	constructor(e, t, n) {
		this.epoch = t, this.base = n, this.previous = n.clone(), this.rateInHz = e;
	}
	static startingNow(t, n) {
		return new e(n, /* @__PURE__ */ new Date(), t);
	}
	static startingAtTime(t, n, r) {
		return new e(r, t, n);
	}
	static rtpStartingNow(t) {
		return e.startingNow(t, 9e4);
	}
	static rtpStartingAtTime(t, n) {
		return e.startingAtTime(t, n, 9e4);
	}
	now() {
		return this.at(/* @__PURE__ */ new Date());
	}
	at(t) {
		let n = t.getTime() - this.epoch.getTime(), r = e.durationInMsToTicks(n, this.rateInHz), i = this.base.clone();
		return i.wrappingAdd(r), i.isBefore(this.previous) && (i = this.previous), this.previous = i.clone(), i.clone();
	}
	static durationInMsToTicks(e, t) {
		let n = (e * 1e6 * t + 5e8) / 1e9;
		return Math.round(n);
	}
};
function sd(e) {
	if (e instanceof DataView) return e;
	if (e instanceof ArrayBuffer) return new DataView(e);
	if (e instanceof Uint8Array) return new DataView(e.buffer, e.byteOffset, e.byteLength);
	throw Error(`Error coercing ${e} to DataView - input was not DataView, ArrayBuffer, or Uint8Array.`);
}
var cd;
(function(e) {
	e[e.Reserved = 0] = "Reserved", e[e.TooLarge = 1] = "TooLarge";
})(cd ||= {});
var ld = class e extends Sc {
	constructor(e, t) {
		super(19, e), this.name = "DataTrackHandleError", this.reason = t, this.reasonName = cd[t];
	}
	isReason(e) {
		return this.reason === e;
	}
	static tooLarge() {
		return new e("Value too large to be a valid track handle", cd.TooLarge);
	}
	static reserved(t) {
		return new e(`0x${t.toString(16)} is a reserved value.`, cd.Reserved);
	}
}, ud = { fromNumber(e) {
	if (e === 0) throw ld.reserved(e);
	if (e > nd) throw ld.tooLarge();
	return e;
} }, dd = class {
	constructor() {
		this.value = 0;
	}
	get() {
		return this.value += 1, this.value > nd ? null : this.value;
	}
	reset() {
		this.value = 0;
	}
}, fd = {
	from(e) {
		return {
			sid: e.sid,
			pubHandle: e.pubHandle,
			name: e.name,
			usesE2ee: e.encryption !== O.NONE
		};
	},
	toProtobuf(e) {
		return new Li({
			sid: e.sid,
			pubHandle: e.pubHandle,
			name: e.name,
			encryption: e.usesE2ee ? O.GCM : O.NONE
		});
	}
}, pd;
(function(e) {
	e[e.WAITING = 0] = "WAITING", e[e.RUNNING = 1] = "RUNNING", e[e.COMPLETED = 2] = "COMPLETED";
})(pd ||= {});
var md = class {
	constructor() {
		this.pendingTasks = /* @__PURE__ */ new Map(), this.taskMutex = new v(), this.nextTaskIndex = 0;
	}
	run(e) {
		return j(this, void 0, void 0, function* () {
			let t = {
				id: this.nextTaskIndex++,
				enqueuedAt: Date.now(),
				status: pd.WAITING
			};
			this.pendingTasks.set(t.id, t);
			let n = yield this.taskMutex.lock();
			try {
				return t.executedAt = Date.now(), t.status = pd.RUNNING, yield e();
			} finally {
				t.status = pd.COMPLETED, this.pendingTasks.delete(t.id), n();
			}
		});
	}
	flush() {
		return j(this, void 0, void 0, function* () {
			return this.run(() => j(this, void 0, void 0, function* () {}));
		});
	}
	snapshot() {
		return Array.from(this.pendingTasks.values());
	}
}, hd = class {
	get readyState() {
		return this.ws.readyState;
	}
	constructor(e) {
		let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
		if (t.signal?.aborted) throw new DOMException("This operation was aborted", "AbortError");
		this.url = e;
		let n = new WebSocket(e, t.protocols ?? []);
		n.binaryType = "arraybuffer", this.ws = n;
		let r = function() {
			let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {}, t = e.closeCode, r = e.reason;
			return n.close(t, r);
		};
		this.opened = new pc((e, t) => {
			let i = () => {
				t(N.websocket("Encountered websocket error during connection establishment"));
			};
			n.onopen = () => {
				e({
					readable: new ReadableStream({
						start(e) {
							n.onmessage = (t) => {
								let n = t.data;
								return e.enqueue(n);
							}, n.onerror = (t) => e.error(t);
						},
						cancel: r
					}),
					writable: new WritableStream({
						write(e) {
							n.send(e);
						},
						abort() {
							n.close();
						},
						close: r
					}),
					protocol: n.protocol,
					extensions: n.extensions
				}), n.removeEventListener("error", i);
			}, n.addEventListener("error", i);
		}), this.closed = new pc((e, t) => {
			let r = () => j(this, void 0, void 0, function* () {
				let r = new pc((e) => {
					n.readyState !== WebSocket.CLOSED && n.addEventListener("close", (t) => {
						e(t);
					}, { once: !0 });
				}), i = yield pc.race([pl(250), r]);
				i ? e(i) : t(N.websocket("Encountered unspecified websocket error without a timely close event"));
			});
			n.onclose = (t) => {
				let i = t.code, a = t.reason;
				e({
					closeCode: i,
					reason: a
				}), n.removeEventListener("error", r);
			}, n.addEventListener("error", r);
		}), t.signal && (t.signal.onabort = () => n.close()), this.close = r;
	}
}, gd = [
	"syncState",
	"trickle",
	"offer",
	"answer",
	"simulate",
	"leave"
];
function _d(e) {
	let t = gd.indexOf(e.case) >= 0;
	return A.trace("request allowed to bypass queue:", {
		canPass: t,
		req: e
	}), t;
}
var W;
(function(e) {
	e[e.CONNECTING = 0] = "CONNECTING", e[e.CONNECTED = 1] = "CONNECTED", e[e.RECONNECTING = 2] = "RECONNECTING", e[e.DISCONNECTING = 3] = "DISCONNECTING", e[e.DISCONNECTED = 4] = "DISCONNECTED";
})(W ||= {});
var vd = 250, yd = class {
	get currentState() {
		return this.state;
	}
	get isDisconnected() {
		return this.state === W.DISCONNECTING || this.state === W.DISCONNECTED;
	}
	get isEstablishingConnection() {
		return this.state === W.CONNECTING || this.state === W.RECONNECTING;
	}
	getNextRequestId() {
		return this._requestId += 1, this._requestId;
	}
	constructor() {
		let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : !1, t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
		this.rtt = 0, this.state = W.DISCONNECTED, this.log = A, this._requestId = 0, this.useV0SignalPath = !1, this.resetCallbacks = () => {
			this.onAnswer = void 0, this.onLeave = void 0, this.onLocalTrackPublished = void 0, this.onLocalTrackUnpublished = void 0, this.onNegotiateRequested = void 0, this.onOffer = void 0, this.onRemoteMuteChanged = void 0, this.onSubscribedQualityUpdate = void 0, this.onTokenRefresh = void 0, this.onTrickle = void 0, this.onClose = void 0, this.onMediaSectionsRequirement = void 0;
		}, this.loggerContextCb = t.loggerContextCb, this.log = Lo(t.loggerName ?? k.Signal, () => this.logContext), this.useJSON = e, this.requestQueue = new md(), this.queuedRequests = [], this.closingLock = new v(), this.connectionLock = new v(), this.state = W.DISCONNECTED;
	}
	get logContext() {
		return this.loggerContextCb?.call(this) ?? {};
	}
	join(e, t, n, r) {
		return j(this, arguments, void 0, function(e, t, n, r) {
			var i = this;
			let a = arguments.length > 4 && arguments[4] !== void 0 ? arguments[4] : !1, o = arguments.length > 5 ? arguments[5] : void 0;
			return function* () {
				return i.state = W.CONNECTING, i.options = n, yield i.connect(e, t, n, r, a, o);
			}();
		});
	}
	reconnect(e, t, n, r) {
		return j(this, void 0, void 0, function* () {
			if (!this.options) {
				this.log.warn("attempted to reconnect without signal options being set, ignoring");
				return;
			}
			return this.state = W.RECONNECTING, this.clearPingInterval(), yield this.connect(e, t, Object.assign(Object.assign({}, this.options), {
				reconnect: !0,
				sid: n,
				reconnectReason: r
			}), void 0, this.useV0SignalPath);
		});
	}
	connect(e, t, n, r) {
		return j(this, arguments, void 0, function(e, t, n, r) {
			var i = this;
			let a = arguments.length > 4 && arguments[4] !== void 0 ? arguments[4] : !1, o = arguments.length > 5 ? arguments[5] : void 0;
			return function* () {
				let s = yield i.connectionLock.lock();
				i.connectOptions = n, i.useV0SignalPath = a;
				let c = Wl(n.clientInfoCapabilities), l = gu(e, a ? Sd(t, c, n) : yield Cd(t, c, n, o), a).toString(), u = vu(l).toString();
				return new Promise((e, t) => j(i, void 0, void 0, function* () {
					try {
						let i = !1, a = (e) => j(this, void 0, void 0, function* () {
							if (i) return;
							i = !0;
							let n = Su(e instanceof Event ? e.currentTarget : e, "Abort handler called");
							this.streamWriter && !this.isDisconnected ? this.sendLeave().then(() => this.close(n)).catch((e) => {
								this.log.error(e), this.close();
							}) : this.close(), o(), t(N.cancelled(n));
						});
						r?.addEventListener("abort", a);
						let o = () => {
							clearTimeout(s), r?.removeEventListener("abort", a);
						}, s = setTimeout(() => {
							a(N.timeout("room connection has timed out (signal)"));
						}, n.websocketTimeout), c = (e, t) => {
							this.handleSignalConnected(e, s, t);
						}, d = new URL(l);
						d.searchParams.has("access_token") && d.searchParams.set("access_token", "<redacted>"), this.log.info(`signal connecting to ${d}`, {
							reconnect: n.reconnect,
							reconnectReason: n.reconnectReason
						}), this.ws && (yield this.close(!1)), this.ws = new hd(l);
						try {
							this.ws.closed.then((e) => {
								this.isEstablishingConnection && t(N.internal(`Websocket got closed during a (re)connection attempt: ${e.reason}`)), e.closeCode !== 1e3 && (this.log.warn("websocket closed", {
									reason: e.reason,
									code: e.closeCode,
									wasClean: e.closeCode === 1e3,
									state: this.state
								}), this.state === W.CONNECTED && this.handleOnClose(e.reason ?? "Unexpected WS error"));
							}).catch((e) => {
								this.isEstablishingConnection && t(N.internal(`Websocket error during a (re)connection attempt: ${e}`));
							});
							let r = yield this.ws.opened.catch((e) => j(this, void 0, void 0, function* () {
								if (this.state !== W.CONNECTED) {
									this.state = W.DISCONNECTED, clearTimeout(s), t(yield this.handleConnectionError(e, u));
									return;
								}
								this.handleWSError(e), t(e);
							}));
							if (clearTimeout(s), !r) return;
							let i = r.readable.getReader();
							this.streamWriter = r.writable.getWriter();
							let a = yield i.read();
							if (i.releaseLock(), !a.value) throw N.internal("no message received as first message");
							let o = xu(a.value), l = this.validateFirstMessage(o, n.reconnect ?? !1);
							if (!l.isValid) {
								t(l.error);
								return;
							}
							o.message?.case === "join" && (this.pingTimeoutDuration = o.message.value.pingTimeout, this.pingIntervalDuration = o.message.value.pingInterval, this.pingTimeoutDuration && this.pingTimeoutDuration > 0 && this.log.debug("ping config", {
								timeout: this.pingTimeoutDuration,
								interval: this.pingIntervalDuration
							}), this.onJoined && this.onJoined(o.message.value)), c(r, l.shouldProcessFirstMessage ? o : void 0), e(l.response);
						} catch (e) {
							t(e);
						} finally {
							o();
						}
					} finally {
						s();
					}
				}));
			}();
		});
	}
	startReadingLoop(e, t) {
		return j(this, void 0, void 0, function* () {
			for (t && this.handleSignalResponse(t);;) {
				this.signalLatency && (yield pl(this.signalLatency));
				let t = yield e.read(), n = t.done, r = t.value;
				if (n) break;
				let i = xu(r);
				this.handleSignalResponse(i);
			}
		});
	}
	close() {
		return j(this, arguments, void 0, function() {
			var e = this;
			let t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : !0, n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "Close method called on signal client";
			return function* () {
				if ([W.DISCONNECTING || W.DISCONNECTED].includes(e.state)) {
					e.log.debug("ignoring signal close as it's already in disconnecting state");
					return;
				}
				let r = yield e.closingLock.lock();
				try {
					if (e.clearPingInterval(), t && (e.state = W.DISCONNECTING), e.ws) {
						e.ws.close({
							closeCode: 1e3,
							reason: n
						});
						let t = e.ws.closed;
						e.ws = void 0, e.streamWriter = void 0, yield Promise.race([t, pl(vd)]);
					}
				} catch (t) {
					e.log.debug("websocket error while closing", { error: t });
				} finally {
					t && (e.state = W.DISCONNECTED), r();
				}
			}();
		});
	}
	sendOffer(e, t) {
		this.log.debug("sending offer", { offerSdp: e.sdp }), this.sendRequest({
			case: "offer",
			value: xd(e, t)
		});
	}
	sendAnswer(e, t) {
		return this.log.debug("sending answer", { answerSdp: e.sdp }), this.sendRequest({
			case: "answer",
			value: xd(e, t)
		});
	}
	sendIceCandidate(e, t) {
		return this.log.debug("sending ice candidate", { candidate: e }), this.sendRequest({
			case: "trickle",
			value: new Ma({
				candidateInit: JSON.stringify(e),
				target: t
			})
		});
	}
	sendMuteTrack(e, t) {
		return this.sendRequest({
			case: "mute",
			value: new Na({
				sid: e,
				muted: t
			})
		});
	}
	sendAddTrack(e) {
		return this.sendRequest({
			case: "addTrack",
			value: e
		});
	}
	sendUpdateLocalMetadata(e, t) {
		return j(this, arguments, void 0, function(e, t) {
			var n = this;
			let r = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
			return function* () {
				let i = n.getNextRequestId();
				return yield n.sendRequest({
					case: "updateMetadata",
					value: new Ya({
						requestId: i,
						metadata: e,
						name: t,
						attributes: r
					})
				}), i;
			}();
		});
	}
	sendUpdateTrackSettings(e) {
		this.sendRequest({
			case: "trackSetting",
			value: e
		});
	}
	sendUpdateSubscription(e) {
		return this.sendRequest({
			case: "subscription",
			value: e
		});
	}
	sendSyncState(e) {
		return this.sendRequest({
			case: "syncState",
			value: e
		});
	}
	sendUpdateVideoLayers(e, t) {
		return this.sendRequest({
			case: "updateLayers",
			value: new Ja({
				trackSid: e,
				layers: t
			})
		});
	}
	sendUpdateSubscriptionPermissions(e, t) {
		return this.sendRequest({
			case: "subscriptionPermission",
			value: new co({
				allParticipants: e,
				trackPermissions: t
			})
		});
	}
	sendSimulateScenario(e) {
		return this.sendRequest({
			case: "simulate",
			value: e
		});
	}
	sendPing() {
		return Promise.all([this.sendRequest({
			case: "ping",
			value: b.parse(Date.now())
		}), this.sendRequest({
			case: "pingReq",
			value: new go({
				timestamp: b.parse(Date.now()),
				rtt: b.parse(this.rtt)
			})
		})]);
	}
	sendUpdateLocalAudioTrack(e, t) {
		return this.sendRequest({
			case: "updateAudioTrack",
			value: new Wa({
				trackSid: e,
				features: t
			})
		});
	}
	sendLeave() {
		return this.sendRequest({
			case: "leave",
			value: new Ka({
				reason: wi.CLIENT_INITIATED,
				action: qa.DISCONNECT
			})
		});
	}
	sendPublishDataTrackRequest(e, t, n) {
		return this.sendRequest({
			case: "publishDataTrackRequest",
			value: new Ea({
				pubHandle: e,
				name: t,
				encryption: n ? O.GCM : O.NONE
			})
		});
	}
	sendUnPublishDataTrackRequest(e) {
		return this.sendRequest({
			case: "unpublishDataTrackRequest",
			value: new Oa({ pubHandle: e })
		});
	}
	sendUpdateDataSubscription(e, t) {
		return this.sendRequest({
			case: "updateDataSubscription",
			value: new Va({ updates: [new Ha({
				trackSid: e,
				subscribe: t
			})] })
		});
	}
	sendRequest(e) {
		return j(this, arguments, void 0, function(e) {
			var t = this;
			let n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !1;
			return function* () {
				if (!n && !_d(e) && t.state === W.RECONNECTING) {
					t.queuedRequests.push(() => j(t, void 0, void 0, function* () {
						yield this.sendRequest(e, !0);
					}));
					return;
				}
				if (n || (yield t.requestQueue.flush()), t.signalLatency && (yield pl(t.signalLatency)), t.isDisconnected) {
					t.log.debug(`skipping signal request (type: ${e.case}) - SignalClient disconnected`);
					return;
				}
				if (!t.streamWriter) {
					t.log.error(`cannot send signal request before connected, type: ${e?.case}`);
					return;
				}
				let r = new Sa({ message: e });
				try {
					t.useJSON ? yield t.streamWriter.write(r.toJsonString()) : yield t.streamWriter.write(r.toBinary().buffer);
				} catch (e) {
					t.log.error("error sending signal message", { error: e });
				}
			}();
		});
	}
	handleSignalResponse(e) {
		let t = e.message;
		if (t == null) {
			this.log.debug("received unsupported message");
			return;
		}
		let n = !1;
		if (t.case === "answer") {
			let e = bd(t.value);
			this.onAnswer && this.onAnswer(e, t.value.id, t.value.midToTrackId);
		} else if (t.case === "offer") {
			let e = bd(t.value);
			this.onOffer && this.onOffer(e, t.value.id, t.value.midToTrackId);
		} else if (t.case === "trickle") {
			let e = JSON.parse(t.value.candidateInit);
			this.onTrickle && this.onTrickle(e, t.value.target);
		} else t.case === "update" ? this.onParticipantUpdate && this.onParticipantUpdate(t.value.participants ?? []) : t.case === "trackPublished" ? this.onLocalTrackPublished && this.onLocalTrackPublished(t.value) : t.case === "speakersChanged" ? this.onSpeakersChanged && this.onSpeakersChanged(t.value.speakers ?? []) : t.case === "leave" ? this.onLeave && this.onLeave(t.value) : t.case === "mute" ? this.onRemoteMuteChanged && this.onRemoteMuteChanged(t.value.sid, t.value.muted) : t.case === "roomUpdate" ? this.onRoomUpdate && t.value.room && this.onRoomUpdate(t.value.room) : t.case === "connectionQuality" ? this.onConnectionQuality && this.onConnectionQuality(t.value) : t.case === "streamStateUpdate" ? this.onStreamStateUpdate && this.onStreamStateUpdate(t.value) : t.case === "subscribedQualityUpdate" ? this.onSubscribedQualityUpdate && this.onSubscribedQualityUpdate(t.value) : t.case === "subscriptionPermissionUpdate" ? this.onSubscriptionPermissionUpdate && this.onSubscriptionPermissionUpdate(t.value) : t.case === "refreshToken" ? this.onTokenRefresh && this.onTokenRefresh(t.value) : t.case === "trackUnpublished" ? this.onLocalTrackUnpublished && this.onLocalTrackUnpublished(t.value) : t.case === "subscriptionResponse" ? this.onSubscriptionError && this.onSubscriptionError(t.value) : t.case === "pong" || (t.case === "pongResp" ? (this.rtt = Date.now() - Number.parseInt(t.value.lastPingTimestamp.toString()), this.resetPingTimeout(), n = !0) : t.case === "requestResponse" ? this.onRequestResponse && this.onRequestResponse(t.value) : t.case === "trackSubscribed" ? this.onLocalTrackSubscribed && this.onLocalTrackSubscribed(t.value.trackSid) : t.case === "roomMoved" ? (this.onTokenRefresh && this.onTokenRefresh(t.value.token), this.onRoomMoved && this.onRoomMoved(t.value)) : t.case === "mediaSectionsRequirement" ? this.onMediaSectionsRequirement && this.onMediaSectionsRequirement(t.value) : t.case === "publishDataTrackResponse" ? this.onPublishDataTrackResponse && this.onPublishDataTrackResponse(t.value) : t.case === "unpublishDataTrackResponse" ? this.onUnPublishDataTrackResponse && this.onUnPublishDataTrackResponse(t.value) : t.case === "dataTrackSubscriberHandles" ? this.onDataTrackSubscriberHandles && this.onDataTrackSubscriberHandles(t.value) : this.log.debug("unsupported message", { msgCase: t.case }));
		n || this.resetPingTimeout();
	}
	setReconnected() {
		for (; this.queuedRequests.length > 0;) {
			let e = this.queuedRequests.shift();
			e && this.requestQueue.run(e);
		}
	}
	handleOnClose(e) {
		return j(this, void 0, void 0, function* () {
			if (this.state === W.DISCONNECTED) return;
			let t = this.onClose;
			yield this.close(void 0, e), this.log.info(`websocket connection closed: ${e}`, { reason: e }), t && t(e);
		});
	}
	handleWSError(e) {
		this.log.error("websocket error", { error: e });
	}
	resetPingTimeout() {
		if (this.clearPingTimeout(), !this.pingTimeoutDuration) {
			this.log.warn("ping timeout duration not set");
			return;
		}
		this.pingTimeout = F.setTimeout(() => {
			this.log.warn(`ping timeout triggered. last pong received at: ${(/* @__PURE__ */ new Date(Date.now() - this.pingTimeoutDuration * 1e3)).toUTCString()}`), this.handleOnClose("ping timeout");
		}, this.pingTimeoutDuration * 1e3);
	}
	clearPingTimeout() {
		this.pingTimeout && F.clearTimeout(this.pingTimeout);
	}
	startPingInterval() {
		if (this.clearPingInterval(), this.resetPingTimeout(), !this.pingIntervalDuration) {
			this.log.warn("ping interval duration not set");
			return;
		}
		this.log.debug("start ping interval"), this.pingInterval = F.setInterval(() => {
			this.sendPing();
		}, this.pingIntervalDuration * 1e3);
	}
	clearPingInterval() {
		this.log.debug("clearing ping interval"), this.clearPingTimeout(), this.pingInterval && F.clearInterval(this.pingInterval);
	}
	handleSignalConnected(e, t, n) {
		this.state = W.CONNECTED, this.log.info("signal connected"), clearTimeout(t), this.startPingInterval(), this.startReadingLoop(e.readable.getReader(), n);
	}
	validateFirstMessage(e, t) {
		return e.message?.case === "join" ? {
			isValid: !0,
			response: e.message.value
		} : this.state === W.RECONNECTING && e.message?.case !== "leave" ? e.message?.case === "reconnect" ? {
			isValid: !0,
			response: e.message.value
		} : (this.log.debug("declaring signal reconnected without reconnect response received"), {
			isValid: !0,
			response: void 0,
			shouldProcessFirstMessage: !0
		}) : this.isEstablishingConnection && e.message?.case === "leave" ? {
			isValid: !1,
			error: N.leaveRequest("Received leave request while trying to (re)connect", e.message.value.reason)
		} : t ? {
			isValid: !1,
			error: N.internal("Unexpected first message")
		} : {
			isValid: !1,
			error: N.internal(`did not receive join response, got ${e.message?.case} instead`)
		};
	}
	handleConnectionError(e, t) {
		return j(this, void 0, void 0, function* () {
			try {
				let n = yield fetch(t);
				switch (n.status) {
					case 404:
						let e = yield n.text();
						return e.includes("requested room does not exist") ? N.notAllowed(e, n.status) : N.serviceNotFound("v1 RTC path not found. Consider upgrading your LiveKit server version", "v0-rtc");
					case 401:
					case 403:
						let t = yield n.text();
						return N.notAllowed(t, n.status);
					default: break;
				}
				return e instanceof N ? e : N.internal(`Encountered unknown websocket error during connection: ${e}`, {
					status: n.status,
					statusText: n.statusText
				});
			} catch (e) {
				return e instanceof N ? e : N.serverUnreachable(e instanceof Error ? e.message : "server was not reachable");
			}
		});
	}
};
function bd(e) {
	let t = {
		type: "offer",
		sdp: e.sdp
	};
	switch (e.type) {
		case "answer":
		case "offer":
		case "pranswer":
		case "rollback":
			t.type = e.type;
			break;
	}
	return t;
}
function xd(e, t) {
	return new Ra({
		sdp: e.sdp,
		type: e.type,
		id: t
	});
}
function Sd(e, t, n) {
	let r = new URLSearchParams();
	return r.set("access_token", e), n.reconnect && (r.set("reconnect", "1"), n.sid && r.set("sid", n.sid)), r.set("auto_subscribe", n.autoSubscribe ? "1" : "0"), r.set("sdk", jl() ? "reactnative" : "js"), r.set("version", t.version), r.set("protocol", t.protocol.toString()), r.set("client_protocol", t.clientProtocol.toString()), t.deviceModel && r.set("device_model", t.deviceModel), t.os && r.set("os", t.os), t.osVersion && r.set("os_version", t.osVersion), t.browser && r.set("browser", t.browser), t.browserVersion && r.set("browser_version", t.browserVersion), n.adaptiveStream && r.set("adaptive_stream", "1"), n.reconnectReason && r.set("reconnect_reason", n.reconnectReason.toString()), navigator.connection?.type && r.set("network", navigator.connection.type), r;
}
function Cd(e, t, n, r) {
	return j(this, void 0, void 0, function* () {
		let i = new URLSearchParams();
		i.set("access_token", e);
		let a = new To({
			clientInfo: t,
			connectionSettings: new wo({
				autoSubscribe: !!n.autoSubscribe,
				adaptiveStream: !!n.adaptiveStream
			}),
			reconnect: !!n.reconnect,
			participantSid: n.sid ? n.sid : void 0,
			publisherOffer: r
		});
		n.reconnectReason && (a.reconnectReason = n.reconnectReason);
		let o = a.toBinary(), s, c;
		if (mu()) {
			let e = new CompressionStream("gzip"), t = e.writable.getWriter();
			t.write(new Uint8Array(o)), t.close();
			let n = [], r = e.readable.getReader();
			for (;;) {
				let e = yield r.read(), t = e.done, i = e.value;
				if (t) break;
				n.push(i);
			}
			let i = n.reduce((e, t) => e + t.length, 0), a = new Uint8Array(i), l = 0;
			for (let e of n) a.set(e, l), l += e.length;
			s = a, c = Do.GZIP;
		} else s = o, c = Do.NONE;
		let l = new Eo({
			joinRequest: s,
			compression: c
		}).toBinary();
		return i.set("join_request", ((e) => {
			let t = Array.from(e, (e) => String.fromCodePoint(e)).join("");
			return btoa(t);
		})(l).replace(/\+/g, "-").replace(/\//g, "_")), i;
	});
}
var wd = class {
	constructor() {
		this.buffer = [], this._totalSize = 0;
	}
	push(e) {
		this.buffer.push(e), this._totalSize += e.data.byteLength;
	}
	pop() {
		let e = this.buffer.shift();
		return e && (this._totalSize -= e.data.byteLength), e;
	}
	getAll() {
		return this.buffer.slice();
	}
	popToSequence(e) {
		for (; this.buffer.length > 0 && this.buffer[0].sequence <= e;) this.pop();
	}
	alignBufferedAmount(e) {
		for (; this.buffer.length > 0;) {
			let t = this.buffer[0];
			if (this._totalSize - t.data.byteLength <= e) break;
			this.pop();
		}
	}
	get length() {
		return this.buffer.length;
	}
}, Td = class {
	constructor(e) {
		this._map = /* @__PURE__ */ new Map(), this._lastCleanup = 0, this.ttl = e;
	}
	set(e, t) {
		let n = Date.now();
		n - this._lastCleanup > this.ttl / 2 && this.cleanup();
		let r = n + this.ttl;
		return this._map.set(e, {
			value: t,
			expiresAt: r
		}), this;
	}
	get(e) {
		let t = this._map.get(e);
		if (t) {
			if (t.expiresAt < Date.now()) {
				this._map.delete(e);
				return;
			}
			return t.value;
		}
	}
	has(e) {
		let t = this._map.get(e);
		return t ? t.expiresAt < Date.now() ? (this._map.delete(e), !1) : !0 : !1;
	}
	delete(e) {
		return this._map.delete(e);
	}
	clear() {
		this._map.clear();
	}
	cleanup() {
		let e = Date.now();
		for (let n of this._map.entries()) {
			var t = C(n, 2);
			let r = t[0];
			t[1].expiresAt < e && this._map.delete(r);
		}
		this._lastCleanup = e;
	}
	get size() {
		return this.cleanup(), this._map.size;
	}
	forEach(e) {
		this.cleanup();
		for (let n of this._map.entries()) {
			var t = C(n, 2);
			let r = t[0], i = t[1];
			i.expiresAt >= Date.now() && e(i.value, r, this.asValueMap());
		}
	}
	map(e) {
		this.cleanup();
		let t = [], n = this.asValueMap();
		for (let i of n.entries()) {
			var r = C(i, 2);
			let a = r[0], o = r[1];
			t.push(e(o, a, n));
		}
		return t;
	}
	asValueMap() {
		let e = /* @__PURE__ */ new Map();
		for (let n of this._map.entries()) {
			var t = C(n, 2);
			let r = t[0], i = t[1];
			i.expiresAt >= Date.now() && e.set(r, i.value);
		}
		return e;
	}
}, Ed = {}, Dd = {}, Od = { exports: {} }, kd;
function Ad() {
	if (kd) return Od.exports;
	kd = 1;
	var e = Od.exports = {
		v: [{
			name: "version",
			reg: /^(\d*)$/
		}],
		o: [{
			name: "origin",
			reg: /^(\S*) (\d*) (\d*) (\S*) IP(\d) (\S*)/,
			names: [
				"username",
				"sessionId",
				"sessionVersion",
				"netType",
				"ipVer",
				"address"
			],
			format: "%s %s %d %s IP%d %s"
		}],
		s: [{ name: "name" }],
		i: [{ name: "description" }],
		u: [{ name: "uri" }],
		e: [{ name: "email" }],
		p: [{ name: "phone" }],
		z: [{ name: "timezones" }],
		r: [{ name: "repeats" }],
		t: [{
			name: "timing",
			reg: /^(\d*) (\d*)/,
			names: ["start", "stop"],
			format: "%d %d"
		}],
		c: [{
			name: "connection",
			reg: /^IN IP(\d) (\S*)/,
			names: ["version", "ip"],
			format: "IN IP%d %s"
		}],
		b: [{
			push: "bandwidth",
			reg: /^(TIAS|AS|CT|RR|RS):(\d*)/,
			names: ["type", "limit"],
			format: "%s:%s"
		}],
		m: [{
			reg: /^(\w*) (\d*) ([\w/]*)(?: (.*))?/,
			names: [
				"type",
				"port",
				"protocol",
				"payloads"
			],
			format: "%s %d %s %s"
		}],
		a: [
			{
				push: "rtp",
				reg: /^rtpmap:(\d*) ([\w\-.]*)(?:\s*\/(\d*)(?:\s*\/(\S*))?)?/,
				names: [
					"payload",
					"codec",
					"rate",
					"encoding"
				],
				format: function(e) {
					return e.encoding ? "rtpmap:%d %s/%s/%s" : e.rate ? "rtpmap:%d %s/%s" : "rtpmap:%d %s";
				}
			},
			{
				push: "fmtp",
				reg: /^fmtp:(\d*) ([\S| ]*)/,
				names: ["payload", "config"],
				format: "fmtp:%d %s"
			},
			{
				name: "control",
				reg: /^control:(.*)/,
				format: "control:%s"
			},
			{
				name: "rtcp",
				reg: /^rtcp:(\d*)(?: (\S*) IP(\d) (\S*))?/,
				names: [
					"port",
					"netType",
					"ipVer",
					"address"
				],
				format: function(e) {
					return e.address == null ? "rtcp:%d" : "rtcp:%d %s IP%d %s";
				}
			},
			{
				push: "rtcpFbTrrInt",
				reg: /^rtcp-fb:(\*|\d*) trr-int (\d*)/,
				names: ["payload", "value"],
				format: "rtcp-fb:%s trr-int %d"
			},
			{
				push: "rtcpFb",
				reg: /^rtcp-fb:(\*|\d*) ([\w-_]*)(?: ([\w-_]*))?/,
				names: [
					"payload",
					"type",
					"subtype"
				],
				format: function(e) {
					return e.subtype == null ? "rtcp-fb:%s %s" : "rtcp-fb:%s %s %s";
				}
			},
			{
				push: "ext",
				reg: /^extmap:(\d+)(?:\/(\w+))?(?: (urn:ietf:params:rtp-hdrext:encrypt))? (\S*)(?: (\S*))?/,
				names: [
					"value",
					"direction",
					"encrypt-uri",
					"uri",
					"config"
				],
				format: function(e) {
					return "extmap:%d" + (e.direction ? "/%s" : "%v") + (e["encrypt-uri"] ? " %s" : "%v") + " %s" + (e.config ? " %s" : "");
				}
			},
			{
				name: "extmapAllowMixed",
				reg: /^(extmap-allow-mixed)/
			},
			{
				push: "crypto",
				reg: /^crypto:(\d*) ([\w_]*) (\S*)(?: (\S*))?/,
				names: [
					"id",
					"suite",
					"config",
					"sessionConfig"
				],
				format: function(e) {
					return e.sessionConfig == null ? "crypto:%d %s %s" : "crypto:%d %s %s %s";
				}
			},
			{
				name: "setup",
				reg: /^setup:(\w*)/,
				format: "setup:%s"
			},
			{
				name: "connectionType",
				reg: /^connection:(new|existing)/,
				format: "connection:%s"
			},
			{
				name: "mid",
				reg: /^mid:([^\s]*)/,
				format: "mid:%s"
			},
			{
				name: "msid",
				reg: /^msid:(.*)/,
				format: "msid:%s"
			},
			{
				name: "ptime",
				reg: /^ptime:(\d*(?:\.\d*)*)/,
				format: "ptime:%d"
			},
			{
				name: "maxptime",
				reg: /^maxptime:(\d*(?:\.\d*)*)/,
				format: "maxptime:%d"
			},
			{
				name: "direction",
				reg: /^(sendrecv|recvonly|sendonly|inactive)/
			},
			{
				name: "icelite",
				reg: /^(ice-lite)/
			},
			{
				name: "iceUfrag",
				reg: /^ice-ufrag:(\S*)/,
				format: "ice-ufrag:%s"
			},
			{
				name: "icePwd",
				reg: /^ice-pwd:(\S*)/,
				format: "ice-pwd:%s"
			},
			{
				name: "fingerprint",
				reg: /^fingerprint:(\S*) (\S*)/,
				names: ["type", "hash"],
				format: "fingerprint:%s %s"
			},
			{
				push: "candidates",
				reg: /^candidate:(\S*) (\d*) (\S*) (\d*) (\S*) (\d*) typ (\S*)(?: raddr (\S*) rport (\d*))?(?: tcptype (\S*))?(?: generation (\d*))?(?: network-id (\d*))?(?: network-cost (\d*))?/,
				names: [
					"foundation",
					"component",
					"transport",
					"priority",
					"ip",
					"port",
					"type",
					"raddr",
					"rport",
					"tcptype",
					"generation",
					"network-id",
					"network-cost"
				],
				format: function(e) {
					var t = "candidate:%s %d %s %d %s %d typ %s";
					return t += e.raddr == null ? "%v%v" : " raddr %s rport %d", t += e.tcptype == null ? "%v" : " tcptype %s", e.generation != null && (t += " generation %d"), t += e["network-id"] == null ? "%v" : " network-id %d", t += e["network-cost"] == null ? "%v" : " network-cost %d", t;
				}
			},
			{
				name: "endOfCandidates",
				reg: /^(end-of-candidates)/
			},
			{
				name: "remoteCandidates",
				reg: /^remote-candidates:(.*)/,
				format: "remote-candidates:%s"
			},
			{
				name: "iceOptions",
				reg: /^ice-options:(\S*)/,
				format: "ice-options:%s"
			},
			{
				push: "ssrcs",
				reg: /^ssrc:(\d*) ([\w_-]*)(?::(.*))?/,
				names: [
					"id",
					"attribute",
					"value"
				],
				format: function(e) {
					var t = "ssrc:%d";
					return e.attribute != null && (t += " %s", e.value != null && (t += ":%s")), t;
				}
			},
			{
				push: "ssrcGroups",
				reg: /^ssrc-group:([\x21\x23\x24\x25\x26\x27\x2A\x2B\x2D\x2E\w]*) (.*)/,
				names: ["semantics", "ssrcs"],
				format: "ssrc-group:%s %s"
			},
			{
				name: "msidSemantic",
				reg: /^msid-semantic:\s?(\w*) (\S*)/,
				names: ["semantic", "token"],
				format: "msid-semantic: %s %s"
			},
			{
				push: "groups",
				reg: /^group:(\w*) (.*)/,
				names: ["type", "mids"],
				format: "group:%s %s"
			},
			{
				name: "rtcpMux",
				reg: /^(rtcp-mux)/
			},
			{
				name: "rtcpRsize",
				reg: /^(rtcp-rsize)/
			},
			{
				name: "sctpmap",
				reg: /^sctpmap:([\w_/]*) (\S*)(?: (\S*))?/,
				names: [
					"sctpmapNumber",
					"app",
					"maxMessageSize"
				],
				format: function(e) {
					return e.maxMessageSize == null ? "sctpmap:%s %s" : "sctpmap:%s %s %s";
				}
			},
			{
				name: "xGoogleFlag",
				reg: /^x-google-flag:([^\s]*)/,
				format: "x-google-flag:%s"
			},
			{
				push: "rids",
				reg: /^rid:([\d\w]+) (\w+)(?: ([\S| ]*))?/,
				names: [
					"id",
					"direction",
					"params"
				],
				format: function(e) {
					return e.params ? "rid:%s %s %s" : "rid:%s %s";
				}
			},
			{
				push: "imageattrs",
				reg: /* @__PURE__ */ RegExp("^imageattr:(\\d+|\\*)[\\s\\t]+(send|recv)[\\s\\t]+(\\*|\\[\\S+\\](?:[\\s\\t]+\\[\\S+\\])*)(?:[\\s\\t]+(recv|send)[\\s\\t]+(\\*|\\[\\S+\\](?:[\\s\\t]+\\[\\S+\\])*))?"),
				names: [
					"pt",
					"dir1",
					"attrs1",
					"dir2",
					"attrs2"
				],
				format: function(e) {
					return "imageattr:%s %s %s" + (e.dir2 ? " %s %s" : "");
				}
			},
			{
				name: "simulcast",
				reg: /* @__PURE__ */ RegExp("^simulcast:(send|recv) ([a-zA-Z0-9\\-_~;,]+)(?:\\s?(send|recv) ([a-zA-Z0-9\\-_~;,]+))?$"),
				names: [
					"dir1",
					"list1",
					"dir2",
					"list2"
				],
				format: function(e) {
					return "simulcast:%s %s" + (e.dir2 ? " %s %s" : "");
				}
			},
			{
				name: "simulcast_03",
				reg: /^simulcast:[\s\t]+([\S+\s\t]+)$/,
				names: ["value"],
				format: "simulcast: %s"
			},
			{
				name: "framerate",
				reg: /^framerate:(\d+(?:$|\.\d+))/,
				format: "framerate:%s"
			},
			{
				name: "sourceFilter",
				reg: /^source-filter: *(excl|incl) (\S*) (IP4|IP6|\*) (\S*) (.*)/,
				names: [
					"filterMode",
					"netType",
					"addressTypes",
					"destAddress",
					"srcList"
				],
				format: "source-filter: %s %s %s %s %s"
			},
			{
				name: "bundleOnly",
				reg: /^(bundle-only)/
			},
			{
				name: "label",
				reg: /^label:(.+)/,
				format: "label:%s"
			},
			{
				name: "sctpPort",
				reg: /^sctp-port:(\d+)$/,
				format: "sctp-port:%s"
			},
			{
				name: "maxMessageSize",
				reg: /^max-message-size:(\d+)$/,
				format: "max-message-size:%s"
			},
			{
				push: "tsRefClocks",
				reg: /^ts-refclk:([^\s=]*)(?:=(\S*))?/,
				names: ["clksrc", "clksrcExt"],
				format: function(e) {
					return "ts-refclk:%s" + (e.clksrcExt == null ? "" : "=%s");
				}
			},
			{
				name: "mediaClk",
				reg: /^mediaclk:(?:id=(\S*))? *([^\s=]*)(?:=(\S*))?(?: *rate=(\d+)\/(\d+))?/,
				names: [
					"id",
					"mediaClockName",
					"mediaClockValue",
					"rateNumerator",
					"rateDenominator"
				],
				format: function(e) {
					var t = "mediaclk:";
					return t += e.id == null ? "%v%s" : "id=%s %s", t += e.mediaClockValue == null ? "" : "=%s", t += e.rateNumerator == null ? "" : " rate=%s", t += e.rateDenominator == null ? "" : "/%s", t;
				}
			},
			{
				name: "keywords",
				reg: /^keywds:(.+)$/,
				format: "keywds:%s"
			},
			{
				name: "content",
				reg: /^content:(.+)/,
				format: "content:%s"
			},
			{
				name: "bfcpFloorCtrl",
				reg: /^floorctrl:(c-only|s-only|c-s)/,
				format: "floorctrl:%s"
			},
			{
				name: "bfcpConfId",
				reg: /^confid:(\d+)/,
				format: "confid:%s"
			},
			{
				name: "bfcpUserId",
				reg: /^userid:(\d+)/,
				format: "userid:%s"
			},
			{
				name: "bfcpFloorId",
				reg: /^floorid:(.+) (?:m-stream|mstrm):(.+)/,
				names: ["id", "mStream"],
				format: "floorid:%s mstrm:%s"
			},
			{
				push: "invalid",
				names: ["value"]
			}
		]
	};
	return Object.keys(e).forEach(function(t) {
		e[t].forEach(function(e) {
			e.reg ||= /(.*)/, e.format ||= "%s";
		});
	}), Od.exports;
}
var jd;
function Md() {
	return jd ? Dd : (jd = 1, (function(e) {
		var t = function(e) {
			return String(Number(e)) === e ? Number(e) : e;
		}, n = function(e, n, r, i) {
			if (i && !r) n[i] = t(e[1]);
			else for (var a = 0; a < r.length; a += 1) e[a + 1] != null && (n[r[a]] = t(e[a + 1]));
		}, r = function(e, t, r) {
			var i = e.name && e.names;
			e.push && !t[e.push] ? t[e.push] = [] : i && !t[e.name] && (t[e.name] = {});
			var a = e.push ? {} : i ? t[e.name] : t;
			n(r.match(e.reg), a, e.names, e.name), e.push && t[e.push].push(a);
		}, i = Ad(), a = RegExp.prototype.test.bind(/^([a-z])=(.*)/);
		e.parse = function(e) {
			var t = {}, n = [], o = t;
			return e.split(/(\r\n|\r|\n)/).filter(a).forEach(function(e) {
				var t = e[0], a = e.slice(2);
				t === "m" && (n.push({
					rtp: [],
					fmtp: []
				}), o = n[n.length - 1]);
				for (var s = 0; s < (i[t] || []).length; s += 1) {
					var c = i[t][s];
					if (c.reg.test(a)) return r(c, o, a);
				}
			}), t.media = n, t;
		};
		var o = function(e, n) {
			var r = n.split(/=(.+)/, 2);
			return r.length === 2 ? e[r[0]] = t(r[1]) : r.length === 1 && n.length > 1 && (e[r[0]] = void 0), e;
		};
		e.parseParams = function(e) {
			return e.split(/;\s?/).reduce(o, {});
		}, e.parseFmtpConfig = e.parseParams, e.parsePayloads = function(e) {
			return e.toString().split(" ").map(Number);
		}, e.parseRemoteCandidates = function(e) {
			for (var n = [], r = e.split(" ").map(t), i = 0; i < r.length; i += 3) n.push({
				component: r[i],
				ip: r[i + 1],
				port: r[i + 2]
			});
			return n;
		}, e.parseImageAttributes = function(e) {
			return e.split(" ").map(function(e) {
				return e.substring(1, e.length - 1).split(",").reduce(o, {});
			});
		}, e.parseSimulcastStreamList = function(e) {
			return e.split(";").map(function(e) {
				return e.split(",").map(function(e) {
					var n, r = !1;
					return e[0] === "~" ? (n = t(e.substring(1, e.length)), r = !0) : n = t(e), {
						scid: n,
						paused: r
					};
				});
			});
		};
	})(Dd), Dd);
}
var Nd, Pd;
function Fd() {
	if (Pd) return Nd;
	Pd = 1;
	var e = Ad(), t = /%[sdv%]/g, n = function(e) {
		var n = 1, r = arguments, i = r.length;
		return e.replace(t, function(e) {
			if (n >= i) return e;
			var t = r[n];
			switch (n += 1, e) {
				case "%%": return "%";
				case "%s": return String(t);
				case "%d": return Number(t);
				case "%v": return "";
			}
		});
	}, r = function(e, t, r) {
		var i = t.format instanceof Function ? t.format(t.push ? r : r[t.name]) : t.format, a = [e + "=" + i];
		if (t.names) for (var o = 0; o < t.names.length; o += 1) {
			var s = t.names[o];
			t.name ? a.push(r[t.name][s]) : a.push(r[t.names[o]]);
		}
		else a.push(r[t.name]);
		return n.apply(null, a);
	}, i = [
		"v",
		"o",
		"s",
		"i",
		"u",
		"e",
		"p",
		"c",
		"b",
		"t",
		"r",
		"z",
		"a"
	], a = [
		"i",
		"c",
		"b",
		"a"
	];
	return Nd = function(t, n) {
		n ||= {}, t.version ??= 0, t.name ??= " ", t.media.forEach(function(e) {
			e.payloads ??= "";
		});
		var o = n.outerOrder || i, s = n.innerOrder || a, c = [];
		return o.forEach(function(n) {
			e[n].forEach(function(e) {
				e.name in t && t[e.name] != null ? c.push(r(n, e, t)) : e.push in t && t[e.push] != null && t[e.push].forEach(function(t) {
					c.push(r(n, e, t));
				});
			});
		}), t.media.forEach(function(t) {
			c.push(r("m", e.m[0], t)), s.forEach(function(n) {
				e[n].forEach(function(e) {
					e.name in t && t[e.name] != null ? c.push(r(n, e, t)) : e.push in t && t[e.push] != null && t[e.push].forEach(function(t) {
						c.push(r(n, e, t));
					});
				});
			});
		}), c.join("\r\n") + "\r\n";
	}, Nd;
}
var Id;
function Ld() {
	if (Id) return Ed;
	Id = 1;
	var e = Md(), t = Fd();
	return Ed.grammar = Ad(), Ed.write = t, Ed.parse = e.parse, Ed.parseParams = e.parseParams, Ed.parseFmtpConfig = e.parseFmtpConfig, Ed.parsePayloads = e.parsePayloads, Ed.parseRemoteCandidates = e.parseRemoteCandidates, Ed.parseImageAttributes = e.parseImageAttributes, Ed.parseSimulcastStreamList = e.parseSimulcastStreamList, Ed;
}
var Rd = Ld(), zd = .7, Bd = 20, Vd = {
	NegotiationStarted: "negotiationStarted",
	NegotiationComplete: "negotiationComplete",
	OfferAnswered: "offerAnswered",
	RTPVideoPayloadTypes: "rtpVideoPayloadTypes"
}, Hd = class extends $o.EventEmitter {
	get pc() {
		return this._pc ||= this.createPC(), this._pc;
	}
	constructor(e) {
		let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
		super(), this.log = A, this.ddExtID = 0, this.latestOfferId = 0, this.latestAcknowledgedOfferId = 0, this.pendingCandidates = [], this.restartingIce = !1, this.renegotiate = !1, this.trackBitrates = [], this.remoteStereoMids = [], this.remoteNackMids = [], this.negotiate = Ru((e) => j(this, void 0, void 0, function* () {
			this.emit(Vd.NegotiationStarted);
			try {
				yield this.createAndSendOffer();
			} catch (t) {
				if (e) e(t);
				else throw t;
			}
		}), Bd), this.close = () => {
			this._pc &&= (this.pendingInitialOffer = void 0, this._pc.close(), this._pc.onconnectionstatechange = null, this._pc.oniceconnectionstatechange = null, this._pc.onicegatheringstatechange = null, this._pc.ondatachannel = null, this._pc.onnegotiationneeded = null, this._pc.onsignalingstatechange = null, this._pc.onicecandidate = null, this._pc.ondatachannel = null, this._pc.ontrack = null, this._pc.onconnectionstatechange = null, this._pc.oniceconnectionstatechange = null, null);
		}, this.log = Lo(t.loggerName ?? k.PCTransport), this.loggerOptions = t, this.config = e, this._pc = this.createPC(), this.offerLock = new v();
	}
	createPC() {
		let e = new RTCPeerConnection(this.config);
		return e.onicecandidate = (e) => {
			var t;
			e.candidate && ((t = this.onIceCandidate) == null || t.call(this, e.candidate));
		}, e.onicecandidateerror = (e) => {
			var t;
			(t = this.onIceCandidateError) == null || t.call(this, e);
		}, e.oniceconnectionstatechange = () => {
			var t;
			(t = this.onIceConnectionStateChange) == null || t.call(this, e.iceConnectionState);
		}, e.onsignalingstatechange = () => {
			var t;
			(t = this.onSignalingStatechange) == null || t.call(this, e.signalingState);
		}, e.onconnectionstatechange = () => {
			var t;
			(t = this.onConnectionStateChange) == null || t.call(this, e.connectionState);
		}, e.ondatachannel = (e) => {
			var t;
			(t = this.onDataChannel) == null || t.call(this, e);
		}, e.ontrack = (e) => {
			var t;
			(t = this.onTrack) == null || t.call(this, e);
		}, e;
	}
	get logContext() {
		var e;
		return Object.assign({}, (e = this.loggerOptions).loggerContextCb?.call(e));
	}
	get isICEConnected() {
		return this._pc !== null && (this.pc.iceConnectionState === "connected" || this.pc.iceConnectionState === "completed");
	}
	addIceCandidate(e) {
		return j(this, void 0, void 0, function* () {
			if (this.pc.remoteDescription && !this.restartingIce) return this.pc.addIceCandidate(e);
			this.pendingCandidates.push(e);
		});
	}
	setRemoteDescription(e, t) {
		return j(this, void 0, void 0, function* () {
			if (e.type === "answer" && this.latestOfferId > 0 && t > 0 && t !== this.latestOfferId) return this.log.warn("ignoring answer for old offer", Object.assign(Object.assign({}, this.logContext), {
				offerId: t,
				latestOfferId: this.latestOfferId
			})), !1;
			let n;
			if (e.type === "offer") {
				let t = Wd(e), n = t.stereoMids, r = t.nackMids;
				this.remoteStereoMids = n, this.remoteNackMids = r;
			} else if (e.type === "answer") {
				if (this.pendingInitialOffer && this._pc) {
					let e = this.pendingInitialOffer;
					this.pendingInitialOffer = void 0;
					let t = Rd.parse(e.sdp ?? "");
					t.media.forEach((e) => {
						Gd(e);
					}), this.log.debug("setting pending initial offer before processing answer", this.logContext), yield this.setMungedSDP(e, Rd.write(t));
				}
				let t = Rd.parse(e.sdp ?? "");
				t.media.forEach((e) => {
					let t = Kd(e.mid);
					e.type === "audio" && this.trackBitrates.some((n) => {
						if (!n.transceiver || t != n.transceiver.mid) return !1;
						let r = 0;
						if (e.rtp.some((e) => e.codec.toUpperCase() === n.codec.toUpperCase() ? (r = e.payload, !0) : !1), r === 0) return !0;
						let i = !1;
						for (let t of e.fmtp) if (t.payload === r) {
							t.config = t.config.split(";").filter((e) => !e.includes("maxaveragebitrate")).join(";"), n.maxbr > 0 && (t.config += `;maxaveragebitrate=${n.maxbr * 1e3}`), i = !0;
							break;
						}
						return i || n.maxbr > 0 && e.fmtp.push({
							payload: r,
							config: `maxaveragebitrate=${n.maxbr * 1e3}`
						}), !0;
					});
				}), n = Rd.write(t);
			}
			return yield this.setMungedSDP(e, n, !0), this.pendingCandidates.forEach((e) => {
				this.pc.addIceCandidate(e);
			}), this.pendingCandidates = [], this.restartingIce = !1, e.type === "answer" && (this.latestAcknowledgedOfferId = t, this.emit(Vd.OfferAnswered, t)), this.renegotiate ? (this.renegotiate = !1, yield this.createAndSendOffer()) : e.type === "answer" && (this.emit(Vd.NegotiationComplete), e.sdp && Rd.parse(e.sdp).media.forEach((e) => {
				e.type === "video" && this.emit(Vd.RTPVideoPayloadTypes, e.rtp);
			})), !0;
		});
	}
	createInitialOffer() {
		return j(this, void 0, void 0, function* () {
			let e = yield this.offerLock.lock();
			try {
				if (this.pc.signalingState !== "stable") {
					this.log.warn("signaling state is not stable, cannot create initial offer", this.logContext);
					return;
				}
				let e = this.latestOfferId + 1;
				this.latestOfferId = e;
				let t = yield this.pc.createOffer();
				this.pendingInitialOffer = {
					sdp: t.sdp,
					type: t.type
				};
				let n = Rd.parse(t.sdp ?? "");
				return n.media.forEach((e) => {
					Gd(e);
				}), t.sdp = Rd.write(n), {
					offer: t,
					offerId: e
				};
			} finally {
				e();
			}
		});
	}
	createAndSendOffer(e) {
		return j(this, void 0, void 0, function* () {
			let t = yield this.offerLock.lock();
			try {
				if (this.onOffer === void 0) return;
				if (e?.iceRestart && (this.log.debug("restarting ICE", this.logContext), this.restartingIce = !0), this._pc && (this._pc.signalingState === "have-local-offer" || this.pendingInitialOffer)) {
					let t = this._pc.remoteDescription;
					if (e?.iceRestart && t) yield this._pc.setRemoteDescription(t);
					else {
						this.renegotiate = !0, this.log.debug("requesting renegotiation", Object.assign({}, this.logContext));
						return;
					}
				} else if (!this._pc || this._pc.signalingState === "closed") {
					this.log.warn("could not createOffer with closed peer connection", this.logContext);
					return;
				}
				this.log.debug("starting to negotiate", this.logContext);
				let t = this.latestOfferId + 1;
				this.latestOfferId = t;
				let n = yield this.pc.createOffer(e);
				this.log.debug("original offer", Object.assign({ sdp: n.sdp }, this.logContext));
				let r = Rd.parse(n.sdp ?? "");
				if (r.media.forEach((e) => {
					Gd(e), e.type === "audio" ? Ud(e, ["all"], []) : e.type === "video" && this.trackBitrates.some((t) => {
						if (!e.msid || !t.cid || !e.msid.includes(t.cid)) return !1;
						let n = 0;
						if (e.rtp.some((e) => e.codec.toUpperCase() === t.codec.toUpperCase() ? (n = e.payload, !0) : !1), n === 0 || (vl(t.codec) && !wl() && this.ensureVideoDDExtensionForSVC(e, r), !vl(t.codec))) return !0;
						let i = Math.round(t.maxbr * zd);
						for (let t of e.fmtp) if (t.payload === n) {
							t.config.includes("x-google-start-bitrate") || (t.config += `;x-google-start-bitrate=${i}`);
							break;
						}
						return !0;
					});
				}), this.latestOfferId > t) {
					this.log.warn("latestOfferId mismatch", Object.assign(Object.assign({}, this.logContext), {
						latestOfferId: this.latestOfferId,
						offerId: t
					}));
					return;
				}
				yield this.setMungedSDP(n, Rd.write(r)), this.onOffer(n, this.latestOfferId);
			} finally {
				t();
			}
		});
	}
	createAndSetAnswer() {
		return j(this, void 0, void 0, function* () {
			let e = yield this.pc.createAnswer(), t = Rd.parse(e.sdp ?? "");
			return t.media.forEach((e) => {
				Gd(e), e.type === "audio" && Ud(e, this.remoteStereoMids, this.remoteNackMids);
			}), yield this.setMungedSDP(e, Rd.write(t)), e;
		});
	}
	createDataChannel(e, t) {
		return this.pc.createDataChannel(e, t);
	}
	addTransceiver(e, t) {
		return this.pc.addTransceiver(e, t);
	}
	addTransceiverOfKind(e, t) {
		return this.pc.addTransceiver(e, t);
	}
	addTrack(e) {
		if (!this._pc) throw new P("PC closed, cannot add track");
		return this._pc.addTrack(e);
	}
	setTrackCodecBitrate(e) {
		this.trackBitrates.push(e);
	}
	setConfiguration(e) {
		if (!this._pc) throw new P("PC closed, cannot configure");
		return this._pc?.setConfiguration(e);
	}
	canRemoveTrack() {
		return !!this._pc?.removeTrack;
	}
	removeTrack(e) {
		return this._pc?.removeTrack(e);
	}
	getConnectionState() {
		return this._pc?.connectionState ?? "closed";
	}
	getICEConnectionState() {
		return this._pc?.iceConnectionState ?? "closed";
	}
	getSignallingState() {
		return this._pc?.signalingState ?? "closed";
	}
	getTransceivers() {
		return this._pc?.getTransceivers() ?? [];
	}
	getSenders() {
		return this._pc?.getSenders() ?? [];
	}
	getLocalDescription() {
		return this._pc?.localDescription;
	}
	getRemoteDescription() {
		return this.pc?.remoteDescription;
	}
	getStats() {
		return this.pc.getStats();
	}
	getConnectedAddress() {
		return j(this, void 0, void 0, function* () {
			if (!this._pc) return;
			let e = "", t = /* @__PURE__ */ new Map(), n = /* @__PURE__ */ new Map();
			if ((yield this._pc.getStats()).forEach((r) => {
				switch (r.type) {
					case "transport":
						e = r.selectedCandidatePairId;
						break;
					case "candidate-pair":
						e === "" && r.selected && (e = r.id), t.set(r.id, r);
						break;
					case "remote-candidate":
						n.set(r.id, `${r.address}:${r.port}`);
						break;
				}
			}), e === "") return;
			let r = t.get(e)?.remoteCandidateId;
			if (r !== void 0) return n.get(r);
		});
	}
	setMungedSDP(e, t, n) {
		return j(this, void 0, void 0, function* () {
			let r = e.sdp;
			if (t) {
				e.sdp = t;
				try {
					this.log.debug(`setting munged ${n ? "remote" : "local"} description`, this.logContext), n ? yield this.pc.setRemoteDescription(e) : yield this.pc.setLocalDescription(e);
					return;
				} catch (n) {
					this.log.warn(`not able to set ${e.type}, falling back to unmodified sdp`, Object.assign(Object.assign({}, this.logContext), {
						error: n,
						mungedSdp: t,
						originalSdp: r
					})), e.sdp = r;
				}
			}
			try {
				n ? yield this._pc?.setRemoteDescription(e) : yield this._pc?.setLocalDescription(e);
			} catch (i) {
				let a = "unknown error";
				i instanceof Error ? a = i.message : typeof i == "string" && (a = i);
				let o = {
					error: a,
					sdp: e.sdp
				};
				throw t && t !== r && (o.mungedSdp = t), !n && this.pc.remoteDescription && (o.remoteSdp = this.pc.remoteDescription), this.log.error(`unable to set ${e.type}`, Object.assign(Object.assign({}, this.logContext), { fields: o })), new Ec(a);
			}
		});
	}
	ensureVideoDDExtensionForSVC(e, t) {
		var n;
		if (!e.ext?.some((e) => e.uri === dl)) {
			if (this.ddExtID === 0) {
				let e = 0;
				t.media.forEach((t) => {
					var n;
					(n = t.ext) == null || n.forEach((t) => {
						t.value > e && (e = t.value);
					});
				}), this.ddExtID = e + 1;
			}
			(n = e.ext) == null || n.push({
				value: this.ddExtID,
				uri: dl
			});
		}
	}
};
function Ud(e, t, n) {
	let r = Kd(e.mid), i = 0;
	e.rtp.some((e) => e.codec === "opus" ? (i = e.payload, !0) : !1), i > 0 && (e.rtcpFb ||= [], n.includes(r) && !e.rtcpFb.some((e) => e.payload === i && e.type === "nack") && e.rtcpFb.push({
		payload: i,
		type: "nack"
	}), (t.includes(r) || t.length === 1 && t[0] === "all") && e.fmtp.some((e) => e.payload === i ? (e.config.includes("stereo=1") || (e.config += ";stereo=1"), !0) : !1));
}
function Wd(e) {
	let t = [], n = [], r = Rd.parse(e.sdp ?? ""), i = 0;
	return r.media.forEach((e) => {
		let r = Kd(e.mid);
		e.type === "audio" && (e.rtp.some((e) => e.codec === "opus" ? (i = e.payload, !0) : !1), e.rtcpFb?.some((e) => e.payload === i && e.type === "nack") && n.push(r), e.fmtp.some((e) => e.payload === i ? (e.config.includes("sprop-stereo=1") && t.push(r), !0) : !1));
	}), {
		stereoMids: t,
		nackMids: n
	};
}
function Gd(e) {
	if (e.connection) {
		let t = e.connection.ip.indexOf(":") >= 0;
		(e.connection.version === 4 && t || e.connection.version === 6 && !t) && (e.connection.ip = "0.0.0.0", e.connection.version = 4);
	}
}
function Kd(e) {
	return typeof e == "number" ? e.toFixed(0) : e;
}
var qd = "vp8", Jd = {
	audioPreset: zc.music,
	dtx: !0,
	red: !0,
	forceStereo: !1,
	simulcast: !0,
	screenShareEncoding: Hc.h1080fps15.encoding,
	stopMicTrackOnMute: !1,
	videoCodec: qd,
	backupCodec: !0,
	preConnectBuffer: !1
}, Yd = {
	deviceId: { ideal: "default" },
	autoGainControl: !0,
	echoCancellation: !0,
	noiseSuppression: !0,
	voiceIsolation: !0
}, Xd = {
	deviceId: { ideal: "default" },
	resolution: Bc.h720.resolution
}, Zd = {
	adaptiveStream: !1,
	dynacast: !1,
	stopLocalTrackOnUnpublish: !0,
	reconnectPolicy: new Uo(),
	disconnectOnPageLeave: !0,
	webAudioMix: !1,
	singlePeerConnection: !0
}, Qd = {
	autoSubscribe: !0,
	maxRetries: 1,
	peerConnectionTimeout: 15e3,
	websocketTimeout: 15e3
}, G;
(function(e) {
	e[e.NEW = 0] = "NEW", e[e.CONNECTING = 1] = "CONNECTING", e[e.CONNECTED = 2] = "CONNECTED", e[e.FAILED = 3] = "FAILED", e[e.CLOSING = 4] = "CLOSING", e[e.CLOSED = 5] = "CLOSED";
})(G ||= {});
var $d = class {
	get needsPublisher() {
		return this.isPublisherConnectionRequired;
	}
	get needsSubscriber() {
		return this.isSubscriberConnectionRequired;
	}
	get currentState() {
		return this.state;
	}
	get mode() {
		return this._mode;
	}
	constructor(e, t, n) {
		this.peerConnectionTimeout = Qd.peerConnectionTimeout, this.log = A, this.updateState = () => {
			var e;
			let t = this.state, n = this.requiredTransports.map((e) => e.getConnectionState());
			n.every((e) => e === "connected") ? this.state = G.CONNECTED : n.some((e) => e === "failed") ? this.state = G.FAILED : n.some((e) => e === "connecting") ? this.state = G.CONNECTING : n.every((e) => e === "closed") ? this.state = G.CLOSED : n.some((e) => e === "closed") ? this.state = G.CLOSING : n.every((e) => e === "new") && (this.state = G.NEW), t !== this.state && (this.log.debug(`pc state change: from ${G[t]} to ${G[this.state]}`, this.logContext), (e = this.onStateChange) == null || e.call(this, this.state, this.publisher.getConnectionState(), this.subscriber?.getConnectionState()));
		}, this.log = Lo(t.loggerName ?? k.PCManager), this.loggerOptions = t, this.isPublisherConnectionRequired = e !== "subscriber-primary", this.isSubscriberConnectionRequired = e === "subscriber-primary", this.publisher = new Hd(n, t), this._mode = e, e !== "publisher-only" && (this.subscriber = new Hd(n, t), this.subscriber.onConnectionStateChange = this.updateState, this.subscriber.onIceConnectionStateChange = this.updateState, this.subscriber.onSignalingStatechange = this.updateState, this.subscriber.onIceCandidate = (e) => {
			var t;
			(t = this.onIceCandidate) == null || t.call(this, e, ya.SUBSCRIBER);
		}, this.subscriber.onDataChannel = (e) => {
			var t;
			(t = this.onDataChannel) == null || t.call(this, e);
		}, this.subscriber.onTrack = (e) => {
			var t;
			(t = this.onTrack) == null || t.call(this, e);
		}), this.publisher.onConnectionStateChange = this.updateState, this.publisher.onIceConnectionStateChange = this.updateState, this.publisher.onSignalingStatechange = this.updateState, this.publisher.onIceCandidate = (e) => {
			var t;
			(t = this.onIceCandidate) == null || t.call(this, e, ya.PUBLISHER);
		}, this.publisher.onTrack = (e) => {
			var t;
			(t = this.onTrack) == null || t.call(this, e);
		}, this.publisher.onOffer = (e, t) => {
			var n;
			(n = this.onPublisherOffer) == null || n.call(this, e, t);
		}, this.state = G.NEW, this.connectionLock = new v(), this.remoteOfferLock = new v();
	}
	get logContext() {
		var e;
		return Object.assign({}, (e = this.loggerOptions).loggerContextCb?.call(e));
	}
	requirePublisher() {
		let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : !0;
		this.isPublisherConnectionRequired = e, this.updateState();
	}
	createAndSendPublisherOffer(e) {
		return this.publisher.createAndSendOffer(e);
	}
	setPublisherAnswer(e, t) {
		return this.publisher.setRemoteDescription(e, t);
	}
	removeTrack(e) {
		return this.publisher.removeTrack(e);
	}
	close() {
		return j(this, void 0, void 0, function* () {
			if (this.publisher && this.publisher.getSignallingState() !== "closed") {
				let e = this.publisher;
				for (let t of e.getSenders()) try {
					e.canRemoveTrack() && e.removeTrack(t);
				} catch (e) {
					this.log.warn("could not removeTrack", Object.assign(Object.assign({}, this.logContext), { error: e }));
				}
			}
			yield Promise.all([this.publisher.close(), this.subscriber?.close()]), this.updateState();
		});
	}
	triggerIceRestart() {
		return j(this, void 0, void 0, function* () {
			this.subscriber && (this.subscriber.restartingIce = !0), this.needsPublisher && (yield this.createAndSendPublisherOffer({ iceRestart: !0 }));
		});
	}
	addIceCandidate(e, t) {
		return j(this, void 0, void 0, function* () {
			t === ya.PUBLISHER ? yield this.publisher.addIceCandidate(e) : yield this.subscriber?.addIceCandidate(e);
		});
	}
	createSubscriberAnswerFromOffer(e, t) {
		return j(this, void 0, void 0, function* () {
			this.log.debug("received server offer", Object.assign(Object.assign({}, this.logContext), {
				RTCSdpType: e.type,
				sdp: e.sdp,
				signalingState: this.subscriber?.getSignallingState().toString()
			}));
			let n = yield this.remoteOfferLock.lock();
			try {
				return (yield this.subscriber?.setRemoteDescription(e, t)) ? yield this.subscriber?.createAndSetAnswer() : void 0;
			} finally {
				n();
			}
		});
	}
	updateConfiguration(e, t) {
		var n;
		this.publisher.setConfiguration(e), (n = this.subscriber) == null || n.setConfiguration(e), t && this.triggerIceRestart();
	}
	ensurePCTransportConnection(e, t) {
		return j(this, void 0, void 0, function* () {
			let n = yield this.connectionLock.lock();
			try {
				this.isPublisherConnectionRequired && this.publisher.getConnectionState() !== "connected" && this.publisher.getConnectionState() !== "connecting" && (this.log.debug("negotiation required, start negotiating", this.logContext), this.publisher.negotiate()), yield Promise.all(this.requiredTransports?.map((n) => this.ensureTransportConnected(n, e, t)));
			} finally {
				n();
			}
		});
	}
	negotiate(e) {
		return j(this, void 0, void 0, function* () {
			return new pc((t, n) => {
				let r = this.publisher.latestOfferId;
				if (this.publisher.latestAcknowledgedOfferId > r) {
					this.log.debug("negotiation already handled in more recent acknowledged offer", this.logContext), t();
					return;
				}
				let i = !1, a = () => {
					i || (i = !0, clearTimeout(c), this.publisher.off(Vd.OfferAnswered, o), e.signal.removeEventListener("abort", s));
				}, o = (e) => {
					e > r && (a(), t());
				}, s = () => {
					a(), n(new Ec("negotiation aborted"));
				}, c = setTimeout(() => {
					a(), n(new Ec("negotiation timed out"));
				}, this.peerConnectionTimeout);
				e.signal.addEventListener("abort", s), this.publisher.on(Vd.OfferAnswered, o), this.publisher.negotiate((e) => {
					a(), e instanceof Error ? n(e) : n(Error(String(e)));
				});
			});
		});
	}
	addPublisherTransceiver(e, t) {
		return this.publisher.addTransceiver(e, t);
	}
	addPublisherTransceiverOfKind(e, t) {
		return this.publisher.addTransceiverOfKind(e, t);
	}
	getMidForReceiver(e) {
		return (this.subscriber ? this.subscriber.getTransceivers() : this.publisher.getTransceivers()).find((t) => t.receiver === e)?.mid;
	}
	addPublisherTrack(e) {
		return this.publisher.addTrack(e);
	}
	createPublisherDataChannel(e, t) {
		return this.publisher.createDataChannel(e, t);
	}
	getConnectedAddress(e) {
		return e === ya.PUBLISHER || e === ya.SUBSCRIBER ? this.publisher.getConnectedAddress() : this.requiredTransports[0].getConnectedAddress();
	}
	get requiredTransports() {
		let e = [];
		return this.isPublisherConnectionRequired && e.push(this.publisher), this.isSubscriberConnectionRequired && this.subscriber && e.push(this.subscriber), e;
	}
	ensureTransportConnected(e, t) {
		return j(this, arguments, void 0, function(e, t) {
			var n = this;
			let r = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : this.peerConnectionTimeout;
			return function* () {
				if (e.getConnectionState() !== "connected") return new Promise((e, i) => j(n, void 0, void 0, function* () {
					let n = () => {
						this.log.warn("abort transport connection", this.logContext), F.clearTimeout(a), i(N.cancelled("room connection has been cancelled"));
					};
					t?.signal.aborted && n(), t?.signal.addEventListener("abort", n);
					let a = F.setTimeout(() => {
						t?.signal.removeEventListener("abort", n), i(N.internal("could not establish pc connection"));
					}, r);
					for (; this.state !== G.CONNECTED;) if (yield pl(50), t?.signal.aborted) {
						i(N.cancelled("room connection has been cancelled"));
						return;
					}
					F.clearTimeout(a), t?.signal.removeEventListener("abort", n), e();
				}));
			}();
		});
	}
}, ef = typeof MediaRecorder < "u", tf = ef ? MediaRecorder : class {
	constructor() {
		throw Error("MediaRecorder is not available in this environment");
	}
}, nf = class extends tf {
	constructor(e, t) {
		if (!ef) throw Error("MediaRecorder is not available in this environment");
		super(new MediaStream([e.mediaStreamTrack]), t);
		let n, r, i = () => r === void 0, a = () => {
			this.removeEventListener("dataavailable", n), this.removeEventListener("stop", a), this.removeEventListener("error", o), r?.close(), r = void 0;
		}, o = (e) => {
			r?.error(e), this.removeEventListener("dataavailable", n), this.removeEventListener("stop", a), this.removeEventListener("error", o), r = void 0;
		};
		this.byteStream = new ReadableStream({
			start: (e) => {
				r = e, n = (t) => j(this, void 0, void 0, function* () {
					let n;
					if (t.data.arrayBuffer) {
						let e = yield t.data.arrayBuffer();
						n = new Uint8Array(e);
					} else if (t.data.byteArray) n = t.data.byteArray;
					else throw Error("no data available!");
					i() || e.enqueue(n);
				}), this.addEventListener("dataavailable", n);
			},
			cancel: () => {
				a();
			}
		}), this.addEventListener("stop", a), this.addEventListener("error", o);
	}
};
function rf() {
	return ef;
}
var af = 1e3, of = 1e4, sf = class extends H {
	get sender() {
		return this._sender;
	}
	set sender(e) {
		this._sender = e;
	}
	get constraints() {
		return this._constraints;
	}
	get hasPreConnectBuffer() {
		return !!this.localTrackRecorder;
	}
	constructor(e, t, n) {
		let r = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : !1, i = arguments.length > 4 ? arguments[4] : void 0;
		super(e, t, i), this.manuallyStopped = !1, this.pendingDeviceChange = !1, this._isUpstreamPaused = !1, this.handleTrackMuteEvent = () => this.debouncedTrackMuteHandler().catch(() => this.log.debug("track mute bounce got cancelled by an unmute event", this.logContext)), this.debouncedTrackMuteHandler = Ru(() => j(this, void 0, void 0, function* () {
			yield this.pauseUpstream();
		}), 5e3), this.handleTrackUnmuteEvent = () => j(this, void 0, void 0, function* () {
			this.debouncedTrackMuteHandler.cancel("unmute"), yield this.resumeUpstream();
		}), this.handleEnded = () => {
			this.isInBackground && (this.reacquireTrack = !0), this._mediaStreamTrack.removeEventListener("mute", this.handleTrackMuteEvent), this._mediaStreamTrack.removeEventListener("unmute", this.handleTrackUnmuteEvent), this.emit(z.Ended, this);
		}, this.reacquireTrack = !1, this.providedByUser = r, this.muteLock = new v(), this.pauseUpstreamLock = new v(), this.trackChangeLock = new v(), this.trackChangeLock.lock().then((t) => j(this, void 0, void 0, function* () {
			try {
				yield this.setMediaStreamTrack(e, !0);
			} finally {
				t();
			}
		})), this._constraints = e.getConstraints(), n && (this._constraints = n);
	}
	get id() {
		return this._mediaStreamTrack.id;
	}
	get dimensions() {
		if (this.kind !== H.Kind.Video) return;
		let e = this._mediaStreamTrack.getSettings(), t = e.width, n = e.height;
		if (t && n) return {
			width: t,
			height: n
		};
	}
	get isUpstreamPaused() {
		return this._isUpstreamPaused;
	}
	get isUserProvided() {
		return this.providedByUser;
	}
	get mediaStreamTrack() {
		return this.processor?.processedTrack ?? this._mediaStreamTrack;
	}
	get isLocal() {
		return !0;
	}
	getSourceTrackSettings() {
		return this._mediaStreamTrack.getSettings();
	}
	setMediaStreamTrack(e, t, n) {
		return j(this, void 0, void 0, function* () {
			if (e === this._mediaStreamTrack && !t) return;
			this._mediaStreamTrack && (this.attachedElements.forEach((e) => {
				ll(this._mediaStreamTrack, e);
			}), this.debouncedTrackMuteHandler.cancel("new-track"), this._mediaStreamTrack.removeEventListener("ended", this.handleEnded), this._mediaStreamTrack.removeEventListener("mute", this.handleTrackMuteEvent), this._mediaStreamTrack.removeEventListener("unmute", this.handleTrackUnmuteEvent)), this.mediaStream = new MediaStream([e]), e && (e.addEventListener("ended", this.handleEnded), e.addEventListener("mute", this.handleTrackMuteEvent), e.addEventListener("unmute", this.handleTrackUnmuteEvent), this._constraints = e.getConstraints());
			let r;
			if (this.processor && e) {
				if (this.log.debug("restarting processor", this.logContext), this.kind === "unknown") throw TypeError("cannot set processor on track of unknown kind");
				this.processorElement && (cl(e, this.processorElement), this.processorElement.muted = !0), yield this.processor.restart({
					track: e,
					kind: this.kind,
					element: this.processorElement,
					localTrack: this
				}), r = this.processor.processedTrack;
			}
			this.sender && this.sender.transport?.state !== "closed" && (yield this.sender.replaceTrack(r ?? e)), !this.providedByUser && this._mediaStreamTrack !== e && this._mediaStreamTrack.stop(), this._mediaStreamTrack = e, e && (this._mediaStreamTrack.enabled = n ? !0 : !this.isMuted, yield this.resumeUpstream(), this.attachedElements.forEach((t) => {
				cl(r ?? e, t);
			}));
		});
	}
	waitForDimensions() {
		return j(this, arguments, void 0, function() {
			var e = this;
			let t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : af;
			return function* () {
				if (e.kind === H.Kind.Audio) throw Error("cannot get dimensions for audio tracks");
				gc()?.os === "iOS" && (yield pl(10));
				let n = Date.now();
				for (; Date.now() - n < t;) {
					let t = e.dimensions;
					if (t) return t;
					yield pl(50);
				}
				throw new wc("unable to get track dimensions after timeout");
			}();
		});
	}
	setDeviceId(e) {
		return j(this, void 0, void 0, function* () {
			return this._constraints.deviceId === e && this._mediaStreamTrack.getSettings().deviceId === Yl(e) ? !0 : (this._constraints.deviceId = e, this.isMuted ? (this.pendingDeviceChange = !0, !0) : (yield this.restartTrack(), Yl(e) === this._mediaStreamTrack.getSettings().deviceId));
		});
	}
	getDeviceId() {
		return j(this, arguments, void 0, function() {
			var e = this;
			let t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : !0;
			return function* () {
				if (e.source === H.Source.ScreenShare) return;
				let n = e._mediaStreamTrack.getSettings(), r = n.deviceId, i = n.groupId, a = e.kind === H.Kind.Audio ? "audioinput" : "videoinput";
				return t ? td.getInstance().normalizeDeviceId(a, r, i) : r;
			}();
		});
	}
	mute() {
		return j(this, void 0, void 0, function* () {
			return this.setTrackMuted(!0), this;
		});
	}
	unmute() {
		return j(this, void 0, void 0, function* () {
			return this.setTrackMuted(!1), this;
		});
	}
	replaceTrack(e, t) {
		return j(this, void 0, void 0, function* () {
			let n = yield this.trackChangeLock.lock();
			try {
				if (!this.sender) throw new wc("unable to replace an unpublished track");
				let n, r;
				typeof t == "boolean" ? n = t : t !== void 0 && (n = t.userProvidedTrack, r = t.stopProcessor), this.providedByUser = n ?? !0, this.log.debug("replace MediaStreamTrack", this.logContext), yield this.setMediaStreamTrack(e), r && this.processor && (yield this.internalStopProcessor());
			} finally {
				n();
			}
			return yield this.onSenderTrackSwapped(), this;
		});
	}
	onSenderTrackSwapped() {
		return j(this, void 0, void 0, function* () {});
	}
	restart(e, t) {
		return j(this, void 0, void 0, function* () {
			this.manuallyStopped = !1;
			let n = yield this.trackChangeLock.lock();
			try {
				e ||= this._constraints;
				let n = e, r = n.deviceId, i = n.facingMode, a = Wo(e, ["deviceId", "facingMode"]);
				this.log.debug("restarting track with constraints", Object.assign(Object.assign({}, this.logContext), { constraints: e }));
				let o = {
					audio: !1,
					video: !1
				};
				this.kind === H.Kind.Video ? o.video = r || i ? {
					deviceId: r,
					facingMode: i
				} : !0 : o.audio = r ? Object.assign({ deviceId: r }, a) : !0, this.attachedElements.forEach((e) => {
					ll(this.mediaStreamTrack, e);
				}), this._mediaStreamTrack.removeEventListener("ended", this.handleEnded), this._mediaStreamTrack.stop();
				let s = (yield navigator.mediaDevices.getUserMedia(o)).getTracks()[0];
				return this.kind === H.Kind.Video && (yield s.applyConstraints(a)), s.addEventListener("ended", this.handleEnded), this.log.debug("re-acquired MediaStreamTrack", this.logContext), yield this.setMediaStreamTrack(s, !1, t), this._constraints = e, this.pendingDeviceChange = !1, this.emit(z.Restarted, this), this.manuallyStopped && (this.log.warn("track was stopped during a restart, stopping restarted track", this.logContext), this.stop()), this;
			} finally {
				n();
			}
		});
	}
	setTrackMuted(e) {
		this.log.debug(`setting ${this.kind} track ${e ? "muted" : "unmuted"}`, this.logContext), !(this.isMuted === e && this._mediaStreamTrack.enabled !== e) && (this.isMuted = e, this._mediaStreamTrack.enabled = !e, this.emit(e ? z.Muted : z.Unmuted, this));
	}
	get needsReAcquisition() {
		return this._mediaStreamTrack.readyState !== "live" || this._mediaStreamTrack.muted || !this._mediaStreamTrack.enabled || this.reacquireTrack;
	}
	handleAppVisibilityChanged() {
		let e = Object.create(null, { handleAppVisibilityChanged: { get: () => super.handleAppVisibilityChanged } });
		return j(this, void 0, void 0, function* () {
			yield e.handleAppVisibilityChanged.call(this), Ol() && (this.log.debug(`visibility changed, is in Background: ${this.isInBackground}`, this.logContext), !this.isInBackground && this.needsReAcquisition && !this.isUserProvided && !this.isMuted && (this.log.debug(`track needs to be reacquired, restarting ${this.source}`, this.logContext), yield this.restart(), this.reacquireTrack = !1));
		});
	}
	stop() {
		var e;
		this.manuallyStopped = !0, super.stop(), this._mediaStreamTrack.removeEventListener("ended", this.handleEnded), this._mediaStreamTrack.removeEventListener("mute", this.handleTrackMuteEvent), this._mediaStreamTrack.removeEventListener("unmute", this.handleTrackUnmuteEvent), (e = this.processor) == null || e.destroy(), this.processor = void 0;
	}
	pauseUpstream() {
		return j(this, void 0, void 0, function* () {
			let e = yield this.pauseUpstreamLock.lock();
			try {
				if (this._isUpstreamPaused === !0) return;
				if (!this.sender) {
					this.log.warn("unable to pause upstream for an unpublished track", this.logContext);
					return;
				}
				this._isUpstreamPaused = !0, this.emit(z.UpstreamPaused, this);
				let e = gc();
				if (e?.name === "Safari" && Ll(e.version, "12.0") < 0) throw new Cc("pauseUpstream is not supported on Safari < 12.");
				this.sender.transport?.state !== "closed" && (yield this.sender.replaceTrack(null));
			} finally {
				e();
			}
		});
	}
	resumeUpstream() {
		return j(this, void 0, void 0, function* () {
			let e = yield this.pauseUpstreamLock.lock();
			try {
				if (this._isUpstreamPaused === !1) return;
				if (!this.sender) {
					this.log.warn("unable to resume upstream for an unpublished track", this.logContext);
					return;
				}
				this._isUpstreamPaused = !1, this.emit(z.UpstreamResumed, this), this.sender.transport?.state !== "closed" && (yield this.sender.replaceTrack(this.mediaStreamTrack));
			} finally {
				e();
			}
		});
	}
	getRTCStatsReport() {
		return j(this, void 0, void 0, function* () {
			if (this.sender?.getStats) return yield this.sender.getStats();
		});
	}
	setProcessor(e) {
		return j(this, arguments, void 0, function(e) {
			var t = this;
			let n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !0;
			return function* () {
				let r = yield t.trackChangeLock.lock();
				try {
					t.log.debug("setting up processor", t.logContext);
					let r = document.createElement(t.kind), i = {
						kind: t.kind,
						track: t._mediaStreamTrack,
						element: r,
						audioContext: t.audioContext,
						localTrack: t
					};
					if (yield e.init(i), t.log.debug("processor initialized", t.logContext), t.processor && (yield t.internalStopProcessor()), t.kind === "unknown") throw TypeError("cannot set processor on track of unknown kind");
					if (cl(t._mediaStreamTrack, r), r.muted = !0, r.play().catch((e) => {
						e instanceof DOMException && e.name === "AbortError" ? (t.log.warn("failed to play processor element, retrying", Object.assign(Object.assign({}, t.logContext), { error: e })), setTimeout(() => {
							r.play().catch((e) => {
								t.log.error("failed to play processor element", Object.assign(Object.assign({}, t.logContext), { err: e }));
							});
						}, 100)) : t.log.error("failed to play processor element", Object.assign(Object.assign({}, t.logContext), { error: e }));
					}), t.processor = e, t.processorElement = r, t.processor.processedTrack) {
						for (let e of t.attachedElements) e !== t.processorElement && n && (ll(t._mediaStreamTrack, e), cl(t.processor.processedTrack, e));
						yield t.sender?.replaceTrack(t.processor.processedTrack);
					}
					t.emit(z.TrackProcessorUpdate, t.processor);
				} finally {
					r();
				}
				yield t.onSenderTrackSwapped();
			}();
		});
	}
	getProcessor() {
		return this.processor;
	}
	stopProcessor() {
		return j(this, arguments, void 0, function() {
			var e = this;
			let t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : !0;
			return function* () {
				let n = yield e.trackChangeLock.lock();
				try {
					yield e.internalStopProcessor(t);
				} finally {
					n();
				}
				yield e.onSenderTrackSwapped();
			}();
		});
	}
	internalStopProcessor() {
		return j(this, arguments, void 0, function() {
			var e = this;
			let t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : !0;
			return function* () {
				var n, r;
				e.processor && (e.log.debug("stopping processor", e.logContext), (n = e.processor.processedTrack) == null || n.stop(), yield e.processor.destroy(), e.processor = void 0, t || ((r = e.processorElement) == null || r.remove(), e.processorElement = void 0), yield e._mediaStreamTrack.applyConstraints(e._constraints), yield e.setMediaStreamTrack(e._mediaStreamTrack, !0), e.emit(z.TrackProcessorUpdate));
			}();
		});
	}
	startPreConnectBuffer() {
		let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : 100;
		if (!rf()) {
			this.log.warn("MediaRecorder is not available, cannot start preconnect buffer", this.logContext);
			return;
		}
		if (this.localTrackRecorder) {
			this.log.warn("preconnect buffer already started");
			return;
		} else {
			let e = "audio/webm;codecs=opus";
			MediaRecorder.isTypeSupported(e) || (e = "video/mp4"), this.localTrackRecorder = new nf(this, { mimeType: e });
		}
		this.localTrackRecorder.start(e), this.autoStopPreConnectBuffer = setTimeout(() => {
			this.log.warn("preconnect buffer timed out, stopping recording automatically", this.logContext), this.stopPreConnectBuffer();
		}, of);
	}
	stopPreConnectBuffer() {
		clearTimeout(this.autoStopPreConnectBuffer), this.localTrackRecorder &&= (this.localTrackRecorder.stop(), void 0);
	}
	getPreConnectBuffer() {
		return this.localTrackRecorder?.byteStream;
	}
	getPreConnectBufferMimeType() {
		return this.localTrackRecorder?.mimeType;
	}
}, cf = class extends sf {
	get enhancedNoiseCancellation() {
		return this.isKrispNoiseFilterEnabled;
	}
	constructor(e, t) {
		let n = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : !0, r = arguments.length > 3 ? arguments[3] : void 0, i = arguments.length > 4 ? arguments[4] : void 0;
		super(e, H.Kind.Audio, t, n, i), this.stopOnMute = !1, this.isKrispNoiseFilterEnabled = !1, this.monitorSender = () => j(this, void 0, void 0, function* () {
			if (!this.sender) {
				this._currentBitrate = 0;
				return;
			}
			let e;
			try {
				e = yield this.getSenderStats();
			} catch (e) {
				this.log.error("could not get audio sender stats", Object.assign(Object.assign({}, this.logContext), { error: e }));
				return;
			}
			e && this.prevStats && (this._currentBitrate = Bu(e, this.prevStats)), this.prevStats = e;
		}), this.handleKrispNoiseFilterEnable = () => {
			this.isKrispNoiseFilterEnabled = !0, this.log.debug("Krisp noise filter enabled", this.logContext), this.emit(z.AudioTrackFeatureUpdate, this, D.TF_ENHANCED_NOISE_CANCELLATION, !0);
		}, this.handleKrispNoiseFilterDisable = () => {
			this.isKrispNoiseFilterEnabled = !1, this.log.debug("Krisp noise filter disabled", this.logContext), this.emit(z.AudioTrackFeatureUpdate, this, D.TF_ENHANCED_NOISE_CANCELLATION, !1);
		}, this.audioContext = r, this.checkForSilence();
	}
	mute() {
		let e = Object.create(null, { mute: { get: () => super.mute } });
		return j(this, void 0, void 0, function* () {
			let t = yield this.muteLock.lock();
			try {
				return this.isMuted ? (this.log.debug("Track already muted", this.logContext), this) : (this.source === H.Source.Microphone && this.stopOnMute && !this.isUserProvided && (this.log.debug("stopping mic track", this.logContext), this._mediaStreamTrack.stop()), yield e.mute.call(this), this);
			} finally {
				t();
			}
		});
	}
	unmute() {
		let e = Object.create(null, { unmute: { get: () => super.unmute } });
		return j(this, void 0, void 0, function* () {
			let t = yield this.muteLock.lock();
			try {
				return this.isMuted ? (this.source === H.Source.Microphone && (this.stopOnMute || this._mediaStreamTrack.readyState === "ended" || this.pendingDeviceChange) && !this.isUserProvided && (this.log.debug("reacquiring mic track", this.logContext), yield this.restart(void 0, !0)), yield e.unmute.call(this), this) : (this.log.debug("Track already unmuted", this.logContext), this);
			} finally {
				t();
			}
		});
	}
	restartTrack(e) {
		return j(this, void 0, void 0, function* () {
			let t;
			if (e) {
				let n = Gc({ audio: e });
				typeof n.audio != "boolean" && (t = n.audio);
			}
			yield this.restart(t);
		});
	}
	restart(e, t) {
		let n = Object.create(null, { restart: { get: () => super.restart } });
		return j(this, void 0, void 0, function* () {
			let r = yield n.restart.call(this, e, t);
			return this.checkForSilence(), r;
		});
	}
	startMonitor() {
		Al() && (this.monitorInterval ||= setInterval(() => {
			this.monitorSender();
		}, zu));
	}
	setProcessor(e) {
		return j(this, void 0, void 0, function* () {
			let t = yield this.trackChangeLock.lock();
			try {
				if (!jl() && !this.audioContext) throw Error("Audio context needs to be set on LocalAudioTrack in order to enable processors");
				this.processor && (yield this.internalStopProcessor());
				let t = {
					kind: this.kind,
					track: this._mediaStreamTrack,
					audioContext: this.audioContext,
					localTrack: this
				};
				this.log.debug(`setting up audio processor ${e.name}`, this.logContext), yield e.init(t), this.processor = e, this.processor.processedTrack && (yield this.sender?.replaceTrack(this.processor.processedTrack), this.processor.processedTrack.addEventListener("enable-lk-krisp-noise-filter", this.handleKrispNoiseFilterEnable), this.processor.processedTrack.addEventListener("disable-lk-krisp-noise-filter", this.handleKrispNoiseFilterDisable)), this.emit(z.TrackProcessorUpdate, this.processor);
			} finally {
				t();
			}
		});
	}
	setAudioContext(e) {
		this.audioContext = e;
	}
	getSenderStats() {
		return j(this, void 0, void 0, function* () {
			if (!this.sender?.getStats) return;
			let e = yield this.sender.getStats(), t;
			return e.forEach((e) => {
				e.type === "outbound-rtp" && (t = {
					type: "audio",
					streamId: e.id,
					packetsSent: e.packetsSent,
					packetsLost: e.packetsLost,
					bytesSent: e.bytesSent,
					timestamp: e.timestamp,
					roundTripTime: e.roundTripTime,
					jitter: e.jitter
				});
			}), t;
		});
	}
	checkForSilence() {
		return j(this, void 0, void 0, function* () {
			let e = yield Kc(this);
			return e && (this.isMuted || this.log.debug("silence detected on local audio track", this.logContext), this.emit(z.AudioSilenceDetected)), e;
		});
	}
};
function lf(e, t, n) {
	switch (e.kind) {
		case "audio": return new cf(e, t, !1, void 0, n);
		case "video": return new Df(e, t, !1, n);
		default: throw new wc(`unsupported track type: ${e.kind}`);
	}
}
var uf = Object.values(Bc), df = Object.values(Vc), ff = Object.values(Hc), pf = [Bc.h180, Bc.h360], mf = [Vc.h180, Vc.h360], hf = (e) => [{
	scaleResolutionDownBy: 2,
	fps: e.encoding.maxFramerate
}].map((t) => new B(Math.floor(e.width / t.scaleResolutionDownBy), Math.floor(e.height / t.scaleResolutionDownBy), Math.max(15e4, Math.floor(e.encoding.maxBitrate / (t.scaleResolutionDownBy ** 2 * ((e.encoding.maxFramerate ?? 30) / (t.fps ?? 30))))), t.fps, e.encoding.priority)), gf = [
	"q",
	"h",
	"f"
];
function _f(e, t, n, r) {
	let i = r?.videoEncoding;
	e && (i = r?.screenShareEncoding);
	let a = r?.simulcast, o = r?.scalabilityMode, s = r?.videoCodec;
	if (!i && !a && !o || !t || !n) return [{}];
	i || (i = yf(e, t, n, s), A.debug("using video encoding", i));
	let c = i.maxFramerate, l = new B(t, n, i.maxBitrate, i.maxFramerate, i.priority);
	if (o && vl(s)) {
		let e = new wf(o), t = [];
		if (e.spatial > 3) throw Error(`unsupported scalabilityMode: ${o}`);
		let n = gc();
		if (Tl() || jl() || n?.name === "Chrome" && Ll(n?.version, "113") < 0) {
			let r = e.suffix == "h" ? 2 : 3, a = Dl(n);
			for (let n = 0; n < e.spatial; n += 1) t.push({
				rid: gf[2 - n],
				maxBitrate: i.maxBitrate / r ** +n,
				maxFramerate: l.encoding.maxFramerate,
				scaleResolutionDownBy: a ? 2 ** n : void 0
			});
			t[0].scalabilityMode = o;
		} else t.push({
			maxBitrate: i.maxBitrate,
			maxFramerate: l.encoding.maxFramerate,
			scalabilityMode: o
		});
		return l.encoding.priority && (t[0].priority = l.encoding.priority, t[0].networkPriority = l.encoding.priority), A.debug("using svc encoding", { encodings: t }), t;
	}
	if (!a) return [i];
	let u;
	u = e ? Cf(r?.screenShareSimulcastLayers) ?? xf(e, l) : Cf(r?.videoSimulcastLayers) ?? xf(e, l);
	let d;
	if (u.length > 0) {
		let e = u[0];
		u.length > 1 && (d = C(u, 2)[1]);
		let r = Math.max(t, n);
		if (r >= 960 && d) return Sf(t, n, [
			e,
			d,
			l
		], c);
		if (r >= 480) return Sf(t, n, [e, l], c);
	}
	return Sf(t, n, [l]);
}
function vf(e, t, n) {
	if (!n.backupCodec || n.backupCodec === !0 || n.backupCodec.codec === n.videoCodec) return;
	t !== n.backupCodec.codec && A.warn("requested a different codec than specified as backup", {
		serverRequested: t,
		backup: n.backupCodec.codec
	}), n.videoCodec = t, n.videoEncoding = n.backupCodec.encoding;
	let r = e.mediaStreamTrack.getSettings(), i = r.width ?? e.dimensions?.width, a = r.height ?? e.dimensions?.height;
	return e.source === H.Source.ScreenShare && n.simulcast && (n.simulcast = !1), _f(e.source === H.Source.ScreenShare, i, a, n);
}
function yf(e, t, n, r) {
	let i = bf(e, t, n), a = i[0].encoding, o = Math.max(t, n);
	for (let e = 0; e < i.length; e += 1) {
		let t = i[e];
		if (a = t.encoding, t.width >= o) break;
	}
	if (r) switch (r) {
		case "av1":
		case "h265":
			a = Object.assign({}, a), a.maxBitrate *= .7;
			break;
		case "vp9":
			a = Object.assign({}, a), a.maxBitrate *= .85;
			break;
	}
	return a;
}
function bf(e, t, n) {
	if (e) return ff;
	let r = t > n ? t / n : n / t;
	return Math.abs(r - 16 / 9) < Math.abs(r - 4 / 3) ? uf : df;
}
function xf(e, t) {
	if (e) return hf(t);
	let n = t.width, r = t.height, i = n > r ? n / r : r / n;
	return Math.abs(i - 16 / 9) < Math.abs(i - 4 / 3) ? pf : mf;
}
function Sf(e, t, n, r) {
	let i = [];
	if (n.forEach((n, a) => {
		if (a >= gf.length) return;
		let o = Math.min(e, t), s = {
			rid: gf[a],
			scaleResolutionDownBy: Math.max(1, o / Math.min(n.width, n.height)),
			maxBitrate: n.encoding.maxBitrate
		}, c = r && n.encoding.maxFramerate ? Math.min(r, n.encoding.maxFramerate) : n.encoding.maxFramerate;
		c && (s.maxFramerate = c);
		let l = gc(), u = l?.name === "Firefox" && l.os !== "iOS" || a === 0;
		n.encoding.priority && u && (s.priority = n.encoding.priority, s.networkPriority = n.encoding.priority), i.push(s);
	}), jl() && Fl() === "ios") {
		let e;
		i.forEach((t) => {
			e ? t.maxFramerate && t.maxFramerate > e && (e = t.maxFramerate) : e = t.maxFramerate;
		});
		let t = !0;
		i.forEach((n) => {
			n.maxFramerate != e && (t && (t = !1, A.info("Simulcast on iOS React-Native requires all encodings to share the same framerate.")), A.info(`Setting framerate of encoding "${n.rid ?? ""}" to ${e}`), n.maxFramerate = e);
		});
	}
	return i;
}
function Cf(e) {
	if (e) return e.sort((e, t) => {
		let n = e.encoding, r = t.encoding;
		return n.maxBitrate > r.maxBitrate ? 1 : n.maxBitrate < r.maxBitrate ? -1 : n.maxBitrate === r.maxBitrate && n.maxFramerate && r.maxFramerate ? n.maxFramerate > r.maxFramerate ? 1 : -1 : 0;
	});
}
var wf = class {
	constructor(e) {
		let t = e.match(/^L(\d)T(\d)(h|_KEY|_KEY_SHIFT){0,1}$/);
		if (!t) throw Error("invalid scalability mode");
		if (this.spatial = parseInt(t[1]), this.temporal = parseInt(t[2]), t.length > 3) switch (t[3]) {
			case "h":
			case "_KEY":
			case "_KEY_SHIFT": this.suffix = t[3];
		}
	}
	toString() {
		return `L${this.spatial}T${this.temporal}${this.suffix ?? ""}`;
	}
};
function Tf(e) {
	return e.source === H.Source.ScreenShare || e.constraints.height && Yl(e.constraints.height) >= 1080 ? "maintain-resolution" : "balanced";
}
var Ef = 5e3, Df = class extends sf {
	get sender() {
		return this._sender;
	}
	set sender(e) {
		this._sender = e, this.degradationPreference && this.setDegradationPreference(this.degradationPreference);
	}
	constructor(e, t) {
		let n = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : !0, r = arguments.length > 3 ? arguments[3] : void 0;
		super(e, H.Kind.Video, t, n, r), this.simulcastCodecs = /* @__PURE__ */ new Map(), this.degradationPreference = "balanced", this.isCpuConstrained = !1, this.optimizeForPerformance = !1, this.monitorSender = () => j(this, void 0, void 0, function* () {
			if (!this.sender) {
				this._currentBitrate = 0;
				return;
			}
			let e;
			try {
				e = yield this.getSenderStats();
			} catch (e) {
				this.log.error("could not get video sender stats", Object.assign(Object.assign({}, this.logContext), { error: e }));
				return;
			}
			let t = new Map(e.map((e) => [e.rid, e])), n = e.some((e) => e.qualityLimitationReason === "cpu");
			if (n !== this.isCpuConstrained && (this.isCpuConstrained = n, this.isCpuConstrained && this.emit(z.CpuConstrained)), this.prevStats) {
				let e = 0;
				t.forEach((t, n) => {
					let r = this.prevStats?.get(n);
					e += Bu(t, r);
				}), this._currentBitrate = e;
			}
			this.prevStats = t;
		}), this.senderLock = new v();
	}
	get isSimulcast() {
		return !!(this.sender && this.sender.getParameters().encodings.length > 1);
	}
	startMonitor(e) {
		if (this.signalClient = e, !Al()) return;
		let t = this.sender?.getParameters();
		t && (this.encodings = t.encodings), !this.monitorInterval && (this.monitorInterval = setInterval(() => {
			this.monitorSender();
		}, zu));
	}
	stop() {
		this._mediaStreamTrack.getConstraints(), this.simulcastCodecs.forEach((e) => {
			e.mediaStreamTrack.stop();
		}), super.stop();
	}
	pauseUpstream() {
		let e = Object.create(null, { pauseUpstream: { get: () => super.pauseUpstream } });
		return j(this, void 0, void 0, function* () {
			var t, n, r, i;
			yield e.pauseUpstream.call(this);
			try {
				for (var a = !0, o = Yo(this.simulcastCodecs.values()), s; s = yield o.next(), t = s.done, !t; a = !0) i = s.value, a = !1, yield i.sender?.replaceTrack(null);
			} catch (e) {
				n = { error: e };
			} finally {
				try {
					!a && !t && (r = o.return) && (yield r.call(o));
				} finally {
					if (n) throw n.error;
				}
			}
		});
	}
	resumeUpstream() {
		let e = Object.create(null, { resumeUpstream: { get: () => super.resumeUpstream } });
		return j(this, void 0, void 0, function* () {
			var t, n, r, i;
			yield e.resumeUpstream.call(this);
			try {
				for (var a = !0, o = Yo(this.simulcastCodecs.values()), s; s = yield o.next(), t = s.done, !t; a = !0) {
					i = s.value, a = !1;
					let e = i;
					yield e.sender?.replaceTrack(e.mediaStreamTrack);
				}
			} catch (e) {
				n = { error: e };
			} finally {
				try {
					!a && !t && (r = o.return) && (yield r.call(o));
				} finally {
					if (n) throw n.error;
				}
			}
		});
	}
	mute() {
		let e = Object.create(null, { mute: { get: () => super.mute } });
		return j(this, void 0, void 0, function* () {
			let t = yield this.muteLock.lock();
			try {
				return this.isMuted ? (this.log.debug("Track already muted", this.logContext), this) : (this.source === H.Source.Camera && !this.isUserProvided && (this.log.debug("stopping camera track", this.logContext), this._mediaStreamTrack.stop()), yield e.mute.call(this), this);
			} finally {
				t();
			}
		});
	}
	unmute() {
		let e = Object.create(null, { unmute: { get: () => super.unmute } });
		return j(this, void 0, void 0, function* () {
			let t = yield this.muteLock.lock();
			try {
				return this.isMuted ? (this.source === H.Source.Camera && !this.isUserProvided && (this.log.debug("reacquiring camera track", this.logContext), yield this.restart(void 0, !0)), yield e.unmute.call(this), this) : (this.log.debug("Track already unmuted", this.logContext), this);
			} finally {
				t();
			}
		});
	}
	setTrackMuted(e) {
		super.setTrackMuted(e);
		for (let t of this.simulcastCodecs.values()) t.mediaStreamTrack.enabled = !e;
	}
	getSenderStats() {
		return j(this, void 0, void 0, function* () {
			if (!this.sender?.getStats) return [];
			let e = [], t = yield this.sender.getStats();
			return t.forEach((n) => {
				if (n.type === "outbound-rtp") {
					let r = {
						type: "video",
						streamId: n.id,
						frameHeight: n.frameHeight,
						frameWidth: n.frameWidth,
						framesPerSecond: n.framesPerSecond,
						framesSent: n.framesSent,
						firCount: n.firCount,
						pliCount: n.pliCount,
						nackCount: n.nackCount,
						packetsSent: n.packetsSent,
						bytesSent: n.bytesSent,
						qualityLimitationReason: n.qualityLimitationReason,
						qualityLimitationDurations: n.qualityLimitationDurations,
						qualityLimitationResolutionChanges: n.qualityLimitationResolutionChanges,
						rid: n.rid ?? n.id,
						retransmittedPacketsSent: n.retransmittedPacketsSent,
						targetBitrate: n.targetBitrate,
						timestamp: n.timestamp
					}, i = t.get(n.remoteId);
					i && (r.jitter = i.jitter, r.packetsLost = i.packetsLost, r.roundTripTime = i.roundTripTime), e.push(r);
				}
			}), e.sort((e, t) => (t.frameWidth ?? 0) - (e.frameWidth ?? 0)), e;
		});
	}
	setPublishingQuality(e) {
		let t = [];
		for (let n = sl.LOW; n <= sl.HIGH; n += 1) t.push(new ro({
			quality: n,
			enabled: n <= e
		}));
		this.log.debug(`setting publishing quality. max quality ${e}`, this.logContext), this.setPublishingLayers(vl(this.codec), t);
	}
	restartTrack(e) {
		return j(this, void 0, void 0, function* () {
			var t, n, r, i;
			let a;
			if (e) {
				let t = Gc({ video: e });
				typeof t.video != "boolean" && (a = t.video);
			}
			yield this.restart(a), this.isCpuConstrained = !1;
			try {
				for (var o = !0, s = Yo(this.simulcastCodecs.values()), c; c = yield s.next(), t = c.done, !t; o = !0) {
					i = c.value, o = !1;
					let e = i;
					e.sender && e.sender.transport?.state !== "closed" && (e.mediaStreamTrack = this.mediaStreamTrack.clone(), yield e.sender.replaceTrack(e.mediaStreamTrack));
				}
			} catch (e) {
				n = { error: e };
			} finally {
				try {
					!o && !t && (r = s.return) && (yield r.call(s));
				} finally {
					if (n) throw n.error;
				}
			}
			yield this.onSenderTrackSwapped();
		});
	}
	onSenderTrackSwapped() {
		return j(this, void 0, void 0, function* () {
			yield this.refreshSenderEncodings();
		});
	}
	refreshSenderEncodings() {
		return j(this, void 0, void 0, function* () {
			if (!this.sender || !this.publishOptions || this.optimizeForPerformance) return;
			let e = yield this.senderLock.lock();
			try {
				let e;
				try {
					e = yield this.waitForDimensions();
				} catch (e) {
					this.log.warn("could not determine new track dimensions, skipping encoding recompute", Object.assign(Object.assign({}, this.logContext), { error: e }));
					return;
				}
				if (this.lastEncodedDimensions && this.lastEncodedDimensions.width === e.width && this.lastEncodedDimensions.height === e.height) return;
				let n = _f(this.source === H.Source.ScreenShare, e.width, e.height, Object.assign({}, this.publishOptions));
				yield this.applyEncodingsToSender(this.sender, n), this.encodings = n, this.lastEncodedDimensions = e;
				for (let e of this.simulcastCodecs) {
					var t = C(e, 2);
					let n = t[0], r = t[1];
					if (!r.sender || r.sender.transport?.state === "closed" || !Ic(n)) continue;
					let i = Object.assign({}, this.publishOptions), a = vf(this, n, i);
					a && (yield this.applyEncodingsToSender(r.sender, a), r.encodings = a);
				}
			} catch (e) {
				this.log.warn("failed to apply recomputed encodings", Object.assign(Object.assign({}, this.logContext), { error: e }));
			} finally {
				e();
			}
		});
	}
	applyEncodingsToSender(e, t) {
		return j(this, void 0, void 0, function* () {
			let n = e.getParameters();
			!n.encodings || n.encodings.length !== t.length || (n.encodings.forEach((e, n) => {
				if (e.active === !1) return;
				let r = t[n];
				r.scaleResolutionDownBy !== void 0 && (e.scaleResolutionDownBy = r.scaleResolutionDownBy), r.maxBitrate !== void 0 && (e.maxBitrate = r.maxBitrate), r.maxFramerate !== void 0 && (e.maxFramerate = r.maxFramerate), r.priority !== void 0 && (e.priority = r.priority, e.networkPriority = r.priority);
			}), this.log.debug("updating sender encodings after track restart", Object.assign(Object.assign({}, this.logContext), { encodings: n.encodings })), yield e.setParameters(n));
		});
	}
	setProcessor(e) {
		let t = Object.create(null, { setProcessor: { get: () => super.setProcessor } });
		return j(this, arguments, void 0, function(e) {
			var n = this;
			let r = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !0;
			return function* () {
				var i, a, o, s;
				if (yield t.setProcessor.call(n, e, r), n.processor?.processedTrack) try {
					for (var c = !0, l = Yo(n.simulcastCodecs.values()), u; u = yield l.next(), i = u.done, !i; c = !0) s = u.value, c = !1, yield s.sender?.replaceTrack(n.processor.processedTrack);
				} catch (e) {
					a = { error: e };
				} finally {
					try {
						!c && !i && (o = l.return) && (yield o.call(l));
					} finally {
						if (a) throw a.error;
					}
				}
			}();
		});
	}
	setDegradationPreference(e) {
		return j(this, void 0, void 0, function* () {
			if (this.degradationPreference = e, this.sender) try {
				this.log.debug(`setting degradationPreference to ${e}`, this.logContext);
				let t = this.sender.getParameters();
				t.degradationPreference = e, this.sender.setParameters(t);
			} catch (e) {
				this.log.warn("failed to set degradationPreference", Object.assign({ error: e }, this.logContext));
			}
		});
	}
	addSimulcastTrack(e, t) {
		if (this.simulcastCodecs.has(e)) {
			this.log.error(`${e} already added, skipping adding simulcast codec`, this.logContext);
			return;
		}
		let n = {
			codec: e,
			mediaStreamTrack: this.mediaStreamTrack.clone(),
			sender: void 0,
			encodings: t
		};
		return this.simulcastCodecs.set(e, n), n;
	}
	setSimulcastTrackSender(e, t) {
		let n = this.simulcastCodecs.get(e);
		n && (n.sender = t, setTimeout(() => {
			this.subscribedCodecs && this.setPublishingCodecs(this.subscribedCodecs);
		}, Ef));
	}
	setPublishingCodecs(e) {
		return j(this, void 0, void 0, function* () {
			var t, n, r, i, a, o, s;
			if (this.log.debug("setting publishing codecs", Object.assign(Object.assign({}, this.logContext), {
				codecs: e,
				currentCodec: this.codec
			})), !this.codec && e.length > 0) return yield this.setPublishingLayers(vl(e[0].codec), e[0].qualities), [];
			this.subscribedCodecs = e;
			let c = [];
			try {
				for (t = !0, n = Yo(e); r = yield n.next(), i = r.done, !i; t = !0) {
					s = r.value, t = !1;
					let e = s;
					if (!this.codec || this.codec === e.codec) yield this.setPublishingLayers(vl(e.codec), e.qualities);
					else {
						let t = this.simulcastCodecs.get(e.codec);
						if (this.log.debug(`try setPublishingCodec for ${e.codec}`, Object.assign(Object.assign({}, this.logContext), { simulcastCodecInfo: t })), !t || !t.sender) {
							for (let t of e.qualities) if (t.enabled) {
								c.push(e.codec);
								break;
							}
						} else t.encodings && (this.log.debug(`try setPublishingLayersForSender ${e.codec}`, this.logContext), yield Of(t.sender, t.encodings, e.qualities, this.senderLock, vl(e.codec), this.log, this.logContext));
					}
				}
			} catch (e) {
				a = { error: e };
			} finally {
				try {
					!t && !i && (o = n.return) && (yield o.call(n));
				} finally {
					if (a) throw a.error;
				}
			}
			return c;
		});
	}
	setPublishingLayers(e, t) {
		return j(this, void 0, void 0, function* () {
			if (this.optimizeForPerformance) {
				this.log.info("skipping setPublishingLayers due to optimized publishing performance", Object.assign(Object.assign({}, this.logContext), { qualities: t }));
				return;
			}
			this.log.debug("setting publishing layers", Object.assign(Object.assign({}, this.logContext), { qualities: t })), !(!this.sender || !this.encodings) && (yield Of(this.sender, this.encodings, t, this.senderLock, e, this.log, this.logContext));
		});
	}
	prioritizePerformance() {
		return j(this, void 0, void 0, function* () {
			if (!this.sender) throw Error("sender not found");
			let e = yield this.senderLock.lock();
			try {
				this.optimizeForPerformance = !0;
				let e = this.sender.getParameters();
				e.encodings = e.encodings.map((e, t) => Object.assign(Object.assign({}, e), {
					active: t === 0,
					scaleResolutionDownBy: Math.max(1, Math.ceil((this.mediaStreamTrack.getSettings().height ?? 360) / 360)),
					scalabilityMode: t === 0 && vl(this.codec) ? "L1T3" : void 0,
					maxFramerate: t === 0 ? 15 : 0,
					maxBitrate: t === 0 ? e.maxBitrate : 0
				})), this.log.debug("setting performance optimised encodings", Object.assign(Object.assign({}, this.logContext), { encodings: e.encodings })), this.encodings = e.encodings, yield this.sender.setParameters(e);
			} catch (e) {
				this.log.error("failed to set performance optimised encodings", Object.assign(Object.assign({}, this.logContext), { error: e })), this.optimizeForPerformance = !1;
			} finally {
				e();
			}
		});
	}
	handleAppVisibilityChanged() {
		let e = Object.create(null, { handleAppVisibilityChanged: { get: () => super.handleAppVisibilityChanged } });
		return j(this, void 0, void 0, function* () {
			yield e.handleAppVisibilityChanged.call(this), Ol() && this.isInBackground && this.source === H.Source.Camera && (this._mediaStreamTrack.enabled = !1);
		});
	}
};
function Of(e, t, n, r, i, a, o) {
	return j(this, void 0, void 0, function* () {
		let s = yield r.lock();
		a.debug("setPublishingLayersForSender", Object.assign(Object.assign({}, o), {
			sender: e,
			qualities: n,
			senderEncodings: t
		}));
		try {
			let r = e.getParameters(), s = r.encodings;
			if (!s) return;
			if (s.length !== t.length) {
				a.warn("cannot set publishing layers, encodings mismatch", Object.assign(Object.assign({}, o), {
					encodings: s,
					senderEncodings: t
				}));
				return;
			}
			let c = !1;
			i && n.some((e) => e.enabled) && n.forEach((e) => e.enabled = !0), s.forEach((e, r) => {
				let i = e.rid ?? "";
				i === "" && (i = "q");
				let s = kf(i), l = n.find((e) => e.quality === s);
				l && e.active !== l.enabled && (c = !0, e.active = l.enabled, a.debug(`setting layer ${l.quality} to ${e.active ? "enabled" : "disabled"}`, o), xl() && (l.enabled ? (e.scaleResolutionDownBy = t[r].scaleResolutionDownBy, e.maxBitrate = t[r].maxBitrate, e.maxFrameRate = t[r].maxFrameRate) : (e.scaleResolutionDownBy = 4, e.maxBitrate = 10, e.maxFrameRate = 2)));
			}), c && (r.encodings = s, a.debug("setting encodings", Object.assign(Object.assign({}, o), { encodings: r.encodings })), yield e.setParameters(r));
		} finally {
			s();
		}
	});
}
function kf(e) {
	switch (e) {
		case "f": return sl.HIGH;
		case "h": return sl.MEDIUM;
		case "q": return sl.LOW;
		default: return sl.HIGH;
	}
}
function Af(e, t, n, r) {
	if (!n) return [new zi({
		quality: sl.HIGH,
		width: e,
		height: t,
		bitrate: 0,
		ssrc: 0
	})];
	if (r) {
		let r = n[0].scalabilityMode, i = new wf(r), a = [], o = i.suffix == "h" ? 1.5 : 2, s = i.suffix == "h" ? 2 : 3;
		for (let r = 0; r < i.spatial; r += 1) a.push(new zi({
			quality: Math.min(sl.HIGH, i.spatial - 1) - r,
			width: Math.ceil(e / o ** +r),
			height: Math.ceil(t / o ** +r),
			bitrate: n[0].maxBitrate ? Math.ceil(n[0].maxBitrate / s ** +r) : 0,
			ssrc: 0
		}));
		return a;
	}
	return n.map((n) => {
		let r = n.scaleResolutionDownBy ?? 1;
		return new zi({
			quality: kf(n.rid ?? ""),
			width: Math.ceil(e / r),
			height: Math.ceil(t / r),
			bitrate: n.maxBitrate ?? 0,
			ssrc: 0
		});
	});
}
var jf = "_lossy", Mf = "_reliable", Nf = "_data_track", Pf = 2 * 1e3, Ff = "leave-reconnect", If = 3e4, Lf = 8 * 1024, Rf = 256 * 1024, zf = 3, Bf = 3, Vf;
(function(e) {
	e[e.New = 0] = "New", e[e.Connected = 1] = "Connected", e[e.Disconnected = 2] = "Disconnected", e[e.Reconnecting = 3] = "Reconnecting", e[e.Closed = 4] = "Closed";
})(Vf ||= {});
var K;
(function(e) {
	e[e.RELIABLE = 0] = "RELIABLE", e[e.LOSSY = 1] = "LOSSY", e[e.DATA_TRACK_LOSSY = 2] = "DATA_TRACK_LOSSY";
})(K ||= {});
var Hf = class extends $o.EventEmitter {
	get isClosed() {
		return this._isClosed;
	}
	get isNewlyCreated() {
		return this._isNewlyCreated;
	}
	get pendingReconnect() {
		return !!this.reconnectTimeout;
	}
	constructor(e) {
		super(), this.options = e, this.rtcConfig = {}, this.peerConnectionTimeout = Qd.peerConnectionTimeout, this.fullReconnectOnNext = !1, this.latestRemoteOfferId = 0, this.subscriberPrimary = !1, this.pcState = Vf.New, this._isClosed = !0, this._isNewlyCreated = !0, this.pendingTrackResolvers = {}, this.reconnectAttempts = 0, this.reconnectStart = 0, this.attemptingReconnect = !1, this.joinAttempts = 0, this.maxJoinAttempts = 1, this.shouldFailNext = !1, this.shouldFailOnV1Path = !1, this.log = A, this.reliableDataSequence = 1, this.reliableMessageBuffer = new wd(), this.reliableReceivedState = new Td(If), this.lossyDataStatCurrentBytes = 0, this.lossyDataStatByterate = 0, this.lossyDataDropCount = 0, this.midToTrackId = {}, this.isWaitingForNetworkReconnect = !1, this.bufferStatusLowClosingFuture = new U(), this.handleDataChannel = (e) => j(this, [e], void 0, function(e) {
			var t = this;
			let n = e.channel;
			return function* () {
				if (!n) return;
				let e;
				if (n.label === Mf) t.reliableDCSub = n, e = t.handleDataMessage;
				else if (n.label === jf) t.lossyDCSub = n, e = t.handleDataMessage;
				else if (n.label === Nf) t.dataTrackDCSub = n, e = t.handleDataTrackMessage;
				else return;
				t.log.debug(`on data channel ${n.id}, ${n.label}`), n.onmessage = e;
			}();
		}), this.handleDataMessage = (e) => j(this, void 0, void 0, function* () {
			let t = yield this.dataProcessLock.lock();
			try {
				let t;
				if (e.data instanceof ArrayBuffer) t = e.data;
				else if (e.data instanceof Blob) t = yield e.data.arrayBuffer();
				else {
					this.log.error("unsupported data type", { data: e.data });
					return;
				}
				let n = Vi.fromBinary(new Uint8Array(t));
				if (n.sequence > 0 && n.participantSid !== "") {
					let e = this.reliableReceivedState.get(n.participantSid);
					if (e && n.sequence <= e) return;
					this.reliableReceivedState.set(n.participantSid, n.sequence);
				}
				if (n.value?.case === "speaker") this.emit(R.ActiveSpeakersUpdate, n.value.value.speakers);
				else if (n.value?.case === "encryptedPacket") {
					if (!this.e2eeManager) {
						this.log.error("Received encrypted packet but E2EE not set up");
						return;
					}
					let e = yield this.e2eeManager?.handleEncryptedData(n.value.value.encryptedValue, n.value.value.iv, n.participantIdentity, n.value.value.keyIndex), t = new Vi({
						value: Wi.fromBinary(e.payload).value,
						participantIdentity: n.participantIdentity,
						participantSid: n.participantSid
					});
					t.value?.case === "user" && Uf(t, t.value.value), this.emit(R.DataPacketReceived, t, n.value.value.encryptionType);
				} else n.value?.case === "user" && Uf(n, n.value.value), this.emit(R.DataPacketReceived, n, O.NONE);
			} finally {
				t();
			}
		}), this.handleDataTrackMessage = (e) => j(this, void 0, void 0, function* () {
			let t;
			if (e.data instanceof ArrayBuffer) t = e.data;
			else if (e.data instanceof Blob) t = yield e.data.arrayBuffer();
			else {
				this.log.error("unsupported data type", { data: e.data });
				return;
			}
			this.emit("dataTrackPacketReceived", new Uint8Array(t));
		}), this.handleDataError = (e) => {
			let t = e.currentTarget.maxRetransmits === 0 ? "lossy" : "reliable";
			if (e instanceof ErrorEvent && e.error) {
				let n = e.error.error;
				this.log.error(`DataChannel error on ${t}: ${e.message}`, { error: n });
			} else this.log.error(`Unknown DataChannel error on ${t}`, { event: e });
		}, this.handleBufferedAmountLow = (e) => {
			this.updateAndEmitDCBufferStatus(e);
		}, this.handleDisconnect = (e, t) => {
			if (this._isClosed) return;
			this.log.warn(`${e} disconnected`), this.reconnectAttempts === 0 && (this.reconnectStart = Date.now());
			let n = (e) => {
				this.log.warn(`could not recover connection after ${this.reconnectAttempts} attempts, ${e}ms. giving up`), this.emit(R.Disconnected), this.close();
			}, r = Date.now() - this.reconnectStart, i = this.getNextRetryDelay({
				elapsedMs: r,
				retryCount: this.reconnectAttempts
			});
			if (i === null) {
				n(r);
				return;
			}
			e === Ff && (i = 0), this.log.debug(`reconnecting in ${i}ms`), this.clearReconnectTimeout(), this.token && this.emit(R.TokenRefreshed, this.token), this.reconnectTimeout = F.setTimeout(() => this.attemptReconnect(t).finally(() => this.reconnectTimeout = void 0), i);
		}, this.waitForRestarted = () => new Promise((e, t) => {
			this.pcState === Vf.Connected && e();
			let n = () => {
				this.off(R.Disconnected, r), e();
			}, r = () => {
				this.off(R.Restarted, n), t();
			};
			this.once(R.Restarted, n), this.once(R.Disconnected, r);
		}), this.updateAndEmitDCBufferStatus = (e) => {
			if (e === K.RELIABLE) {
				let t = this.dataChannelForKind(e);
				t && this.reliableMessageBuffer.alignBufferedAmount(t.bufferedAmount);
			}
			let t = this.isBufferStatusLow(e);
			t !== void 0 && t !== this.dcBufferStatus.get(e) && (this.dcBufferStatus.set(e, t), this.emit(R.DCBufferStatusChanged, t, e));
		}, this.isBufferStatusLow = (e) => {
			let t = this.dataChannelForKind(e);
			if (t) return t.bufferedAmount <= t.bufferedAmountLowThreshold;
		}, this.onRtpMapAvailable = (e) => {
			let t = /* @__PURE__ */ new Map();
			e.forEach((e) => {
				let n = e.codec.toLowerCase();
				Jl(n) && t.set(e.payload, n);
			}), this.emit(R.RTPVideoMapUpdate, t);
		}, this.handleBrowserOnLine = () => j(this, void 0, void 0, function* () {
			this.url && (yield fetch(Zl(this.url), { method: "HEAD" }).then((e) => e.ok).catch(() => !1)) && (this.log.info("detected network reconnected"), (this.client.currentState === W.RECONNECTING || this.isWaitingForNetworkReconnect && this.client.currentState === W.CONNECTED) && (this.clearReconnectTimeout(), this.attemptReconnect(Ti.RR_SIGNAL_DISCONNECTED), this.isWaitingForNetworkReconnect = !1));
		}), this.handleBrowserOffline = () => j(this, void 0, void 0, function* () {
			if (this.url) try {
				yield Promise.race([fetch(Zl(this.url), { method: "HEAD" }), pl(4e3).then(() => Promise.reject())]);
			} catch {
				window.navigator.onLine === !1 && (this.log.info("detected network interruption"), this.isWaitingForNetworkReconnect = !0);
			}
		}), this.log = Lo(e.loggerName ?? k.Engine, () => this.logContext), this.loggerOptions = {
			loggerName: e.loggerName,
			loggerContextCb: () => this.logContext
		}, this.client = new yd(void 0, this.loggerOptions), this.client.signalLatency = this.options.expSignalLatency, this.reconnectPolicy = this.options.reconnectPolicy, this.closingLock = new v(), this.dataProcessLock = new v(), this.dcBufferStatus = new Map([
			[K.RELIABLE, !0],
			[K.LOSSY, !0],
			[K.DATA_TRACK_LOSSY, !0]
		]), this.client.onParticipantUpdate = (e) => this.emit(R.ParticipantUpdate, e), this.client.onConnectionQuality = (e) => this.emit(R.ConnectionQualityUpdate, e), this.client.onRoomUpdate = (e) => this.emit(R.RoomUpdate, e), this.client.onSubscriptionError = (e) => this.emit(R.SubscriptionError, e), this.client.onSubscriptionPermissionUpdate = (e) => this.emit(R.SubscriptionPermissionUpdate, e), this.client.onSpeakersChanged = (e) => this.emit(R.SpeakersChanged, e), this.client.onStreamStateUpdate = (e) => this.emit(R.StreamStateChanged, e), this.client.onRequestResponse = (e) => this.emit(R.SignalRequestResponse, e), this.client.onParticipantUpdate = (e) => this.emit(R.ParticipantUpdate, e), this.client.onJoined = (e) => this.emit(R.Joined, e), this.on(R.Closing, () => {
			var e, t;
			(t = (e = this.bufferStatusLowClosingFuture).reject) == null || t.call(e, new P("engine closed"));
		}), this.bufferStatusLowClosingFuture.promise.catch(() => {});
	}
	get logContext() {
		return {
			room: this.latestJoinResponse?.room?.name,
			roomID: this.latestJoinResponse?.room?.sid,
			participant: this.latestJoinResponse?.participant?.identity,
			participantID: this.participantSid
		};
	}
	join(e, t, n, r) {
		return j(this, arguments, void 0, function(e, t, n, r) {
			var i = this;
			let a = arguments.length > 4 && arguments[4] !== void 0 ? arguments[4] : !1;
			return function* () {
				var o;
				i._isNewlyCreated = !1, i.url = e, i.token = t, i.signalOpts = n, i.maxJoinAttempts = n.maxRetries;
				try {
					i.joinAttempts += 1, i.setupSignalClientCallbacks();
					let s = !a && hu(), c;
					if (s) {
						i.pcManager || (yield i.configure(), i.applyInitialPublisherLayout());
						let e = yield i.pcManager?.publisher.createInitialOffer();
						e && (c = xd(e.offer, e.offerId));
					}
					if (r?.aborted) throw N.cancelled("Connection aborted");
					if (!a && i.shouldFailOnV1Path) throw i.shouldFailOnV1Path = !1, N.serviceNotFound("Simulated v1 path failure", "v0-rtc");
					let l = yield i.client.join(e, t, n, r, a, c);
					i._isClosed = !1, i.latestJoinResponse = l, i.participantSid = l.participant?.sid, i.subscriberPrimary = l.subscriberPrimary, s ? (o = i.pcManager) == null || o.updateConfiguration(i.makeRTCConfiguration(l)) : (i.pcManager || (yield i.configure(l, !a), a || i.applyInitialPublisherLayout()), (!i.subscriberPrimary || l.fastPublish) && i.negotiate().catch((e) => {
						i.log.error(e);
					})), i.registerOnLineListener(), i.clientConfiguration = l.clientConfiguration, i.emit(R.SignalConnected, l);
					let u = l.serverInfo;
					return u ||= {
						version: l.serverVersion,
						region: l.serverRegion
					}, i.log.info(`connected to Livekit Server ${Object.entries(u).map((e) => {
						let t = C(e, 2);
						return `${t[0]}: ${t[1]}`;
					}).join(", ")}`), {
						joinResponse: l,
						serverInfo: u
					};
				} catch (o) {
					if (o instanceof N) {
						if (o.reason === M.ServerUnreachable) {
							if (i.log.warn(`Couldn't connect to server, attempt ${i.joinAttempts} of ${i.maxJoinAttempts}`), i.joinAttempts < i.maxJoinAttempts) return i.join(e, t, n, r, a);
						} else if (o.reason === M.ServiceNotFound) return i.log.warn(`Initial connection failed: ${o.message} – Retrying`), i.pcManager && (i.pcManager.onStateChange = void 0, yield i.cleanupPeerConnections()), i.join(e, t, n, r, !0);
					}
					throw o;
				}
			}();
		});
	}
	close() {
		return j(this, void 0, void 0, function* () {
			let e = yield this.closingLock.lock();
			if (this.isClosed) {
				e();
				return;
			}
			try {
				this._isClosed = !0, this.joinAttempts = 0, this.emit(R.Closing), this.removeAllListeners(), this.deregisterOnLineListener(), this.clearPendingReconnect(), this.cleanupLossyDataStats(), yield this.cleanupPeerConnections(), yield this.cleanupClient();
			} finally {
				e();
			}
		});
	}
	cleanupPeerConnections() {
		return j(this, void 0, void 0, function* () {
			yield this.pcManager?.close(), this.pcManager = void 0;
			let e = (e) => {
				e && (e.close(), e.onbufferedamountlow = null, e.onclose = null, e.onclosing = null, e.onerror = null, e.onmessage = null, e.onopen = null);
			};
			e(this.lossyDC), e(this.lossyDCSub), e(this.reliableDC), e(this.reliableDCSub), e(this.dataTrackDC), e(this.dataTrackDCSub), this.lossyDC = void 0, this.lossyDCSub = void 0, this.reliableDC = void 0, this.reliableDCSub = void 0, this.dataTrackDC = void 0, this.dataTrackDCSub = void 0, this.reliableMessageBuffer = new wd(), this.reliableDataSequence = 1, this.reliableReceivedState.clear();
		});
	}
	cleanupLossyDataStats() {
		this.lossyDataStatByterate = 0, this.lossyDataStatCurrentBytes = 0, this.lossyDataStatInterval &&= (clearInterval(this.lossyDataStatInterval), void 0), this.lossyDataDropCount = 0;
	}
	cleanupClient() {
		return j(this, void 0, void 0, function* () {
			yield this.client.close(), this.client.resetCallbacks();
			for (let e of Object.keys(this.pendingTrackResolvers)) this.pendingTrackResolvers[e].reject();
			this.pendingTrackResolvers = {};
		});
	}
	addTrack(e) {
		if (this.pendingTrackResolvers[e.cid]) throw new wc("a track with the same ID has already been published");
		return new Promise((t, n) => {
			let r = setTimeout(() => {
				delete this.pendingTrackResolvers[e.cid], n(N.timeout("publication of local track timed out, no response from server"));
			}, 1e4);
			this.pendingTrackResolvers[e.cid] = {
				resolve: (e) => {
					clearTimeout(r), t(e);
				},
				reject: () => {
					clearTimeout(r), n(/* @__PURE__ */ Error("Cancelled publication by calling unpublish"));
				}
			}, this.client.sendAddTrack(e);
		});
	}
	removeTrack(e) {
		if (e.track && this.pendingTrackResolvers[e.track.id]) {
			let t = this.pendingTrackResolvers[e.track.id].reject;
			t && t(), delete this.pendingTrackResolvers[e.track.id];
		}
		try {
			return this.pcManager.removeTrack(e), !0;
		} catch (e) {
			this.log.warn("failed to remove track", { error: e });
		}
		return !1;
	}
	updateMuteStatus(e, t) {
		this.client.sendMuteTrack(e, t);
	}
	get dataSubscriberReadyState() {
		return this.reliableDCSub?.readyState;
	}
	getConnectedServerAddress() {
		return j(this, void 0, void 0, function* () {
			return this.pcManager?.getConnectedAddress();
		});
	}
	setRegionStrategy(e) {
		this.regionStrategy = e;
	}
	configure(e, t) {
		return j(this, void 0, void 0, function* () {
			if (!(this.pcManager && this.pcManager.currentState !== G.NEW)) {
				if (e) {
					this.participantSid = e.participant?.sid;
					let n = this.makeRTCConfiguration(e);
					this.pcManager = new $d(t ? "publisher-only" : e.subscriberPrimary ? "subscriber-primary" : "publisher-primary", this.loggerOptions, n);
				} else {
					let e = this.makeRTCConfiguration();
					this.pcManager = new $d("publisher-only", this.loggerOptions, e);
				}
				this.emit(R.TransportsCreated, this.pcManager.publisher, this.pcManager.subscriber), this.pcManager.onIceCandidate = (e, t) => {
					this.client.sendIceCandidate(e, t);
				}, this.pcManager.onPublisherOffer = (e, t) => {
					this.client.sendOffer(e, t);
				}, this.pcManager.onDataChannel = this.handleDataChannel, this.pcManager.onStateChange = (e, t, n) => j(this, void 0, void 0, function* () {
					if (this.log.debug(`primary PC state changed ${e}`), [
						"closed",
						"disconnected",
						"failed"
					].includes(t) && (this.publisherConnectionPromise = void 0), e === G.CONNECTED) {
						let e = this.pcState === Vf.New;
						this.pcState = Vf.Connected, e && this.emit(R.Connected, this.latestJoinResponse);
					} else e === G.FAILED && (this.pcState === Vf.Connected || this.pcState === Vf.Reconnecting) && (this.pcState = Vf.Disconnected, this.handleDisconnect("peerconnection failed", n === "failed" ? Ti.RR_SUBSCRIBER_FAILED : Ti.RR_PUBLISHER_FAILED));
					let r = this.client.isDisconnected || this.client.currentState === W.RECONNECTING, i = [
						G.FAILED,
						G.CLOSING,
						G.CLOSED
					].includes(e);
					r && i && !this._isClosed && this.emit(R.Offline);
				}), this.pcManager.onTrack = (e) => {
					e.streams.length !== 0 && this.emit(R.MediaTrackAdded, e.track, e.streams[0], e.receiver);
				};
			}
		});
	}
	setupSignalClientCallbacks() {
		this.client.onAnswer = (e, t, n) => j(this, void 0, void 0, function* () {
			this.pcManager && (this.log.debug("received server answer", {
				RTCSdpType: e.type,
				sdp: e.sdp,
				midToTrackId: n
			}), this.midToTrackId = n, yield this.pcManager.setPublisherAnswer(e, t));
		}), this.client.onTrickle = (e, t) => {
			this.pcManager && (this.log.debug("got ICE candidate from peer", {
				candidate: e,
				target: t
			}), this.pcManager.addIceCandidate(e, t));
		}, this.client.onOffer = (e, t, n) => j(this, void 0, void 0, function* () {
			if (this.latestRemoteOfferId = t, !this.pcManager) return;
			this.midToTrackId = n;
			let r = yield this.pcManager.createSubscriberAnswerFromOffer(e, t);
			r && this.client.sendAnswer(r, t);
		}), this.client.onLocalTrackPublished = (e) => {
			if (this.log.debug("received trackPublishedResponse", {
				cid: e.cid,
				track: e.track?.sid
			}), !this.pendingTrackResolvers[e.cid]) {
				this.log.error(`missing track resolver for ${e.cid}`, { cid: e.cid });
				return;
			}
			let t = this.pendingTrackResolvers[e.cid].resolve;
			delete this.pendingTrackResolvers[e.cid], t(e.track);
		}, this.client.onLocalTrackUnpublished = (e) => {
			this.emit(R.LocalTrackUnpublished, e);
		}, this.client.onLocalTrackSubscribed = (e) => {
			this.emit(R.LocalTrackSubscribed, e);
		}, this.client.onTokenRefresh = (e) => {
			this.token = e, this.emit(R.TokenRefreshed, e);
		}, this.client.onRemoteMuteChanged = (e, t) => {
			this.emit(R.RemoteMute, e, t);
		}, this.client.onSubscribedQualityUpdate = (e) => {
			this.emit(R.SubscribedQualityUpdate, e);
		}, this.client.onRoomMoved = (e) => {
			this.participantSid = e.participant?.sid, this.latestJoinResponse && (this.latestJoinResponse.room = e.room), this.emit(R.RoomMoved, e);
		}, this.client.onMediaSectionsRequirement = (e) => {
			this.addMediaSections(e.numAudios, e.numVideos), this.negotiate();
		}, this.client.onPublishDataTrackResponse = (e) => {
			this.emit(R.PublishDataTrackResponse, e);
		}, this.client.onUnPublishDataTrackResponse = (e) => {
			this.emit(R.UnPublishDataTrackResponse, e);
		}, this.client.onDataTrackSubscriberHandles = (e) => {
			this.emit(R.DataTrackSubscriberHandles, e);
		}, this.client.onClose = () => {
			this.handleDisconnect("signal", Ti.RR_SIGNAL_DISCONNECTED);
		}, this.client.onLeave = (e) => {
			switch (this.log.info(`client leave request received (action=${e?.action})`, { reason: e?.reason }), e.regions && (this.log.debug("updating regions"), this.emit(R.ServerRegionsReported, e.regions)), e.action) {
				case qa.DISCONNECT:
					this.emit(R.Disconnected, e?.reason), this.close();
					break;
				case qa.RECONNECT:
					this.fullReconnectOnNext = !0, this.handleDisconnect(Ff);
					break;
				case qa.RESUME: this.handleDisconnect(Ff);
			}
		};
	}
	makeRTCConfiguration(e) {
		let t = Object.assign({}, this.rtcConfig);
		if ((this.signalOpts?.e2eeEnabled || this.options.packetTrailer?.worker && !Nu()) && Au() && (this.log.debug("E2EE - setting up transports with insertable streams"), t.encodedInsertableStreams = !0), t.sdpSemantics = "unified-plan", t.continualGatheringPolicy = "gather_continually", !e) return t;
		if (e.iceServers && !t.iceServers) {
			let n = [];
			e.iceServers.forEach((e) => {
				let t = { urls: e.urls };
				e.username && (t.username = e.username), e.credential && (t.credential = e.credential), n.push(t);
			}), t.iceServers = n;
		}
		return e.clientConfiguration && e.clientConfiguration.forceRelay === Ci.ENABLED && (t.iceTransportPolicy = "relay"), t;
	}
	applyInitialPublisherLayout() {
		this.createDataChannels(), this.addMediaSections(zf, Bf);
	}
	addMediaSections(e, t) {
		var n, r;
		let i = { direction: "recvonly" };
		for (let t = 0; t < e; t++) (n = this.pcManager) == null || n.addPublisherTransceiverOfKind("audio", i);
		for (let e = 0; e < t; e++) (r = this.pcManager) == null || r.addPublisherTransceiverOfKind("video", i);
	}
	createDataChannels() {
		this.pcManager && (this.lossyDC && (this.lossyDC.onmessage = null, this.lossyDC.onerror = null), this.reliableDC && (this.reliableDC.onmessage = null, this.reliableDC.onerror = null), this.dataTrackDC && (this.dataTrackDC.onmessage = null, this.dataTrackDC.onerror = null), this.lossyDC = this.pcManager.createPublisherDataChannel(jf, {
			ordered: !1,
			maxRetransmits: 0
		}), this.reliableDC = this.pcManager.createPublisherDataChannel(Mf, { ordered: !0 }), this.dataTrackDC = this.pcManager.createPublisherDataChannel(Nf, {
			ordered: !1,
			maxRetransmits: 0
		}), this.lossyDC.onmessage = this.handleDataMessage, this.reliableDC.onmessage = this.handleDataMessage, this.dataTrackDC.onmessage = this.handleDataTrackMessage, this.lossyDC.onerror = this.handleDataError, this.reliableDC.onerror = this.handleDataError, this.dataTrackDC.onerror = this.handleDataError, this.lossyDC.bufferedAmountLowThreshold = 65535, this.reliableDC.bufferedAmountLowThreshold = 65535, this.dataTrackDC.bufferedAmountLowThreshold = 65535, this.lossyDC.onbufferedamountlow = () => this.handleBufferedAmountLow(K.LOSSY), this.reliableDC.onbufferedamountlow = () => this.handleBufferedAmountLow(K.RELIABLE), this.dataTrackDC.onbufferedamountlow = () => this.handleBufferedAmountLow(K.DATA_TRACK_LOSSY), this.cleanupLossyDataStats(), this.lossyDataStatInterval = setInterval(() => {
			this.lossyDataStatByterate = this.lossyDataStatCurrentBytes, this.lossyDataStatCurrentBytes = 0;
			let e = this.dataChannelForKind(K.LOSSY);
			if (e) {
				let t = this.lossyDataStatByterate / 10;
				e.bufferedAmountLowThreshold = Math.min(Math.max(t, Lf), Rf);
			}
		}, 1e3));
	}
	createSender(e, t, n) {
		return j(this, void 0, void 0, function* () {
			let r;
			if (ml()) r = yield this.createTransceiverRTCRtpSender(e, t, n);
			else if (hl()) this.log.warn("using add-track fallback"), r = yield this.createRTCRtpSender(e.mediaStreamTrack);
			else throw new P("Required webRTC APIs not supported on this device");
			return this.setupPacketTrailerSender(r, t), r;
		});
	}
	createSimulcastSender(e, t, n, r) {
		return j(this, void 0, void 0, function* () {
			let i;
			if (ml()) i = yield this.createSimulcastTransceiverSender(e, t, n, r);
			else if (hl()) this.log.debug("using add-track fallback"), i = yield this.createRTCRtpSender(e.mediaStreamTrack);
			else throw new P("Cannot stream on this device");
			return i && this.setupPacketTrailerSender(i, n), i;
		});
	}
	setupPacketTrailerSender(e) {
		let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
		if (!this.options.packetTrailer?.worker || this.signalOpts?.e2eeEnabled) return;
		let n = t.packetTrailer, r = Fu(n);
		if (Nu()) {
			r && (e.transform = new RTCRtpScriptTransform(this.options.packetTrailer.worker, {
				kind: "encode",
				packetTrailer: n
			}));
			return;
		}
		if (!Pu(this.options.packetTrailer) || !("createEncodedStreams" in e)) {
			r && this.log.warn("packet trailer transform not supported; skipping write", this.logContext);
			return;
		}
		let i = e.createEncodedStreams(), a = i.readable, o = i.writable;
		r ? this.options.packetTrailer.worker.postMessage({
			kind: "encode",
			data: {
				readableStream: a,
				writableStream: o,
				packetTrailer: n
			}
		}, [a, o]) : a.pipeTo(o);
	}
	createTransceiverRTCRtpSender(e, t, n) {
		return j(this, void 0, void 0, function* () {
			if (!this.pcManager) throw new P("publisher is closed");
			let r = [];
			e.mediaStream && r.push(e.mediaStream), au(e) && (e.codec = t.videoCodec);
			let i = {
				direction: "sendonly",
				streams: r
			};
			return n && (i.sendEncodings = n), (yield this.pcManager.addPublisherTransceiver(e.mediaStreamTrack, i)).sender;
		});
	}
	createSimulcastTransceiverSender(e, t, n, r) {
		return j(this, void 0, void 0, function* () {
			if (!this.pcManager) throw new P("publisher is closed");
			let i = { direction: "sendonly" };
			r && (i.sendEncodings = r);
			let a = yield this.pcManager.addPublisherTransceiver(t.mediaStreamTrack, i);
			if (n.videoCodec) return e.setSimulcastTrackSender(n.videoCodec, a.sender), a.sender;
		});
	}
	createRTCRtpSender(e) {
		return j(this, void 0, void 0, function* () {
			if (!this.pcManager) throw new P("publisher is closed");
			return this.pcManager.addPublisherTrack(e);
		});
	}
	attemptReconnect(e) {
		return j(this, void 0, void 0, function* () {
			if (!this._isClosed) {
				if (this.attemptingReconnect) {
					this.log.warn("already attempting reconnect, returning early");
					return;
				}
				(this.clientConfiguration?.resumeConnection === Ci.DISABLED || (this.pcManager?.currentState ?? G.NEW) === G.NEW) && (this.fullReconnectOnNext = !0);
				try {
					this.attemptingReconnect = !0, this.fullReconnectOnNext ? yield this.restartConnection() : yield this.resumeConnection(e), this.clearPendingReconnect(), this.fullReconnectOnNext = !1;
				} catch (e) {
					this.reconnectAttempts += 1;
					let t = !0;
					e instanceof P ? (this.log.debug("received unrecoverable error", { error: e }), t = !1) : e instanceof jc || (this.fullReconnectOnNext = !0), t ? this.handleDisconnect("reconnect", Ti.RR_UNKNOWN) : (this.log.info(`could not recover connection after ${this.reconnectAttempts} attempts, ${Date.now() - this.reconnectStart}ms. giving up`), this.emit(R.Disconnected), yield this.close());
				} finally {
					this.attemptingReconnect = !1;
				}
			}
		});
	}
	getNextRetryDelay(e) {
		try {
			return this.reconnectPolicy.nextRetryDelayInMs(e);
		} catch (e) {
			this.log.warn("encountered error in reconnect policy", { error: e });
		}
		return null;
	}
	restartConnection(e) {
		return j(this, void 0, void 0, function* () {
			var t, n;
			try {
				if (!this.url || !this.token) throw new P("could not reconnect, url or token not saved");
				this.log.info(`reconnecting, attempt: ${this.reconnectAttempts}`), this.emit(R.Restarting), this.client.isDisconnected || (yield this.client.sendLeave()), yield this.cleanupPeerConnections(), yield this.cleanupClient();
				let n;
				try {
					if (!this.signalOpts) throw this.log.warn("attempted connection restart, without signal options present"), new jc();
					n = (yield this.join(e ?? this.url, this.token, this.signalOpts, void 0, !this.options.singlePeerConnection)).joinResponse;
				} catch (e) {
					throw e instanceof N && e.reason === M.NotAllowed ? new P("could not reconnect, token might be expired") : new jc();
				}
				if (this.shouldFailNext) throw this.shouldFailNext = !1, Error("simulated failure");
				if (this.client.setReconnected(), this.emit(R.SignalRestarted, n), yield this.waitForPCReconnected(), this.client.currentState !== W.CONNECTED) throw new jc("Signal connection got severed during reconnect");
				(t = this.regionStrategy) == null || t.resetAttempts(), this.emit(R.Restarted);
			} catch (e) {
				let t = yield this.regionStrategy?.getNextUrl();
				if (t) {
					yield this.restartConnection(t);
					return;
				} else throw (n = this.regionStrategy) == null || n.resetAttempts(), e;
			}
		});
	}
	resumeConnection(e) {
		return j(this, void 0, void 0, function* () {
			if (!this.url || !this.token) throw new P("could not reconnect, url or token not saved");
			if (!this.pcManager) throw new P("publisher and subscriber connections unset");
			this.log.info(`resuming signal connection, attempt ${this.reconnectAttempts}`), this.emit(R.Resuming);
			let t;
			try {
				this.setupSignalClientCallbacks(), t = yield this.client.reconnect(this.url, this.token, this.participantSid, e);
			} catch (e) {
				let t = "";
				throw e instanceof Error && (t = e.message, this.log.error(e.message, { error: e })), e instanceof N && e.reason === M.NotAllowed ? new P("could not reconnect, token might be expired") : e instanceof N && e.reason === M.LeaveRequest ? e : new jc(t);
			}
			if (this.emit(R.SignalResumed), t) {
				let e = this.makeRTCConfiguration(t);
				this.pcManager.updateConfiguration(e), this.latestJoinResponse && (this.latestJoinResponse.serverInfo = t.serverInfo);
			} else this.log.warn("Did not receive reconnect response");
			if (this.shouldFailNext) throw this.shouldFailNext = !1, Error("simulated failure");
			if (yield this.pcManager.triggerIceRestart(), yield this.waitForPCReconnected(), this.client.currentState !== W.CONNECTED) throw new jc("Signal connection got severed during reconnect");
			this.client.setReconnected(), this.reliableDC?.readyState === "open" && this.reliableDC.id === null && this.createDataChannels(), t?.lastMessageSeq && this.resendReliableMessagesForResume(t.lastMessageSeq), this.emit(R.Resumed);
		});
	}
	waitForPCInitialConnection(e, t) {
		return j(this, void 0, void 0, function* () {
			if (!this.pcManager) throw new P("PC manager is closed");
			yield this.pcManager.ensurePCTransportConnection(t, e);
		});
	}
	waitForPCReconnected() {
		return j(this, void 0, void 0, function* () {
			this.pcState = Vf.Reconnecting, this.log.debug("waiting for peer connection to reconnect");
			try {
				if (yield pl(Pf), !this.pcManager) throw new P("PC manager is closed");
				yield this.pcManager.ensurePCTransportConnection(void 0, this.peerConnectionTimeout), this.pcState = Vf.Connected;
			} catch (e) {
				throw this.pcState = Vf.Disconnected, N.internal(`could not establish PC connection, ${e.message}`);
			}
		});
	}
	publishRpcAck(e, t) {
		return j(this, void 0, void 0, function* () {
			let n = new Vi({
				destinationIdentities: [e],
				kind: Hi.RELIABLE,
				value: {
					case: "rpcAck",
					value: new $i({ requestId: t })
				}
			});
			yield this.sendDataPacket(n, K.RELIABLE);
		});
	}
	sendDataPacket(e, t) {
		return j(this, void 0, void 0, function* () {
			if (yield this.ensurePublisherConnected(t), this.e2eeManager && this.e2eeManager.isDataChannelEncryptionEnabled) {
				let t = ju(e);
				if (t) {
					let n = yield this.e2eeManager.encryptData(t.toBinary());
					e.value = {
						case: "encryptedPacket",
						value: new Ui({
							encryptedValue: n.payload,
							iv: n.iv,
							keyIndex: n.keyIndex
						})
					};
				}
			}
			t === K.RELIABLE && (e.sequence = this.reliableDataSequence, this.reliableDataSequence += 1);
			let n = e.toBinary();
			switch (t) {
				case K.LOSSY:
				case K.DATA_TRACK_LOSSY: return this.sendLossyBytes(n, t);
				case K.RELIABLE:
					let r = this.dataChannelForKind(t);
					if (r) {
						if (yield this.waitForBufferStatusLow(t), this.reliableMessageBuffer.push({
							data: n,
							sequence: e.sequence
						}), this.attemptingReconnect) return;
						r.send(n);
					}
					this.updateAndEmitDCBufferStatus(t);
					break;
			}
		});
	}
	sendLossyBytes(e, t) {
		return j(this, arguments, void 0, function(e, t) {
			var n = this;
			let r = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : "drop";
			return function* () {
				yield n.ensurePublisherConnected(t);
				let i = n.dataChannelForKind(t);
				if (i) {
					if (!n.isBufferStatusLow(t)) switch (r) {
						case "wait":
							yield n.waitForBufferStatusLow(t);
							break;
						case "drop":
							n.lossyDataDropCount += 1, n.lossyDataDropCount % 100 == 0 && n.log.warn(`dropping lossy data channel messages, total dropped: ${n.lossyDataDropCount}`);
							return;
					}
					if (n.lossyDataStatCurrentBytes += e.byteLength, n.attemptingReconnect) return;
					i.send(e);
				}
				n.updateAndEmitDCBufferStatus(t);
			}();
		});
	}
	resendReliableMessagesForResume(e) {
		return j(this, void 0, void 0, function* () {
			yield this.ensurePublisherConnected(K.RELIABLE);
			let t = this.dataChannelForKind(K.RELIABLE);
			t && (this.reliableMessageBuffer.popToSequence(e), this.reliableMessageBuffer.getAll().forEach((e) => {
				t.send(e.data);
			})), this.updateAndEmitDCBufferStatus(K.RELIABLE);
		});
	}
	waitForBufferStatusLow(e) {
		return j(this, void 0, void 0, function* () {
			return new pc((t, n) => j(this, void 0, void 0, function* () {
				if (this.isClosed && n(new P("engine closed")), this.isBufferStatusLow(e)) t();
				else {
					let r = this.dataChannelForKind(e);
					if (!r) {
						n(new P(`DataChannel not found, kind: ${e}`));
						return;
					}
					this.bufferStatusLowClosingFuture.promise.catch((e) => n(e)), r.addEventListener("bufferedamountlow", () => t(), { once: !0 });
				}
			}));
		});
	}
	ensureDataTransportConnected(e) {
		return j(this, arguments, void 0, function(e) {
			var t = this;
			let n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : this.subscriberPrimary;
			return function* () {
				if (!t.pcManager) throw new P("PC manager is closed");
				let r = n ? t.pcManager.subscriber : t.pcManager.publisher, i = n ? "Subscriber" : "Publisher";
				if (!r) throw N.internal(`${i} connection not set`);
				let a = !1;
				if (!n && !t.dataChannelForKind(e, n) && (t.createDataChannels(), a = !0), !a && !n && !t.pcManager.publisher.isICEConnected && t.pcManager.publisher.getICEConnectionState() !== "checking" && (a = !0), a && t.negotiate().catch((e) => {
					t.log.error(e);
				}), t.dataChannelForKind(e, n)?.readyState === "open") return;
				let o = (/* @__PURE__ */ new Date()).getTime() + t.peerConnectionTimeout;
				for (; (/* @__PURE__ */ new Date()).getTime() < o;) {
					if (r.isICEConnected && t.dataChannelForKind(e, n)?.readyState === "open") return;
					yield pl(50);
				}
				throw N.internal(`could not establish ${i} connection, state: ${r.getICEConnectionState()}`);
			}();
		});
	}
	ensurePublisherConnected(e) {
		return j(this, void 0, void 0, function* () {
			this.publisherConnectionPromise ||= this.ensureDataTransportConnected(e, !1), yield this.publisherConnectionPromise;
		});
	}
	verifyTransport() {
		return !(!this.pcManager || ![G.CONNECTING, G.CONNECTED].includes(this.pcManager.currentState) || !this.client.ws || this.client.ws.readyState === WebSocket.CLOSED);
	}
	negotiate() {
		return j(this, void 0, void 0, function* () {
			return new pc((e, t) => j(this, void 0, void 0, function* () {
				if (!this.pcManager) {
					t(new Ec("PC manager is closed"));
					return;
				}
				this.pcManager.requirePublisher(), this.pcManager.publisher.getTransceivers().length == 0 && !this.lossyDC && !this.reliableDC && !this.dataTrackDC && this.createDataChannels();
				let n = new AbortController(), r = () => {
					n.abort(), this.log.debug("engine disconnected while negotiation was ongoing"), e();
				};
				this.isClosed && t(new Ec("cannot negotiate on closed engine")), this.on(R.Closing, r), this.on(R.Restarting, r), this.pcManager.publisher.off(Vd.RTPVideoPayloadTypes, this.onRtpMapAvailable), this.pcManager.publisher.once(Vd.RTPVideoPayloadTypes, this.onRtpMapAvailable);
				try {
					yield this.pcManager.negotiate(n), e();
				} catch (r) {
					if (n.signal.aborted) {
						e();
						return;
					}
					r instanceof Ec && (this.fullReconnectOnNext = !0), this.handleDisconnect("negotiation", Ti.RR_UNKNOWN), r instanceof Error ? t(r) : t(Error(String(r)));
				} finally {
					this.off(R.Closing, r), this.off(R.Restarting, r);
				}
			}));
		});
	}
	dataChannelForKind(e, t) {
		switch (e) {
			case K.RELIABLE: return t ? this.reliableDCSub : this.reliableDC;
			case K.LOSSY: return t ? this.lossyDCSub : this.lossyDC;
			case K.DATA_TRACK_LOSSY: return t ? this.dataTrackDCSub : this.dataTrackDC;
		}
	}
	sendSyncState(e, t, n) {
		if (!this.pcManager) {
			this.log.warn("sync state cannot be sent without peer connection setup");
			return;
		}
		let r = this.pcManager.publisher.getLocalDescription(), i = this.pcManager.publisher.getRemoteDescription(), a = this.pcManager.subscriber?.getRemoteDescription(), o = this.pcManager.subscriber?.getLocalDescription(), s = this.signalOpts?.autoSubscribe ?? !0, c = [], l = [];
		e.forEach((e) => {
			e.isDesired !== s && c.push(e.trackSid), e.isEnabled || l.push(e.trackSid);
		}), this.client.sendSyncState(new fo({
			answer: this.pcManager.mode === "publisher-only" ? i ? xd({
				sdp: i.sdp,
				type: i.type
			}) : void 0 : o ? xd({
				sdp: o.sdp,
				type: o.type
			}) : void 0,
			offer: this.pcManager.mode === "publisher-only" ? r ? xd({
				sdp: r.sdp,
				type: r.type
			}) : void 0 : a ? xd({
				sdp: a.sdp,
				type: a.type
			}) : void 0,
			subscription: new Ba({
				trackSids: c,
				subscribe: !s,
				participantTracks: []
			}),
			publishTracks: Qc(t),
			dataChannels: this.dataChannelsInfo(),
			trackSidsDisabled: l,
			datachannelReceiveStates: this.reliableReceivedState.map((e, t) => new po({
				publisherSid: t,
				lastSeq: e
			})),
			publishDataTracks: n.map((e) => new Da({ info: fd.toProtobuf(e) }))
		}));
	}
	failNext() {
		this.shouldFailNext = !0;
	}
	failNextV1Path() {
		this.shouldFailOnV1Path = !0;
	}
	dataChannelsInfo() {
		let e = [], t = (t, n) => {
			t?.id !== void 0 && t.id !== null && e.push(new mo({
				label: t.label,
				id: t.id,
				target: n
			}));
		};
		return t(this.dataChannelForKind(K.LOSSY), ya.PUBLISHER), t(this.dataChannelForKind(K.RELIABLE), ya.PUBLISHER), t(this.dataChannelForKind(K.LOSSY, !0), ya.SUBSCRIBER), t(this.dataChannelForKind(K.RELIABLE, !0), ya.SUBSCRIBER), e;
	}
	clearReconnectTimeout() {
		this.reconnectTimeout && F.clearTimeout(this.reconnectTimeout);
	}
	clearPendingReconnect() {
		this.clearReconnectTimeout(), this.reconnectAttempts = 0;
	}
	registerOnLineListener() {
		Al() && (window.addEventListener("online", this.handleBrowserOnLine), window.addEventListener("offline", this.handleBrowserOffline));
	}
	deregisterOnLineListener() {
		Al() && (window.removeEventListener("online", this.handleBrowserOnLine), window.removeEventListener("offline", this.handleBrowserOffline));
	}
	getTrackIdForReceiver(e) {
		let t = this.pcManager?.getMidForReceiver(e);
		if (t) {
			let e = Object.entries(this.midToTrackId).find((e) => C(e, 1)[0] === t);
			if (e) return e[1];
		}
	}
};
function Uf(e, t) {
	let n = e.participantIdentity ? e.participantIdentity : t.participantIdentity;
	e.participantIdentity = n, t.participantIdentity = n;
	let r = e.destinationIdentities.length === 0 ? t.destinationIdentities : e.destinationIdentities;
	e.destinationIdentities = r, t.destinationIdentities = r;
}
var Wf = 5e3, Gf = 3e4, Kf = class e {
	static fetchRegionSettings(t, n, r) {
		return j(this, void 0, void 0, function* () {
			let i = yield e.fetchLock.lock();
			try {
				let e = yield fetch(`${qf(t)}/regions`, {
					headers: { authorization: `Bearer ${n}` },
					signal: r
				});
				if (e.ok) {
					let t = pu(e.headers), n = t ? t * 1e3 : Wf;
					return {
						regionSettings: yield e.json(),
						updatedAtInMs: Date.now(),
						maxAgeInMs: n
					};
				} else if (e.status === 401) throw N.notAllowed(`Could not fetch region settings: ${e.statusText}`, e.status);
				else throw N.internal(`Could not fetch region settings: ${e.statusText}`);
			} catch (e) {
				throw e instanceof N ? e : r?.aborted ? N.cancelled("Region fetching was aborted") : N.serverUnreachable(`Could not fetch region settings, ${e instanceof Error ? `${e.name}: ${e.message}` : e}`);
			} finally {
				i();
			}
		});
	}
	static scheduleRefetch(t, n, r) {
		return j(this, void 0, void 0, function* () {
			let i = e.settingsTimeouts.get(t.hostname);
			clearTimeout(i), e.settingsTimeouts.set(t.hostname, setTimeout(() => j(this, void 0, void 0, function* () {
				try {
					let r = yield e.fetchRegionSettings(t, n);
					e.updateCachedRegionSettings(t, n, r);
				} catch (i) {
					if (i instanceof N && i.reason === M.NotAllowed) {
						A.debug("token is not valid, cancelling auto region refresh");
						return;
					}
					A.debug("auto refetching of region settings failed", { error: i }), e.scheduleRefetch(t, n, r);
				}
			}), r));
		});
	}
	static updateCachedRegionSettings(t, n, r) {
		e.cache.set(t.hostname, r), e.scheduleRefetch(t, n, r.maxAgeInMs);
	}
	static stopRefetch(t) {
		let n = e.settingsTimeouts.get(t);
		n && (clearTimeout(n), e.settingsTimeouts.delete(t));
	}
	static scheduleCleanup(t) {
		let n = e.connectionTrackers.get(t);
		n && (n.cleanupTimeout && clearTimeout(n.cleanupTimeout), n.cleanupTimeout = setTimeout(() => {
			let n = e.connectionTrackers.get(t);
			n && n.connectionCount === 0 && (A.debug("stopping region refetch after disconnect delay", { hostname: t }), e.stopRefetch(t)), n && (n.cleanupTimeout = void 0);
		}, Gf));
	}
	static cancelCleanup(t) {
		let n = e.connectionTrackers.get(t);
		n?.cleanupTimeout && (clearTimeout(n.cleanupTimeout), n.cleanupTimeout = void 0);
	}
	notifyConnected() {
		let t = this.serverUrl.hostname, n = e.connectionTrackers.get(t);
		n || (n = { connectionCount: 0 }, e.connectionTrackers.set(t, n)), n.connectionCount++, e.cancelCleanup(t);
	}
	notifyDisconnected() {
		let t = this.serverUrl.hostname, n = e.connectionTrackers.get(t);
		n && (n.connectionCount = Math.max(0, n.connectionCount - 1), n.connectionCount === 0 && e.scheduleCleanup(t));
	}
	constructor(e, t) {
		this.attemptedRegions = [], this.serverUrl = new URL(e), this.token = t;
	}
	updateToken(t) {
		this.token = t;
		let n = this.getServerUrl(), r = e.cache.get(n.hostname);
		e.scheduleRefetch(this.serverUrl, this.token, r?.maxAgeInMs ?? Wf);
	}
	isCloud() {
		return Ml(this.serverUrl);
	}
	getServerUrl() {
		return this.serverUrl;
	}
	fetchRegionSettings(t) {
		return j(this, void 0, void 0, function* () {
			return e.fetchRegionSettings(this.serverUrl, this.token, t);
		});
	}
	getNextBestRegionUrl(t) {
		return j(this, void 0, void 0, function* () {
			if (!this.isCloud()) throw Error("region availability is only supported for LiveKit Cloud domains");
			let n = e.cache.get(this.serverUrl.hostname);
			(!n || Date.now() - n.updatedAtInMs > n.maxAgeInMs) && (n = yield this.fetchRegionSettings(t), e.updateCachedRegionSettings(this.serverUrl, this.token, n));
			let r = n.regionSettings.regions.filter((e) => !this.attemptedRegions.find((t) => t.url === e.url));
			if (r.length > 0) {
				let e = r[0];
				return this.attemptedRegions.push(e), A.debug(`next region: ${e.region}`), e.url;
			} else return null;
		});
	}
	resetAttempts() {
		this.attemptedRegions = [];
	}
	setServerReportedRegions(t) {
		e.updateCachedRegionSettings(this.serverUrl, this.token, t);
	}
};
Kf.cache = /* @__PURE__ */ new Map(), Kf.settingsTimeouts = /* @__PURE__ */ new Map(), Kf.connectionTrackers = /* @__PURE__ */ new Map(), Kf.fetchLock = new v();
function qf(e) {
	return `${e.protocol.replace("ws", "http")}//${e.host}/settings`;
}
var Jf = class {
	get info() {
		return this._info;
	}
	validateBytesReceived() {
		let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : !1;
		if (!(typeof this.totalByteSize != "number" || this.totalByteSize === 0)) {
			if (e && this.bytesReceived < this.totalByteSize) throw new Ac(`Not enough chunk(s) received - expected ${this.totalByteSize} bytes of data total, only received ${this.bytesReceived} bytes`, kc.Incomplete);
			if (this.bytesReceived > this.totalByteSize) throw new Ac(`Extra chunk(s) received - expected ${this.totalByteSize} bytes of data total, received ${this.bytesReceived} bytes`, kc.LengthExceeded);
		}
	}
	constructor(e, t, n) {
		this.reader = t, this.totalByteSize = n, this._info = e, this.bytesReceived = 0;
	}
}, Yf = class extends Jf {
	handleChunkReceived(e) {
		var t;
		this.bytesReceived += e.content.byteLength, this.validateBytesReceived();
		let n = this.totalByteSize ? this.bytesReceived / this.totalByteSize : void 0;
		(t = this.onProgress) == null || t.call(this, n);
	}
	[Symbol.asyncIterator]() {
		let e = this.reader.getReader();
		e.closed.catch(() => {});
		let t = () => {
			e.releaseLock(), this.signal = void 0;
		};
		return {
			next: () => j(this, void 0, void 0, function* () {
				try {
					let t = this.signal;
					if (t?.aborted) throw t.reason;
					let n = yield new Promise((n, r) => {
						if (t) {
							let i = () => r(t.reason);
							t.addEventListener("abort", i, { once: !0 }), e.read().then(n, r).finally(() => {
								t.removeEventListener("abort", i);
							});
						} else e.read().then(n, r);
					});
					return n.done ? (this.validateBytesReceived(!0), {
						done: !0,
						value: void 0
					}) : (this.handleChunkReceived(n.value), {
						done: !1,
						value: n.value.content
					});
				} catch (e) {
					throw t(), e;
				}
			}),
			return() {
				return j(this, void 0, void 0, function* () {
					return t(), {
						done: !0,
						value: void 0
					};
				});
			}
		};
	}
	withAbortSignal(e) {
		return this.signal = e, this;
	}
	readAll() {
		return j(this, arguments, void 0, function() {
			var e = this;
			let t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
			return function* () {
				var n, r, i, a;
				let o = /* @__PURE__ */ new Set(), s = t.signal ? e.withAbortSignal(t.signal) : e;
				try {
					for (var c = !0, l = Yo(s), u; u = yield l.next(), n = u.done, !n; c = !0) {
						a = u.value, c = !1;
						let e = a;
						o.add(e);
					}
				} catch (e) {
					r = { error: e };
				} finally {
					try {
						!c && !n && (i = l.return) && (yield i.call(l));
					} finally {
						if (r) throw r.error;
					}
				}
				return Array.from(o);
			}();
		});
	}
}, Xf = class extends Jf {
	constructor(e, t, n) {
		super(e, t, n), this.receivedChunks = /* @__PURE__ */ new Map();
	}
	handleChunkReceived(e) {
		var t;
		let n = tu(e.chunkIndex), r = this.receivedChunks.get(n);
		if (r && r.version > e.version) return;
		this.receivedChunks.set(n, e), this.bytesReceived += e.content.byteLength, this.validateBytesReceived();
		let i = this.totalByteSize ? this.bytesReceived / this.totalByteSize : void 0;
		(t = this.onProgress) == null || t.call(this, i);
	}
	[Symbol.asyncIterator]() {
		let e = this.reader.getReader();
		e.closed.catch(() => {});
		let t = new TextDecoder("utf-8", { fatal: !0 }), n = this.signal, r = () => {
			e.releaseLock(), this.signal = void 0;
		};
		return {
			next: () => j(this, void 0, void 0, function* () {
				try {
					if (n?.aborted) throw n.reason;
					let r = yield new Promise((t, r) => {
						if (n) {
							let i = () => r(n.reason);
							n.addEventListener("abort", i, { once: !0 }), e.read().then(t, r).finally(() => {
								n.removeEventListener("abort", i);
							});
						} else e.read().then(t, r);
					});
					if (r.done) return this.validateBytesReceived(!0), {
						done: !0,
						value: void 0
					};
					{
						this.handleChunkReceived(r.value);
						let e;
						try {
							e = t.decode(r.value.content);
						} catch (e) {
							throw new Ac(`Cannot decode datastream chunk ${r.value.chunkIndex} as text: ${e}`, kc.DecodeFailed);
						}
						return {
							done: !1,
							value: e
						};
					}
				} catch (e) {
					throw r(), e;
				}
			}),
			return() {
				return j(this, void 0, void 0, function* () {
					return r(), {
						done: !0,
						value: void 0
					};
				});
			}
		};
	}
	withAbortSignal(e) {
		return this.signal = e, this;
	}
	readAll() {
		return j(this, arguments, void 0, function() {
			var e = this;
			let t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
			return function* () {
				var n, r, i, a;
				let o = "", s = t.signal ? e.withAbortSignal(t.signal) : e;
				try {
					for (var c = !0, l = Yo(s), u; u = yield l.next(), n = u.done, !n; c = !0) a = u.value, c = !1, o += a;
				} catch (e) {
					r = { error: e };
				} finally {
					try {
						!c && !n && (i = l.return) && (yield i.call(l));
					} finally {
						if (r) throw r.error;
					}
				}
				return o;
			}();
		});
	}
}, Zf = class {
	constructor() {
		this.log = A, this.byteStreamControllers = /* @__PURE__ */ new Map(), this.textStreamControllers = /* @__PURE__ */ new Map(), this.byteStreamHandlers = /* @__PURE__ */ new Map(), this.textStreamHandlers = /* @__PURE__ */ new Map(), this.isConnected = !1, this.bufferedPackets = [];
	}
	setConnected(e) {
		this.isConnected = e, e && this.flushBufferedPackets();
	}
	flushBufferedPackets() {
		let e = this.bufferedPackets;
		this.bufferedPackets = [];
		for (let t of e) {
			let e = t.packet, n = t.encryptionType;
			this.handleDataStreamPacket(e, n);
		}
	}
	registerTextStreamHandler(e, t) {
		if (this.textStreamHandlers.has(e)) throw new Ac(`A text stream handler for topic "${e}" has already been set.`, kc.HandlerAlreadyRegistered);
		this.textStreamHandlers.set(e, t);
	}
	unregisterTextStreamHandler(e) {
		this.textStreamHandlers.delete(e);
	}
	registerByteStreamHandler(e, t) {
		if (this.byteStreamHandlers.has(e)) throw new Ac(`A byte stream handler for topic "${e}" has already been set.`, kc.HandlerAlreadyRegistered);
		this.byteStreamHandlers.set(e, t);
	}
	unregisterByteStreamHandler(e) {
		this.byteStreamHandlers.delete(e);
	}
	clearControllers() {
		this.byteStreamControllers.clear(), this.textStreamControllers.clear(), this.bufferedPackets = [];
	}
	validateParticipantHasNoActiveDataStreams(e) {
		let t = Array.from(this.textStreamControllers.entries()).filter((t) => t[1].sendingParticipantIdentity === e), n = Array.from(this.byteStreamControllers.entries()).filter((t) => t[1].sendingParticipantIdentity === e);
		if (t.length > 0 || n.length > 0) {
			let a = new Ac(`Participant ${e} unexpectedly disconnected in the middle of sending data`, kc.AbnormalEnd);
			for (let e of n) {
				var r = C(e, 2);
				let t = r[0];
				r[1].controller.error(a), this.byteStreamControllers.delete(t);
			}
			for (let e of t) {
				var i = C(e, 2);
				let t = i[0];
				i[1].controller.error(a), this.textStreamControllers.delete(t);
			}
		}
	}
	handleDataStreamPacket(e, t) {
		if (!this.isConnected) {
			this.bufferedPackets.push({
				packet: e,
				encryptionType: t
			});
			return;
		}
		switch (e.value.case) {
			case "streamHeader": return this.handleStreamHeader(e.value.value, e.participantIdentity, t);
			case "streamChunk": return this.handleStreamChunk(e.value.value, t);
			case "streamTrailer": return this.handleStreamTrailer(e.value.value, t);
			default: throw Error(`DataPacket of value "${e.value.case}" is not data stream related!`);
		}
	}
	handleStreamHeader(e, t, n) {
		if (e.contentHeader.case === "byteHeader") {
			let r = this.byteStreamHandlers.get(e.topic);
			if (!r) {
				this.log.debug("ignoring incoming byte stream due to no handler for topic", e.topic);
				return;
			}
			let i, a = {
				id: e.streamId,
				name: e.contentHeader.value.name ?? "unknown",
				mimeType: e.mimeType,
				size: e.totalLength ? Number(e.totalLength) : void 0,
				topic: e.topic,
				timestamp: tu(e.timestamp),
				attributes: e.attributes,
				encryptionType: n
			};
			r(new Yf(a, new ReadableStream({ start: (n) => {
				if (i = n, this.textStreamControllers.has(e.streamId)) throw new Ac(`A data stream read is already in progress for a stream with id ${e.streamId}.`, kc.AlreadyOpened);
				this.byteStreamControllers.set(e.streamId, {
					info: a,
					controller: i,
					startTime: Date.now(),
					sendingParticipantIdentity: t
				});
			} }), tu(e.totalLength)), { identity: t });
		} else if (e.contentHeader.case === "textHeader") {
			let r = this.textStreamHandlers.get(e.topic);
			if (!r) {
				this.log.debug("ignoring incoming text stream due to no handler for topic", e.topic);
				return;
			}
			let i, a = {
				id: e.streamId,
				mimeType: e.mimeType,
				size: e.totalLength ? Number(e.totalLength) : void 0,
				topic: e.topic,
				timestamp: Number(e.timestamp),
				attributes: e.attributes,
				encryptionType: n,
				attachedStreamIds: e.contentHeader.value.attachedStreamIds
			};
			r(new Xf(a, new ReadableStream({ start: (n) => {
				if (i = n, this.textStreamControllers.has(e.streamId)) throw new Ac(`A data stream read is already in progress for a stream with id ${e.streamId}.`, kc.AlreadyOpened);
				this.textStreamControllers.set(e.streamId, {
					info: a,
					controller: i,
					startTime: Date.now(),
					sendingParticipantIdentity: t
				});
			} }), tu(e.totalLength)), { identity: t });
		}
	}
	handleStreamChunk(e, t) {
		let n = this.byteStreamControllers.get(e.streamId);
		n && (n.info.encryptionType === t ? e.content.length > 0 && n.controller.enqueue(e) : (n.controller.error(new Ac(`Encryption type mismatch for stream ${e.streamId}. Expected ${t}, got ${n.info.encryptionType}`, kc.EncryptionTypeMismatch)), this.byteStreamControllers.delete(e.streamId)));
		let r = this.textStreamControllers.get(e.streamId);
		r && (r.info.encryptionType === t ? e.content.length > 0 && r.controller.enqueue(e) : (r.controller.error(new Ac(`Encryption type mismatch for stream ${e.streamId}. Expected ${t}, got ${r.info.encryptionType}`, kc.EncryptionTypeMismatch)), this.textStreamControllers.delete(e.streamId)));
	}
	handleStreamTrailer(e, t) {
		let n = this.textStreamControllers.get(e.streamId);
		n && (n.info.encryptionType === t ? (n.info.attributes = Object.assign(Object.assign({}, n.info.attributes), e.attributes), n.controller.close(), this.textStreamControllers.delete(e.streamId)) : n.controller.error(new Ac(`Encryption type mismatch for stream ${e.streamId}. Expected ${t}, got ${n.info.encryptionType}`, kc.EncryptionTypeMismatch)));
		let r = this.byteStreamControllers.get(e.streamId);
		r && (r.info.encryptionType === t ? (r.info.attributes = Object.assign(Object.assign({}, r.info.attributes), e.attributes), r.controller.close()) : r.controller.error(new Ac(`Encryption type mismatch for stream ${e.streamId}. Expected ${t}, got ${r.info.encryptionType}`, kc.EncryptionTypeMismatch)), this.byteStreamControllers.delete(e.streamId));
	}
}, Qf = class {
	constructor(e, t, n) {
		this.writableStream = e, this.defaultWriter = e.getWriter(), this.onClose = n, this.info = t;
	}
	write(e) {
		return this.defaultWriter.write(e);
	}
	close() {
		return j(this, void 0, void 0, function* () {
			var e;
			yield this.defaultWriter.close(), this.defaultWriter.releaseLock(), (e = this.onClose) == null || e.call(this);
		});
	}
}, $f = class extends Qf {}, ep = class extends Qf {}, tp = 15e3, np = class {
	constructor(e, t) {
		this.engine = e, this.log = t;
	}
	setupEngine(e) {
		this.engine = e;
	}
	sendText(e, t) {
		return j(this, void 0, void 0, function* () {
			let n = crypto.randomUUID(), r = new TextEncoder().encode(e).byteLength, i = (t?.attachments)?.map(() => crypto.randomUUID()), a = Array(i ? i.length + 1 : 1).fill(0), o = (e, n) => {
				var r;
				a[n] = e;
				let i = a.reduce((e, t) => e + t, 0);
				(r = t?.onProgress) == null || r.call(t, i);
			}, s = yield this.streamText({
				streamId: n,
				totalSize: r,
				destinationIdentities: t?.destinationIdentities,
				topic: t?.topic,
				attachedStreamIds: i,
				attributes: t?.attributes
			});
			return yield s.write(e), o(1, 0), yield s.close(), t?.attachments && i && (yield Promise.all(t.attachments.map((e, n) => j(this, void 0, void 0, function* () {
				return this._sendFile(i[n], e, {
					topic: t.topic,
					mimeType: e.type,
					onProgress: (e) => {
						o(e, n + 1);
					}
				});
			})))), s.info;
		});
	}
	streamText(e) {
		return j(this, void 0, void 0, function* () {
			let t = e?.streamId ?? crypto.randomUUID(), n = {
				id: t,
				mimeType: "text/plain",
				timestamp: Date.now(),
				topic: e?.topic ?? "",
				size: e?.totalSize,
				attributes: e?.attributes,
				encryptionType: this.engine.e2eeManager?.isDataChannelEncryptionEnabled ? O.GCM : O.NONE,
				attachedStreamIds: e?.attachedStreamIds
			}, r = new ha({
				streamId: t,
				mimeType: n.mimeType,
				topic: n.topic,
				timestamp: nu(n.timestamp),
				totalLength: nu(n.size),
				attributes: n.attributes,
				contentHeader: {
					case: "textHeader",
					value: new pa({
						version: e?.version,
						attachedStreamIds: n.attachedStreamIds,
						replyToStreamId: e?.replyToStreamId,
						operationType: e?.type === "update" ? fa.UPDATE : fa.CREATE
					})
				}
			}), i = e?.destinationIdentities, a = new Vi({
				destinationIdentities: i,
				value: {
					case: "streamHeader",
					value: r
				}
			});
			yield this.engine.sendDataPacket(a, K.RELIABLE);
			let o = 0, s = this.engine, c = new WritableStream({
				write(e) {
					return j(this, void 0, void 0, function* () {
						for (let n of fu(e, tp)) {
							let e = new Vi({
								destinationIdentities: i,
								value: {
									case: "streamChunk",
									value: new ga({
										content: n,
										streamId: t,
										chunkIndex: nu(o)
									})
								}
							});
							yield s.sendDataPacket(e, K.RELIABLE), o += 1;
						}
					});
				},
				close() {
					return j(this, void 0, void 0, function* () {
						let e = new Vi({
							destinationIdentities: i,
							value: {
								case: "streamTrailer",
								value: new _a({ streamId: t })
							}
						});
						yield s.sendDataPacket(e, K.RELIABLE);
					});
				},
				abort(e) {
					console.log("Sink error:", e);
				}
			}), l = () => j(this, void 0, void 0, function* () {
				yield u.close();
			});
			s.once(R.Closing, l);
			let u = new $f(c, n, () => this.engine.off(R.Closing, l));
			return u;
		});
	}
	sendFile(e, t) {
		return j(this, void 0, void 0, function* () {
			let n = crypto.randomUUID();
			return yield this._sendFile(n, e, t), { id: n };
		});
	}
	_sendFile(e, t, n) {
		return j(this, void 0, void 0, function* () {
			let r = yield this.streamBytes({
				streamId: e,
				totalSize: t.size,
				name: t.name,
				mimeType: n?.mimeType ?? t.type,
				topic: n?.topic,
				destinationIdentities: n?.destinationIdentities
			}), i = t.stream().getReader();
			for (;;) {
				let e = yield i.read(), t = e.done, n = e.value;
				if (t) break;
				yield r.write(n);
			}
			return yield r.close(), r.info;
		});
	}
	streamBytes(e) {
		return j(this, void 0, void 0, function* () {
			let t = e?.streamId ?? crypto.randomUUID(), n = e?.destinationIdentities, r = {
				id: t,
				mimeType: e?.mimeType ?? "application/octet-stream",
				topic: e?.topic ?? "",
				timestamp: Date.now(),
				attributes: e?.attributes,
				size: e?.totalSize,
				name: e?.name ?? "unknown",
				encryptionType: this.engine.e2eeManager?.isDataChannelEncryptionEnabled ? O.GCM : O.NONE
			}, i = new Vi({
				destinationIdentities: n,
				value: {
					case: "streamHeader",
					value: new ha({
						totalLength: nu(r.size),
						mimeType: r.mimeType,
						streamId: t,
						topic: r.topic,
						timestamp: nu(Date.now()),
						attributes: r.attributes,
						contentHeader: {
							case: "byteHeader",
							value: new ma({ name: r.name })
						}
					})
				}
			});
			yield this.engine.sendDataPacket(i, K.RELIABLE);
			let a = 0, o = new v(), s = this.engine, c = this.log;
			return new ep(new WritableStream({
				write(e) {
					return j(this, void 0, void 0, function* () {
						let r = yield o.lock(), i = 0;
						try {
							for (; i < e.byteLength;) {
								let r = e.slice(i, i + tp), o = new Vi({
									destinationIdentities: n,
									value: {
										case: "streamChunk",
										value: new ga({
											content: r,
											streamId: t,
											chunkIndex: nu(a)
										})
									}
								});
								yield s.sendDataPacket(o, K.RELIABLE), a += 1, i += r.byteLength;
							}
						} finally {
							r();
						}
					});
				},
				close() {
					return j(this, void 0, void 0, function* () {
						let e = new Vi({
							destinationIdentities: n,
							value: {
								case: "streamTrailer",
								value: new _a({ streamId: t })
							}
						});
						yield s.sendDataPacket(e, K.RELIABLE);
					});
				},
				abort(e) {
					c.error("Sink error:", e);
				}
			}), r);
		});
	}
};
function rp(e) {
	if (e.length === 0) return new AbortController().signal;
	if (e.length === 1) return e[0];
	for (let t of e) if (t.aborted) return t;
	let t = new AbortController(), n = Array(e.length), r = () => {
		for (let e of n) e();
	};
	return e.forEach((e, i) => {
		let a = () => {
			t.abort(e.reason), r();
		};
		e.addEventListener("abort", a), n[i] = () => e.removeEventListener("abort", a);
	}), t.signal;
}
function ip(e) {
	let t = new AbortController();
	return setTimeout(() => {
		t.abort(new DOMException(`signal timed out after ${e} ms`, "TimeoutError"));
	}, e), t.signal;
}
var ap = 1, op = 2, sp = 4, cp = 8, lp = 0, up = 12, dp = 5, fp = 7, pp = 3, mp = 3, hp = 2, gp = 1, _p = 0, vp = 3, yp = 2, bp = 2, xp = 1, Sp = 0, Cp;
(function(e) {
	e[e.TooShort = 0] = "TooShort", e[e.HeaderOverrun = 1] = "HeaderOverrun", e[e.MissingExtWords = 2] = "MissingExtWords", e[e.UnsupportedVersion = 3] = "UnsupportedVersion", e[e.InvalidHandle = 4] = "InvalidHandle", e[e.MalformedExt = 5] = "MalformedExt";
})(Cp ||= {});
var wp = class e extends Sc {
	constructor(e, t, n) {
		super(19, e, n), this.name = "DataTrackDeserializeError", this.reason = t, this.reasonName = Cp[t];
	}
	static tooShort() {
		return new e("Too short to contain a valid header", Cp.TooShort);
	}
	static headerOverrun() {
		return new e("Header exceeds total packet length", Cp.HeaderOverrun);
	}
	static missingExtWords() {
		return new e("Extension word indicator is missing", Cp.MissingExtWords);
	}
	static unsupportedVersion(t) {
		return new e(`Unsupported version ${t}`, Cp.UnsupportedVersion);
	}
	static invalidHandle(t) {
		return new e(`invalid track handle: ${t.message}`, Cp.InvalidHandle, { cause: t });
	}
	static malformedExt(t) {
		return new e(`Extension with tag ${t} is malformed`, Cp.MalformedExt);
	}
}, Tp;
(function(e) {
	e[e.TooSmallForHeader = 0] = "TooSmallForHeader", e[e.TooSmallForPayload = 1] = "TooSmallForPayload";
})(Tp ||= {});
var Ep = class e extends Sc {
	constructor(e, t, n) {
		super(19, e, n), this.name = "DataTrackSerializeError", this.reason = t, this.reasonName = Tp[t];
	}
	static tooSmallForHeader() {
		return new e("Buffer cannot fit header", Tp.TooSmallForHeader);
	}
	static tooSmallForPayload() {
		return new e("Buffer cannot fit payload", Tp.TooSmallForPayload);
	}
}, Dp = class {
	toBinary() {
		let e = this.toBinaryLengthBytes(), t = new ArrayBuffer(e), n = new DataView(t), r = this.toBinaryInto(n);
		if (e !== r) throw Error(`${this.constructor.name}.toBinary: written bytes (${r} bytes) not equal to allocated array buffer length (${e} bytes).`);
		return new Uint8Array(t);
	}
}, Op;
(function(e) {
	e[e.UserTimestamp = 2] = "UserTimestamp", e[e.E2ee = 1] = "E2ee";
})(Op ||= {});
var kp = class extends Dp {}, Ap = class e extends kp {
	constructor(e) {
		super(), this.timestamp = e;
	}
	toBinaryLengthBytes() {
		return 2 + e.lengthBytes;
	}
	toBinaryInto(t) {
		let n = 0;
		t.setUint8(n, e.tag), n += ap, t.setUint8(n, e.lengthBytes), n += ap, t.setBigUint64(n, this.timestamp), n += cp;
		let r = this.toBinaryLengthBytes();
		if (n !== r) throw Error(`DataTrackUserTimestampExtension.toBinaryInto: Wrote ${n} bytes but expected length was ${r} bytes`);
		return n;
	}
	toJSON() {
		return {
			tag: e.tag,
			lengthBytes: e.lengthBytes,
			timestamp: this.timestamp
		};
	}
};
Ap.tag = Op.UserTimestamp, Ap.lengthBytes = 8;
var jp = class e extends kp {
	constructor(e, t) {
		super(), this.keyIndex = e, this.iv = t;
	}
	toBinaryLengthBytes() {
		return 2 + e.lengthBytes;
	}
	toBinaryInto(t) {
		let n = 0;
		t.setUint8(n, e.tag), n += ap, t.setUint8(n, e.lengthBytes), n += ap, t.setUint8(n, this.keyIndex), n += ap;
		for (let e = 0; e < this.iv.length; e += 1) t.setUint8(n, this.iv[e]), n += ap;
		let r = this.toBinaryLengthBytes();
		if (n !== r) throw Error(`DataTrackE2eeExtension.toBinaryInto: Wrote ${n} bytes but expected length was ${r} bytes`);
		return n;
	}
	toJSON() {
		return {
			tag: e.tag,
			lengthBytes: e.lengthBytes,
			keyIndex: this.keyIndex,
			iv: this.iv
		};
	}
};
jp.tag = Op.E2ee, jp.lengthBytes = 13;
var Mp = class e extends Dp {
	constructor() {
		let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
		super(), this.userTimestamp = e.userTimestamp, this.e2ee = e.e2ee;
	}
	toBinaryLengthBytes() {
		let e = 0;
		return this.userTimestamp && (e += this.userTimestamp.toBinaryLengthBytes()), this.e2ee && (e += this.e2ee.toBinaryLengthBytes()), e;
	}
	toBinaryInto(e) {
		let t = 0;
		if (this.e2ee) {
			let n = this.e2ee.toBinaryInto(e);
			t += n;
		}
		if (this.userTimestamp) {
			let n = this.userTimestamp.toBinaryInto(new DataView(e.buffer, e.byteOffset + t));
			t += n;
		}
		let n = this.toBinaryLengthBytes();
		if (t !== n) throw Error(`DataTrackExtensions.toBinaryInto: Wrote ${t} bytes but expected length was ${n} bytes`);
		return t;
	}
	static fromBinary(t) {
		let n = sd(t), r, i, a = 0;
		for (; n.byteLength - a >= 2;) {
			let e = n.getUint8(a);
			a += ap;
			let t = n.getUint8(a);
			if (a += ap, e !== Sp) switch (e) {
				case Op.UserTimestamp:
					if (n.byteLength - a < Ap.lengthBytes) throw wp.malformedExt(e);
					r = new Ap(n.getBigUint64(a)), a += t;
					break;
				case Op.E2ee:
					if (n.byteLength - a < jp.lengthBytes) throw wp.malformedExt(e);
					let o = n.getUint8(a), s = new Uint8Array(12);
					for (let e = 0; e < s.length; e += 1) {
						let t = a;
						t += ap, t += e * ap, s[e] = n.getUint8(t);
					}
					i = new jp(o, s), a += t;
					break;
				default:
					if (n.byteLength - a < t) throw wp.malformedExt(e);
					a += t;
					break;
			}
		}
		return [new e({
			userTimestamp: r,
			e2ee: i
		}), n.byteLength];
	}
	toJSON() {
		return {
			userTimestamp: this.userTimestamp?.toJSON() ?? null,
			e2ee: this.e2ee?.toJSON() ?? null
		};
	}
}, Np = {
	from(e) {
		return {
			payload: e.payload,
			extensions: new Mp({ userTimestamp: e.userTimestamp ? new Ap(e.userTimestamp) : void 0 })
		};
	},
	lossyIntoFrame(e) {
		return {
			payload: e.payload,
			userTimestamp: e.extensions.userTimestamp?.timestamp
		};
	}
}, Pp = Symbol.for("lk.track"), Fp = Symbol.for("lk.data-track"), Ip = class {
	constructor(e, t, n) {
		this.trackSymbol = Pp, this.isLocal = !1, this.typeSymbol = Fp, this.info = e, this.manager = t, this.publisherIdentity = n.publisherIdentity;
	}
	subscribe(e) {
		try {
			let t = C(this.manager.openSubscriptionStream(this.info.sid, e?.signal, e?.bufferSize), 2), n = t[0];
			return t[1].catch(() => {}), n;
		} catch (e) {
			throw e;
		}
	}
	setPipelineOptions(e) {
		this.manager.setPipelineOptions(this.info.sid, e);
	}
}, Lp = class e extends Dp {
	constructor(e) {
		super(), this.marker = e.marker, this.trackHandle = e.trackHandle, this.sequence = e.sequence, this.frameNumber = e.frameNumber, this.timestamp = e.timestamp, this.extensions = e.extensions ?? new Mp();
	}
	extensionsMetrics() {
		let e = this.extensions.toBinaryLengthBytes(), t = Math.ceil((yp + e) / 4);
		return {
			lengthBytes: e,
			lengthWords: t,
			paddingLengthBytes: t * 4 - yp - e
		};
	}
	toBinaryLengthBytes() {
		let e = this.extensionsMetrics(), t = e.lengthBytes, n = e.paddingLengthBytes, r = up;
		return t > 0 && (r += yp + t + n), r;
	}
	toBinaryInto(e) {
		if (e.byteLength < this.toBinaryLengthBytes()) throw Ep.tooSmallForHeader();
		let t = lp << dp, n;
		switch (this.marker) {
			case q.Inter:
				n = _p;
				break;
			case q.Final:
				n = gp;
				break;
			case q.Start:
				n = hp;
				break;
			case q.Single:
				n = vp;
				break;
		}
		t |= n << pp;
		let r = this.extensionsMetrics(), i = r.lengthBytes, a = r.lengthWords, o = r.paddingLengthBytes;
		i > 0 && (t |= 1 << bp);
		let s = 0;
		if (e.setUint8(s, t), s += ap, e.setUint8(s, 0), s += ap, e.setUint16(s, this.trackHandle), s += op, e.setUint16(s, this.sequence.value), s += op, e.setUint16(s, this.frameNumber.value), s += op, e.setUint32(s, this.timestamp.asTicks()), s += sp, i > 0) {
			let t = a - 1;
			e.setUint16(s, t), s += op;
			let n = this.extensions.toBinaryInto(new DataView(e.buffer, e.byteOffset + s));
			s += n;
			for (let t = 0; t < o; t += 1) e.setUint8(s, 0), s += ap;
		}
		let c = this.toBinaryLengthBytes();
		if (s !== c) throw Error(`DataTrackPacketHeader.toBinaryInto: Wrote ${s} bytes but expected length was ${c} bytes`);
		return c;
	}
	static fromBinary(t) {
		let n = sd(t);
		if (n.byteLength < up) throw wp.tooShort();
		let r = 0, i = n.getUint8(r);
		r += ap;
		let a = i >> dp & fp;
		if (a > lp) throw wp.unsupportedVersion(a);
		let o;
		switch (i >> pp & mp) {
			case hp:
				o = q.Start;
				break;
			case gp:
				o = q.Final;
				break;
			case vp:
				o = q.Single;
				break;
			case _p:
			default:
				o = q.Inter;
				break;
		}
		let s = (i >> bp & xp) > 0;
		r += ap;
		let c;
		try {
			c = ud.fromNumber(n.getUint16(r));
		} catch (e) {
			throw e instanceof ld && (e.isReason(cd.Reserved) || e.isReason(cd.TooLarge)) ? wp.invalidHandle(e) : e;
		}
		r += op;
		let l = id.u16(n.getUint16(r));
		r += op;
		let u = id.u16(n.getUint16(r));
		r += op;
		let d = ad.fromRtpTicks(n.getUint32(r));
		r += sp;
		let f = new Mp();
		if (s) {
			if (n.byteLength - r < op) throw wp.missingExtWords();
			let e = n.getUint16(r);
			r += op;
			let t = 4 * (e + 1) - yp;
			if (r + t > n.byteLength) throw wp.headerOverrun();
			let i = new DataView(n.buffer, n.byteOffset + r, t), a = C(Mp.fromBinary(i), 2), o = a[0], s = a[1];
			f = o, r += s;
		}
		return [new e({
			marker: o,
			trackHandle: c,
			sequence: l,
			frameNumber: u,
			timestamp: d,
			extensions: f
		}), r];
	}
	toJSON() {
		return {
			marker: this.marker,
			trackHandle: this.trackHandle,
			sequence: this.sequence.value,
			frameNumber: this.frameNumber.value,
			timestamp: this.timestamp.asTicks(),
			extensions: this.extensions.toJSON()
		};
	}
}, q;
(function(e) {
	e[e.Start = 0] = "Start", e[e.Inter = 1] = "Inter", e[e.Final = 2] = "Final", e[e.Single = 3] = "Single";
})(q ||= {});
var Rp = class e extends Dp {
	constructor(e, t) {
		super(), this.header = e, this.payload = t;
	}
	toBinaryLengthBytes() {
		return this.header.toBinaryLengthBytes() + this.payload.byteLength;
	}
	toBinaryInto(e) {
		let t = 0, n = this.header.toBinaryInto(e);
		if (t += n, e.byteLength - t < this.payload.byteLength) throw Ep.tooSmallForPayload();
		for (let n = 0; n < this.payload.length; n += 1) e.setUint8(t, this.payload[n]), t += ap;
		let r = this.toBinaryLengthBytes();
		if (t !== r) throw Error(`DataTrackPacket.toBinaryInto: Wrote ${t} bytes but expected length was ${r} bytes`);
		return r;
	}
	static fromBinary(t) {
		let n = sd(t), r = C(Lp.fromBinary(n), 2), i = r[0], a = r[1], o = n.buffer.slice(n.byteOffset + a, n.byteOffset + n.byteLength);
		return [new e(i, new Uint8Array(o)), n.byteLength];
	}
	toJSON() {
		return {
			header: this.header.toJSON(),
			payload: this.payload
		};
	}
}, zp = Lo(k.DataTracks), Bp = class e extends Sc {
	constructor(e, t, n, r) {
		super(19, `Frame ${n} dropped: ${e}`, r), this.name = "DataTrackDepacketizerDropError", this.reason = t, this.reasonName = Vp[t], this.frameNumber = n;
	}
	static interrupted(t, n) {
		return new e(`Interrupted by the start of a new frame ${n}`, Vp.Interrupted, t);
	}
	static unknownFrame(t) {
		return new e("Initial packet was never received.", Vp.UnknownFrame, t);
	}
	static bufferFull(t) {
		return new e("Reorder buffer is full.", Vp.BufferFull, t);
	}
	static incomplete(t, n, r) {
		return new e(`Not all packets received before final packet. Received ${n} packets, expected ${r} packets.`, Vp.Incomplete, t);
	}
}, Vp;
(function(e) {
	e[e.Interrupted = 0] = "Interrupted", e[e.UnknownFrame = 1] = "UnknownFrame", e[e.BufferFull = 2] = "BufferFull", e[e.Incomplete = 3] = "Incomplete";
})(Vp ||= {});
var Hp = class e {
	constructor() {
		this.partials = /* @__PURE__ */ new Map();
	}
	push(e, t) {
		switch (e.header.marker) {
			case q.Single: return this.frameFromSingle(e, t);
			case q.Start: return this.beginPartial(e, t);
			case q.Inter:
			case q.Final: return this.pushToPartial(e);
		}
	}
	reset() {
		this.partials.clear();
	}
	peekOldestPartialFrameNumber() {
		let e = this.partials.keys().next();
		return e.done ? null : e.value;
	}
	frameFromSingle(e, t) {
		if (e.header.marker !== q.Single) throw Error(`Depacketizer.frameFromSingle: packet.header.marker was not FrameMarker.Single, found ${e.header.marker}.`);
		let n = t?.maxPartialFrames ?? 1;
		if (this.partials.size >= n) {
			let n = this.peekOldestPartialFrameNumber();
			if (typeof n != "number") throw Error(`Depacketizer.frameFromSingle: no oldest frame number found, but partials.size is ${this.partials.size}.`);
			if (this.partials.delete(n), t?.throwOnInterruption) throw Bp.interrupted(n, e.header.frameNumber.value);
			zp.warn(`Data track frame ${n} was interrupted by single-packet frame ${e.header.frameNumber.value}, dropping.`);
		}
		return {
			payload: e.payload,
			extensions: e.header.extensions
		};
	}
	beginPartial(e, t) {
		if (e.header.marker !== q.Start) throw Error(`Depacketizer.beginPartial: packet.header.marker was not FrameMarker.Start, found ${e.header.marker}.`);
		let n = e.header.sequence, r = e.header.frameNumber.value, i = {
			startSequence: n,
			extensions: e.header.extensions,
			payloads: new Map([[n.value, e.payload]])
		}, a = t?.maxPartialFrames ?? 1;
		for (; this.partials.size >= a;) {
			let e = this.peekOldestPartialFrameNumber();
			if (typeof e != "number") break;
			if (this.partials.delete(e), t?.throwOnInterruption) throw Bp.interrupted(e, r);
			zp.warn(`Data track partials full (max ${a}), evicted oldest frame ${e} to make room for new frame ${r}.`);
		}
		return this.partials.set(r, i), null;
	}
	pushToPartial(t) {
		if (t.header.marker !== q.Inter && t.header.marker !== q.Final) throw Error(`Depacketizer.pushToPartial: packet.header.marker was not FrameMarker.Inter or FrameMarker.Final, found ${t.header.marker}.`);
		let n = t.header.frameNumber.value, r = this.partials.get(n);
		if (!r) throw this.partials.delete(n), Bp.unknownFrame(n);
		if (r.payloads.size >= e.MAX_BUFFER_PACKETS) throw this.partials.delete(n), Bp.bufferFull(n);
		return r.payloads.has(t.header.sequence.value) && zp.warn(`Data track frame ${n} received duplicate packet for sequence ${t.header.sequence.value}, so replacing with newly received packet.`), r.payloads.set(t.header.sequence.value, t.payload), t.header.marker === q.Final ? this.finalize(n, r, t.header.sequence.value) : null;
	}
	finalize(e, t, n) {
		let r = t.payloads.size, i = 0;
		for (let e of t.payloads.values()) i += e.length;
		let a = new Uint8Array(i), o = t.startSequence.clone(), s = 0;
		for (;;) {
			let r = t.payloads.get(o.value);
			if (!r) break;
			t.payloads.delete(o.value);
			let i = a.length - s;
			if (r.length > i) throw Error(`Depacketizer.finalize: Expected at least ${r.length} more bytes left in the payload buffer, only got ${i} bytes.`);
			if (a.set(r, s), s += r.length, o.value != n) {
				o.increment();
				continue;
			}
			return this.partials.delete(e), {
				payload: a,
				extensions: t.extensions
			};
		}
		throw this.partials.delete(e), Bp.incomplete(e, r, n - t.startSequence.value + 1);
	}
};
Hp.MAX_BUFFER_PACKETS = 128;
var Up;
(function(e) {
	e[e.Unpublished = 0] = "Unpublished", e[e.Timeout = 1] = "Timeout", e[e.Disconnected = 2] = "Disconnected", e[e.Cancelled = 4] = "Cancelled";
})(Up ||= {});
var Wp = class e extends Sc {
	constructor(e, t, n) {
		super(22, e, n), this.name = "DataTrackSubscribeError", this.reason = t, this.reasonName = Up[t];
	}
	static unpublished() {
		return new e("The track has been unpublished and is no longer available", Up.Unpublished);
	}
	static timeout() {
		return new e("Request to subscribe to data track timed-out", Up.Timeout);
	}
	static disconnected() {
		return new e("Cannot subscribe to data track when disconnected", Up.Disconnected);
	}
	static cancelled() {
		return new e("Subscription to data track cancelled by caller", Up.Cancelled);
	}
}, Gp = Lo(k.DataTracks), Kp = class {
	constructor(e) {
		let t = e.e2eeManager !== null;
		if (e.info.usesE2ee !== t) throw Error("IncomingDataTrackPipeline: DataTrackInfo.usesE2ee must match presence of decryptionProvider");
		let n = new Hp();
		this.publisherIdentity = e.publisherIdentity, this.e2eeManager = e.e2eeManager ?? null, this.depacketizer = n, this.options = e.pipelineOptions ?? {};
	}
	updateE2eeManager(e) {
		this.e2eeManager = e;
	}
	setOptions(e) {
		this.options = e;
	}
	processPacket(e) {
		return j(this, void 0, void 0, function* () {
			let t = this.depacketize(e);
			return t && (yield this.decryptIfNeeded(t)) || null;
		});
	}
	depacketize(e) {
		let t;
		try {
			t = this.depacketizer.push(e, {
				throwOnInterruption: !1,
				maxPartialFrames: this.options.maxPartialFrames
			});
		} catch (e) {
			return Gp.warn(`Data frame depacketize error: ${e}`), null;
		}
		return t;
	}
	decryptIfNeeded(e) {
		return j(this, void 0, void 0, function* () {
			let t = this.e2eeManager;
			if (!t) return e;
			let n = e.extensions?.e2ee ?? null;
			if (!n) return Gp.error("Missing E2EE meta"), null;
			let r;
			try {
				r = yield t.handleEncryptedData(e.payload, n.iv, this.publisherIdentity, n.keyIndex);
			} catch (e) {
				return Gp.error(`Error decrypting packet: ${e}`), null;
			}
			return e.payload = r.payload, e;
		});
	}
}, J = Lo(k.DataTracks), qp = 1e4, Jp = 16, Yp = class extends $o.EventEmitter {
	constructor(e) {
		super(), this.descriptors = /* @__PURE__ */ new Map(), this.subscriptionHandles = /* @__PURE__ */ new Map(), this.e2eeManager = e?.e2eeManager ?? null;
	}
	updateE2eeManager(e) {
		this.e2eeManager = e;
		for (let t of this.descriptors.values()) t.subscription.type === "active" && t.subscription.pipeline.updateE2eeManager(e);
	}
	setPipelineOptions(e, t) {
		let n = this.descriptors.get(e);
		if (!n) {
			J.warn(`Unknown track ${e}, cannot set pipeline options.`);
			return;
		}
		n.pipelineOptions = t, n.subscription.type === "active" && n.subscription.pipeline.setOptions(t);
	}
	openSubscriptionStream(e, t) {
		let n = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : Jp, r = null, i = new U(), a = () => {
			t?.removeEventListener("abort", s);
		}, o = () => {
			if (a(), !r) {
				J.warn(`ReadableStream subscribed to ${e} was not started.`);
				return;
			}
			let t = this.descriptors.get(e);
			if (!t) {
				J.warn(`Unknown track ${e}, skipping cancel...`);
				return;
			}
			if (t.subscription.type !== "active") {
				J.warn(`Subscription for track ${e} is not active, skipping cancel...`);
				return;
			}
			t.subscription.streamControllers.delete(r), t.subscription.streamControllers.size === 0 && this.unSubscribeRequest(t.info.sid);
		}, s = () => {
			var t;
			if (!r) return;
			let n = this.descriptors.get(e);
			n?.subscription.type === "active" && n.subscription.streamControllers.delete(r), r.error(Wp.cancelled()), (t = i.reject) == null || t.call(i, Wp.cancelled()), o();
		};
		return [new ReadableStream({
			start: (n) => {
				r = n, this.subscribeRequest(e, t).then(() => j(this, void 0, void 0, function* () {
					var r, o, c;
					let l = this.descriptors.get(e);
					if (!l) {
						J.error(`Unknown track ${e}`);
						let t = Wp.disconnected();
						n.error(t), (r = i.reject) == null || r.call(i, t);
						return;
					}
					if (l.subscription.type !== "active") {
						J.error(`Subscription for track ${e} is not active`);
						let t = Wp.disconnected();
						n.error(t), (o = i.reject) == null || o.call(i, t);
						return;
					}
					if (t?.aborted) {
						s();
						return;
					}
					t?.addEventListener("abort", s), l.subscription.streamControllers.set(n, a), (c = i.resolve) == null || c.call(i);
				})).catch((e) => {
					var t;
					n.error(e), (t = i.reject) == null || t.call(i, e);
				});
			},
			cancel: () => {
				o();
			}
		}, new CountQueuingStrategy({ highWaterMark: n })), i.promise];
	}
	subscribeRequest(e, t) {
		return j(this, void 0, void 0, function* () {
			let n = this.descriptors.get(e);
			if (!n) throw Error("Cannot subscribe to unknown track");
			let r = (t, n, r) => j(this, void 0, void 0, function* () {
				if (t.subscription.type === "active") return;
				if (t.subscription.type !== "pending") throw Error(`Descriptor for track ${e} is not pending, found ${t.subscription.type}`);
				let i = rp([n, r].filter((e) => e !== void 0)), a = new U();
				t.subscription.completionFuture.promise.then(() => a.resolve?.call(a)).catch((e) => a.reject?.call(a, e));
				let o = () => {
					var e;
					if (t.subscription.type === "pending") {
						if (--t.subscription.pendingRequestCount, r?.aborted) {
							t.subscription.cancel();
							return;
						}
						if (t.subscription.pendingRequestCount <= 0) {
							t.subscription.cancel();
							return;
						}
						(e = a.reject) == null || e.call(a, Wp.cancelled());
					}
				};
				i.aborted && o(), i.addEventListener("abort", o), yield a.promise, i.removeEventListener("abort", o);
			});
			switch (n.subscription.type) {
				case "none": {
					n.subscription = {
						type: "pending",
						completionFuture: new U(),
						pendingRequestCount: 1,
						cancel: () => {
							var t, r;
							let a = n.subscription;
							n.subscription = { type: "none" }, this.emit("sfuUpdateSubscription", {
								sid: e,
								subscribe: !1
							}), a.type === "pending" && ((r = (t = a.completionFuture).reject) == null || r.call(t, i.aborted ? Wp.timeout() : Wp.cancelled()));
						}
					}, this.emit("sfuUpdateSubscription", {
						sid: e,
						subscribe: !0
					});
					let i = ip(qp);
					yield r(n, t, i);
					return;
				}
				case "pending":
					n.subscription.pendingRequestCount += 1, yield r(n, t);
					return;
				case "active": return;
			}
		});
	}
	querySubscribed() {
		return j(this, void 0, void 0, function* () {
			return Array.from(this.descriptors.values()).filter((e) => e.subscription.type === "active").map((e) => [e.info, e.publisherIdentity]);
		});
	}
	unSubscribeRequest(e) {
		let t = this.descriptors.get(e);
		if (!t) throw Error("Cannot subscribe to unknown track");
		if (t.subscription.type !== "active") {
			J.warn(`Unexpected descriptor state in unSubscribeRequest, expected active, found ${t.subscription?.type}`);
			return;
		}
		this.closeStreamControllers(t.subscription.streamControllers, e);
		let n = t.subscription;
		t.subscription = { type: "none" }, this.subscriptionHandles.delete(n.subcriptionHandle), this.emit("sfuUpdateSubscription", {
			sid: e,
			subscribe: !1
		});
	}
	closeStreamControllers(e, t) {
		for (let r of e) {
			var n = C(r, 2);
			let e = n[0], i = n[1];
			i();
			try {
				e.close();
			} catch (e) {
				J.warn(`Failed to close readable stream for track ${t}: ${e}`);
			}
		}
	}
	receiveSfuPublicationUpdates(e) {
		return j(this, void 0, void 0, function* () {
			if (e.size === 0) return;
			let t = /* @__PURE__ */ new Map();
			for (let r of e.entries()) {
				var n = C(r, 2);
				let e = n[0], i = n[1], a = /* @__PURE__ */ new Set();
				for (let t of i) a.add(t.sid), !this.descriptors.has(t.sid) && (yield this.handleTrackPublished(e, t));
				t.set(e, a);
			}
			for (let e of t.entries()) {
				var r = C(e, 2);
				let t = r[0], n = r[1], i = Array.from(this.descriptors.entries()).filter((e) => {
					let n = C(e, 2);
					return n[0], n[1].publisherIdentity === t;
				}).map((e) => C(e, 1)[0]).filter((e) => !n.has(e));
				for (let e of i) this.handleTrackUnpublished(e);
			}
		});
	}
	queryPublications() {
		return j(this, void 0, void 0, function* () {
			return Array.from(this.descriptors.values()).map((e) => e.info);
		});
	}
	handleTrackPublished(e, t) {
		return j(this, void 0, void 0, function* () {
			if (this.descriptors.has(t.sid)) {
				J.error(`Existing descriptor for track ${t.sid}`);
				return;
			}
			let n = {
				info: t,
				publisherIdentity: e,
				subscription: { type: "none" },
				pipelineOptions: {}
			};
			this.descriptors.set(n.info.sid, n);
			let r = new Ip(n.info, this, { publisherIdentity: e });
			this.emit("trackPublished", { track: r });
		});
	}
	handleTrackUnpublished(e) {
		let t = this.descriptors.get(e);
		if (!t) {
			J.error(`Unknown track ${e}`);
			return;
		}
		this.descriptors.delete(e), t.subscription.type === "active" && (this.closeStreamControllers(t.subscription.streamControllers, e), this.subscriptionHandles.delete(t.subscription.subcriptionHandle)), this.emit("trackUnpublished", {
			sid: e,
			publisherIdentity: t.publisherIdentity
		});
	}
	receivedSfuSubscriberHandles(e) {
		for (let n of e.entries()) {
			var t = C(n, 2);
			let e = t[0], r = t[1];
			this.registerSubscriberHandle(e, r);
		}
	}
	registerSubscriberHandle(e, t) {
		var n, r;
		let i = this.descriptors.get(t);
		if (!i) {
			J.error(`Unknown track ${t}`);
			return;
		}
		switch (i.subscription.type) {
			case "none":
				J.warn(`No subscription for ${t}`);
				return;
			case "active":
				i.subscription.subcriptionHandle = e, this.subscriptionHandles.set(e, t);
				return;
			case "pending": {
				let a = new Kp({
					info: i.info,
					publisherIdentity: i.publisherIdentity,
					e2eeManager: this.e2eeManager,
					pipelineOptions: i.pipelineOptions
				}), o = i.subscription;
				i.subscription = {
					type: "active",
					subcriptionHandle: e,
					pipeline: a,
					streamControllers: /* @__PURE__ */ new Map()
				}, this.subscriptionHandles.set(e, t), (r = (n = o.completionFuture).resolve) == null || r.call(n);
			}
		}
	}
	packetReceived(e) {
		return j(this, void 0, void 0, function* () {
			let t;
			try {
				t = C(Rp.fromBinary(e), 1)[0];
			} catch (e) {
				J.error(`Failed to deserialize packet: ${e}`);
				return;
			}
			let n = this.subscriptionHandles.get(t.header.trackHandle);
			if (!n) {
				J.warn(`Unknown subscriber handle ${t.header.trackHandle}`);
				return;
			}
			let r = this.descriptors.get(n);
			if (!r) {
				J.error(`Missing descriptor for track ${n}`);
				return;
			}
			if (r.subscription.type !== "active") {
				J.warn(`Received packet for track ${n} without active subscription`);
				return;
			}
			let i = yield r.subscription.pipeline.processPacket(t);
			if (i) for (let e of r.subscription.streamControllers.keys()) {
				if (e.desiredSize !== null && e.desiredSize <= 0) {
					J.warn(`Cannot send frame to subscribers: readable stream is full (desiredSize is ${e.desiredSize}). To increase this threshold, set a higher 'options.highWaterMark' when calling .subscribe().`);
					continue;
				}
				let t = Np.lossyIntoFrame(i);
				e.enqueue(t);
			}
		});
	}
	resendSubscriptionUpdates() {
		for (let t of this.descriptors) {
			var e = C(t, 2);
			let n = e[0];
			e[1].subscription.type !== "none" && this.emit("sfuUpdateSubscription", {
				sid: n,
				subscribe: !0
			});
		}
	}
	handleRemoteParticipantDisconnected(e) {
		var t, n;
		for (let r of this.descriptors.values()) if (r.publisherIdentity === e) switch (r.subscription.type) {
			case "none": break;
			case "pending":
				(n = (t = r.subscription.completionFuture).reject) == null || n.call(t, Wp.disconnected());
				break;
			case "active":
				this.unSubscribeRequest(r.info.sid);
				break;
		}
	}
	reset() {
		var e, t;
		for (let n of this.descriptors.values()) this.emit("trackUnpublished", {
			sid: n.info.sid,
			publisherIdentity: n.publisherIdentity
		}), n.subscription.type === "pending" && ((t = (e = n.subscription.completionFuture).reject) == null || t.call(e, Wp.disconnected())), n.subscription.type === "active" && this.closeStreamControllers(n.subscription.streamControllers, n.info.sid);
		this.descriptors.clear(), this.subscriptionHandles.clear();
	}
}, Xp = class e extends Sc {
	constructor(e, t, n) {
		super(19, e, n), this.name = "DataTrackPacketizerError", this.reason = t, this.reasonName = Zp[t];
	}
	static mtuTooShort() {
		return new e("MTU is too short to send frame", Zp.MtuTooShort);
	}
}, Zp;
(function(e) {
	e[e.MtuTooShort = 0] = "MtuTooShort";
})(Zp ||= {});
var Qp = class e {
	constructor(e, t) {
		this.sequence = id.u16(0), this.frameNumber = id.u16(0), this.clock = od.rtpStartingNow(ad.rtpRandom()), this.handle = e, this.mtuSizeBytes = t;
	}
	static computeFrameMarker(e, t) {
		return t <= 1 ? q.Single : e === 0 ? q.Start : e === t - 1 ? q.Final : q.Inter;
	}
	*packetize(t, n) {
		let r = this.frameNumber.getThenIncrement(), i = {
			marker: q.Inter,
			trackHandle: this.handle,
			sequence: id.u16(0),
			frameNumber: r,
			timestamp: n?.now ?? this.clock.now(),
			extensions: t.extensions
		}, a = new Lp(i).toBinaryLengthBytes();
		if (a >= this.mtuSizeBytes) throw Xp.mtuTooShort();
		let o = this.mtuSizeBytes - a, s = Math.ceil(t.payload.byteLength / o);
		for (let n = 0, r = 0; r < t.payload.byteLength; c = [n + 1, r + o], n = c[0], r = c[1]) {
			var c;
			let a = this.sequence.getThenIncrement(), l = new Lp(Object.assign(Object.assign({}, i), {
				marker: e.computeFrameMarker(n, s),
				sequence: a
			})), u = Math.min(o, t.payload.byteLength - r);
			yield new Rp(l, new Uint8Array(t.payload.buffer, t.payload.byteOffset + r, u));
		}
	}
}, $p;
(function(e) {
	e[e.NotAllowed = 0] = "NotAllowed", e[e.DuplicateName = 1] = "DuplicateName", e[e.Timeout = 2] = "Timeout", e[e.LimitReached = 3] = "LimitReached", e[e.Disconnected = 4] = "Disconnected", e[e.Cancelled = 5] = "Cancelled", e[e.InvalidName = 6] = "InvalidName", e[e.Unknown = 7] = "Unknown";
})($p ||= {});
var em = class e extends Sc {
	constructor(e, t, n) {
		super(21, e, n), this.name = "DataTrackPublishError", this.reason = t, this.reasonName = $p[t], this.rawMessage = n?.rawMessage;
	}
	static notAllowed(t) {
		return new e("Data track publishing unauthorized", $p.NotAllowed, { rawMessage: t });
	}
	static duplicateName(t) {
		return new e("Track name already taken", $p.DuplicateName, { rawMessage: t });
	}
	static invalidName(t) {
		return new e("Track name is invalid", $p.InvalidName, { rawMessage: t });
	}
	static timeout() {
		return new e("Publish data track timed-out. Does the LiveKit server support data tracks?", $p.Timeout);
	}
	static limitReached(t) {
		return new e("Data track publication limit reached", $p.LimitReached, { rawMessage: t });
	}
	static unknown(t, n) {
		return new e(`Received RequestResponse for publishDataTrack, but reason was unrecognised (${t}, ${n})`, $p.Unknown);
	}
	static disconnected() {
		return new e("Room disconnected", $p.Disconnected);
	}
	static cancelled() {
		return new e("Publish data track cancelled by caller", $p.Cancelled);
	}
}, tm;
(function(e) {
	e[e.TrackUnpublished = 0] = "TrackUnpublished", e[e.Dropped = 1] = "Dropped";
})(tm ||= {});
var nm = class e extends Sc {
	constructor(e, t, n) {
		super(22, e, n), this.name = "DataTrackPushFrameError", this.reason = t, this.reasonName = tm[t];
	}
	static trackUnpublished() {
		return new e("Track is no longer published", tm.TrackUnpublished);
	}
	static dropped(t) {
		return new e("Frame was dropped", tm.Dropped, { cause: t });
	}
}, rm;
(function(e) {
	e[e.Packetizer = 0] = "Packetizer", e[e.Encryption = 1] = "Encryption";
})(rm ||= {});
var im = class e extends Sc {
	constructor(e, t, n) {
		super(21, e, n), this.name = "DataTrackOutgoingPipelineError", this.reason = t, this.reasonName = rm[t];
	}
	static packetizer(t) {
		return new e("Error packetizing frame", rm.Packetizer, { cause: t });
	}
	static encryption(t) {
		return new e("Error encrypting frame", rm.Encryption, { cause: t });
	}
}, am = class e {
	constructor(e, t) {
		this.trackSymbol = Pp, this.isLocal = !0, this.typeSymbol = Fp, this.handle = null, this.log = A, this.flushedFuture = new U(), this.isFlushed = !0, this.handleManagerReset = () => {
			var e, t;
			(t = (e = this.flushedFuture).resolve) == null || t.call(e), this.manager.off("packetsFlushedChange", this.handleManagerPacketsFlushedChange), this.manager.off("reset", this.handleManagerReset);
		}, this.handleManagerPacketsFlushedChange = (e) => {
			var t, n;
			this.isFlushed = e.isFlushed, e.isFlushed && ((n = (t = this.flushedFuture).resolve) == null || n.call(t), this.flushedFuture = new U());
		}, this.options = e, this.manager = t, this.log = Lo(k.DataTracks), this.manager.on("packetsFlushedChange", this.handleManagerPacketsFlushedChange), this.manager.on("reset", this.handleManagerReset);
	}
	static withExplicitHandle(t, n, r) {
		let i = new e(t, n);
		return i.handle = r, i;
	}
	get info() {
		let e = this.descriptor;
		if (e?.type === "active") return e.info;
	}
	get descriptor() {
		return this.handle ? this.manager.getDescriptor(this.handle) : null;
	}
	publish(e) {
		return j(this, void 0, void 0, function* () {
			try {
				this.handle = yield this.manager.publishRequest(this.options, e);
			} catch (e) {
				throw e;
			}
		});
	}
	isPublished() {
		return this.descriptor?.type === "active" && this.descriptor.publishState !== "unpublished";
	}
	tryPush(e) {
		if (!this.handle) throw nm.trackUnpublished();
		let t = Np.from(e);
		try {
			return this.manager.tryProcessAndSend(this.handle, t);
		} catch (e) {
			throw e;
		}
	}
	flush() {
		return j(this, void 0, void 0, function* () {
			if (!this.isFlushed) return this.flushedFuture.promise;
		});
	}
	unpublish() {
		return j(this, void 0, void 0, function* () {
			if (!this.handle) {
				A.warn(`Data track "${this.options.name}" is not published, so unpublishing has no effect.`);
				return;
			}
			try {
				yield this.manager.unpublishRequest(this.handle);
			} catch (e) {
				throw e;
			}
		});
	}
}, om = class e {
	constructor(t) {
		this.e2eeManager = t.e2eeManager, this.packetizer = new Qp(t.info.pubHandle, e.TRANSPORT_MTU_BYTES);
	}
	updateE2eeManager(e) {
		this.e2eeManager = e;
	}
	processFrame(e) {
		return qo(this, arguments, function* () {
			let t = yield Ko(this.encryptIfNeeded(e));
			try {
				yield Ko(yield* Jo(Yo(this.packetizer.packetize(t))));
			} catch (e) {
				throw e instanceof Xp ? im.packetizer(e) : e;
			}
		});
	}
	encryptIfNeeded(e) {
		return j(this, void 0, void 0, function* () {
			if (!this.e2eeManager) return e;
			let t;
			try {
				t = yield this.e2eeManager.encryptData(e.payload);
			} catch (e) {
				throw im.encryption(e);
			}
			return e.payload = t.payload, e.extensions.e2ee = new jp(t.keyIndex, t.iv), e;
		});
	}
};
om.TRANSPORT_MTU_BYTES = 16e3;
var sm = Lo(k.DataTracks), cm = {
	pending() {
		return {
			type: "pending",
			completionFuture: new U()
		};
	},
	active(e, t) {
		return {
			type: "active",
			info: e,
			publishState: "published",
			pipeline: new om({
				info: e,
				e2eeManager: t
			}),
			unpublishingFuture: new U()
		};
	}
}, lm = 1e4, um = class e extends $o.EventEmitter {
	constructor(e) {
		super(), this.handleAllocator = new dd(), this.descriptors = /* @__PURE__ */ new Map(), this.inFlightPacketCounter = /* @__PURE__ */ new Map(), this.e2eeManager = e?.e2eeManager ?? null;
	}
	static withDescriptors(t) {
		let n = new e();
		return n.descriptors = t, n;
	}
	updateE2eeManager(e) {
		this.e2eeManager = e;
		for (let t of this.descriptors.values()) t.type === "active" && t.pipeline.updateE2eeManager(e);
	}
	getDescriptor(e) {
		return this.descriptors.get(e) ?? null;
	}
	tryProcessAndSend(e, t) {
		return j(this, void 0, void 0, function* () {
			var n, r, i, a;
			let o = this.getDescriptor(e);
			if (o?.type !== "active" || o.publishState === "unpublished") throw nm.trackUnpublished();
			if (o.publishState === "republishing") throw nm.dropped("Data track republishing");
			try {
				try {
					for (var s = !0, c = Yo(o.pipeline.processFrame(t)), l; l = yield c.next(), n = l.done, !n; s = !0) {
						a = l.value, s = !1;
						let t = a, n = this.inFlightPacketCounter.get(e) ?? 0;
						this.inFlightPacketCounter.set(e, n + 1), n === 0 && this.emit("packetsFlushedChange", {
							handle: e,
							isFlushed: !1
						}), this.emit("packetAvailable", {
							handle: e,
							bytes: t.toBinary()
						});
					}
				} catch (e) {
					r = { error: e };
				} finally {
					try {
						!s && !n && (i = c.return) && (yield i.call(c));
					} finally {
						if (r) throw r.error;
					}
				}
			} catch (e) {
				throw nm.dropped(e);
			}
		});
	}
	handlePacketSendComplete(e) {
		let t = (this.inFlightPacketCounter.get(e) ?? 0) - 1;
		t < 0 && (sm.warn(`OutgoingDataTrackManager.handlePacketSendComplete: inFlightPacketCounter was decremented below 0 (got ${this.inFlightPacketCounter} - resetting to 0. Were more packets send than were emitted?`), t = 0), this.inFlightPacketCounter.set(e, t), t === 0 && this.emit("packetsFlushedChange", {
			handle: e,
			isFlushed: !0
		});
	}
	publishRequest(e, t) {
		return j(this, void 0, void 0, function* () {
			let n = this.handleAllocator.get();
			if (!n) throw em.limitReached();
			let r = ip(lm), i = t ? rp([t, r]) : r;
			if (this.descriptors.has(n)) throw Error("Descriptor for handle already exists");
			let a = cm.pending();
			this.descriptors.set(n, a);
			let o = () => {
				var e, t;
				let i = this.descriptors.get(n);
				if (!i) {
					sm.warn(`No descriptor for ${n}`);
					return;
				}
				this.descriptors.delete(n), this.emit("sfuUnpublishRequest", { handle: n }), i.type === "pending" && ((t = (e = i.completionFuture).reject) == null || t.call(e, r.aborted ? em.timeout() : em.cancelled()));
			};
			return i.aborted ? (o(), a.completionFuture.promise.then(() => n)) : (i.addEventListener("abort", o), this.emit("sfuPublishRequest", {
				handle: n,
				name: e.name,
				usesE2ee: this.e2eeManager !== null
			}), yield a.completionFuture.promise, i.removeEventListener("abort", o), this.emit("trackPublished", { track: am.withExplicitHandle(e, this, n) }), n);
		});
	}
	queryPublished() {
		return Array.from(this.descriptors.values()).filter((e) => e.type === "active").map((e) => e.info);
	}
	unpublishRequest(e) {
		return j(this, void 0, void 0, function* () {
			let t = this.descriptors.get(e);
			if (!t) {
				sm.warn(`No descriptor for ${e}`);
				return;
			}
			if (t.type !== "active") {
				sm.warn(`Track ${e} not active`);
				return;
			}
			this.emit("sfuUnpublishRequest", { handle: e }), yield t.unpublishingFuture.promise, this.inFlightPacketCounter.delete(e), this.emit("trackUnpublished", { sid: t.info.sid });
		});
	}
	receivedSfuPublishResponse(e, t) {
		var n, r, i, a;
		let o = this.descriptors.get(e);
		if (!o) {
			sm.warn(`No descriptor for ${e}`);
			return;
		}
		switch (this.descriptors.delete(e), o.type) {
			case "pending":
				if (t.type === "ok") {
					let e = t.data, i = e.usesE2ee ? this.e2eeManager : null;
					this.descriptors.set(e.pubHandle, cm.active(e, i)), (r = (n = o.completionFuture).resolve) == null || r.call(n);
				} else (a = (i = o.completionFuture).reject) == null || a.call(i, t.error);
				return;
			case "active":
				if (o.publishState !== "republishing") {
					sm.warn(`Track ${e} already active`);
					return;
				}
				if (t.type === "error") {
					sm.warn(`Republish failed for track ${e}`);
					return;
				}
				sm.debug(`Track ${e} republished`), o.info.sid = t.data.sid, o.publishState = "published", this.descriptors.set(o.info.pubHandle, o);
		}
	}
	receivedSfuUnpublishResponse(e) {
		var t, n;
		let r = this.descriptors.get(e);
		if (!r) {
			sm.warn(`No descriptor for ${e}`);
			return;
		}
		if (this.descriptors.delete(e), r.type !== "active") {
			sm.warn(`Track ${e} not active`);
			return;
		}
		r.publishState = "unpublished", (n = (t = r.unpublishingFuture).resolve) == null || n.call(t);
	}
	sfuWillRepublishTracks() {
		var e, t;
		for (let r of this.descriptors.entries()) {
			var n = C(r, 2);
			let i = n[0], a = n[1];
			switch (a.type) {
				case "pending":
					this.descriptors.delete(i), (t = (e = a.completionFuture).reject) == null || t.call(e, em.disconnected());
					break;
				case "active": a.publishState = "republishing", this.emit("sfuPublishRequest", {
					handle: a.info.pubHandle,
					name: a.info.name,
					usesE2ee: a.info.usesE2ee
				});
			}
		}
	}
	reset() {
		return j(this, void 0, void 0, function* () {
			var e, t, n, r;
			this.handleAllocator.reset();
			for (let i of this.descriptors.values()) switch (i.type) {
				case "pending":
					(t = (e = i.completionFuture).reject) == null || t.call(e, em.disconnected());
					break;
				case "active":
					(r = (n = i.unpublishingFuture).resolve) == null || r.call(n), yield this.unpublishRequest(i.info.pubHandle);
					break;
			}
			this.descriptors.clear(), this.inFlightPacketCounter.clear(), this.emit("reset");
		});
	}
}, Y = class e extends Error {
	constructor(t, n, r, i) {
		super(n), this.code = t, this.message = vm(n, e.MAX_MESSAGE_BYTES), this.data = r ? vm(r, e.MAX_DATA_BYTES) : void 0, i?.cause !== void 0 && (this.cause = i?.cause);
	}
	static fromProto(t) {
		return new e(t.code, t.message, t.data);
	}
	toProto() {
		return new ta({
			code: this.code,
			message: this.message,
			data: this.data
		});
	}
	static builtIn(t, n, r) {
		return new e(e.ErrorCode[t], e.ErrorMessage[t], n, r);
	}
};
Y.MAX_MESSAGE_BYTES = 256, Y.MAX_DATA_BYTES = 15360, Y.ErrorCode = {
	APPLICATION_ERROR: 1500,
	CONNECTION_TIMEOUT: 1501,
	RESPONSE_TIMEOUT: 1502,
	RECIPIENT_DISCONNECTED: 1503,
	RESPONSE_PAYLOAD_TOO_LARGE: 1504,
	SEND_FAILED: 1505,
	UNSUPPORTED_METHOD: 1400,
	RECIPIENT_NOT_FOUND: 1401,
	REQUEST_PAYLOAD_TOO_LARGE: 1402,
	UNSUPPORTED_SERVER: 1403,
	UNSUPPORTED_VERSION: 1404
}, Y.ErrorMessage = {
	APPLICATION_ERROR: "Application error in method handler",
	CONNECTION_TIMEOUT: "Connection timeout",
	RESPONSE_TIMEOUT: "Response timeout",
	RECIPIENT_DISCONNECTED: "Recipient disconnected",
	RESPONSE_PAYLOAD_TOO_LARGE: "Response payload too large",
	SEND_FAILED: "Failed to send",
	UNSUPPORTED_METHOD: "Method not supported at destination",
	RECIPIENT_NOT_FOUND: "Recipient not found",
	REQUEST_PAYLOAD_TOO_LARGE: "Request payload too large",
	UNSUPPORTED_SERVER: "RPC not supported by server",
	UNSUPPORTED_VERSION: "Unsupported RPC version"
};
var dm = 15360, fm = "lk.rpc_request", pm = "lk.rpc_response", mm;
(function(e) {
	e.RPC_REQUEST_ID = "lk.rpc_request_id", e.RPC_REQUEST_METHOD = "lk.rpc_request_method", e.RPC_REQUEST_RESPONSE_TIMEOUT_MS = "lk.rpc_request_response_timeout_ms", e.RPC_REQUEST_VERSION = "lk.rpc_request_version";
})(mm ||= {});
var hm = 1, gm = 2;
function _m(e) {
	return new TextEncoder().encode(e).length;
}
function vm(e, t) {
	if (_m(e) <= t) return e;
	let n = 0, r = e.length, i = new TextEncoder();
	for (; n < r;) {
		let a = Math.floor((n + r + 1) / 2);
		i.encode(e.slice(0, a)).length <= t ? n = a : r = a - 1;
	}
	return e.slice(0, n);
}
var ym = class extends es {
	constructor(e, t, n, r) {
		super(), this.pendingAcks = /* @__PURE__ */ new Map(), this.pendingResponses = /* @__PURE__ */ new Map(), this.log = e, this.outgoingDataStreamManager = t, this.getRemoteParticipantClientProtocol = n, this.getServerVersion = r;
	}
	performRpc(e) {
		return j(this, arguments, void 0, function(e) {
			var t = this;
			let n = e.destinationIdentity, r = e.method, i = e.payload, a = e.responseTimeout, o = a === void 0 ? 15e3 : a;
			return function* () {
				let e = t.getRemoteParticipantClientProtocol(n);
				if (_m(i) > dm && e < 1) throw Y.builtIn("REQUEST_PAYLOAD_TOO_LARGE");
				let a = t.getServerVersion();
				if (a && Ll(a, "1.8.0") < 0) throw Y.builtIn("UNSUPPORTED_SERVER");
				let s = Math.max(o, 8e3), c = crypto.randomUUID(), l = new U(), u = null, d = setTimeout(() => {
					var e;
					t.pendingAcks.delete(c), (e = l.reject) == null || e.call(l, Y.builtIn("CONNECTION_TIMEOUT")), t.pendingResponses.delete(c), u !== null && clearTimeout(u);
				}, 7e3);
				return t.pendingAcks.set(c, {
					resolve: () => {
						clearTimeout(d);
					},
					participantIdentity: n
				}), t.pendingResponses.set(c, {
					completionFuture: l,
					participantIdentity: n
				}), yield t.publishRpcRequest(n, c, r, i, s, e), u = setTimeout(() => {
					var e;
					t.pendingResponses.delete(c), (e = l.reject) == null || e.call(l, Y.builtIn("RESPONSE_TIMEOUT"));
				}, o), [c, l.promise.finally(() => {
					clearTimeout(u), t.pendingAcks.has(c) && (t.log.warn("RPC response received before ack", c), t.pendingAcks.delete(c), clearTimeout(d));
				})];
			}();
		});
	}
	publishRpcRequest(e, t, n, r, i, a) {
		return j(this, void 0, void 0, function* () {
			if (a >= 1) {
				let a = yield this.outgoingDataStreamManager.streamText({
					topic: fm,
					destinationIdentities: [e],
					attributes: {
						[mm.RPC_REQUEST_ID]: t,
						[mm.RPC_REQUEST_METHOD]: n,
						[mm.RPC_REQUEST_RESPONSE_TIMEOUT_MS]: `${i}`,
						[mm.RPC_REQUEST_VERSION]: `${gm}`
					}
				});
				yield a.write(r), yield a.close();
				return;
			}
			this.emit("sendDataPacket", { packet: new Vi({
				destinationIdentities: [e],
				kind: Hi.RELIABLE,
				value: {
					case: "rpcRequest",
					value: new Qi({
						id: t,
						method: n,
						payload: r,
						responseTimeoutMs: i,
						version: hm
					})
				}
			}) });
		});
	}
	handleIncomingDataStream(e, t, n) {
		return j(this, void 0, void 0, function* () {
			let r = n[mm.RPC_REQUEST_ID];
			if (!r) {
				this.log.warn(`RPC data stream malformed: ${mm.RPC_REQUEST_ID} not set.`);
				return;
			}
			let i = this.pendingResponses.get(r);
			if (i && i.participantIdentity !== t) {
				this.log.warn(`RPC response stream for ${r} arrived from unexpected sender ${t}, expected ${i.participantIdentity}. Ignoring.`);
				return;
			}
			let a;
			try {
				a = yield e.readAll();
			} catch (e) {
				this.log.warn(`Error reading RPC response payload: ${e}`), this.handleIncomingRpcResponseFailure(r, Y.builtIn("APPLICATION_ERROR", "Error reading RPC response payload", { cause: e }));
				return;
			}
			this.handleIncomingRpcResponseSuccess(r, a);
		});
	}
	handleIncomingRpcResponseSuccess(e, t) {
		var n, r;
		let i = this.pendingResponses.get(e);
		i ? ((r = (n = i.completionFuture).resolve) == null || r.call(n, t), this.pendingResponses.delete(e)) : this.log.error("Response received for unexpected RPC request", e);
	}
	handleIncomingRpcResponseFailure(e, t) {
		var n, r;
		let i = this.pendingResponses.get(e);
		i ? ((r = (n = i.completionFuture).reject) == null || r.call(n, t), this.pendingResponses.delete(e)) : this.log.error("Response received for unexpected RPC request", e);
	}
	handleIncomingRpcAck(e) {
		let t = this.pendingAcks.get(e);
		t ? (t.resolve(), this.pendingAcks.delete(e)) : this.log.error(`Ack received for unexpected RPC request: ${e}`);
	}
	handleParticipantDisconnected(e) {
		var t;
		for (let t of this.pendingAcks) {
			var n = C(t, 2);
			let r = n[0];
			n[1].participantIdentity === e && this.pendingAcks.delete(r);
		}
		for (let n of this.pendingResponses) {
			var r = C(n, 2);
			let a = r[0];
			var i = r[1];
			let o = i.participantIdentity, s = i.completionFuture;
			o === e && ((t = s.reject) == null || t.call(s, Y.builtIn("RECIPIENT_DISCONNECTED")), this.pendingResponses.delete(a));
		}
	}
}, bm = class extends es {
	constructor(e, t, n) {
		super(), this.rpcHandlers = /* @__PURE__ */ new Map(), this.log = e, this.outgoingDataStreamManager = t, this.getRemoteParticipantClientProtocol = n;
	}
	registerRpcMethod(e, t) {
		if (this.rpcHandlers.has(e)) throw Error(`RPC handler already registered for method ${e}, unregisterRpcMethod before trying to register again`);
		this.rpcHandlers.set(e, t);
	}
	unregisterRpcMethod(e) {
		this.rpcHandlers.delete(e);
	}
	handleIncomingRpcRequest(e, t) {
		return j(this, void 0, void 0, function* () {
			if (this.publishRpcAck(e, t.id), t.version !== 1) {
				this.publishRpcResponsePacket(e, t.id, null, Y.builtIn("UNSUPPORTED_VERSION"));
				return;
			}
			let n = this.rpcHandlers.get(t.method);
			if (!n) {
				this.publishRpcResponsePacket(e, t.id, null, Y.builtIn("UNSUPPORTED_METHOD"));
				return;
			}
			let r;
			try {
				r = yield n({
					requestId: t.id,
					callerIdentity: e,
					payload: t.payload,
					responseTimeout: t.responseTimeoutMs
				});
			} catch (n) {
				let r;
				n instanceof Y ? r = n : (this.log.warn(`Uncaught error returned by RPC handler for ${t.method}. Returning APPLICATION_ERROR instead.`, n), r = Y.builtIn("APPLICATION_ERROR", `Uncaught error: ${n?.message ?? n}`, { cause: n })), this.publishRpcResponsePacket(e, t.id, null, r);
				return;
			}
			yield this.publishRpcResponse(e, t.id, r ?? "");
		});
	}
	handleIncomingDataStream(e, t, n) {
		return j(this, void 0, void 0, function* () {
			let r = n[mm.RPC_REQUEST_ID], i = n[mm.RPC_REQUEST_METHOD], a = parseInt(n[mm.RPC_REQUEST_RESPONSE_TIMEOUT_MS], 10), o = parseInt(n[mm.RPC_REQUEST_VERSION], 10);
			if (!r || !i || Number.isNaN(a) || Number.isNaN(o)) {
				this.log.warn(`RPC data stream malformed: ${mm.RPC_REQUEST_ID} / ${mm.RPC_REQUEST_METHOD} / ${mm.RPC_REQUEST_RESPONSE_TIMEOUT_MS} / ${mm.RPC_REQUEST_VERSION} not set.`), this.publishRpcResponsePacket(t, r, null, Y.builtIn("APPLICATION_ERROR", "RPC data stream malformed"));
				return;
			}
			if (this.publishRpcAck(t, r), o !== gm) {
				this.publishRpcResponsePacket(t, r, null, Y.builtIn("UNSUPPORTED_VERSION"));
				return;
			}
			let s;
			try {
				s = yield e.readAll();
			} catch (e) {
				this.log.warn(`Error reading RPC request payload: ${e}`), this.publishRpcResponsePacket(t, r, null, Y.builtIn("APPLICATION_ERROR", "Error reading RPC request payload", { cause: e }));
				return;
			}
			let c = this.rpcHandlers.get(i);
			if (!c) {
				this.publishRpcResponsePacket(t, r, null, Y.builtIn("UNSUPPORTED_METHOD"));
				return;
			}
			let l;
			try {
				l = yield c({
					requestId: r,
					callerIdentity: t,
					payload: s,
					responseTimeout: a
				});
			} catch (e) {
				let n;
				e instanceof Y ? n = e : (this.log.warn(`Uncaught error returned by RPC handler for ${i}. Returning APPLICATION_ERROR instead.`, e), n = Y.builtIn("APPLICATION_ERROR")), this.publishRpcResponsePacket(t, r, null, n);
				return;
			}
			yield this.publishRpcResponse(t, r, l ?? "");
		});
	}
	publishRpcAck(e, t) {
		this.emit("sendDataPacket", { packet: new Vi({
			destinationIdentities: [e],
			kind: Hi.RELIABLE,
			value: {
				case: "rpcAck",
				value: new $i({ requestId: t })
			}
		}) });
	}
	publishRpcResponsePacket(e, t, n, r) {
		this.emit("sendDataPacket", { packet: new Vi({
			destinationIdentities: [e],
			kind: Hi.RELIABLE,
			value: {
				case: "rpcResponse",
				value: new ea({
					requestId: t,
					value: r ? {
						case: "error",
						value: r.toProto()
					} : {
						case: "payload",
						value: n ?? ""
					}
				})
			}
		}) });
	}
	publishRpcResponse(e, t, n) {
		return j(this, void 0, void 0, function* () {
			if (this.getRemoteParticipantClientProtocol(e) >= 1) {
				let r = yield this.outgoingDataStreamManager.streamText({
					topic: pm,
					destinationIdentities: [e],
					attributes: { [mm.RPC_REQUEST_ID]: t }
				});
				yield r.write(n), yield r.close();
				return;
			}
			if (_m(n) > dm) {
				this.log.warn(`RPC Response payload too large for request ${t}. To send larger responses, consider updating the sending client.`), this.publishRpcResponsePacket(e, t, null, Y.builtIn("RESPONSE_PAYLOAD_TOO_LARGE"));
				return;
			}
			this.publishRpcResponsePacket(e, t, n, null);
		});
	}
}, xm = class extends Vu {
	constructor(e, t, n, r, i, a) {
		super(e, t, H.Kind.Audio, n, a), this.monitorReceiver = () => j(this, void 0, void 0, function* () {
			if (!this.receiver) {
				this._currentBitrate = 0;
				return;
			}
			let e = yield this.getReceiverStats();
			e && this.prevStats && this.receiver && (this._currentBitrate = Bu(e, this.prevStats)), this.prevStats = e;
		}), this.audioContext = r, this.webAudioPluginNodes = [], i && (this.sinkId = i.deviceId);
	}
	setVolume(e) {
		var t;
		for (let n of this.attachedElements) this.audioContext ? (t = this.gainNode) == null || t.gain.setTargetAtTime(e, 0, .1) : n.volume = e;
		jl() && this._mediaStreamTrack._setVolume(e), this.elementVolume = e;
	}
	getVolume() {
		if (this.elementVolume) return this.elementVolume;
		if (jl()) return 1;
		let e = 0;
		return this.attachedElements.forEach((t) => {
			t.volume > e && (e = t.volume);
		}), e;
	}
	setSinkId(e) {
		return j(this, void 0, void 0, function* () {
			this.sinkId = e, yield Promise.all(this.attachedElements.map((t) => {
				if (yl(t)) return t.setSinkId(e);
			}));
		});
	}
	attach(e) {
		let t = this.attachedElements.length === 0;
		return e ? super.attach(e) : e = super.attach(), this.sinkId && yl(e) && e.setSinkId(this.sinkId).catch((e) => {
			this.log.error("Failed to set sink id on remote audio track", e, this.logContext);
		}), this.audioContext && t && (this.log.debug("using audio context mapping", this.logContext), this.connectWebAudio(this.audioContext, e), e.volume = 0, e.muted = !0), this.elementVolume && this.setVolume(this.elementVolume), e;
	}
	detach(e) {
		let t;
		return e ? (t = super.detach(e), this.audioContext && (this.attachedElements.length > 0 ? this.connectWebAudio(this.audioContext, this.attachedElements[0]) : this.disconnectWebAudio())) : (t = super.detach(), this.disconnectWebAudio()), t;
	}
	setAudioContext(e) {
		this.audioContext = e, e && this.attachedElements.length > 0 ? this.connectWebAudio(e, this.attachedElements[0]) : e || this.disconnectWebAudio();
	}
	setWebAudioPlugins(e) {
		this.webAudioPluginNodes = e, this.attachedElements.length > 0 && this.audioContext && this.connectWebAudio(this.audioContext, this.attachedElements[0]);
	}
	connectWebAudio(e, t) {
		this.disconnectWebAudio(), this.sourceNode = e.createMediaStreamSource(t.srcObject);
		let n = this.sourceNode;
		this.webAudioPluginNodes.forEach((e) => {
			n.connect(e), n = e;
		}), this.gainNode = e.createGain(), n.connect(this.gainNode), this.gainNode.connect(e.destination), this.elementVolume && this.gainNode.gain.setTargetAtTime(this.elementVolume, 0, .1), e.state !== "running" && e.resume().then(() => {
			e.state !== "running" && this.emit(z.AudioPlaybackFailed, /* @__PURE__ */ Error("Audio Context couldn't be started automatically"));
		}).catch((e) => {
			this.emit(z.AudioPlaybackFailed, e);
		});
	}
	disconnectWebAudio() {
		var e, t;
		(e = this.gainNode) == null || e.disconnect(), (t = this.sourceNode) == null || t.disconnect(), this.gainNode = void 0, this.sourceNode = void 0;
	}
	getReceiverStats() {
		return j(this, void 0, void 0, function* () {
			if (!this.receiver || !this.receiver.getStats) return;
			let e = yield this.receiver.getStats(), t;
			return e.forEach((e) => {
				e.type === "inbound-rtp" && (t = {
					type: "audio",
					streamId: e.id,
					timestamp: e.timestamp,
					jitter: e.jitter,
					bytesReceived: e.bytesReceived,
					concealedSamples: e.concealedSamples,
					concealmentEvents: e.concealmentEvents,
					silentConcealedSamples: e.silentConcealedSamples,
					silentConcealmentEvents: e.silentConcealmentEvents,
					totalAudioEnergy: e.totalAudioEnergy,
					totalSamplesDuration: e.totalSamplesDuration
				});
			}), t;
		});
	}
}, Sm = class extends $o.EventEmitter {
	constructor(e, t, n, r) {
		super(), this.metadataMuted = !1, this.encryption = O.NONE, this.log = A, this.handleMuted = () => {
			this.emit(z.Muted);
		}, this.handleUnmuted = () => {
			this.emit(z.Unmuted);
		}, this.log = Lo(r?.loggerName ?? k.Publication), this.loggerContextCb = this.loggerContextCb, this.setMaxListeners(100), this.kind = e, this.trackSid = t, this.trackName = n, this.source = H.Source.Unknown;
	}
	setTrack(e) {
		this.track && (this.track.off(z.Muted, this.handleMuted), this.track.off(z.Unmuted, this.handleUnmuted)), this.track = e, e && (e.on(z.Muted, this.handleMuted), e.on(z.Unmuted, this.handleUnmuted));
	}
	get logContext() {
		return Object.assign(Object.assign({}, this.loggerContextCb?.call(this)), V(this));
	}
	get isMuted() {
		return this.metadataMuted;
	}
	get isEnabled() {
		return !0;
	}
	get isSubscribed() {
		return this.track !== void 0;
	}
	get isEncrypted() {
		return this.encryption !== O.NONE;
	}
	get audioTrack() {
		if (iu(this.track)) return this.track;
	}
	get videoTrack() {
		if (au(this.track)) return this.track;
	}
	updateInfo(e) {
		this.trackSid = e.sid, this.trackName = e.name, this.source = H.sourceFromProto(e.source), this.mimeType = e.mimeType, this.kind === H.Kind.Video && e.width > 0 && (this.dimensions = {
			width: e.width,
			height: e.height
		}, this.simulcasted = e.simulcast), this.encryption = e.encryption, this.trackInfo = e, this.log.debug("update publication info", Object.assign(Object.assign({}, this.logContext), { info: e }));
	}
};
(function(e) {
	(function(e) {
		e.Desired = "desired", e.Subscribed = "subscribed", e.Unsubscribed = "unsubscribed";
	})(e.SubscriptionStatus ||= {}), (function(e) {
		e.Allowed = "allowed", e.NotAllowed = "not_allowed";
	})(e.PermissionStatus ||= {});
})(Sm ||= {});
var Cm = class extends Sm {
	get isUpstreamPaused() {
		return this.track?.isUpstreamPaused;
	}
	constructor(e, t, n, r) {
		super(e, t.sid, t.name, r), this.track = void 0, this.handleTrackEnded = () => {
			this.emit(z.Ended);
		}, this.handleCpuConstrained = () => {
			this.track && au(this.track) && this.emit(z.CpuConstrained, this.track);
		}, this.updateInfo(t), this.setTrack(n);
	}
	setTrack(e) {
		this.track && (this.track.off(z.Ended, this.handleTrackEnded), this.track.off(z.CpuConstrained, this.handleCpuConstrained)), super.setTrack(e), e && (e.on(z.Ended, this.handleTrackEnded), e.on(z.CpuConstrained, this.handleCpuConstrained));
	}
	get isMuted() {
		return this.track ? this.track.isMuted : super.isMuted;
	}
	get audioTrack() {
		return super.audioTrack;
	}
	get videoTrack() {
		return super.videoTrack;
	}
	get isLocal() {
		return !0;
	}
	mute() {
		return j(this, void 0, void 0, function* () {
			return this.track?.mute();
		});
	}
	unmute() {
		return j(this, void 0, void 0, function* () {
			return this.track?.unmute();
		});
	}
	pauseUpstream() {
		return j(this, void 0, void 0, function* () {
			yield this.track?.pauseUpstream();
		});
	}
	resumeUpstream() {
		return j(this, void 0, void 0, function* () {
			yield this.track?.resumeUpstream();
		});
	}
	getTrackFeatures() {
		if (iu(this.track)) {
			let e = this.track.getSourceTrackSettings(), t = /* @__PURE__ */ new Set();
			return e.autoGainControl && t.add(D.TF_AUTO_GAIN_CONTROL), e.echoCancellation && t.add(D.TF_ECHO_CANCELLATION), e.noiseSuppression && t.add(D.TF_NOISE_SUPPRESSION), e.channelCount && e.channelCount > 1 && t.add(D.TF_STEREO), this.options?.dtx || t.add(D.TF_NO_DTX), this.track.enhancedNoiseCancellation && t.add(D.TF_ENHANCED_NOISE_CANCELLATION), Array.from(t.values());
		} else return [];
	}
};
function wm(e, t) {
	return j(this, void 0, void 0, function* () {
		e ??= {};
		let n = !1, r = tl(e), i = r.audioProcessor, a = r.videoProcessor, o = r.optionsWithoutProcessor, s = o.audio, c = o.video;
		if (i && typeof o.audio == "object" && (o.audio.processor = i), a && typeof o.video == "object" && (o.video.processor = a), e.audio && typeof o.audio == "object" && typeof o.audio.deviceId == "string") {
			let e = o.audio.deviceId;
			o.audio.deviceId = { exact: e }, n = !0, s = Object.assign(Object.assign({}, o.audio), { deviceId: { ideal: e } });
		}
		if (o.video && typeof o.video == "object" && typeof o.video.deviceId == "string") {
			let e = o.video.deviceId;
			o.video.deviceId = { exact: e }, n = !0, c = Object.assign(Object.assign({}, o.video), { deviceId: { ideal: e } });
		}
		o.audio === !0 ? o.audio = { deviceId: "default" } : typeof o.audio == "object" && o.audio !== null && (o.audio = Object.assign(Object.assign({}, o.audio), { deviceId: o.audio.deviceId || "default" })), o.video === !0 ? o.video = { deviceId: "default" } : typeof o.video == "object" && !o.video.deviceId && (o.video.deviceId = "default");
		let l = Gc(Uc(o, Yd, Xd)), u = navigator.mediaDevices.getUserMedia(l);
		o.audio && (td.userMediaPromiseMap.set("audioinput", u), u.catch(() => td.userMediaPromiseMap.delete("audioinput"))), o.video && (td.userMediaPromiseMap.set("videoinput", u), u.catch(() => td.userMediaPromiseMap.delete("videoinput")));
		try {
			let e = yield u;
			return yield Promise.all(e.getTracks().map((n) => j(this, void 0, void 0, function* () {
				let r = n.kind === "audio", o, s = r ? l.audio : l.video;
				typeof s != "boolean" && (o = s);
				let c = n.getSettings().deviceId;
				o?.deviceId && Yl(o.deviceId) !== c ? o.deviceId = c : o ||= { deviceId: c };
				let u = lf(n, o, t);
				return u.kind === H.Kind.Video ? u.source = H.Source.Camera : u.kind === H.Kind.Audio && (u.source = H.Source.Microphone), u.mediaStream = e, iu(u) && i ? yield u.setProcessor(i) : au(u) && a && (yield u.setProcessor(a)), u;
			})));
		} catch (r) {
			if (!n) throw r;
			return wm(Object.assign(Object.assign({}, e), {
				audio: s,
				video: c
			}), t);
		}
	});
}
function Tm(e) {
	return j(this, void 0, void 0, function* () {
		return (yield wm({
			audio: !1,
			video: e ?? !0
		}))[0];
	});
}
function Em(e) {
	return j(this, void 0, void 0, function* () {
		return (yield wm({
			audio: e ?? !0,
			video: !1
		}))[0];
	});
}
function Dm(e) {
	return j(this, void 0, void 0, function* () {
		if (e === void 0 && (e = {}), e.resolution === void 0 && !El() && (e.resolution = Hc.h1080fps30.resolution), navigator.mediaDevices.getDisplayMedia === void 0) throw new Cc("getDisplayMedia not supported");
		let t = Xc(e), n = yield navigator.mediaDevices.getDisplayMedia(t), r = n.getVideoTracks();
		if (r.length === 0) throw new wc("no video track found");
		let i = new Df(r[0], void 0, !1);
		i.source = H.Source.ScreenShare;
		let a = [i];
		if (n.getAudioTracks().length > 0) {
			let e = new cf(n.getAudioTracks()[0], void 0, !1);
			e.source = H.Source.ScreenShareAudio, a.push(e);
		}
		return a;
	});
}
var Om;
(function(e) {
	e.Excellent = "excellent", e.Good = "good", e.Poor = "poor", e.Lost = "lost", e.Unknown = "unknown";
})(Om ||= {});
function km(e) {
	switch (e) {
		case Si.EXCELLENT: return Om.Excellent;
		case Si.GOOD: return Om.Good;
		case Si.POOR: return Om.Poor;
		case Si.LOST: return Om.Lost;
		default: return Om.Unknown;
	}
}
var Am = class extends $o.EventEmitter {
	get logContext() {
		var e;
		return Object.assign({}, ((e = this.loggerOptions)?.loggerContextCb)?.call(e));
	}
	get isEncrypted() {
		return this.trackPublications.size > 0 && Array.from(this.trackPublications.values()).every((e) => e.isEncrypted);
	}
	get isAgent() {
		return this.permissions?.agent || this.kind === Ni.AGENT;
	}
	get isActive() {
		return this.participantInfo?.state === Mi.ACTIVE;
	}
	get kind() {
		return this._kind;
	}
	get attributes() {
		return Object.freeze(Object.assign({}, this._attributes));
	}
	constructor(e, t, n, r, i, a) {
		let o = arguments.length > 6 && arguments[6] !== void 0 ? arguments[6] : Ni.STANDARD;
		super(), this.audioLevel = 0, this.isSpeaking = !1, this._connectionQuality = Om.Unknown, this.log = A, this.loggerOptions = a, this.log = Lo(a?.loggerName ?? k.Participant, () => this.logContext), this.setMaxListeners(100), this.sid = e, this.identity = t, this.name = n, this.metadata = r, this.audioTrackPublications = /* @__PURE__ */ new Map(), this.videoTrackPublications = /* @__PURE__ */ new Map(), this.trackPublications = /* @__PURE__ */ new Map(), this._kind = o, this._attributes = i ?? {};
	}
	getTrackPublications() {
		return Array.from(this.trackPublications.values());
	}
	getTrackPublication(e) {
		for (let t of this.trackPublications) {
			let n = C(t, 2)[1];
			if (n.source === e) return n;
		}
	}
	getTrackPublicationByName(e) {
		for (let t of this.trackPublications) {
			let n = C(t, 2)[1];
			if (n.trackName === e) return n;
		}
	}
	waitUntilActive() {
		return this.isActive ? Promise.resolve() : this.activeFuture ? this.activeFuture.promise : (this.activeFuture = new U(), this.once(L.Active, () => {
			var e, t;
			(t = (e = this.activeFuture)?.resolve) == null || t.call(e), this.activeFuture = void 0;
		}), this.activeFuture.promise);
	}
	get connectionQuality() {
		return this._connectionQuality;
	}
	get isCameraEnabled() {
		return !(this.getTrackPublication(H.Source.Camera)?.isMuted ?? !0);
	}
	get isMicrophoneEnabled() {
		return !(this.getTrackPublication(H.Source.Microphone)?.isMuted ?? !0);
	}
	get isScreenShareEnabled() {
		return !!this.getTrackPublication(H.Source.ScreenShare);
	}
	get isLocal() {
		return !1;
	}
	get joinedAt() {
		return this.participantInfo ? /* @__PURE__ */ new Date(Number.parseInt(this.participantInfo.joinedAt.toString()) * 1e3) : /* @__PURE__ */ new Date();
	}
	updateInfo(e) {
		return this.participantInfo && this.participantInfo.sid === e.sid && this.participantInfo.version > e.version ? !1 : (this.identity = e.identity, this.sid = e.sid, this._setName(e.name), this._setMetadata(e.metadata), this._setAttributes(e.attributes), e.state === Mi.ACTIVE && this.participantInfo?.state !== Mi.ACTIVE && this.emit(L.Active), e.permission && this.setPermissions(e.permission), this.participantInfo = e, !0);
	}
	_setMetadata(e) {
		let t = this.metadata !== e, n = this.metadata;
		this.metadata = e, t && this.emit(L.ParticipantMetadataChanged, n);
	}
	_setName(e) {
		let t = this.name !== e;
		this.name = e, t && this.emit(L.ParticipantNameChanged, e);
	}
	_setAttributes(e) {
		let t = el(this.attributes, e);
		this._attributes = e, Object.keys(t).length > 0 && this.emit(L.AttributesChanged, t);
	}
	setPermissions(e) {
		let t = this.permissions, n = e.canPublish !== this.permissions?.canPublish || e.canSubscribe !== this.permissions?.canSubscribe || e.canPublishData !== this.permissions?.canPublishData || e.hidden !== this.permissions?.hidden || e.recorder !== this.permissions?.recorder || e.canPublishSources.length !== this.permissions.canPublishSources.length || e.canPublishSources.some((e, t) => e !== this.permissions?.canPublishSources[t]) || e.canSubscribeMetrics !== this.permissions?.canSubscribeMetrics;
		return this.permissions = e, n && this.emit(L.ParticipantPermissionsChanged, t), n;
	}
	setIsSpeaking(e) {
		e !== this.isSpeaking && (this.isSpeaking = e, e && (this.lastSpokeAt = /* @__PURE__ */ new Date()), this.emit(L.IsSpeakingChanged, e));
	}
	setConnectionQuality(e) {
		let t = this._connectionQuality;
		this._connectionQuality = km(e), t !== this._connectionQuality && this.emit(L.ConnectionQualityChanged, this._connectionQuality);
	}
	setDisconnected() {
		var e, t;
		this.activeFuture &&= ((t = (e = this.activeFuture).reject) == null || t.call(e, /* @__PURE__ */ Error("Participant disconnected")), void 0);
	}
	setAudioContext(e) {
		this.audioContext = e, this.audioTrackPublications.forEach((t) => iu(t.track) && t.track.setAudioContext(e));
	}
	addTrackPublication(e) {
		e.on(z.Muted, () => {
			this.emit(L.TrackMuted, e);
		}), e.on(z.Unmuted, () => {
			this.emit(L.TrackUnmuted, e);
		});
		let t = e;
		switch (t.track && (t.track.sid = e.trackSid), this.trackPublications.set(e.trackSid, e), e.kind) {
			case H.Kind.Audio:
				this.audioTrackPublications.set(e.trackSid, e);
				break;
			case H.Kind.Video:
				this.videoTrackPublications.set(e.trackSid, e);
				break;
		}
	}
};
function jm(e) {
	if (!e.participantSid && !e.participantIdentity) throw Error("Invalid track permission, must provide at least one of participantIdentity and participantSid");
	return new so({
		participantIdentity: e.participantIdentity ?? "",
		participantSid: e.participantSid ?? "",
		allTracks: e.allowAll ?? !1,
		trackSids: e.allowedTrackSids || []
	});
}
var Mm = class extends Am {
	constructor(e, t, n, r, i, a, o, s) {
		super(e, t, void 0, void 0, void 0, {
			loggerName: r.loggerName,
			loggerContextCb: () => this.engine.logContext
		}), this.pendingPublishing = /* @__PURE__ */ new Set(), this.pendingPublishPromises = /* @__PURE__ */ new Map(), this.participantTrackPermissions = [], this.allParticipantsAllowedToSubscribe = !0, this.encryptionType = O.NONE, this.e2eeStateMutex = new v(), this.enabledPublishVideoCodecs = [], this.handleReconnecting = () => {
			this.reconnectFuture ||= new U();
		}, this.handleReconnected = () => {
			var e, t;
			(t = (e = this.reconnectFuture)?.resolve) == null || t.call(e), this.reconnectFuture = void 0, this.updateTrackSubscriptionPermissions();
		}, this.handleClosing = () => {
			var e, t, n, r, i, a;
			this.reconnectFuture &&= (this.reconnectFuture.promise.catch((e) => this.log.warn(e.message)), (t = (e = this.reconnectFuture)?.reject) == null || t.call(e, /* @__PURE__ */ Error("Got disconnected during reconnection attempt")), void 0), this.signalConnectedFuture &&= ((r = (n = this.signalConnectedFuture).reject) == null || r.call(n, /* @__PURE__ */ Error("Got disconnected without signal connected")), void 0), (a = (i = this.activeAgentFuture)?.reject) == null || a.call(i, /* @__PURE__ */ Error("Got disconnected without active agent present")), this.activeAgentFuture = void 0, this.firstActiveAgent = void 0;
		}, this.handleSignalConnected = (e) => {
			var t, n;
			e.participant && this.updateInfo(e.participant), this.signalConnectedFuture ||= new U(), (n = (t = this.signalConnectedFuture).resolve) == null || n.call(t);
		}, this.handleSignalRequestResponse = (e) => {
			let t = e.requestId, n = e.reason, r = e.message, i = this.pendingSignalRequests.get(t);
			switch (i && (n !== So.OK && i.reject(new Oc(r, n)), this.pendingSignalRequests.delete(t)), e.request.case) {
				case "publishDataTrack": {
					let t;
					switch (e.reason) {
						case So.NOT_ALLOWED:
							t = em.notAllowed(e.message);
							break;
						case So.DUPLICATE_NAME:
							t = em.duplicateName(e.message);
							break;
						case So.INVALID_NAME:
							t = em.invalidName(e.message);
							break;
						case So.LIMIT_EXCEEDED:
							t = em.limitReached(e.message);
							break;
						default:
							t = em.unknown(e.reason, e.message);
							break;
					}
					this.roomOutgoingDataTrackManager.receivedSfuPublishResponse(e.request.value.pubHandle, {
						type: "error",
						error: t
					});
					break;
				}
			}
		}, this.updateTrackSubscriptionPermissions = () => {
			this.log.debug("updating track subscription permissions", {
				allParticipantsAllowed: this.allParticipantsAllowedToSubscribe,
				participantTrackPermissions: this.participantTrackPermissions
			}), this.engine.client.sendUpdateSubscriptionPermissions(this.allParticipantsAllowedToSubscribe, this.participantTrackPermissions.map((e) => jm(e)));
		}, this.onTrackUnmuted = (e) => {
			this.onTrackMuted(e, e.isUpstreamPaused);
		}, this.onTrackMuted = (e, t) => {
			if (t === void 0 && (t = !0), !e.sid) {
				this.log.error("could not update mute status for unpublished track", V(e));
				return;
			}
			this.engine.updateMuteStatus(e.sid, t);
		}, this.onTrackUpstreamPaused = (e) => {
			this.log.debug("upstream paused", V(e)), this.onTrackMuted(e, !0);
		}, this.onTrackUpstreamResumed = (e) => {
			this.log.debug("upstream resumed", V(e)), this.onTrackMuted(e, e.isMuted);
		}, this.onTrackFeatureUpdate = (e) => {
			let t = this.audioTrackPublications.get(e.sid);
			if (!t) {
				this.log.warn(`Could not update local audio track settings, missing publication for track ${e.sid}`);
				return;
			}
			this.engine.client.sendUpdateLocalAudioTrack(t.trackSid, t.getTrackFeatures());
		}, this.onTrackCpuConstrained = (e, t) => {
			this.log.debug("track cpu constrained", V(t)), this.emit(L.LocalTrackCpuConstrained, e, t);
		}, this.handleSubscribedQualityUpdate = (e) => j(this, void 0, void 0, function* () {
			var t, n, r, i;
			if (!this.roomOptions?.dynacast) return;
			let a = this.videoTrackPublications.get(e.trackSid);
			if (!a) {
				this.log.warn("received subscribed quality update for unknown track", { trackSid: e.trackSid });
				return;
			}
			if (!a.videoTrack) return;
			let o = yield a.videoTrack.setPublishingCodecs(e.subscribedCodecs);
			try {
				for (var s = !0, c = Yo(o), l; l = yield c.next(), t = l.done, !t; s = !0) {
					i = l.value, s = !1;
					let e = i;
					Lc(e) && (this.log.debug(`publish ${e} for ${a.videoTrack.sid}`, V(a)), yield this.publishAdditionalCodecForTrack(a.videoTrack, e, a.options));
				}
			} catch (e) {
				n = { error: e };
			} finally {
				try {
					!s && !t && (r = c.return) && (yield r.call(c));
				} finally {
					if (n) throw n.error;
				}
			}
		}), this.handleLocalTrackUnpublished = (e) => {
			let t = this.trackPublications.get(e.trackSid);
			if (!t) {
				this.log.warn("received unpublished event for unknown track", { trackSid: e.trackSid });
				return;
			}
			this.unpublishTrack(t.track);
		}, this.handleTrackEnded = (e) => j(this, void 0, void 0, function* () {
			if (e.source === H.Source.ScreenShare || e.source === H.Source.ScreenShareAudio) this.log.debug("unpublishing local track due to TrackEnded", V(e)), this.unpublishTrack(e);
			else if (e.isUserProvided) yield e.mute();
			else if (su(e) || ou(e)) try {
				if (Al()) try {
					let t = yield navigator == null ? void 0 : navigator.permissions.query({ name: e.source === H.Source.Camera ? "camera" : "microphone" });
					if (t && t.state === "denied") throw this.log.warn(`user has revoked access to ${e.source}`, V(e)), t.onchange = () => {
						t.state !== "denied" && (e.isMuted || e.restartTrack(), t.onchange = null);
					}, Error("GetUserMedia Permission denied");
				} catch {}
				e.isMuted || (this.log.debug("track ended, attempting to use a different device", V(e)), su(e) ? yield e.restartTrack({ deviceId: "default" }) : yield e.restartTrack());
			} catch {
				this.log.warn("could not restart track, muting instead", V(e)), yield e.mute();
			}
		}), this.audioTrackPublications = /* @__PURE__ */ new Map(), this.videoTrackPublications = /* @__PURE__ */ new Map(), this.trackPublications = /* @__PURE__ */ new Map(), this.engine = n, this.roomOptions = r, this.setupEngine(n), this.activeDeviceMap = new Map([
			["audioinput", "default"],
			["videoinput", "default"],
			["audiooutput", "default"]
		]), this.pendingSignalRequests = /* @__PURE__ */ new Map(), this.roomOutgoingDataStreamManager = i, this.roomOutgoingDataTrackManager = a, this.rpcClientManager = o, this.rpcServerManager = s;
	}
	get lastCameraError() {
		return this.cameraError;
	}
	get lastMicrophoneError() {
		return this.microphoneError;
	}
	get isE2EEEnabled() {
		return this.encryptionType !== O.NONE;
	}
	getTrackPublication(e) {
		let t = super.getTrackPublication(e);
		if (t) return t;
	}
	getTrackPublicationByName(e) {
		let t = super.getTrackPublicationByName(e);
		if (t) return t;
	}
	setupEngine(e) {
		this.engine = e, this.engine.on(R.RemoteMute, (e, t) => {
			let n = this.trackPublications.get(e);
			!n || !n.track || (t ? n.mute() : n.unmute());
		}), this.signalConnectedFuture?.isResolved && (this.signalConnectedFuture = void 0), this.engine.on(R.Connected, this.handleReconnected).on(R.SignalConnected, this.handleSignalConnected).on(R.SignalRestarted, this.handleReconnected).on(R.SignalResumed, this.handleReconnected).on(R.Restarting, this.handleReconnecting).on(R.Resuming, this.handleReconnecting).on(R.LocalTrackUnpublished, this.handleLocalTrackUnpublished).on(R.SubscribedQualityUpdate, this.handleSubscribedQualityUpdate).on(R.Closing, this.handleClosing).on(R.SignalRequestResponse, this.handleSignalRequestResponse);
	}
	setMetadata(e) {
		return j(this, void 0, void 0, function* () {
			yield this.requestMetadataUpdate({ metadata: e });
		});
	}
	setName(e) {
		return j(this, void 0, void 0, function* () {
			yield this.requestMetadataUpdate({ name: e });
		});
	}
	setAttributes(e) {
		return j(this, void 0, void 0, function* () {
			yield this.requestMetadataUpdate({ attributes: e });
		});
	}
	requestMetadataUpdate(e) {
		return j(this, arguments, void 0, function(e) {
			var t = this;
			let n = e.metadata, r = e.name, i = e.attributes;
			return function* () {
				return new pc((e, a) => j(t, void 0, void 0, function* () {
					try {
						let t = !1, o = yield this.engine.client.sendUpdateLocalMetadata(n ?? this.metadata ?? "", r ?? this.name ?? "", i), s = performance.now();
						for (this.pendingSignalRequests.set(o, {
							resolve: e,
							reject: (e) => {
								a(e), t = !0;
							},
							values: {
								name: r,
								metadata: n,
								attributes: i
							}
						}); performance.now() - s < 5e3 && !t;) {
							if ((!r || this.name === r) && (!n || this.metadata === n) && (!i || Object.entries(i).every((e) => {
								let t = C(e, 2), n = t[0], r = t[1];
								return this.attributes[n] === r || r === "" && !this.attributes[n];
							}))) {
								this.pendingSignalRequests.delete(o), e();
								return;
							}
							yield pl(50);
						}
						a(new Oc("Request to update local metadata timed out", "TimeoutError"));
					} catch (e) {
						e instanceof Error ? a(e) : a(Error(String(e)));
					}
				}));
			}();
		});
	}
	setCameraEnabled(e, t, n) {
		return this.setTrackEnabled(H.Source.Camera, e, t, n);
	}
	setMicrophoneEnabled(e, t, n) {
		return this.setTrackEnabled(H.Source.Microphone, e, t, n);
	}
	setScreenShareEnabled(e, t, n) {
		return this.setTrackEnabled(H.Source.ScreenShare, e, t, n);
	}
	setE2EEEnabled(e) {
		return j(this, void 0, void 0, function* () {
			let t = yield this.e2eeStateMutex.lock();
			try {
				if (this.encryptionType = e ? O.GCM : O.NONE, yield Promise.all(this.pendingPublishPromises.values()), this.trackPublications.size === 0 || Array.from(this.trackPublications.values()).every((t) => t.isEncrypted === e)) return;
				yield this.republishAllTracks(void 0, !1);
			} finally {
				t();
			}
		});
	}
	setTrackEnabled(e, t, n, r) {
		return j(this, void 0, void 0, function* () {
			this.log.debug("setTrackEnabled", {
				source: e,
				enabled: t
			}), this.republishPromise && (yield this.republishPromise);
			let i = this.getTrackPublication(e);
			if (t) if (i) yield i.unmute();
			else {
				let t;
				if (this.pendingPublishing.has(e)) {
					let t = yield this.waitForPendingPublicationOfSource(e);
					return t || this.log.info("waiting for pending publication promise timed out", { source: e }), yield t?.unmute(), t;
				}
				this.pendingPublishing.add(e);
				try {
					switch (e) {
						case H.Source.Camera:
							t = yield this.createTracks({ video: n ?? !0 });
							break;
						case H.Source.Microphone:
							t = yield this.createTracks({ audio: n ?? !0 });
							break;
						case H.Source.ScreenShare:
							t = yield this.createScreenTracks(Object.assign({}, n));
							break;
						default: throw new wc(e);
					}
				} catch (n) {
					throw t?.forEach((e) => {
						e.stop();
					}), n instanceof Error && this.emit(L.MediaDevicesError, n, Yc(e)), this.pendingPublishing.delete(e), n;
				}
				for (let r of t) {
					let t = Object.assign(Object.assign({}, this.roomOptions.publishDefaults), n);
					e === H.Source.Microphone && iu(r) && t.preConnectBuffer && (this.log.info("starting preconnect buffer for microphone"), r.startPreConnectBuffer());
				}
				try {
					let e = [];
					for (let n of t) this.log.info("publishing track", V(n)), e.push(this.publishTrack(n, r));
					i = C(yield Promise.all(e), 1)[0];
				} catch (e) {
					throw t?.forEach((e) => {
						e.stop();
					}), e;
				} finally {
					this.pendingPublishing.delete(e);
				}
			}
			else if (!i?.track && this.pendingPublishing.has(e) && (i = yield this.waitForPendingPublicationOfSource(e), i || this.log.info("waiting for pending publication promise timed out", { source: e })), i && i.track) if (e === H.Source.ScreenShare) {
				let e = [this.unpublishTrack(i.track)], t = this.getTrackPublication(H.Source.ScreenShareAudio);
				t && t.track && e.push(this.unpublishTrack(t.track)), i = C(yield Promise.all(e), 1)[0];
			} else yield i.mute();
			return i;
		});
	}
	enableCameraAndMicrophone() {
		return j(this, void 0, void 0, function* () {
			if (!(this.pendingPublishing.has(H.Source.Camera) || this.pendingPublishing.has(H.Source.Microphone))) {
				this.pendingPublishing.add(H.Source.Camera), this.pendingPublishing.add(H.Source.Microphone);
				try {
					let e = yield this.createTracks({
						audio: !0,
						video: !0
					});
					yield Promise.all(e.map((e) => this.publishTrack(e)));
				} finally {
					this.pendingPublishing.delete(H.Source.Camera), this.pendingPublishing.delete(H.Source.Microphone);
				}
			}
		});
	}
	createTracks(e) {
		return j(this, void 0, void 0, function* () {
			e ??= {};
			let t = Uc(e, this.roomOptions?.audioCaptureDefaults, this.roomOptions?.videoCaptureDefaults);
			try {
				return (yield wm(t, {
					loggerName: this.roomOptions.loggerName,
					loggerContextCb: () => this.logContext
				})).map((e) => (iu(e) && (this.microphoneError = void 0, e.setAudioContext(this.audioContext), e.source = H.Source.Microphone, this.emit(L.AudioStreamAcquired)), au(e) && (this.cameraError = void 0, e.source = H.Source.Camera), e));
			} catch (t) {
				throw t instanceof Error && (e.audio && (this.microphoneError = t), e.video && (this.cameraError = t)), t;
			}
		});
	}
	createScreenTracks(e) {
		return j(this, void 0, void 0, function* () {
			if (e === void 0 && (e = {}), navigator.mediaDevices.getDisplayMedia === void 0) throw new Cc("getDisplayMedia not supported");
			e.resolution === void 0 && !El() && (e.resolution = Hc.h1080fps30.resolution);
			let t = Xc(e), n = yield navigator.mediaDevices.getDisplayMedia(t), r = n.getVideoTracks();
			if (r.length === 0) throw new wc("no video track found");
			let i = new Df(r[0], void 0, !1, {
				loggerName: this.roomOptions.loggerName,
				loggerContextCb: () => this.logContext
			});
			i.source = H.Source.ScreenShare, e.contentHint && (i.mediaStreamTrack.contentHint = e.contentHint);
			let a = [i];
			if (n.getAudioTracks().length > 0) {
				this.emit(L.AudioStreamAcquired);
				let e = new cf(n.getAudioTracks()[0], void 0, !1, this.audioContext, {
					loggerName: this.roomOptions.loggerName,
					loggerContextCb: () => this.logContext
				});
				e.source = H.Source.ScreenShareAudio, a.push(e);
			}
			return a;
		});
	}
	publishTrack(e, t) {
		return j(this, void 0, void 0, function* () {
			return this.publishOrRepublishTrack(e, t);
		});
	}
	waitForNextEngineRestart() {
		let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : 15e3;
		return new Promise((t, n) => {
			let r = () => {
				clearTimeout(o), this.engine.off(R.Restarted, i), this.engine.off(R.Closing, a);
			}, i = () => {
				r(), t();
			}, a = () => {
				r(), n(/* @__PURE__ */ Error("engine closed before restart completed"));
			}, o = setTimeout(() => {
				r(), n(/* @__PURE__ */ Error("timed out waiting for engine restart"));
			}, e);
			this.engine.once(R.Restarted, i), this.engine.once(R.Closing, a);
		});
	}
	publishOrRepublishTrack(e, t) {
		return j(this, arguments, void 0, function(e, t) {
			var n = this;
			let r = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : !1, i = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : !1;
			return function* () {
				su(e) && e.setAudioContext(n.audioContext), yield n.reconnectFuture?.promise, n.republishPromise && !r && (yield n.republishPromise), ru(e) && n.pendingPublishPromises.has(e) && (yield n.pendingPublishPromises.get(e));
				let a;
				if (e instanceof MediaStreamTrack) a = e.getConstraints();
				else {
					a = e.constraints;
					let t;
					switch (e.source) {
						case H.Source.Microphone:
							t = "audioinput";
							break;
						case H.Source.Camera: t = "videoinput";
					}
					t && n.activeDeviceMap.has(t) && (a = Object.assign(Object.assign({}, a), { deviceId: n.activeDeviceMap.get(t) }));
				}
				if (e instanceof MediaStreamTrack) switch (e.kind) {
					case "audio":
						e = new cf(e, a, !0, n.audioContext, {
							loggerName: n.roomOptions.loggerName,
							loggerContextCb: () => n.logContext
						});
						break;
					case "video":
						e = new Df(e, a, !0, {
							loggerName: n.roomOptions.loggerName,
							loggerContextCb: () => n.logContext
						});
						break;
					default: throw new wc(`unsupported MediaStreamTrack kind ${e.kind}`);
				}
				else e.updateLoggerOptions({
					loggerName: n.roomOptions.loggerName,
					loggerContextCb: () => n.logContext
				});
				let o;
				if (n.trackPublications.forEach((t) => {
					t.track && t.track === e && (o = t);
				}), o) return n.log.warn("track has already been published, skipping", V(o)), o;
				let s = Object.assign(Object.assign({}, n.roomOptions.publishDefaults), t), c = "channelCount" in e.mediaStreamTrack.getSettings() && e.mediaStreamTrack.getSettings().channelCount === 2 || e.mediaStreamTrack.getConstraints().channelCount === 2, l = s.forceStereo ?? c;
				l && (s.dtx === void 0 && n.log.debug("Opus DTX will be disabled for stereo tracks by default. Enable them explicitly to make it work.", V(e)), s.red === void 0 && n.log.debug("Opus RED will be disabled for stereo tracks by default. Enable them explicitly to make it work."), s.dtx ??= !1, s.red ??= !1), !kl() && n.roomOptions.e2ee && (n.log.info("End-to-end encryption is set up, simulcast publishing will be disabled on Safari versions and iOS browsers running iOS < v17.2"), s.simulcast = !1), s.source && (e.source = s.source);
				let u = new Promise((t, r) => j(n, void 0, void 0, function* () {
					try {
						if (this.engine.client.currentState !== W.CONNECTED) {
							this.log.debug("deferring track publication until signal is connected", { track: V(e) });
							let n = !1, i = setTimeout(() => {
								n = !0, e.stop(), r(new Dc("publishing rejected as engine not connected within timeout", 408));
							}, 15e3);
							if (yield this.waitUntilEngineConnected(), clearTimeout(i), n) return;
							t(yield this.publish(e, s, l));
						} else try {
							t(yield this.publish(e, s, l));
						} catch (e) {
							r(e);
						}
					} catch (e) {
						r(e);
					}
				}));
				n.pendingPublishPromises.set(e, u);
				try {
					return yield u;
				} catch (a) {
					if (!i && a instanceof Ec) return n.log.warn("negotiation due to track publish failed, retrying after reconnect", { error: a }), n.pendingPublishPromises.delete(e), yield n.waitForNextEngineRestart(), yield n.publishOrRepublishTrack(e, t, r, !0);
					throw a;
				} finally {
					n.pendingPublishPromises.delete(e);
				}
			}();
		});
	}
	waitUntilEngineConnected() {
		return this.signalConnectedFuture ||= new U(), this.signalConnectedFuture.promise;
	}
	hasPermissionsToPublish(e) {
		if (!this.permissions) return this.log.warn("no permissions present for publishing track", V(e)), !1;
		let t = this.permissions, n = t.canPublish, r = t.canPublishSources;
		return n && (r.length === 0 || r.map((e) => nl(e)).includes(e.source)) ? !0 : (this.log.warn("insufficient permissions to publish", V(e)), !1);
	}
	publish(e, t, n) {
		return j(this, void 0, void 0, function* () {
			if (!this.hasPermissionsToPublish(e)) throw new Dc("failed to publish track, insufficient permissions", 403);
			Array.from(this.trackPublications.values()).find((t) => ru(e) && t.source === e.source) && e.source !== H.Source.Unknown && this.log.info(`publishing a second track with the same source: ${e.source}`, V(e)), t.stopMicTrackOnMute && iu(e) && (e.stopOnMute = !0), e.source === H.Source.ScreenShare && xl() && (t.simulcast = !1), t.videoCodec === "av1" && !gl() && (t.videoCodec = void 0), t.videoCodec === "vp9" && !_l() && (t.videoCodec = void 0), t.videoCodec === void 0 && (t.videoCodec = qd), this.enabledPublishVideoCodecs.length > 0 && (this.enabledPublishVideoCodecs.some((e) => t.videoCodec === Zc(e.mime)) || (t.videoCodec = Zc(this.enabledPublishVideoCodecs[0].mime)));
			let r = t.videoCodec;
			e.on(z.Muted, this.onTrackMuted), e.on(z.Unmuted, this.onTrackUnmuted), e.on(z.Ended, this.handleTrackEnded), e.on(z.UpstreamPaused, this.onTrackUpstreamPaused), e.on(z.UpstreamResumed, this.onTrackUpstreamResumed), e.on(z.AudioTrackFeatureUpdate, this.onTrackFeatureUpdate);
			let i = [], a = !(t.dtx ?? !0), o = e.getSourceTrackSettings();
			o.autoGainControl && i.push(D.TF_AUTO_GAIN_CONTROL), o.echoCancellation && i.push(D.TF_ECHO_CANCELLATION), o.noiseSuppression && i.push(D.TF_NOISE_SUPPRESSION), o.channelCount && o.channelCount > 1 && i.push(D.TF_STEREO), a && i.push(D.TF_NO_DTX), su(e) && e.hasPreConnectBuffer && i.push(D.TF_PRECONNECT_BUFFER);
			let s = this.normalizeRequestedPacketTrailerOptions(e, t), c = new Ta({
				cid: e.mediaStreamTrack.id,
				name: t.name,
				type: H.kindToProto(e.kind),
				muted: e.isMuted,
				source: H.sourceToProto(e.source),
				disableDtx: a,
				encryption: this.encryptionType,
				stereo: n,
				disableRed: this.isE2EEEnabled || !(t.red ?? !0),
				stream: t?.stream,
				backupCodecPolicy: t?.backupCodecPolicy,
				audioFeatures: i,
				packetTrailerFeatures: s
			}), l;
			if (e.kind === H.Kind.Video) {
				let n;
				try {
					n = yield e.waitForDimensions();
				} catch {
					let t = this.roomOptions.videoCaptureDefaults?.resolution ?? Bc.h720.resolution;
					n = {
						width: t.width,
						height: t.height
					}, this.log.error("could not determine track dimensions, using defaults", Object.assign(Object.assign({}, V(e)), { dims: n }));
				}
				c.width = n.width, c.height = n.height, ou(e) && (vl(r) && (e.source === H.Source.ScreenShare && (t.scalabilityMode = "L1T3", "contentHint" in e.mediaStreamTrack && (e.mediaStreamTrack.contentHint = "motion", this.log.debug("forcing contentHint to motion for screenshare with SVC codecs", V(e)))), t.scalabilityMode = t.scalabilityMode ?? "L3T3_KEY"), c.simulcastCodecs = [new wa({
					codec: r,
					cid: e.mediaStreamTrack.id
				})], t.backupCodec === !0 && (t.backupCodec = { codec: qd }), t.backupCodec && r !== t.backupCodec.codec && c.encryption === O.NONE && (this.roomOptions.dynacast || (this.roomOptions.dynacast = !0), c.simulcastCodecs.push(new wa({
					codec: t.backupCodec.codec,
					cid: ""
				})))), l = _f(e.source === H.Source.ScreenShare, c.width, c.height, t), c.layers = Af(c.width, c.height, l, vl(t.videoCodec));
			} else e.kind === H.Kind.Audio && (l = [{
				maxBitrate: t.audioPreset?.maxBitrate,
				priority: t.audioPreset?.priority ?? "high",
				networkPriority: t.audioPreset?.priority ?? "high"
			}]);
			if (!this.engine || this.engine.isClosed) throw new P("cannot publish track when not connected");
			let u = () => j(this, void 0, void 0, function* () {
				if (!this.engine.pcManager) throw new P("pcManager is not ready");
				if (e.sender = yield this.engine.createSender(e, t, l), ou(e) && (e.publishOptions = t), this.emit(L.LocalSenderCreated, e.sender, e), ou(e) && (t.degradationPreference ??= Tf(e), e.setDegradationPreference(t.degradationPreference)), l) if (xl() && e.kind === H.Kind.Audio) {
					let t;
					for (let n of this.engine.pcManager.publisher.getTransceivers()) if (n.sender === e.sender) {
						t = n;
						break;
					}
					t && this.engine.pcManager.publisher.setTrackCodecBitrate({
						transceiver: t,
						codec: "opus",
						maxbr: l[0]?.maxBitrate ? l[0].maxBitrate / 1e3 : 0
					});
				} else e.codec && vl(e.codec) && l[0]?.maxBitrate && this.engine.pcManager.publisher.setTrackCodecBitrate({
					cid: c.cid,
					codec: e.codec,
					maxbr: l[0].maxBitrate / 1e3
				});
				yield this.engine.negotiate();
			}), d, f = new Promise((t, n) => j(this, void 0, void 0, function* () {
				try {
					d = yield this.engine.addTrack(c), t(d);
				} catch (t) {
					if (e.sender && this.engine.pcManager?.publisher) {
						try {
							this.engine.pcManager.publisher.removeTrack(e.sender);
						} catch (e) {
							this.log.error(e);
						}
						yield this.engine.negotiate().catch((t) => {
							this.log.error("failed to negotiate after removing track due to failed add track request", Object.assign(Object.assign({}, V(e)), { error: t }));
						});
					}
					n(t);
				}
			}));
			if (this.enabledPublishVideoCodecs.length > 0 && s.length === 0) d = (yield Promise.all([f, u()]))[0];
			else {
				d = yield f;
				let n;
				if (d.codecs.forEach((e) => {
					n === void 0 && (n = e.mimeType);
				}), n && e.kind === H.Kind.Video) {
					let i = Zc(n);
					i !== r && (this.log.debug("falling back to server selected codec", Object.assign(Object.assign({}, V(e)), { codec: i })), t.videoCodec = i, l = _f(e.source === H.Source.ScreenShare, c.width, c.height, t));
				}
				yield u();
			}
			let ee = new Cm(e.kind, d, e, {
				loggerName: this.roomOptions.loggerName,
				loggerContextCb: () => this.logContext
			});
			if (ee.on(z.CpuConstrained, (e) => this.onTrackCpuConstrained(e, ee)), ee.options = t, e.sid = d.sid, ou(e) && (e.publishOptions = t, c.width && c.height && (e.lastEncodedDimensions = {
				width: c.width,
				height: c.height
			})), this.log.debug(`publishing ${e.kind} with encodings`, {
				encodings: l,
				trackInfo: d
			}), ou(e) ? e.startMonitor(this.engine.client) : su(e) && e.startMonitor(), this.addTrackPublication(ee), this.emit(L.LocalTrackPublished, ee), su(e) && d.audioFeatures.includes(D.TF_PRECONNECT_BUFFER)) {
				let t = e.getPreConnectBuffer(), n = e.getPreConnectBufferMimeType();
				this.on(L.LocalTrackSubscribed, (t) => {
					if (t.trackSid === d.sid) {
						if (!e.hasPreConnectBuffer) {
							this.log.warn("subscribe event came to late, buffer already closed");
							return;
						}
						this.log.debug("finished recording preconnect buffer", V(e)), e.stopPreConnectBuffer();
					}
				}), t && new Promise((r, i) => j(this, void 0, void 0, function* () {
					var a, s, c, l;
					try {
						this.log.debug("waiting for agent", V(e));
						let p = setTimeout(() => {
							i(/* @__PURE__ */ Error("agent not active within 10 seconds"));
						}, 1e4), m = yield this.waitUntilActiveAgentPresent();
						clearTimeout(p), this.log.debug("sending preconnect buffer", V(e));
						let te = yield this.streamBytes({
							name: "preconnect-buffer",
							mimeType: n,
							topic: "lk.agent.pre-connect-audio-buffer",
							destinationIdentities: [m.identity],
							attributes: {
								trackId: ee.trackSid,
								sampleRate: String(o.sampleRate ?? "48000"),
								channels: String(o.channelCount ?? "1")
							}
						});
						try {
							for (var u = !0, d = Yo(t), f; f = yield d.next(), a = f.done, !a; u = !0) {
								l = f.value, u = !1;
								let e = l;
								yield te.write(e);
							}
						} catch (e) {
							s = { error: e };
						} finally {
							try {
								!u && !a && (c = d.return) && (yield c.call(d));
							} finally {
								if (s) throw s.error;
							}
						}
						yield te.close(), r();
					} catch (e) {
						i(e);
					}
				})).then(() => {
					this.log.debug("preconnect buffer sent successfully", V(e));
				}).catch((t) => {
					this.log.error("error sending preconnect buffer", Object.assign(Object.assign({}, V(e)), { error: t }));
				});
			}
			return ee;
		});
	}
	canPublishPacketTrailer() {
		return !!(this.roomOptions.e2ee || this.roomOptions.encryption || Pu(this.roomOptions.packetTrailer));
	}
	normalizeRequestedPacketTrailerOptions(e, t) {
		if (e.kind !== H.Kind.Video || !Fu(t.packetTrailer)) return t.packetTrailer = void 0, [];
		if (!this.canPublishPacketTrailer()) return this.log.warn("packet trailer transform not supported; not advertising features", Object.assign(Object.assign({}, this.logContext), V(e))), t.packetTrailer = void 0, [];
		let n = Iu(t.packetTrailer);
		return t.packetTrailer = Lu(n), n;
	}
	get isLocal() {
		return !0;
	}
	publishAdditionalCodecForTrack(e, t, n) {
		return j(this, void 0, void 0, function* () {
			if (this.encryptionType !== O.NONE) return;
			let r;
			if (this.trackPublications.forEach((t) => {
				t.track && t.track === e && (r = t);
			}), !r) throw new wc("track is not published");
			if (!ou(e)) throw new wc("track is not a video track");
			let i = Object.assign(Object.assign({}, this.roomOptions?.publishDefaults), n), a = vf(e, t, i);
			if (!a) {
				this.log.info("backup codec has been disabled, ignoring request to add additional codec for track", V(e));
				return;
			}
			let o = e.addSimulcastTrack(t, a);
			if (!o) return;
			let s = this.normalizeRequestedPacketTrailerOptions(e, i), c = new Ta({
				cid: o.mediaStreamTrack.id,
				type: H.kindToProto(e.kind),
				muted: e.isMuted,
				source: H.sourceToProto(e.source),
				sid: e.sid,
				packetTrailerFeatures: s,
				simulcastCodecs: [{
					codec: i.videoCodec,
					cid: o.mediaStreamTrack.id
				}]
			});
			if (c.layers = Af(c.width, c.height, a), !this.engine || this.engine.isClosed) throw new P("cannot publish track when not connected");
			let l = (yield Promise.all([this.engine.addTrack(c), j(this, void 0, void 0, function* () {
				yield this.engine.createSimulcastSender(e, o, i, a), yield this.engine.negotiate();
			})]))[0];
			this.log.debug(`published ${t} for track ${e.sid}`, {
				encodings: a,
				trackInfo: l
			});
		});
	}
	unpublishTrack(e, t) {
		return j(this, void 0, void 0, function* () {
			if (ru(e)) {
				let t = this.pendingPublishPromises.get(e);
				t && (this.log.debug("awaiting publish promise before attempting to unpublish", V(e)), yield t);
			}
			let n = this.getPublicationForTrack(e), r = n ? V(n) : void 0;
			if (this.log.info("unpublishing track", r), !n || !n.track) {
				this.log.warn("track was not unpublished because no publication was found", r);
				return;
			}
			e = n.track, e.off(z.Muted, this.onTrackMuted), e.off(z.Unmuted, this.onTrackUnmuted), e.off(z.Ended, this.handleTrackEnded), e.off(z.UpstreamPaused, this.onTrackUpstreamPaused), e.off(z.UpstreamResumed, this.onTrackUpstreamResumed), e.off(z.AudioTrackFeatureUpdate, this.onTrackFeatureUpdate), t === void 0 && (t = this.roomOptions?.stopLocalTrackOnUnpublish ?? !0), t ? e.stop() : e.stopMonitor();
			let i = !1, a = e.sender;
			if (e.sender = void 0, this.engine.pcManager && this.engine.pcManager.currentState < G.FAILED && a) try {
				for (let e of this.engine.pcManager.publisher.getTransceivers()) e.sender === a && (e.direction = "inactive", i = !0);
				try {
					i = this.engine.removeTrack(a);
				} catch (e) {
					this.log.warn(e), i = !0;
				}
				if (ou(e)) {
					for (let t of e.simulcastCodecs) {
						let e = C(t, 2)[1];
						if (e.sender) {
							try {
								i = this.engine.removeTrack(e.sender);
							} catch (e) {
								this.log.warn(e), i = !0;
							}
							e.sender = void 0;
						}
					}
					e.simulcastCodecs.clear();
				}
			} catch (e) {
				this.log.warn("failed to unpublish track", Object.assign(Object.assign({}, r), { error: e }));
			}
			switch (this.trackPublications.delete(n.trackSid), n.kind) {
				case H.Kind.Audio:
					this.audioTrackPublications.delete(n.trackSid);
					break;
				case H.Kind.Video:
					this.videoTrackPublications.delete(n.trackSid);
					break;
			}
			return this.emit(L.LocalTrackUnpublished, n), n.setTrack(void 0), i && (yield this.engine.negotiate()), n;
		});
	}
	unpublishTracks(e) {
		return j(this, void 0, void 0, function* () {
			return (yield Promise.all(e.map((e) => this.unpublishTrack(e)))).filter((e) => !!e);
		});
	}
	republishAllTracks(e) {
		return j(this, arguments, void 0, function(e) {
			var t = this;
			let n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !0;
			return function* () {
				t.republishPromise && (yield t.republishPromise), t.republishPromise = new pc((r, i) => j(t, void 0, void 0, function* () {
					try {
						let t = [];
						this.trackPublications.forEach((n) => {
							n.track && (e && (n.options = Object.assign(Object.assign({}, n.options), e)), t.push(n));
						}), yield Promise.all(t.map((e) => j(this, void 0, void 0, function* () {
							let t = e.track;
							yield this.unpublishTrack(t, !1), n && !t.isMuted && t.source !== H.Source.ScreenShare && t.source !== H.Source.ScreenShareAudio && (su(t) || ou(t)) && !t.isUserProvided && (this.log.debug("restarting existing track", { track: e.trackSid }), yield t.restartTrack()), yield this.publishOrRepublishTrack(t, e.options, !0);
						}))), r();
					} catch (e) {
						e instanceof Error ? i(e) : i(Error(String(e)));
					} finally {
						this.republishPromise = void 0;
					}
				})), yield t.republishPromise;
			}();
		});
	}
	publishData(e) {
		return j(this, arguments, void 0, function(e) {
			var t = this;
			let n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
			return function* () {
				let r = n.reliable ? K.RELIABLE : K.LOSSY, i = n.reliable ? Hi.RELIABLE : Hi.LOSSY, a = n.destinationIdentities, o = n.topic, s = new Vi({
					kind: i,
					value: {
						case: "user",
						value: new qi({
							participantIdentity: t.identity,
							payload: e,
							destinationIdentities: a,
							topic: o
						})
					}
				});
				yield t.engine.sendDataPacket(s, r);
			}();
		});
	}
	publishDtmf(e, t) {
		return j(this, void 0, void 0, function* () {
			let n = new Vi({
				kind: Hi.RELIABLE,
				value: {
					case: "sipDtmf",
					value: new Ji({
						code: e,
						digit: t
					})
				}
			});
			yield this.engine.sendDataPacket(n, K.RELIABLE);
		});
	}
	sendChatMessage(e, t) {
		return j(this, void 0, void 0, function* () {
			let n = {
				id: crypto.randomUUID(),
				message: e,
				timestamp: Date.now(),
				attachedFiles: t?.attachments
			}, r = new Vi({ value: {
				case: "chatMessage",
				value: new Zi(Object.assign(Object.assign({}, n), { timestamp: b.parse(n.timestamp) }))
			} });
			return yield this.engine.sendDataPacket(r, K.RELIABLE), this.emit(L.ChatMessage, n), n;
		});
	}
	editChatMessage(e, t) {
		return j(this, void 0, void 0, function* () {
			let n = Object.assign(Object.assign({}, t), {
				message: e,
				editTimestamp: Date.now()
			}), r = new Vi({ value: {
				case: "chatMessage",
				value: new Zi(Object.assign(Object.assign({}, n), {
					timestamp: b.parse(n.timestamp),
					editTimestamp: b.parse(n.editTimestamp)
				}))
			} });
			return yield this.engine.sendDataPacket(r, K.RELIABLE), this.emit(L.ChatMessage, n), n;
		});
	}
	sendText(e, t) {
		return j(this, void 0, void 0, function* () {
			return this.roomOutgoingDataStreamManager.sendText(e, t);
		});
	}
	streamText(e) {
		return j(this, void 0, void 0, function* () {
			return this.roomOutgoingDataStreamManager.streamText(e);
		});
	}
	sendFile(e, t) {
		return j(this, void 0, void 0, function* () {
			return this.roomOutgoingDataStreamManager.sendFile(e, t);
		});
	}
	streamBytes(e) {
		return j(this, void 0, void 0, function* () {
			return this.roomOutgoingDataStreamManager.streamBytes(e);
		});
	}
	performRpc(e) {
		return this.rpcClientManager.performRpc(e).then((e) => {
			let t = C(e, 2);
			return t[0], t[1];
		});
	}
	registerRpcMethod(e, t) {
		this.rpcServerManager.registerRpcMethod(e, t);
	}
	unregisterRpcMethod(e) {
		this.rpcServerManager.unregisterRpcMethod(e);
	}
	setTrackSubscriptionPermissions(e) {
		let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : [];
		this.participantTrackPermissions = t, this.allParticipantsAllowedToSubscribe = e, this.engine.client.isDisconnected || this.updateTrackSubscriptionPermissions();
	}
	setEnabledPublishCodecs(e) {
		this.enabledPublishVideoCodecs = e.filter((e) => e.mime.split("/")[0].toLowerCase() === "video");
	}
	updateInfo(e) {
		return super.updateInfo(e) ? (e.tracks.forEach((e) => {
			let t = this.trackPublications.get(e.sid);
			if (t) {
				let n = t.isMuted || (t.track?.isUpstreamPaused ?? !1);
				n !== e.muted && (this.log.debug("updating server mute state after reconcile", Object.assign(Object.assign({}, V(t)), { mutedOnServer: n })), this.engine.client.sendMuteTrack(e.sid, n));
			}
		}), !0) : !1;
	}
	setActiveAgent(e) {
		var t, n, r, i;
		this.firstActiveAgent = e, e && !this.firstActiveAgent && (this.firstActiveAgent = e), e ? (n = (t = this.activeAgentFuture)?.resolve) == null || n.call(t, e) : (i = (r = this.activeAgentFuture)?.reject) == null || i.call(r, /* @__PURE__ */ Error("Agent disconnected")), this.activeAgentFuture = void 0;
	}
	waitUntilActiveAgentPresent() {
		return this.firstActiveAgent ? Promise.resolve(this.firstActiveAgent) : (this.activeAgentFuture ||= new U(), this.activeAgentFuture.promise);
	}
	getPublicationForTrack(e) {
		let t;
		return this.trackPublications.forEach((n) => {
			let r = n.track;
			r && (e instanceof MediaStreamTrack ? (su(r) || ou(r)) && r.mediaStreamTrack === e && (t = n) : e === r && (t = n));
		}), t;
	}
	waitForPendingPublicationOfSource(e) {
		return j(this, void 0, void 0, function* () {
			let t = Date.now();
			for (; Date.now() < t + 1e4;) {
				let t = Array.from(this.pendingPublishPromises.entries()).find((t) => C(t, 1)[0].source === e);
				if (t) return t[1];
				yield pl(20);
			}
		});
	}
	publishDataTrack(e) {
		return j(this, void 0, void 0, function* () {
			let t = new am(e, this.roomOutgoingDataTrackManager);
			return yield t.publish(), t;
		});
	}
}, Nm = class extends DOMException {
	constructor(e, t) {
		super(e, "AbortError"), this.reason = t;
	}
}, Pm = class extends Map {
	constructor() {
		super(...arguments), this.pending = /* @__PURE__ */ new Map();
	}
	set(e, t) {
		var n;
		super.set(e, t);
		let r = this.pending?.get(e);
		if (r) {
			for (let e of r) e.isResolved || (n = e.resolve) == null || n.call(e, t);
			this.pending.delete(e);
		}
		return this;
	}
	get [Symbol.toStringTag]() {
		return "DeferrableMap";
	}
	getDeferred(e, t) {
		return j(this, void 0, void 0, function* () {
			let n = this.get(e);
			if (n !== void 0) return n;
			if (t?.aborted) throw new Nm("The operation was aborted.", t.reason);
			let r = new U(void 0, () => {
				let t = this.pending.get(e);
				if (!t) return;
				let n = t.indexOf(r);
				n !== -1 && t.splice(n, 1), t.length === 0 && this.pending.delete(e);
			}), i = this.pending.get(e);
			if (i ? i.push(r) : this.pending.set(e, [r]), t) {
				let e = () => {
					var e;
					r.isResolved || (e = r.reject) == null || e.call(r, new Nm("The operation was aborted.", t.reason));
				};
				t.addEventListener("abort", e, { once: !0 }), r.promise.finally(() => {
					t.removeEventListener("abort", e);
				});
			}
			return r.promise;
		});
	}
}, Fm = class extends Sm {
	constructor(e, t, n, r) {
		super(e, t.sid, t.name, r), this.track = void 0, this.allowed = !0, this.requestedDisabled = void 0, this.visible = !0, this.handleEnded = (e) => {
			this.setTrack(void 0), this.emit(z.Ended, e);
		}, this.handleVisibilityChange = (e) => {
			this.log.debug(`adaptivestream video visibility ${this.trackSid}, visible=${e}`, this.logContext), this.visible = e, this.emitTrackUpdate();
		}, this.handleVideoDimensionsChange = (e) => {
			this.log.debug(`adaptivestream video dimensions ${e.width}x${e.height}`, this.logContext), this.videoDimensionsAdaptiveStream = e, this.emitTrackUpdate();
		}, this.subscribed = n, this.updateInfo(t);
	}
	setSubscribed(e) {
		let t = this.subscriptionStatus, n = this.permissionStatus;
		this.subscribed = e, e && (this.allowed = !0);
		let r = new Ba({
			trackSids: [this.trackSid],
			subscribe: this.subscribed,
			participantTracks: [new na({
				participantSid: "",
				trackSids: [this.trackSid]
			})]
		});
		this.emit(z.UpdateSubscription, r), this.emitSubscriptionUpdateIfChanged(t), this.emitPermissionUpdateIfChanged(n);
	}
	get subscriptionStatus() {
		return this.subscribed === !1 ? Sm.SubscriptionStatus.Unsubscribed : super.isSubscribed ? Sm.SubscriptionStatus.Subscribed : Sm.SubscriptionStatus.Desired;
	}
	get permissionStatus() {
		return this.allowed ? Sm.PermissionStatus.Allowed : Sm.PermissionStatus.NotAllowed;
	}
	get isSubscribed() {
		return this.subscribed === !1 ? !1 : super.isSubscribed;
	}
	get isDesired() {
		return this.subscribed !== !1;
	}
	get isEnabled() {
		return this.requestedDisabled === void 0 ? this.isAdaptiveStream ? this.visible : !0 : !this.requestedDisabled;
	}
	get isLocal() {
		return !1;
	}
	setEnabled(e) {
		!this.isManualOperationAllowed() || this.requestedDisabled === !e || (this.requestedDisabled = !e, this.emitTrackUpdate());
	}
	setVideoQuality(e) {
		!this.isManualOperationAllowed() || this.requestedMaxQuality === e || (this.requestedMaxQuality = e, this.requestedVideoDimensions = void 0, this.emitTrackUpdate());
	}
	setVideoDimensions(e) {
		this.isManualOperationAllowed() && (this.requestedVideoDimensions?.width === e.width && this.requestedVideoDimensions?.height === e.height || (uu(this.track) && (this.requestedVideoDimensions = e), this.requestedMaxQuality = void 0, this.emitTrackUpdate()));
	}
	setVideoFPS(e) {
		this.isManualOperationAllowed() && uu(this.track) && this.fps !== e && (this.fps = e, this.emitTrackUpdate());
	}
	get videoQuality() {
		return this.requestedMaxQuality ?? sl.HIGH;
	}
	setTrack(e) {
		let t = this.subscriptionStatus, n = this.permissionStatus, r = this.track;
		r !== e && (r && (r.off(z.VideoDimensionsChanged, this.handleVideoDimensionsChange), r.off(z.VisibilityChanged, this.handleVisibilityChange), r.off(z.Ended, this.handleEnded), r.detach(), r.stopMonitor(), this.emit(z.Unsubscribed, r)), super.setTrack(e), e && (e.sid = this.trackSid, e.on(z.VideoDimensionsChanged, this.handleVideoDimensionsChange), e.on(z.VisibilityChanged, this.handleVisibilityChange), e.on(z.Ended, this.handleEnded), this.emit(z.Subscribed, e)), this.emitPermissionUpdateIfChanged(n), this.emitSubscriptionUpdateIfChanged(t));
	}
	setAllowed(e) {
		let t = this.subscriptionStatus, n = this.permissionStatus;
		this.allowed = e, this.emitPermissionUpdateIfChanged(n), this.emitSubscriptionUpdateIfChanged(t);
	}
	setSubscriptionError(e) {
		this.emit(z.SubscriptionFailed, e);
	}
	updateInfo(e) {
		super.updateInfo(e);
		let t = this.metadataMuted;
		this.metadataMuted = e.muted, this.track ? this.track.setMuted(e.muted) : t !== e.muted && this.emit(e.muted ? z.Muted : z.Unmuted);
	}
	emitSubscriptionUpdateIfChanged(e) {
		let t = this.subscriptionStatus;
		e !== t && this.emit(z.SubscriptionStatusChanged, t, e);
	}
	emitPermissionUpdateIfChanged(e) {
		this.permissionStatus !== e && this.emit(z.SubscriptionPermissionChanged, this.permissionStatus, e);
	}
	isManualOperationAllowed() {
		return this.isDesired ? !0 : (this.log.warn("cannot update track settings when not subscribed", this.logContext), !1);
	}
	get isAdaptiveStream() {
		return uu(this.track) && this.track.isAdaptiveStream;
	}
	emitTrackUpdate() {
		let e = new Ua({
			trackSids: [this.trackSid],
			disabled: !this.isEnabled,
			fps: this.fps
		});
		if (this.kind === H.Kind.Video) {
			let t = this.requestedVideoDimensions;
			if (this.videoDimensionsAdaptiveStream !== void 0) if (t) rl(this.videoDimensionsAdaptiveStream, t) && (this.log.debug("using adaptive stream dimensions instead of requested", Object.assign(Object.assign({}, this.logContext), this.videoDimensionsAdaptiveStream)), t = this.videoDimensionsAdaptiveStream);
			else if (this.requestedMaxQuality !== void 0 && this.trackInfo) {
				let e = il(this.trackInfo, this.requestedMaxQuality);
				e && rl(this.videoDimensionsAdaptiveStream, e) && (this.log.debug("using adaptive stream dimensions instead of max quality layer", Object.assign(Object.assign({}, this.logContext), this.videoDimensionsAdaptiveStream)), t = this.videoDimensionsAdaptiveStream);
			} else this.log.debug("using adaptive stream dimensions", Object.assign(Object.assign({}, this.logContext), this.videoDimensionsAdaptiveStream)), t = this.videoDimensionsAdaptiveStream;
			t ? (e.width = Math.ceil(t.width), e.height = Math.ceil(t.height)) : this.requestedMaxQuality === void 0 ? (this.log.debug("using default quality", Object.assign(Object.assign({}, this.logContext), { quality: sl.HIGH })), e.quality = sl.HIGH) : (this.log.debug("using requested max quality", Object.assign(Object.assign({}, this.logContext), { quality: this.requestedMaxQuality })), e.quality = this.requestedMaxQuality);
		}
		this.emit(z.UpdateSettings, e);
	}
}, Im = class e extends Am {
	static fromParticipantInfo(t, n, r, i) {
		return new e(t, n.sid, n.identity, n.name, n.metadata, n.attributes, r, n.kind, n.dataTracks.map((e) => new Ip(fd.from(e), i, { publisherIdentity: n.identity })), n.clientProtocol);
	}
	get logContext() {
		return Object.assign(Object.assign({}, super.logContext), {
			remoteParticipantID: this.sid,
			remoteParticipant: this.identity
		});
	}
	constructor(e, t, n, r, i, a, o) {
		let s = arguments.length > 7 && arguments[7] !== void 0 ? arguments[7] : Ni.STANDARD, c = arguments.length > 8 && arguments[8] !== void 0 ? arguments[8] : [], l = arguments.length > 9 && arguments[9] !== void 0 ? arguments[9] : 0;
		super(t, n || "", r, i, a, o, s), this.signalClient = e, this.trackPublications = /* @__PURE__ */ new Map(), this.audioTrackPublications = /* @__PURE__ */ new Map(), this.videoTrackPublications = /* @__PURE__ */ new Map(), this.dataTracks = new Pm(c.map((e) => [e.info.name, e])), this.volumeMap = /* @__PURE__ */ new Map(), this.clientProtocol = l;
	}
	addTrackPublication(e) {
		super.addTrackPublication(e), e.on(z.UpdateSettings, (t) => {
			this.log.debug("send update settings", Object.assign(Object.assign(Object.assign({}, this.logContext), V(e)), { settings: t })), this.signalClient.sendUpdateTrackSettings(t);
		}), e.on(z.UpdateSubscription, (e) => {
			e.participantTracks.forEach((e) => {
				e.participantSid = this.sid;
			}), this.signalClient.sendUpdateSubscription(e);
		}), e.on(z.SubscriptionPermissionChanged, (t) => {
			this.emit(L.TrackSubscriptionPermissionChanged, e, t);
		}), e.on(z.SubscriptionStatusChanged, (t) => {
			this.emit(L.TrackSubscriptionStatusChanged, e, t);
		}), e.on(z.Subscribed, (t) => {
			this.emit(L.TrackSubscribed, t, e);
		}), e.on(z.Unsubscribed, (t) => {
			this.emit(L.TrackUnsubscribed, t, e);
		}), e.on(z.SubscriptionFailed, (t) => {
			this.emit(L.TrackSubscriptionFailed, e.trackSid, t);
		});
	}
	getTrackPublication(e) {
		let t = super.getTrackPublication(e);
		if (t) return t;
	}
	getTrackPublicationByName(e) {
		let t = super.getTrackPublicationByName(e);
		if (t) return t;
	}
	setVolume(e) {
		let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : H.Source.Microphone;
		this.volumeMap.set(t, e);
		let n = this.getTrackPublication(t);
		n && n.track && n.track.setVolume(e);
	}
	getVolume() {
		let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : H.Source.Microphone, t = this.getTrackPublication(e);
		return t && t.track ? t.track.getVolume() : this.volumeMap.get(e);
	}
	addSubscribedMediaTrack(e, t, n, r, i, a) {
		let o = this.getTrackPublicationBySid(t);
		if (o || t.startsWith("TR") || this.trackPublications.forEach((t) => {
			!o && e.kind === t.kind.toString() && (o = t);
		}), !o) {
			if (a === 0) {
				this.log.error("could not find published track", Object.assign(Object.assign({}, this.logContext), { trackSid: t })), this.emit(L.TrackSubscriptionFailed, t);
				return;
			}
			a === void 0 && (a = 20), setTimeout(() => {
				this.addSubscribedMediaTrack(e, t, n, r, i, a - 1);
			}, 150);
			return;
		}
		if (e.readyState === "ended") {
			this.log.error("unable to subscribe because MediaStreamTrack is ended. Do not call MediaStreamTrack.stop()", Object.assign(Object.assign({}, this.logContext), V(o))), this.emit(L.TrackSubscriptionFailed, t);
			return;
		}
		let s = e.kind === "video", c;
		return c = s ? new Uu(e, t, r, i) : new xm(e, t, r, this.audioContext, this.audioOutput), c.source = o.source, c.isMuted = o.isMuted, c.setMediaStream(n), c.start(), o.setTrack(c), this.volumeMap.has(o.source) && cu(c) && iu(c) && c.setVolume(this.volumeMap.get(o.source)), o;
	}
	get hasMetadata() {
		return !!this.participantInfo;
	}
	getTrackPublicationBySid(e) {
		return this.trackPublications.get(e);
	}
	updateInfo(e) {
		if (!super.updateInfo(e)) return !1;
		let t = /* @__PURE__ */ new Map(), n = /* @__PURE__ */ new Map();
		return e.tracks.forEach((e) => {
			let r = this.getTrackPublicationBySid(e.sid);
			if (r) r.updateInfo(e);
			else {
				let t = H.kindFromProto(e.type);
				if (!t) return;
				r = new Fm(t, e, this.signalClient.connectOptions?.autoSubscribe, {
					loggerContextCb: () => this.logContext,
					loggerName: this.loggerOptions?.loggerName
				}), r.updateInfo(e), n.set(e.sid, r);
				let i = Array.from(this.trackPublications.values()).find((e) => e.source === r?.source);
				i && r.source !== H.Source.Unknown && this.log.debug(`received a second track publication for ${this.identity} with the same source: ${r.source}`, Object.assign(Object.assign({}, this.logContext), {
					oldTrack: V(i),
					newTrack: V(r)
				})), this.addTrackPublication(r);
			}
			t.set(e.sid, r);
		}), this.trackPublications.forEach((e) => {
			t.has(e.trackSid) || (this.log.trace("detected removed track on remote participant, unpublishing", Object.assign(Object.assign({}, this.logContext), V(e))), this.unpublishTrack(e.trackSid, !0));
		}), n.forEach((e) => {
			this.emit(L.TrackPublished, e);
		}), !0;
	}
	unpublishTrack(e, t) {
		let n = this.trackPublications.get(e);
		if (!n) return;
		let r = n.track;
		switch (r && (r.stop(), n.setTrack(void 0)), this.trackPublications.delete(e), n.kind) {
			case H.Kind.Audio:
				this.audioTrackPublications.delete(e);
				break;
			case H.Kind.Video:
				this.videoTrackPublications.delete(e);
				break;
		}
		t && this.emit(L.TrackUnpublished, n);
	}
	setAudioOutput(e) {
		return j(this, void 0, void 0, function* () {
			this.audioOutput = e;
			let t = [];
			this.audioTrackPublications.forEach((n) => {
				iu(n.track) && cu(n.track) && t.push(n.track.setSinkId(e.deviceId ?? "default"));
			}), yield Promise.all(t);
		});
	}
	addRemoteDataTrack(e) {
		this.dataTracks.set(e.info.name, e);
	}
	removeRemoteDataTrack(e) {
		for (let n of this.dataTracks.entries()) {
			var t = C(n, 2);
			let r = t[0];
			e === t[1].info.sid && this.dataTracks.delete(r);
		}
	}
	emit(e) {
		var t = [...arguments].slice(1);
		return this.log.trace("participant event", Object.assign(Object.assign({}, this.logContext), {
			event: e,
			args: t
		})), super.emit(e, ...t);
	}
}, X;
(function(e) {
	e.Disconnected = "disconnected", e.Connecting = "connecting", e.Connected = "connected", e.Reconnecting = "reconnecting", e.SignalReconnecting = "signalReconnecting";
})(X ||= {});
var Lm = 4 * 1e3, Rm = class e extends $o.EventEmitter {
	get hasE2EESetup() {
		return this.e2eeManager !== void 0;
	}
	constructor(t) {
		var n, r, i;
		if (super(), n = this, this.state = X.Disconnected, this.activeSpeakers = [], this.isE2EEEnabled = !1, this.audioEnabled = !0, this.e2eeStateMutex = new v(), this.isVideoPlaybackBlocked = !1, this.log = A, this.bufferedEvents = [], this.isResuming = !1, this.connect = (e, t, n) => j(this, void 0, void 0, function* () {
			if (!bl()) throw jl() ? Error("WebRTC isn't detected, have you called registerGlobals?") : Error("LiveKit doesn't seem to be supported on this browser. Try to update your browser and make sure no browser extensions are disabling webRTC.");
			let r = yield this.disconnectLock.lock();
			if (this.state === X.Connected) return this.log.info(`already connected to room ${this.name}`), r(), Promise.resolve();
			if (this.connectFuture) return r(), this.connectFuture.promise;
			this.setAndEmitConnectionState(X.Connecting), this.regionUrlProvider?.getServerUrl().toString() !== yu(e) && (this.regionUrl = void 0, this.regionUrlProvider = void 0), Ml(new URL(e)) && (this.regionUrlProvider === void 0 ? this.regionUrlProvider = new Kf(e, t) : this.regionUrlProvider.updateToken(t), this.regionUrlProvider.fetchRegionSettings().then((e) => {
				var t;
				(t = this.regionUrlProvider) == null || t.setServerReportedRegions(e);
			}).catch((e) => {
				this.log.warn("could not fetch region settings", { error: e });
			}));
			let i = (a, o, s) => j(this, void 0, void 0, function* () {
				this.abortController && this.abortController.abort();
				let c = new AbortController();
				this.abortController = c, r?.();
				try {
					if (yield $u.getInstance().getBackOffPromise(e), c.signal.aborted) throw N.cancelled("Connection attempt aborted");
					yield this.attemptConnection(s ?? e, t, n, c), this.abortController = void 0, a();
				} catch (t) {
					if (this.regionUrlProvider && t instanceof N && t.reason !== M.Cancelled && t.reason !== M.NotAllowed) {
						let n = null;
						try {
							this.log.debug("Fetching next region"), n = yield this.regionUrlProvider.getNextBestRegionUrl(this.abortController?.signal);
						} catch (e) {
							if (e instanceof N && (e.status === 401 || e.reason === M.Cancelled)) {
								this.handleDisconnect(this.options.stopLocalTrackOnUnpublish), o(e);
								return;
							}
						}
						[
							M.InternalError,
							M.ServerUnreachable,
							M.Timeout
						].includes(t.reason) && (this.log.debug("Adding failed connection attempt to back off"), $u.getInstance().addFailedConnectionAttempt(e)), n && !this.abortController?.signal.aborted ? (this.log.info(`Initial connection failed with ConnectionError: ${t.message}. Retrying with another region: ${n}`), this.recreateEngine(!0), yield i(a, o, n)) : (this.handleDisconnect(this.options.stopLocalTrackOnUnpublish, eu(t)), o(t));
					} else {
						let e = wi.UNKNOWN_REASON;
						t instanceof N && (e = eu(t)), this.handleDisconnect(this.options.stopLocalTrackOnUnpublish, e), o(t);
					}
				}
			}), a = this.regionUrl;
			return this.regionUrl = void 0, this.connectFuture = new U((e, t) => {
				i(e, t, a);
			}, () => {
				this.clearConnectionFutures();
			}), this.connectFuture.promise;
		}), this.connectSignal = (e, t, n, r, i, a) => j(this, void 0, void 0, function* () {
			let o = yield n.join(e, t, {
				autoSubscribe: r.autoSubscribe,
				adaptiveStream: typeof i.adaptiveStream == "object" ? !0 : i.adaptiveStream,
				clientInfoCapabilities: Pu(i.packetTrailer) || this.e2eeManager ? [sa.CAP_PACKET_TRAILER] : void 0,
				maxRetries: r.maxRetries,
				e2eeEnabled: !!this.e2eeManager,
				websocketTimeout: r.websocketTimeout
			}, a.signal, !i.singlePeerConnection), s = o.joinResponse, c = o.serverInfo;
			if (this.serverInfo = c, !c.version) throw new Tc("unknown server version");
			return c.version === "0.15.1" && this.options.dynacast && (this.log.debug("disabling dynacast due to server version"), i.dynacast = !1), s;
		}), this.applyJoinResponse = (e) => {
			let t = e.participant;
			if (this.localParticipant.sid = t.sid, this.localParticipant.identity = t.identity, this.localParticipant.setEnabledPublishCodecs(e.enabledPublishCodecs), this.e2eeManager) try {
				this.e2eeManager.setSifTrailer(e.sifTrailer);
			} catch (e) {
				this.log.error(e instanceof Error ? e.message : "Could not set SifTrailer", { error: e });
			}
			this.handleParticipantUpdates([t, ...e.otherParticipants]), e.room && this.handleRoomUpdate(e.room);
		}, this.attemptConnection = (e, t, n, r) => j(this, void 0, void 0, function* () {
			this.state === X.Reconnecting || this.isResuming || this.engine?.pendingReconnect ? (this.log.info("Reconnection attempt replaced by new connection attempt"), this.recreateEngine(!0)) : this.maybeCreateEngine(), this.regionUrlProvider?.isCloud() && this.engine.setRegionStrategy(this.createRegionStrategy()), this.acquireAudioContext(), this.connOptions = Object.assign(Object.assign({}, Qd), n), this.connOptions.rtcConfig && (this.engine.rtcConfig = this.connOptions.rtcConfig), this.connOptions.peerConnectionTimeout && (this.engine.peerConnectionTimeout = this.connOptions.peerConnectionTimeout);
			try {
				let n = yield this.connectSignal(e, t, this.engine, this.connOptions, this.options, r);
				this.applyJoinResponse(n), this.setupLocalParticipantEvents(), this.emit(I.SignalConnected);
			} catch (e) {
				yield this.engine.close(), this.recreateEngine();
				let t = r.signal.aborted ? N.cancelled("Signal connection aborted") : N.serverUnreachable("could not establish signal connection");
				throw e instanceof Error && (t.message = `${t.message}: ${e.message}`), e instanceof N && (t.reason = e.reason, t.status = e.status), this.log.debug("error trying to establish signal connection", { error: e }), t;
			}
			if (r.signal.aborted) throw yield this.engine.close(), this.recreateEngine(), N.cancelled("Connection attempt aborted");
			try {
				yield this.engine.waitForPCInitialConnection(this.connOptions.peerConnectionTimeout, r);
			} catch (e) {
				throw yield this.engine.close(), this.recreateEngine(), e;
			}
			Al() && this.options.disconnectOnPageLeave && (window.addEventListener("pagehide", this.onPageLeave), window.addEventListener("beforeunload", this.onPageLeave)), Al() && window.addEventListener("freeze", this.onPageLeave), this.setAndEmitConnectionState(X.Connected), this.emit(I.Connected), $u.getInstance().resetFailedConnectionAttempts(e), this.registerConnectionReconcile(), this.regionUrlProvider && this.regionUrlProvider.notifyConnected();
		}), this.disconnect = function() {
			return j(n, [...arguments], void 0, function() {
				var e = this;
				let t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : !0;
				return function* () {
					var n, r, i;
					let a = yield e.disconnectLock.lock();
					try {
						if (e.state === X.Disconnected) {
							e.log.debug("already disconnected");
							return;
						}
						if (e.log.info("disconnect from room"), e.state === X.Connecting || e.state === X.Reconnecting || e.isResuming) {
							let t = "Abort connection attempt due to user initiated disconnect";
							e.log.warn(t), (n = e.abortController) == null || n.abort(t), (i = (r = e.connectFuture)?.reject) == null || i.call(r, N.cancelled("Client initiated disconnect")), e.connectFuture = void 0;
						}
						e.engine && (e.engine.client.isDisconnected || (yield e.engine.client.sendLeave()), yield e.engine.close()), e.handleDisconnect(t, wi.CLIENT_INITIATED), e.engine = void 0;
					} finally {
						a();
					}
				}();
			});
		}, this.onPageLeave = () => j(this, void 0, void 0, function* () {
			this.log.info("Page leave detected, disconnecting"), yield this.disconnect();
		}), this.startAudio = () => j(this, void 0, void 0, function* () {
			let e = [], t = gc();
			if (t && t.os === "iOS") {
				let t = "livekit-dummy-audio-el", n = document.getElementById(t);
				if (!n) {
					n = document.createElement("audio"), n.id = t, n.autoplay = !0, n.hidden = !0;
					let e = ql();
					e.enabled = !0;
					let r = new MediaStream([e]);
					n.srcObject = r, document.addEventListener("visibilitychange", () => {
						n && (n.srcObject = document.hidden ? null : r, document.hidden || (this.log.debug("page visible again, triggering startAudio to resume playback and update playback status"), this.startAudio()));
					}), document.body.append(n), this.once(I.Disconnected, () => {
						n?.remove(), n = null;
					});
				}
				e.push(n);
			}
			this.remoteParticipants.forEach((t) => {
				t.audioTrackPublications.forEach((t) => {
					t.track && t.track.attachedElements.forEach((t) => {
						e.push(t);
					});
				});
			});
			try {
				yield Promise.all([this.acquireAudioContext(), ...e.map((e) => (e.muted = !1, e.play()))]), this.handleAudioPlaybackStarted();
			} catch (e) {
				throw this.handleAudioPlaybackFailed(e), e;
			}
		}), this.startVideo = () => j(this, void 0, void 0, function* () {
			let e = [];
			for (let t of this.remoteParticipants.values()) t.videoTrackPublications.forEach((t) => {
				var n;
				(n = t.track) == null || n.attachedElements.forEach((t) => {
					e.includes(t) || e.push(t);
				});
			});
			yield Promise.all(e.map((e) => e.play())).then(() => {
				this.handleVideoPlaybackStarted();
			}).catch((e) => {
				e.name === "NotAllowedError" ? this.handleVideoPlaybackFailed() : this.log.warn("Resuming video playback failed, make sure you call `startVideo` directly in a user gesture handler");
			});
		}), this.handleRestarting = () => {
			this.clearConnectionReconcile(), this.isResuming = !1;
			for (let e of this.remoteParticipants.values()) this.handleParticipantDisconnected(e.identity, e);
			this.setAndEmitConnectionState(X.Reconnecting) && this.emit(I.Reconnecting);
		}, this.handleRestarted = () => {
			this.outgoingDataTrackManager.sfuWillRepublishTracks(), this.incomingDataTrackManager.resendSubscriptionUpdates();
		}, this.handleSignalRestarted = (e) => j(this, void 0, void 0, function* () {
			this.log.debug(`signal reconnected to server, region ${e.serverRegion}`, { region: e.serverRegion }), this.bufferedEvents = [], this.applyJoinResponse(e);
			try {
				yield this.localParticipant.republishAllTracks(void 0, !0);
			} catch (e) {
				this.log.error("error trying to re-publish tracks after reconnection", { error: e });
			}
			try {
				yield this.engine.waitForRestarted(), this.log.debug("fully reconnected to server", { region: e.serverRegion });
			} catch {
				return;
			}
			this.setAndEmitConnectionState(X.Connected), this.emit(I.Reconnected), this.registerConnectionReconcile(), this.emitBufferedEvents();
		}), this.handleParticipantUpdates = (e) => {
			for (let t of e) {
				if (t.identity === this.localParticipant.identity) {
					this.localParticipant.updateInfo(t);
					continue;
				}
				t.identity === "" && (t.identity = this.sidToIdentity.get(t.sid) ?? "");
				let e = this.remoteParticipants.get(t.identity);
				t.state === Mi.DISCONNECTED ? this.handleParticipantDisconnected(t.identity, e) : this.getOrCreateParticipant(t.identity, t);
			}
			let t = new Map(e.filter((e) => e.identity !== this.localParticipant.identity).map((e) => [e.identity, e.dataTracks.map((e) => fd.from(e))]));
			this.incomingDataTrackManager.receiveSfuPublicationUpdates(t);
		}, this.handleActiveSpeakersUpdate = (e) => {
			let t = [], n = {};
			e.forEach((e) => {
				if (n[e.sid] = !0, e.sid === this.localParticipant.sid) this.localParticipant.audioLevel = e.level, this.localParticipant.setIsSpeaking(!0), t.push(this.localParticipant);
				else {
					let n = this.getRemoteParticipantBySid(e.sid);
					n && (n.audioLevel = e.level, n.setIsSpeaking(!0), t.push(n));
				}
			}), n[this.localParticipant.sid] || (this.localParticipant.audioLevel = 0, this.localParticipant.setIsSpeaking(!1)), this.remoteParticipants.forEach((e) => {
				n[e.sid] || (e.audioLevel = 0, e.setIsSpeaking(!1));
			}), this.activeSpeakers = t, this.emitWhenConnected(I.ActiveSpeakersChanged, t);
		}, this.handleSpeakersChanged = (e) => {
			let t = /* @__PURE__ */ new Map();
			this.activeSpeakers.forEach((e) => {
				let n = this.remoteParticipants.get(e.identity);
				n && n.sid !== e.sid || t.set(e.sid, e);
			}), e.forEach((e) => {
				let n = this.getRemoteParticipantBySid(e.sid);
				e.sid === this.localParticipant.sid && (n = this.localParticipant), n && (n.audioLevel = e.level, n.setIsSpeaking(e.active), e.active ? t.set(e.sid, n) : t.delete(e.sid));
			});
			let n = Array.from(t.values());
			n.sort((e, t) => t.audioLevel - e.audioLevel), this.activeSpeakers = n, this.emitWhenConnected(I.ActiveSpeakersChanged, n);
		}, this.handleStreamStateUpdate = (e) => {
			e.streamStates.forEach((e) => {
				let t = this.getRemoteParticipantBySid(e.participantSid);
				if (!t) return;
				let n = t.getTrackPublicationBySid(e.trackSid);
				if (!n || !n.track) return;
				let r = H.streamStateFromProto(e.state);
				n.track.setStreamState(r), r !== n.track.streamState && (t.emit(L.TrackStreamStateChanged, n, n.track.streamState), this.emitWhenConnected(I.TrackStreamStateChanged, n, n.track.streamState, t));
			});
		}, this.handleSubscriptionPermissionUpdate = (e) => {
			let t = this.getRemoteParticipantBySid(e.participantSid);
			if (!t) return;
			let n = t.getTrackPublicationBySid(e.trackSid);
			n && n.setAllowed(e.allowed);
		}, this.handleSubscriptionError = (e) => {
			let t = Array.from(this.remoteParticipants.values()).find((t) => t.trackPublications.has(e.trackSid));
			if (!t) return;
			let n = t.getTrackPublicationBySid(e.trackSid);
			n && n.setSubscriptionError(e.err);
		}, this.handleDataPacket = (e, t) => {
			let n = this.remoteParticipants.get(e.participantIdentity);
			if (e.value.case === "user") this.handleUserPacket(n, e.value.value, e.kind, t);
			else if (e.value.case === "transcription") this.handleTranscription(n, e.value.value);
			else if (e.value.case === "sipDtmf") this.handleSipDtmf(n, e.value.value);
			else if (e.value.case === "chatMessage") this.handleChatMessage(n, e.value.value);
			else if (e.value.case === "metrics") this.handleMetrics(e.value.value, n);
			else if (e.value.case === "streamHeader" || e.value.case === "streamChunk" || e.value.case === "streamTrailer") this.handleDataStream(e, t);
			else if (e.value.case === "rpcRequest") {
				let t = e.value.value;
				this.rpcServerManager.handleIncomingRpcRequest(e.participantIdentity, t);
			} else if (e.value.case === "rpcResponse") {
				let t = e.value.value;
				switch (t.value.case) {
					case "payload":
						this.rpcClientManager.handleIncomingRpcResponseSuccess(t.requestId, t.value.value);
						break;
					case "error":
						this.rpcClientManager.handleIncomingRpcResponseFailure(t.requestId, Y.fromProto(t.value.value));
						break;
					default:
						this.log.warn(`Unknown rpcResponse.value.case: ${t.value.case}`, this.logContext);
						break;
				}
			} else e.value.case === "rpcAck" && this.rpcClientManager.handleIncomingRpcAck(e.value.value.requestId);
		}, this.handleUserPacket = (e, t, n, r) => {
			this.emit(I.DataReceived, t.payload, e, n, t.topic, r), e?.emit(L.DataReceived, t.payload, n, r);
		}, this.handleSipDtmf = (e, t) => {
			this.emit(I.SipDTMFReceived, t, e), e?.emit(L.SipDTMFReceived, t);
		}, this.handleTranscription = (e, t) => {
			let n = t.transcribedParticipantIdentity === this.localParticipant.identity ? this.localParticipant : this.getParticipantByIdentity(t.transcribedParticipantIdentity), r = n?.trackPublications.get(t.trackId), i = Ql(t, this.transcriptionReceivedTimes);
			r?.emit(z.TranscriptionReceived, i), n?.emit(L.TranscriptionReceived, i, r), this.emit(I.TranscriptionReceived, i, n, r);
		}, this.handleChatMessage = (e, t) => {
			let n = $l(t);
			this.emit(I.ChatMessage, n, e);
		}, this.handleMetrics = (e, t) => {
			this.emit(I.MetricsReceived, e, t);
		}, this.handleDataStream = (e, t) => {
			this.incomingDataStreamManager.handleDataStreamPacket(e, t);
		}, this.bufferedSegments = /* @__PURE__ */ new Map(), this.handleAudioPlaybackStarted = () => {
			this.canPlaybackAudio || (this.audioEnabled = !0, this.emit(I.AudioPlaybackStatusChanged, !0));
		}, this.handleAudioPlaybackFailed = (e) => {
			this.log.warn("could not playback audio", { error: e }), this.canPlaybackAudio && (this.audioEnabled = !1, this.emit(I.AudioPlaybackStatusChanged, !1));
		}, this.handleVideoPlaybackStarted = () => {
			this.isVideoPlaybackBlocked && (this.isVideoPlaybackBlocked = !1, this.emit(I.VideoPlaybackStatusChanged, !0));
		}, this.handleVideoPlaybackFailed = () => {
			this.isVideoPlaybackBlocked || (this.isVideoPlaybackBlocked = !0, this.emit(I.VideoPlaybackStatusChanged, !1));
		}, this.handleDeviceChange = () => j(this, void 0, void 0, function* () {
			gc()?.os !== "iOS" && (yield this.selectDefaultDevices()), this.emit(I.MediaDevicesChanged);
		}), this.handleRoomUpdate = (e) => {
			let t = this.roomInfo;
			this.roomInfo = e, t && t.metadata !== e.metadata && this.emitWhenConnected(I.RoomMetadataChanged, e.metadata), t?.activeRecording !== e.activeRecording && this.emitWhenConnected(I.RecordingStatusChanged, e.activeRecording);
		}, this.handleConnectionQualityUpdate = (e) => {
			e.updates.forEach((e) => {
				if (e.participantSid === this.localParticipant.sid) {
					this.localParticipant.setConnectionQuality(e.quality);
					return;
				}
				let t = this.getRemoteParticipantBySid(e.participantSid);
				t && t.setConnectionQuality(e.quality);
			});
		}, this.getRemoteParticipantClientProtocol = (e) => this.remoteParticipants.get(e)?.clientProtocol ?? 0, this.onLocalParticipantMetadataChanged = (e) => {
			this.emit(I.ParticipantMetadataChanged, e, this.localParticipant);
		}, this.onLocalParticipantNameChanged = (e) => {
			this.emit(I.ParticipantNameChanged, e, this.localParticipant);
		}, this.onLocalAttributesChanged = (e) => {
			this.emit(I.ParticipantAttributesChanged, e, this.localParticipant);
		}, this.onLocalTrackMuted = (e) => {
			this.emit(I.TrackMuted, e, this.localParticipant);
		}, this.onLocalTrackUnmuted = (e) => {
			this.emit(I.TrackUnmuted, e, this.localParticipant);
		}, this.onTrackProcessorUpdate = (e) => {
			var t;
			(t = e?.onPublish) == null || t.call(e, this);
		}, this.onLocalTrackPublished = (e) => j(this, void 0, void 0, function* () {
			var t, n, r, i;
			(t = e.track) == null || t.on(z.TrackProcessorUpdate, this.onTrackProcessorUpdate), (n = e.track) == null || n.on(z.Restarted, this.onLocalTrackRestarted), (i = (r = e.track?.getProcessor())?.onPublish) == null || i.call(r, this), this.emit(I.LocalTrackPublished, e, this.localParticipant), su(e.track) && (yield e.track.checkForSilence()) && this.emit(I.LocalAudioSilenceDetected, e);
			let a = yield e.track?.getDeviceId(!1), o = Yc(e.source);
			o && a && a !== this.localParticipant.activeDeviceMap.get(o) && (this.localParticipant.activeDeviceMap.set(o, a), this.emit(I.ActiveDeviceChanged, o, a));
		}), this.onLocalTrackUnpublished = (e) => {
			var t, n;
			(t = e.track) == null || t.off(z.TrackProcessorUpdate, this.onTrackProcessorUpdate), (n = e.track) == null || n.off(z.Restarted, this.onLocalTrackRestarted), this.emit(I.LocalTrackUnpublished, e, this.localParticipant);
		}, this.onLocalTrackRestarted = (e) => j(this, void 0, void 0, function* () {
			let t = yield e.getDeviceId(!1), n = Yc(e.source);
			n && t && t !== this.localParticipant.activeDeviceMap.get(n) && (this.log.debug(`local track restarted, setting ${n} ${t} active`), this.localParticipant.activeDeviceMap.set(n, t), this.emit(I.ActiveDeviceChanged, n, t));
		}), this.onLocalConnectionQualityChanged = (e) => {
			this.emit(I.ConnectionQualityChanged, e, this.localParticipant);
		}, this.onMediaDevicesError = (e, t) => {
			this.emit(I.MediaDevicesError, e, t);
		}, this.onLocalParticipantPermissionsChanged = (e) => {
			this.emit(I.ParticipantPermissionsChanged, e, this.localParticipant);
		}, this.onLocalChatMessageSent = (e) => {
			this.emit(I.ChatMessage, e, this.localParticipant);
		}, this.setMaxListeners(100), this.remoteParticipants = /* @__PURE__ */ new Map(), this.sidToIdentity = /* @__PURE__ */ new Map(), this.options = Object.assign(Object.assign({}, Zd), t), this.log = Lo(this.options.loggerName ?? k.Room, () => this.logContext), this.transcriptionReceivedTimes = /* @__PURE__ */ new Map(), this.options.audioCaptureDefaults = Object.assign(Object.assign({}, Yd), t?.audioCaptureDefaults), this.options.videoCaptureDefaults = Object.assign(Object.assign({}, Xd), t?.videoCaptureDefaults), this.options.publishDefaults = Object.assign(Object.assign({}, Jd), t?.publishDefaults), this.maybeCreateEngine(), this.incomingDataStreamManager = new Zf(), this.outgoingDataStreamManager = new np(this.engine, this.log), this.incomingDataTrackManager = new Yp({ e2eeManager: this.e2eeManager }), this.incomingDataTrackManager.on("sfuUpdateSubscription", (e) => {
			this.engine.client.sendUpdateDataSubscription(e.sid, e.subscribe);
		}).on("trackPublished", (e) => {
			var t;
			e.track.publisherIdentity !== this.localParticipant.identity && (this.emit(I.DataTrackPublished, e.track), (t = this.remoteParticipants.get(e.track.publisherIdentity)) == null || t.addRemoteDataTrack(e.track));
		}).on("trackUnpublished", (e) => {
			var t;
			e.publisherIdentity !== this.localParticipant.identity && (this.emit(I.DataTrackUnpublished, e.sid), (t = this.remoteParticipants.get(e.publisherIdentity)) == null || t.removeRemoteDataTrack(e.sid));
		}), this.outgoingDataTrackManager = new um({ e2eeManager: this.e2eeManager }), this.outgoingDataTrackManager.on("sfuPublishRequest", (e) => {
			this.engine.client.sendPublishDataTrackRequest(e.handle, e.name, e.usesE2ee);
		}).on("sfuUnpublishRequest", (e) => {
			this.engine.client.sendUnPublishDataTrackRequest(e.handle);
		}).on("trackPublished", (e) => {
			this.emit(I.LocalDataTrackPublished, e.track);
		}).on("trackUnpublished", (e) => {
			this.emit(I.LocalDataTrackUnpublished, e.sid);
		}).on("packetAvailable", (e) => {
			let t = e.handle, n = e.bytes;
			this.engine.sendLossyBytes(n, K.DATA_TRACK_LOSSY, "wait").finally(() => this.outgoingDataTrackManager.handlePacketSendComplete(t));
		}), this.registerRpcDataStreamHandler(), this.rpcClientManager = new ym(this.log, this.outgoingDataStreamManager, this.getRemoteParticipantClientProtocol, () => this.engine.latestJoinResponse?.serverInfo?.version), this.rpcClientManager.on("sendDataPacket", (e) => {
			let t = e.packet;
			var n;
			(n = this.engine) == null || n.sendDataPacket(t, K.RELIABLE);
		}), this.rpcServerManager = new bm(this.log, this.outgoingDataStreamManager, this.getRemoteParticipantClientProtocol), this.rpcServerManager.on("sendDataPacket", (e) => {
			let t = e.packet;
			var n;
			(n = this.engine) == null || n.sendDataPacket(t, K.RELIABLE);
		}), this.disconnectLock = new v(), this.localParticipant = new Mm("", "", this.engine, this.options, this.outgoingDataStreamManager, this.outgoingDataTrackManager, this.rpcClientManager, this.rpcServerManager), this.setupPacketTrailer(), (this.options.e2ee || this.options.encryption) && this.setupE2EE(), this.engine.e2eeManager = this.e2eeManager, this.incomingDataTrackManager.updateE2eeManager(this.e2eeManager ?? null), this.outgoingDataTrackManager.updateE2eeManager(this.e2eeManager ?? null), this.options.videoCaptureDefaults.deviceId && this.localParticipant.activeDeviceMap.set("videoinput", Yl(this.options.videoCaptureDefaults.deviceId)), this.options.audioCaptureDefaults.deviceId && this.localParticipant.activeDeviceMap.set("audioinput", Yl(this.options.audioCaptureDefaults.deviceId)), this.options.audioOutput?.deviceId && this.switchActiveDevice("audiooutput", Yl(this.options.audioOutput.deviceId)).catch((e) => this.log.warn(`Could not set audio output: ${e.message}`)), Al()) {
			let t = new AbortController(), n;
			if (e.cleanupRegistry) {
				let r = new WeakRef(this);
				n = () => {
					let e = r.deref();
					e && e.handleDeviceChange();
				}, e.cleanupRegistry.register(this, () => {
					t.abort();
				});
			} else n = this.handleDeviceChange;
			(i = (r = navigator.mediaDevices)?.addEventListener) == null || i.call(r, "devicechange", n, { signal: t.signal });
		}
	}
	registerTextStreamHandler(e, t) {
		return this.incomingDataStreamManager.registerTextStreamHandler(e, t);
	}
	unregisterTextStreamHandler(e) {
		return this.incomingDataStreamManager.unregisterTextStreamHandler(e);
	}
	registerByteStreamHandler(e, t) {
		return this.incomingDataStreamManager.registerByteStreamHandler(e, t);
	}
	unregisterByteStreamHandler(e) {
		return this.incomingDataStreamManager.unregisterByteStreamHandler(e);
	}
	registerRpcMethod(e, t) {
		this.rpcServerManager.registerRpcMethod(e, t);
	}
	unregisterRpcMethod(e) {
		this.rpcServerManager.unregisterRpcMethod(e);
	}
	setE2EEEnabled(e) {
		return j(this, void 0, void 0, function* () {
			let t = yield this.e2eeStateMutex.lock();
			try {
				if (this.e2eeManager) this.isE2EEEnabled !== e && (yield this.localParticipant.setE2EEEnabled(e), this.localParticipant.identity !== "" && this.e2eeManager.setParticipantCryptorEnabled(e, this.localParticipant.identity));
				else throw Error("e2ee not configured, please set e2ee settings within the room options");
			} finally {
				t();
			}
		});
	}
	setupE2EE() {
		var e, t;
		let n = !!this.options.encryption, r = this.options.encryption || this.options.e2ee;
		r && ("e2eeManager" in r ? (this.e2eeManager = r.e2eeManager, this.e2eeManager.isDataChannelEncryptionEnabled = n) : this.e2eeManager = new qu(r, n), this.e2eeManager.on(Eu.ParticipantEncryptionStatusChanged, (e, t) => {
			du(t) && (this.isE2EEEnabled = e), this.emit(I.ParticipantEncryptionStatusChanged, e, t);
		}), this.e2eeManager.on(Eu.EncryptionError, (e, t) => {
			let n = t ? this.getParticipantByIdentity(t) : void 0;
			this.emit(I.EncryptionError, e, n);
		}), (e = this.e2eeManager) == null || e.setup(this), (t = this.e2eeManager) == null || t.setupEngine(this.engine));
	}
	setupPacketTrailer() {
		this.packetTrailerManager = new Xu(this.options.packetTrailer), this.packetTrailerManager.setup(this);
	}
	get logContext() {
		return {
			room: this.name,
			roomID: this.roomInfo?.sid,
			participant: this.localParticipant?.identity,
			participantID: this.localParticipant?.sid
		};
	}
	get isRecording() {
		return this.roomInfo?.activeRecording ?? !1;
	}
	getSid() {
		return this.state === X.Disconnected ? pc.resolve("") : this.roomInfo && this.roomInfo.sid !== "" ? pc.resolve(this.roomInfo.sid) : new pc((e, t) => {
			let n = (t) => {
				t.sid !== "" && (this.engine.off(R.RoomUpdate, n), e(t.sid));
			};
			this.engine.on(R.RoomUpdate, n), this.once(I.Disconnected, () => {
				this.engine.off(R.RoomUpdate, n), t(new P("Room disconnected before room server id was available"));
			});
		});
	}
	get name() {
		return this.roomInfo?.name ?? "";
	}
	get metadata() {
		return this.roomInfo?.metadata;
	}
	get numParticipants() {
		return this.roomInfo?.numParticipants ?? 0;
	}
	get numPublishers() {
		return this.roomInfo?.numPublishers ?? 0;
	}
	maybeCreateEngine() {
		this.engine && (this.engine.isNewlyCreated || !this.engine.isClosed) || (this.engine = new Hf(this.options), this.engine.e2eeManager = this.e2eeManager, this.engine.on(R.ParticipantUpdate, this.handleParticipantUpdates).on(R.RoomUpdate, this.handleRoomUpdate).on(R.SpeakersChanged, this.handleSpeakersChanged).on(R.StreamStateChanged, this.handleStreamStateUpdate).on(R.ConnectionQualityUpdate, this.handleConnectionQualityUpdate).on(R.SubscriptionError, this.handleSubscriptionError).on(R.SubscriptionPermissionUpdate, this.handleSubscriptionPermissionUpdate).on(R.MediaTrackAdded, (e, t, n) => {
			this.onTrackAdded(e, t, n);
		}).on(R.Disconnected, (e) => {
			this.handleDisconnect(this.options.stopLocalTrackOnUnpublish, e);
		}).on(R.ActiveSpeakersUpdate, this.handleActiveSpeakersUpdate).on(R.DataPacketReceived, this.handleDataPacket).on(R.Resuming, () => {
			this.clearConnectionReconcile(), this.isResuming = !0, this.log.debug("Resuming signal connection"), this.setAndEmitConnectionState(X.SignalReconnecting) && this.emit(I.SignalReconnecting);
		}).on(R.Resumed, () => {
			this.registerConnectionReconcile(), this.isResuming = !1, this.log.debug("Resumed signal connection"), this.updateSubscriptions(), this.emitBufferedEvents(), this.setAndEmitConnectionState(X.Connected) && this.emit(I.Reconnected);
		}).on(R.SignalResumed, () => {
			this.bufferedEvents = [], (this.state === X.Reconnecting || this.isResuming) && this.sendSyncState();
		}).on(R.Restarting, this.handleRestarting).on(R.Restarted, this.handleRestarted).on(R.SignalRestarted, this.handleSignalRestarted).on(R.Offline, () => {
			this.setAndEmitConnectionState(X.Reconnecting) && this.emit(I.Reconnecting);
		}).on(R.DCBufferStatusChanged, (e, t) => {
			this.emit(I.DCBufferStatusChanged, e, t);
		}).on(R.LocalTrackSubscribed, (e) => {
			this.handleLocalTrackSubscribed(e);
		}).on(R.RoomMoved, (e) => {
			this.log.debug("room moved", e), e.room && this.handleRoomUpdate(e.room), this.remoteParticipants.forEach((e, t) => {
				this.handleParticipantDisconnected(t, e);
			}), this.emit(I.Moved, e.room.name), e.participant ? this.handleParticipantUpdates([e.participant, ...e.otherParticipants]) : this.handleParticipantUpdates(e.otherParticipants);
		}).on(R.PublishDataTrackResponse, (e) => {
			if (!e.info) {
				this.log.warn(`received PublishDataTrackResponse, but event.info was ${e.info}, so skipping.`);
				return;
			}
			this.outgoingDataTrackManager.receivedSfuPublishResponse(e.info.pubHandle, {
				type: "ok",
				data: {
					sid: e.info.sid,
					pubHandle: e.info.pubHandle,
					name: e.info.name,
					usesE2ee: e.info.encryption !== O.NONE
				}
			});
		}).on(R.UnPublishDataTrackResponse, (e) => {
			if (!e.info) {
				this.log.warn(`received UnPublishDataTrackResponse, but event.info was ${e.info}, so skipping.`);
				return;
			}
			this.outgoingDataTrackManager.receivedSfuUnpublishResponse(e.info.pubHandle);
		}).on(R.DataTrackSubscriberHandles, (e) => {
			let t = new Map(Object.entries(e.subHandles).map((e) => {
				let t = C(e, 2), n = t[0], r = t[1];
				return [parseInt(n, 10), r.trackSid];
			}));
			this.incomingDataTrackManager.receivedSfuSubscriberHandles(t);
		}).on(R.DataTrackPacketReceived, (e) => {
			try {
				this.incomingDataTrackManager.packetReceived(e);
			} catch (e) {
				throw e;
			}
		}).on(R.Joined, (e) => {
			let t = new Map(e.otherParticipants.map((e) => [e.identity, e.dataTracks.map((e) => fd.from(e))]));
			this.incomingDataTrackManager.receiveSfuPublicationUpdates(t);
		}).on(R.TokenRefreshed, (e) => {
			var t;
			(t = this.regionUrlProvider) == null || t.updateToken(e);
		}).on(R.ServerRegionsReported, (e) => {
			var t;
			(t = this.regionUrlProvider) == null || t.setServerReportedRegions({
				regionSettings: e,
				updatedAtInMs: Date.now(),
				maxAgeInMs: Wf
			});
		}), this.localParticipant && this.localParticipant.setupEngine(this.engine), this.e2eeManager && this.e2eeManager.setupEngine(this.engine), this.outgoingDataStreamManager && this.outgoingDataStreamManager.setupEngine(this.engine));
	}
	createRegionStrategy() {
		return {
			getNextUrl: (e) => j(this, void 0, void 0, function* () {
				return this.regionUrlProvider ? this.regionUrlProvider.getNextBestRegionUrl(e) : null;
			}),
			resetAttempts: () => this.regionUrlProvider?.resetAttempts()
		};
	}
	static getLocalDevices(e) {
		let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !0;
		return td.getInstance().getDevices(e, t);
	}
	prepareConnection(e, t) {
		return j(this, void 0, void 0, function* () {
			if (this.state === X.Disconnected) {
				this.log.debug(`prepareConnection to ${e}`);
				try {
					if (Ml(new URL(e)) && t) {
						this.regionUrlProvider = new Kf(e, t);
						let n = yield this.regionUrlProvider.getNextBestRegionUrl();
						n && this.state === X.Disconnected && (this.regionUrl = n, yield fetch(Zl(n), { method: "HEAD" }), this.log.debug(`prepared connection to ${n}`));
					} else yield fetch(Zl(e), { method: "HEAD" });
				} catch (e) {
					this.log.warn("could not prepare connection", { error: e });
				}
			}
		});
	}
	getParticipantByIdentity(e) {
		return this.localParticipant.identity === e ? this.localParticipant : this.remoteParticipants.get(e);
	}
	clearConnectionFutures() {
		this.connectFuture = void 0;
	}
	simulateScenario(e, t) {
		return j(this, void 0, void 0, function* () {
			let n = () => j(this, void 0, void 0, function* () {}), r;
			switch (e) {
				case "signal-reconnect":
					yield this.engine.client.handleOnClose("simulate disconnect");
					break;
				case "fail-on-v1-path":
					this.engine.failNextV1Path();
					break;
				case "speaker":
					r = new ho({ scenario: {
						case: "speakerUpdate",
						value: 3
					} });
					break;
				case "node-failure":
					r = new ho({ scenario: {
						case: "nodeFailure",
						value: !0
					} });
					break;
				case "server-leave":
					r = new ho({ scenario: {
						case: "serverLeave",
						value: !0
					} });
					break;
				case "migration":
					r = new ho({ scenario: {
						case: "migration",
						value: !0
					} });
					break;
				case "resume-reconnect":
					this.engine.failNext(), yield this.engine.client.handleOnClose("simulate resume-disconnect");
					break;
				case "disconnect-signal-on-resume":
					n = () => j(this, void 0, void 0, function* () {
						yield this.engine.client.handleOnClose("simulate resume-disconnect");
					}), r = new ho({ scenario: {
						case: "disconnectSignalOnResume",
						value: !0
					} });
					break;
				case "disconnect-signal-on-resume-no-messages":
					n = () => j(this, void 0, void 0, function* () {
						yield this.engine.client.handleOnClose("simulate resume-disconnect");
					}), r = new ho({ scenario: {
						case: "disconnectSignalOnResumeNoMessages",
						value: !0
					} });
					break;
				case "full-reconnect":
					this.engine.fullReconnectOnNext = !0, yield this.engine.client.handleOnClose("simulate full-reconnect");
					break;
				case "force-tcp":
				case "force-tls":
					r = new ho({ scenario: {
						case: "switchCandidateProtocol",
						value: e === "force-tls" ? 2 : 1
					} }), n = () => j(this, void 0, void 0, function* () {
						let e = this.engine.client.onLeave;
						e && e(new Ka({
							reason: wi.CLIENT_INITIATED,
							action: qa.RECONNECT
						}));
					});
					break;
				case "subscriber-bandwidth":
					if (t === void 0 || typeof t != "number") throw Error("subscriber-bandwidth requires a number as argument");
					r = new ho({ scenario: {
						case: "subscriberBandwidth",
						value: nu(t)
					} });
					break;
				case "leave-full-reconnect": r = new ho({ scenario: {
					case: "leaveRequestFullReconnect",
					value: !0
				} });
			}
			r && (yield this.engine.client.sendSimulateScenario(r), yield n());
		});
	}
	get canPlaybackAudio() {
		return this.audioEnabled;
	}
	get canPlaybackVideo() {
		return !this.isVideoPlaybackBlocked;
	}
	getActiveDevice(e) {
		return this.localParticipant.activeDeviceMap.get(e);
	}
	switchActiveDevice(e, t) {
		return j(this, arguments, void 0, function(e, t) {
			var n = this;
			let r = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : !0;
			return function* () {
				var i, a;
				let o = !0, s = !1, c = r ? { exact: t } : t;
				if (e === "audioinput") {
					s = n.localParticipant.audioTrackPublications.size === 0;
					let t = n.getActiveDevice(e) ?? n.options.audioCaptureDefaults.deviceId;
					n.options.audioCaptureDefaults.deviceId = c;
					let r = Array.from(n.localParticipant.audioTrackPublications.values()).filter((e) => e.source === H.Source.Microphone);
					try {
						o = (yield Promise.all(r.map((e) => e.audioTrack?.setDeviceId(c)))).every((e) => e === !0);
					} catch (e) {
						throw n.options.audioCaptureDefaults.deviceId = t, e;
					}
					let i = r.some((e) => e.track?.isMuted ?? !1);
					o && i && (s = !0);
				} else if (e === "videoinput") {
					s = n.localParticipant.videoTrackPublications.size === 0;
					let t = n.getActiveDevice(e) ?? n.options.videoCaptureDefaults.deviceId;
					n.options.videoCaptureDefaults.deviceId = c;
					let r = Array.from(n.localParticipant.videoTrackPublications.values()).filter((e) => e.source === H.Source.Camera);
					try {
						o = (yield Promise.all(r.map((e) => e.videoTrack?.setDeviceId(c)))).every((e) => e === !0);
					} catch (e) {
						throw n.options.videoCaptureDefaults.deviceId = t, e;
					}
					let i = r.some((e) => e.track?.isMuted ?? !1);
					o && i && (s = !0);
				} else if (e === "audiooutput") {
					if (s = !0, !yl() && !n.options.webAudioMix || n.options.webAudioMix && n.audioContext && !("setSinkId" in n.audioContext)) throw Error("cannot switch audio output, the current browser does not support it");
					n.options.webAudioMix && (t = (yield td.getInstance().normalizeDeviceId("audiooutput", t)) ?? ""), (a = n.options).audioOutput ?? (a.audioOutput = {});
					let r = n.getActiveDevice(e) ?? n.options.audioOutput.deviceId;
					n.options.audioOutput.deviceId = t;
					try {
						n.options.webAudioMix && ((i = n.audioContext) == null || i.setSinkId(t)), yield Promise.all(Array.from(n.remoteParticipants.values()).map((e) => e.setAudioOutput({ deviceId: t })));
					} catch (e) {
						throw n.options.audioOutput.deviceId = r, e;
					}
				}
				return s && (n.localParticipant.activeDeviceMap.set(e, t), n.emit(I.ActiveDeviceChanged, e, t)), o;
			}();
		});
	}
	setupLocalParticipantEvents() {
		this.localParticipant.on(L.ParticipantMetadataChanged, this.onLocalParticipantMetadataChanged).on(L.ParticipantNameChanged, this.onLocalParticipantNameChanged).on(L.AttributesChanged, this.onLocalAttributesChanged).on(L.TrackMuted, this.onLocalTrackMuted).on(L.TrackUnmuted, this.onLocalTrackUnmuted).on(L.LocalTrackPublished, this.onLocalTrackPublished).on(L.LocalTrackUnpublished, this.onLocalTrackUnpublished).on(L.ConnectionQualityChanged, this.onLocalConnectionQualityChanged).on(L.MediaDevicesError, this.onMediaDevicesError).on(L.AudioStreamAcquired, this.startAudio).on(L.ChatMessage, this.onLocalChatMessageSent).on(L.ParticipantPermissionsChanged, this.onLocalParticipantPermissionsChanged);
	}
	recreateEngine(e) {
		let t = this.engine;
		e && t && !t.client.isDisconnected ? t.client.sendLeave().finally(() => t.close()) : t?.close(), this.engine = void 0, this.isResuming = !1, this.remoteParticipants.clear(), this.sidToIdentity.clear(), this.bufferedEvents = [], this.maybeCreateEngine();
	}
	onTrackAdded(e, t, n) {
		if (this.state === X.Connecting || this.state === X.Reconnecting) {
			let r = () => {
				this.log.debug("deferring on track for later", {
					mediaTrackId: e.id,
					mediaStreamId: t.id,
					tracksInStream: t.getTracks().map((e) => e.id)
				}), this.onTrackAdded(e, t, n), i();
			}, i = () => {
				this.off(I.Reconnected, r), this.off(I.Connected, r), this.off(I.Disconnected, i);
			};
			this.once(I.Reconnected, r), this.once(I.Connected, r), this.once(I.Disconnected, i);
			return;
		}
		if (this.state === X.Disconnected) {
			this.log.warn("skipping incoming track after Room disconnected");
			return;
		}
		if (e.readyState === "ended") {
			this.log.debug("skipping incoming track as it already ended");
			return;
		}
		let r = fl(t.id), i = r[0], a = r[1], o = e.id;
		if (a && a.startsWith("TR") && (o = a), i === this.localParticipant.sid) {
			this.log.warn("tried to create RemoteParticipant for local participant");
			return;
		}
		let s = Array.from(this.remoteParticipants.values()).find((e) => e.sid === i);
		if (!s) {
			i.startsWith("PA") && this.log.error(`Tried to add a track for a participant, that's not present. Sid: ${i}`);
			return;
		}
		if (!o.startsWith("TR")) {
			let e = this.engine.getTrackIdForReceiver(n);
			if (!e) {
				this.log.error(`Tried to add a track whose 'sid' could not be found for a participant, that's not present. Sid: ${i}`);
				return;
			}
			o = e;
		}
		o.startsWith("TR") || this.log.warn(`Tried to add a track whose 'sid' could not be determined for a participant, that's not present. Sid: ${i}, streamId: ${a}, trackId: ${o}`, {
			remoteParticipantID: i,
			streamId: a,
			trackId: o
		});
		let c;
		this.options.adaptiveStream && (c = typeof this.options.adaptiveStream == "object" ? this.options.adaptiveStream : {});
		let l = s.addSubscribedMediaTrack(e, o, t, n, c);
		l?.isEncrypted && !this.e2eeManager && this.emit(I.EncryptionError, /* @__PURE__ */ Error(`Encrypted ${l.source} track received from participant ${s.sid}, but room does not have encryption enabled!`));
	}
	handleLocalTrackSubscribed(e) {
		let t = () => this.localParticipant.getTrackPublications().find((t) => t.trackSid === e), n = t();
		if (n) {
			this.emitLocalTrackSubscribed(n);
			return;
		}
		this.log.debug("deferring LocalTrackSubscribed, publication not yet available", { subscribedSid: e });
		let r, i = (t) => {
			t.trackSid === e && (a(), this.emitLocalTrackSubscribed(t));
		}, a = () => {
			clearTimeout(r), this.localParticipant.off(L.LocalTrackPublished, i), this.off(I.Disconnected, a);
		};
		this.localParticipant.on(L.LocalTrackPublished, i), this.once(I.Disconnected, a), r = setTimeout(() => {
			a();
			let n = t();
			n ? this.emitLocalTrackSubscribed(n) : this.log.warn("could not find local track publication for LocalTrackSubscribed event after timeout", { subscribedSid: e });
		}, 1e4);
	}
	emitLocalTrackSubscribed(e) {
		this.localParticipant.emit(L.LocalTrackSubscribed, e), this.emitWhenConnected(I.LocalTrackSubscribed, e, this.localParticipant);
	}
	handleDisconnect() {
		let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : !0, t = arguments.length > 1 ? arguments[1] : void 0;
		var n, r;
		if (this.clearConnectionReconcile(), this.isResuming = !1, this.bufferedEvents = [], this.transcriptionReceivedTimes.clear(), this.incomingDataStreamManager.clearControllers(), this.incomingDataTrackManager.reset(), this.outgoingDataTrackManager.reset(), this.state !== X.Disconnected) {
			this.regionUrl = void 0, this.regionUrlProvider && this.regionUrlProvider.notifyDisconnected();
			try {
				this.remoteParticipants.forEach((e) => {
					e.trackPublications.forEach((t) => {
						e.unpublishTrack(t.trackSid);
					});
				}), this.localParticipant.trackPublications.forEach((t) => {
					var n, r, i;
					t.track && this.localParticipant.unpublishTrack(t.track, e), e ? ((n = t.track) == null || n.detach(), (r = t.track) == null || r.stop()) : (i = t.track) == null || i.stopMonitor();
				}), this.localParticipant.off(L.ParticipantMetadataChanged, this.onLocalParticipantMetadataChanged).off(L.ParticipantNameChanged, this.onLocalParticipantNameChanged).off(L.AttributesChanged, this.onLocalAttributesChanged).off(L.TrackMuted, this.onLocalTrackMuted).off(L.TrackUnmuted, this.onLocalTrackUnmuted).off(L.LocalTrackPublished, this.onLocalTrackPublished).off(L.LocalTrackUnpublished, this.onLocalTrackUnpublished).off(L.ConnectionQualityChanged, this.onLocalConnectionQualityChanged).off(L.MediaDevicesError, this.onMediaDevicesError).off(L.AudioStreamAcquired, this.startAudio).off(L.ChatMessage, this.onLocalChatMessageSent).off(L.ParticipantPermissionsChanged, this.onLocalParticipantPermissionsChanged), this.localParticipant.trackPublications.clear(), this.localParticipant.videoTrackPublications.clear(), this.localParticipant.audioTrackPublications.clear(), this.remoteParticipants.clear(), this.sidToIdentity.clear(), this.activeSpeakers = [], this.audioContext && typeof this.options.webAudioMix == "boolean" && (this.audioContext.close(), this.audioContext = void 0), Al() && (window.removeEventListener("beforeunload", this.onPageLeave), window.removeEventListener("pagehide", this.onPageLeave), window.removeEventListener("freeze", this.onPageLeave), (r = (n = navigator.mediaDevices)?.removeEventListener) == null || r.call(n, "devicechange", this.handleDeviceChange));
			} finally {
				this.setAndEmitConnectionState(X.Disconnected), this.emit(I.Disconnected, t);
			}
		}
	}
	handleParticipantDisconnected(e, t) {
		this.remoteParticipants.delete(e), t && (this.incomingDataStreamManager.validateParticipantHasNoActiveDataStreams(e), this.incomingDataTrackManager.handleRemoteParticipantDisconnected(e), t.trackPublications.forEach((e) => {
			t.unpublishTrack(e.trackSid, !0);
		}), this.emit(I.ParticipantDisconnected, t), t.setDisconnected(), this.rpcClientManager.handleParticipantDisconnected(t.identity));
	}
	selectDefaultDevices() {
		return j(this, void 0, void 0, function* () {
			let e = td.getInstance().previousDevices, t = yield td.getInstance().getDevices(void 0, !1), n = gc();
			if (n?.name === "Chrome" && n.os !== "iOS") for (let n of t) {
				let t = e.find((e) => e.deviceId === n.deviceId);
				t && t.label !== "" && t.kind === n.kind && t.label !== n.label && this.getActiveDevice(n.kind) === "default" && this.emit(I.ActiveDeviceChanged, n.kind, n.deviceId);
			}
			for (let n of [
				"audiooutput",
				"audioinput",
				"videoinput"
			]) {
				let r = Jc(n), i = this.localParticipant.getTrackPublication(r);
				if (i && i.track?.isUserProvided) continue;
				let a = t.filter((e) => e.kind === n), o = this.getActiveDevice(n);
				if (o === e.filter((e) => e.kind === n)[0]?.deviceId && a.length > 0 && a[0]?.deviceId !== o) {
					yield this.switchActiveDevice(n, a[0].deviceId);
					continue;
				}
				n === "audioinput" && !Tl() || n === "videoinput" || a.length > 0 && !a.find((e) => e.deviceId === this.getActiveDevice(n)) && (n !== "audiooutput" || !Tl()) && (yield this.switchActiveDevice(n, a[0].deviceId));
			}
		});
	}
	acquireAudioContext() {
		return j(this, void 0, void 0, function* () {
			if (typeof this.options.webAudioMix != "boolean" && this.options.webAudioMix.audioContext ? this.audioContext = this.options.webAudioMix.audioContext : (!this.audioContext || this.audioContext.state === "closed") && (this.audioContext = qc() ?? void 0), this.options.webAudioMix && this.remoteParticipants.forEach((e) => e.setAudioContext(this.audioContext)), this.localParticipant.setAudioContext(this.audioContext), this.audioContext && this.audioContext.state === "suspended") try {
				yield Promise.race([this.audioContext.resume(), pl(200)]);
			} catch (e) {
				this.log.warn("Could not resume audio context", { error: e });
			}
			let e = this.audioContext?.state === "running";
			e !== this.canPlaybackAudio && (this.audioEnabled = e, this.emit(I.AudioPlaybackStatusChanged, e));
		});
	}
	createParticipant(e, t) {
		let n;
		return n = t ? Im.fromParticipantInfo(this.engine.client, t, {
			loggerContextCb: () => this.logContext,
			loggerName: this.options.loggerName
		}, this.incomingDataTrackManager) : new Im(this.engine.client, "", e, void 0, void 0, void 0, {
			loggerContextCb: () => this.logContext,
			loggerName: this.options.loggerName
		}), this.options.webAudioMix && n.setAudioContext(this.audioContext), this.options.audioOutput?.deviceId && n.setAudioOutput(this.options.audioOutput).catch((e) => this.log.warn(`Could not set audio output: ${e.message}`)), n;
	}
	getOrCreateParticipant(e, t) {
		if (this.remoteParticipants.has(e)) {
			let n = this.remoteParticipants.get(e);
			return t && n.updateInfo(t) && this.sidToIdentity.set(t.sid, t.identity), n;
		}
		let n = this.createParticipant(e, t);
		return this.remoteParticipants.set(e, n), this.sidToIdentity.set(t.sid, t.identity), this.emitWhenConnected(I.ParticipantConnected, n), n.on(L.TrackPublished, (e) => {
			this.emitWhenConnected(I.TrackPublished, e, n);
		}).on(L.TrackSubscribed, (e, t) => {
			e.kind === H.Kind.Audio ? (e.on(z.AudioPlaybackStarted, this.handleAudioPlaybackStarted), e.on(z.AudioPlaybackFailed, this.handleAudioPlaybackFailed)) : e.kind === H.Kind.Video && (e.on(z.VideoPlaybackFailed, this.handleVideoPlaybackFailed), e.on(z.VideoPlaybackStarted, this.handleVideoPlaybackStarted)), this.emitWhenConnected(I.TrackSubscribed, e, t, n);
		}).on(L.TrackUnpublished, (e) => {
			this.emit(I.TrackUnpublished, e, n);
		}).on(L.TrackUnsubscribed, (e, t) => {
			this.emit(I.TrackUnsubscribed, e, t, n);
		}).on(L.TrackMuted, (e) => {
			this.emitWhenConnected(I.TrackMuted, e, n);
		}).on(L.TrackUnmuted, (e) => {
			this.emitWhenConnected(I.TrackUnmuted, e, n);
		}).on(L.ParticipantMetadataChanged, (e) => {
			this.emitWhenConnected(I.ParticipantMetadataChanged, e, n);
		}).on(L.ParticipantNameChanged, (e) => {
			this.emitWhenConnected(I.ParticipantNameChanged, e, n);
		}).on(L.AttributesChanged, (e) => {
			this.emitWhenConnected(I.ParticipantAttributesChanged, e, n);
		}).on(L.ConnectionQualityChanged, (e) => {
			this.emitWhenConnected(I.ConnectionQualityChanged, e, n);
		}).on(L.ParticipantPermissionsChanged, (e) => {
			this.emitWhenConnected(I.ParticipantPermissionsChanged, e, n);
		}).on(L.TrackSubscriptionStatusChanged, (e, t) => {
			this.emitWhenConnected(I.TrackSubscriptionStatusChanged, e, t, n);
		}).on(L.TrackSubscriptionFailed, (e, t) => {
			this.emit(I.TrackSubscriptionFailed, e, n, t);
		}).on(L.TrackSubscriptionPermissionChanged, (e, t) => {
			this.emitWhenConnected(I.TrackSubscriptionPermissionChanged, e, t, n);
		}).on(L.Active, () => {
			this.emitWhenConnected(I.ParticipantActive, n), n.kind === Ni.AGENT && this.localParticipant.setActiveAgent(n);
		}), t && n.updateInfo(t), n;
	}
	sendSyncState() {
		let e = Array.from(this.remoteParticipants.values()).reduce((e, t) => (e.push(...t.getTrackPublications()), e), []), t = this.localParticipant.getTrackPublications(), n = this.outgoingDataTrackManager.queryPublished();
		this.engine.sendSyncState(e, t, n);
	}
	updateSubscriptions() {
		for (let e of this.remoteParticipants.values()) for (let t of e.videoTrackPublications.values()) t.isSubscribed && lu(t) && t.emitTrackUpdate();
	}
	getRemoteParticipantBySid(e) {
		let t = this.sidToIdentity.get(e);
		if (t) return this.remoteParticipants.get(t);
	}
	registerRpcDataStreamHandler() {
		this.incomingDataStreamManager.registerTextStreamHandler(fm, (e, t) => j(this, [e, t], void 0, function(e, t) {
			var n = this;
			let r = t.identity;
			return function* () {
				let t = e.info.attributes ?? {};
				yield n.rpcServerManager.handleIncomingDataStream(e, r, t);
			}();
		})), this.incomingDataStreamManager.registerTextStreamHandler(pm, (e, t) => j(this, [e, t], void 0, function(e, t) {
			var n = this;
			let r = t.identity;
			return function* () {
				let t = e.info.attributes ?? {};
				yield n.rpcClientManager.handleIncomingDataStream(e, r, t);
			}();
		}));
	}
	registerConnectionReconcile() {
		this.clearConnectionReconcile();
		let e = 0;
		this.connectionReconcileInterval = F.setInterval(() => {
			!this.engine || this.engine.isClosed || !this.engine.verifyTransport() ? (e++, this.log.warn("detected connection state mismatch", {
				numFailures: e,
				engine: this.engine ? {
					closed: this.engine.isClosed,
					transportsConnectedOrConnecting: this.engine.verifyTransport()
				} : void 0
			}), e >= 3 && (this.recreateEngine(), this.handleDisconnect(this.options.stopLocalTrackOnUnpublish, wi.STATE_MISMATCH))) : e = 0;
		}, Lm);
	}
	clearConnectionReconcile() {
		this.connectionReconcileInterval && F.clearInterval(this.connectionReconcileInterval);
	}
	setAndEmitConnectionState(e) {
		return e === this.state ? !1 : (this.log.info(`connection state changed: ${this.state} -> ${e}`), this.state = e, this.incomingDataStreamManager.setConnected(e === X.Connected), this.emit(I.ConnectionStateChanged, this.state), !0);
	}
	emitBufferedEvents() {
		this.bufferedEvents.forEach((e) => {
			let t = C(e, 2), n = t[0], r = t[1];
			this.emit(n, ...r);
		}), this.bufferedEvents = [];
	}
	emitWhenConnected(e) {
		var t = [...arguments].slice(1);
		if (this.state === X.Reconnecting || this.isResuming || !this.engine || this.engine.pendingReconnect) this.bufferedEvents.push([e, t]);
		else if (this.state === X.Connected) return this.emit(e, ...t);
		return !1;
	}
	simulateParticipants(e) {
		return j(this, void 0, void 0, function* () {
			let t = Object.assign({
				audio: !0,
				video: !0,
				useRealTracks: !1
			}, e.publish), n = Object.assign({
				count: 9,
				audio: !1,
				video: !0,
				aspectRatios: [
					1.66,
					1.7,
					1.3
				]
			}, e.participants);
			if (this.handleDisconnect(), this.roomInfo = new Oi({
				sid: "RM_SIMULATED",
				name: "simulated-room",
				emptyTimeout: 0,
				maxParticipants: 0,
				creationTime: b.parse((/* @__PURE__ */ new Date()).getTime()),
				metadata: "",
				numParticipants: 1,
				numPublishers: 1,
				turnPassword: "",
				enabledCodecs: [],
				activeRecording: !1
			}), this.localParticipant.updateInfo(new ji({
				identity: "simulated-local",
				name: "local-name"
			})), this.setupLocalParticipantEvents(), this.emit(I.SignalConnected), this.emit(I.Connected), this.setAndEmitConnectionState(X.Connected), t.video) {
				let e = new Cm(H.Kind.Video, new Ii({
					source: E.CAMERA,
					sid: Math.floor(Math.random() * 1e4).toString(),
					type: bi.AUDIO,
					name: "video-dummy"
				}), new Df(t.useRealTracks && window.navigator.mediaDevices?.getUserMedia ? (yield window.navigator.mediaDevices.getUserMedia({ video: !0 })).getVideoTracks()[0] : Gl(160 * (n.aspectRatios[0] ?? 1), 160, !0, !0), void 0, !1, {
					loggerName: this.options.loggerName,
					loggerContextCb: () => this.logContext
				}), {
					loggerName: this.options.loggerName,
					loggerContextCb: () => this.logContext
				});
				this.localParticipant.addTrackPublication(e), this.localParticipant.emit(L.LocalTrackPublished, e);
			}
			if (t.audio) {
				let e = new Cm(H.Kind.Audio, new Ii({
					source: E.MICROPHONE,
					sid: Math.floor(Math.random() * 1e4).toString(),
					type: bi.AUDIO
				}), new cf(t.useRealTracks && navigator.mediaDevices?.getUserMedia ? (yield navigator.mediaDevices.getUserMedia({ audio: !0 })).getAudioTracks()[0] : ql(), void 0, !1, this.audioContext, {
					loggerName: this.options.loggerName,
					loggerContextCb: () => this.logContext
				}), {
					loggerName: this.options.loggerName,
					loggerContextCb: () => this.logContext
				});
				this.localParticipant.addTrackPublication(e), this.localParticipant.emit(L.LocalTrackPublished, e);
			}
			for (let e = 0; e < n.count - 1; e += 1) {
				let t = new ji({
					sid: Math.floor(Math.random() * 1e4).toString(),
					identity: `simulated-${e}`,
					state: Mi.ACTIVE,
					tracks: [],
					joinedAt: b.parse(Date.now())
				}), r = this.getOrCreateParticipant(t.identity, t);
				if (n.video) {
					let i = Gl(160 * (n.aspectRatios[e % n.aspectRatios.length] ?? 1), 160, !1, !0), a = new Ii({
						source: E.CAMERA,
						sid: Math.floor(Math.random() * 1e4).toString(),
						type: bi.AUDIO
					});
					r.addSubscribedMediaTrack(i, a.sid, new MediaStream([i]), new RTCRtpReceiver()), t.tracks = [...t.tracks, a];
				}
				if (n.audio) {
					let e = ql(), n = new Ii({
						source: E.MICROPHONE,
						sid: Math.floor(Math.random() * 1e4).toString(),
						type: bi.AUDIO
					});
					r.addSubscribedMediaTrack(e, n.sid, new MediaStream([e]), new RTCRtpReceiver()), t.tracks = [...t.tracks, n];
				}
				r.updateInfo(t);
			}
		});
	}
	emit(e) {
		var t = [...arguments].slice(1);
		if (e !== I.ActiveSpeakersChanged && e !== I.TranscriptionReceived) {
			let n = zm(t).filter((e) => e !== void 0);
			(e === I.TrackSubscribed || e === I.TrackUnsubscribed) && this.log.trace(`subscribe trace: ${e}`, {
				event: e,
				args: n
			}), this.log.debug(`room event ${e}`, {
				event: e,
				args: n
			});
		}
		return super.emit(e, ...t);
	}
};
Rm.cleanupRegistry = typeof FinalizationRegistry < "u" && typeof WeakRef < "u" && new FinalizationRegistry((e) => {
	e();
});
function zm(e) {
	return e.map((e) => {
		if (e) return Array.isArray(e) ? zm(e) : typeof e == "object" ? "logContext" in e ? e.logContext : void 0 : e;
	});
}
var Bm;
(function(e) {
	e[e.IDLE = 0] = "IDLE", e[e.RUNNING = 1] = "RUNNING", e[e.SKIPPED = 2] = "SKIPPED", e[e.SUCCESS = 3] = "SUCCESS", e[e.FAILED = 4] = "FAILED";
})(Bm ||= {}), $o.EventEmitter, $o.EventEmitter, new TextEncoder(), new TextDecoder();
var Vm = class extends Error {
	constructor(e, t) {
		var n;
		super(e, t), S(this, "code", "ERR_JOSE_GENERIC"), this.name = this.constructor.name, (n = Error.captureStackTrace) == null || n.call(Error, this, this.constructor);
	}
};
S(Vm, "code", "ERR_JOSE_GENERIC"), S(class extends Vm {
	constructor(e, t) {
		let n = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : "unspecified", r = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : "unspecified";
		super(e, { cause: {
			claim: n,
			reason: r,
			payload: t
		} }), S(this, "code", "ERR_JWT_CLAIM_VALIDATION_FAILED"), S(this, "claim", void 0), S(this, "reason", void 0), S(this, "payload", void 0), this.claim = n, this.reason = r, this.payload = t;
	}
}, "code", "ERR_JWT_CLAIM_VALIDATION_FAILED"), S(class extends Vm {
	constructor(e, t) {
		let n = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : "unspecified", r = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : "unspecified";
		super(e, { cause: {
			claim: n,
			reason: r,
			payload: t
		} }), S(this, "code", "ERR_JWT_EXPIRED"), S(this, "claim", void 0), S(this, "reason", void 0), S(this, "payload", void 0), this.claim = n, this.reason = r, this.payload = t;
	}
}, "code", "ERR_JWT_EXPIRED"), S(class extends Vm {
	constructor() {
		super(...arguments), S(this, "code", "ERR_JOSE_ALG_NOT_ALLOWED");
	}
}, "code", "ERR_JOSE_ALG_NOT_ALLOWED"), S(class extends Vm {
	constructor() {
		super(...arguments), S(this, "code", "ERR_JOSE_NOT_SUPPORTED");
	}
}, "code", "ERR_JOSE_NOT_SUPPORTED"), S(class extends Vm {
	constructor() {
		let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "decryption operation failed", t = arguments.length > 1 ? arguments[1] : void 0;
		super(e, t), S(this, "code", "ERR_JWE_DECRYPTION_FAILED");
	}
}, "code", "ERR_JWE_DECRYPTION_FAILED"), S(class extends Vm {
	constructor() {
		super(...arguments), S(this, "code", "ERR_JWE_INVALID");
	}
}, "code", "ERR_JWE_INVALID"), S(class extends Vm {
	constructor() {
		super(...arguments), S(this, "code", "ERR_JWS_INVALID");
	}
}, "code", "ERR_JWS_INVALID"), S(class extends Vm {
	constructor() {
		super(...arguments), S(this, "code", "ERR_JWT_INVALID");
	}
}, "code", "ERR_JWT_INVALID"), S(class extends Vm {
	constructor() {
		super(...arguments), S(this, "code", "ERR_JWK_INVALID");
	}
}, "code", "ERR_JWK_INVALID"), S(class extends Vm {
	constructor() {
		super(...arguments), S(this, "code", "ERR_JWKS_INVALID");
	}
}, "code", "ERR_JWKS_INVALID"), S(class extends Vm {
	constructor() {
		let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "no applicable key found in the JSON Web Key Set", t = arguments.length > 1 ? arguments[1] : void 0;
		super(e, t), S(this, "code", "ERR_JWKS_NO_MATCHING_KEY");
	}
}, "code", "ERR_JWKS_NO_MATCHING_KEY"), S(class extends Vm {
	constructor() {
		let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "multiple matching keys found in the JSON Web Key Set", t = arguments.length > 1 ? arguments[1] : void 0;
		super(e, t), S(this, Symbol.asyncIterator, void 0), S(this, "code", "ERR_JWKS_MULTIPLE_MATCHING_KEYS");
	}
}, "code", "ERR_JWKS_MULTIPLE_MATCHING_KEYS"), S(class extends Vm {
	constructor() {
		let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "request timed out", t = arguments.length > 1 ? arguments[1] : void 0;
		super(e, t), S(this, "code", "ERR_JWKS_TIMEOUT");
	}
}, "code", "ERR_JWKS_TIMEOUT"), S(class extends Vm {
	constructor() {
		let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "signature verification failed", t = arguments.length > 1 ? arguments[1] : void 0;
		super(e, t), S(this, "code", "ERR_JWS_SIGNATURE_VERIFICATION_FAILED");
	}
}, "code", "ERR_JWS_SIGNATURE_VERIFICATION_FAILED");
//#endregion
//#region src/ui/Menu.ts
var Hm = new m("Menu"), Um = ".livekit-menu-item:not(:disabled), .livekit-menu-custom :is(input, select, button):not(:disabled)", Wm = class {
	label;
	build;
	popover;
	constructor(e, t, n, r) {
		this.label = t, this.build = n, this.popover = new Wt(`livekit-menu ${e}`, r, "menu"), this.popover.element.tabIndex = -1, this.popover.element.addEventListener("keydown", this.onKeyDown);
	}
	get element() {
		return this.popover.element;
	}
	get isOpen() {
		return this.popover.isOpen;
	}
	openAt(e, t = e) {
		this.render(), this.popover.openAt(e, t), this.element.focus({ preventScroll: !0 });
	}
	openAtPoint(e, t, n) {
		this.render(), this.popover.openAtPoint(e, t, n), this.element.focus({ preventScroll: !0 });
	}
	toggle(e, t = e) {
		this.isOpen ? this.close() : this.openAt(e, t);
	}
	close() {
		this.popover.close();
	}
	refresh() {
		if (!this.isOpen) return;
		let e = this.focusableItems().findIndex((e) => e === document.activeElement);
		this.render(), this.popover.reposition(), e >= 0 && this.focusableItems()[e]?.focus({ preventScroll: !0 });
	}
	render() {
		this.element.ariaLabel = this.label(), this.element.replaceChildren(...this.build().map((e) => this.renderItem(e)));
	}
	renderItem(e) {
		switch (e.type) {
			case "header": return h("div", {
				className: "livekit-menu-header",
				text: e.label,
				attrs: { role: "presentation" }
			});
			case "separator": return h("div", {
				className: "livekit-menu-separator",
				attrs: { role: "separator" }
			});
			case "custom": return h("div", {
				className: "livekit-menu-custom",
				children: [e.element]
			});
		}
		let t = h("button", {
			className: "livekit-menu-item",
			attrs: {
				type: "button",
				tabindex: "-1"
			},
			children: [h("span", {
				className: "livekit-menu-item-text",
				children: [h("span", {
					className: "livekit-menu-item-label",
					text: e.label
				}), e.detail && h("span", {
					className: "livekit-menu-item-detail",
					text: e.detail
				})]
			})]
		});
		return t.disabled = !!e.disabled, e.type === "action" ? (t.setAttribute("role", "menuitem"), t.classList.toggle("is-danger", !!e.danger), e.icon && t.append(Tt(e.icon, "livekit-menu-item-icon"))) : (t.setAttribute("role", e.type === "radio" ? "menuitemradio" : "menuitemcheckbox"), t.setAttribute("aria-checked", String(e.checked)), t.classList.toggle("is-checked", e.checked), t.append(h("span", {
			className: `livekit-menu-${e.type}`,
			attrs: { "aria-hidden": "true" },
			children: [e.type === "checkbox" && Tt("fa-check")]
		}))), t.addEventListener("click", (t) => {
			t.preventDefault(), t.stopPropagation();
			let n = e.type !== "action" || !!e.keepOpen;
			n || this.close(), Promise.resolve(e.onSelect()).catch((e) => {
				Hm.error("Error choosing a menu item:", e);
			}).finally(() => {
				n && this.refresh();
			});
		}), t;
	}
	focusableItems() {
		return [...this.element.querySelectorAll(Um)];
	}
	onKeyDown = (e) => {
		let t = this.focusableItems();
		if (!t.length) return;
		let n = document.activeElement;
		if (n instanceof HTMLInputElement && n.type === "range" && (e.key === "Home" || e.key === "End")) return;
		let r = t.findIndex((e) => e === n), i;
		switch (e.key) {
			case "ArrowDown":
				i = r < 0 ? 0 : (r + 1) % t.length;
				break;
			case "ArrowUp":
				i = r < 0 ? t.length - 1 : r - 1, i < 0 && (i = t.length - 1);
				break;
			case "Home":
				i = 0;
				break;
			case "End":
				i = t.length - 1;
				break;
			default: return;
		}
		e.preventDefault(), e.stopPropagation(), t[i].focus({ preventScroll: !0 });
	};
}, Gm = "icons/svg/mystery-man.svg";
function Km({ icon: e, label: t, slashed: n }) {
	return h("span", {
		className: `livekit-badge ${n ? "livekit-slashed" : ""}`.trim(),
		title: t,
		attrs: { role: "img" },
		children: [Tt(e)]
	});
}
var qm = class {
	element;
	image = h("img", {
		className: "livekit-avatar-image",
		attrs: {
			alt: "",
			draggable: "false"
		}
	});
	badges = h("span", { className: "livekit-avatar-badges" });
	constructor({ src: e, size: t = "md", className: n = "" } = {}) {
		this.element = h("span", {
			className: `livekit-avatar livekit-avatar-${t} ${n}`.trim(),
			children: [this.image, this.badges]
		}), this.setSource(e);
	}
	setSource(e) {
		let t = e?.trim() ? e : Gm;
		this.image.getAttribute("src") !== t && this.image.setAttribute("src", t);
	}
	setSpeaking(e) {
		this.element.classList.toggle("is-speaking", e);
	}
	setBadges(e) {
		this.badges.replaceChildren(...e.map((e) => Km(e)));
	}
}, Jm = class {
	userId;
	local;
	element;
	video;
	avatar = new qm({ size: "fill" });
	name = h("span", { className: "livekit-tile-name" });
	secondaryName = h("span", { className: "livekit-tile-secondary" });
	badges = h("span", { className: "livekit-tile-badges" });
	quality = h("span", {
		className: "livekit-quality",
		attrs: { role: "img" },
		children: [
			h("span"),
			h("span"),
			h("span")
		]
	});
	muteButton;
	videoButton;
	constructor(e, t, n) {
		this.userId = e, this.local = t, this.video = h("video", {
			className: `user-camera ${t ? "local-camera" : ""}`.trim(),
			attrs: {
				autoplay: "",
				playsinline: ""
			}
		}), this.video.muted = !0;
		let r = h("div", { className: "livekit-tile-controls" });
		if (t) this.muteButton = Gt({
			icon: "fa-microphone",
			label: g("mute"),
			onClick: () => {
				n.toggleOwnMute();
			}
		}), this.videoButton = Gt({
			icon: "fa-video",
			label: g("cameraOff"),
			onClick: () => {
				n.toggleOwnVideo();
			}
		}), r.append(this.muteButton, this.videoButton);
		else {
			let t = Gt({
				icon: "fa-ellipsis",
				label: g("userOptions"),
				onClick: () => {
					let r = t.getBoundingClientRect();
					n.openMenu(e, r.left, r.bottom, t);
				}
			});
			t.setAttribute("aria-haspopup", "menu"), r.append(t);
		}
		this.element = h("div", {
			className: "livekit-tile",
			attrs: {
				"data-user": e,
				role: "listitem",
				tabindex: "0"
			},
			children: [
				h("div", {
					className: "livekit-tile-media",
					children: [this.video, h("div", {
						className: "livekit-tile-avatar",
						children: [this.avatar.element]
					})]
				}),
				h("div", { className: "livekit-tile-ring" }),
				r,
				h("div", {
					className: "livekit-tile-footer",
					children: [
						h("span", {
							className: "livekit-tile-names",
							children: [this.name, this.secondaryName]
						}),
						this.badges,
						this.quality
					]
				})
			]
		}), this.element.addEventListener("click", (t) => {
			t.target.closest("button") || n.activate(e);
		}), this.element.addEventListener("contextmenu", (t) => {
			t.preventDefault(), t.stopPropagation(), n.openMenu(e, t.clientX, t.clientY, this.element);
		}), this.element.addEventListener("keydown", (t) => {
			if (t.target === this.element) {
				if (t.key === "Enter" || t.key === " ") t.preventDefault(), n.activate(e);
				else if (t.key === "ContextMenu" || t.key === "F10" && t.shiftKey) {
					t.preventDefault();
					let r = this.element.getBoundingClientRect();
					n.openMenu(e, r.left, r.bottom, this.element);
				}
			}
		});
	}
	update(e, t) {
		let { user: n, nameplates: r } = e, i = r.charname ? e.charname : "", a = r.playerName || !i ? n.name : i;
		this.name.textContent = a, this.secondaryName.textContent = r.playerName && i ? i : "", this.element.classList.toggle("no-nameplate", r.hidden), this.element.ariaLabel = n.name, this.avatar.setSource(n.avatar), this.element.classList.toggle("is-video", t.showVideo), this.element.classList.toggle("is-focused", t.focused), this.element.classList.toggle("has-color", t.borderColor), this.element.style.setProperty("--lk-tile-color", Ym(n)), this.setSpeaking(t.speaking);
		let o = [];
		if (t.muted && o.push({
			icon: "fa-microphone-slash",
			label: g("muted")
		}), t.deafened && o.push({
			icon: "fa-headphones",
			label: g("deafened"),
			slashed: !0
		}), t.locallyMuted && o.push({
			icon: "fa-volume-xmark",
			label: g("userLocalMute")
		}), t.videoHiddenByMe ? o.push({
			icon: "fa-eye-slash",
			label: g("videoHiddenByMe")
		}) : e.hasVideo || o.push({
			icon: "fa-video-slash",
			label: g("cameraIsOff")
		}), this.badges.replaceChildren(...o.map((e) => Km(e))), this.quality.dataset.quality = t.quality, wt(this.quality, game.i18n?.localize(`LIVEKITAVCLIENT.connectionQuality.${t.quality}`) ?? t.quality), this.muteButton && Kt(this.muteButton, {
			icon: t.muted ? "fa-microphone-slash" : "fa-microphone",
			label: g(t.muted ? "unmute" : "mute"),
			off: t.muted,
			pressed: t.muted
		}), this.videoButton) {
			let t = !e.hasVideo;
			Kt(this.videoButton, {
				icon: t ? "fa-video-slash" : "fa-video",
				label: g(t ? "cameraOn" : "cameraOff"),
				off: t,
				pressed: t
			});
		}
	}
	setSpeaking(e) {
		this.element.classList.toggle("is-speaking", e), this.avatar.setSpeaking(e);
	}
};
function Ym(e) {
	let t = e.color;
	return t && typeof t == "object" && t.css ? t.css : typeof t == "string" ? t : "transparent";
}
//#endregion
//#region src/ui/dock/drag.ts
var Xm = 8;
function Zm(e) {
	let t = Math.min(e.width, window.innerWidth - 2 * Xm), n = Math.min(e.height, window.innerHeight - 2 * Xm);
	return {
		width: t,
		height: n,
		left: Et(e.left, Xm, window.innerWidth - t - Xm),
		top: Et(e.top, Xm, window.innerHeight - n - Xm)
	};
}
function Qm(e, t, n, r) {
	e.addEventListener("pointerdown", (i) => {
		if (i.button !== 0 || i.target.closest("button, input, select, a")) return;
		i.preventDefault();
		let a = i.clientX, o = i.clientY;
		e.setPointerCapture(i.pointerId), t();
		let s = (e) => {
			n(e.clientX - a, e.clientY - o);
		}, c = () => {
			e.removeEventListener("pointermove", s), e.removeEventListener("pointerup", c), e.removeEventListener("pointercancel", c), r();
		};
		e.addEventListener("pointermove", s), e.addEventListener("pointerup", c), e.addEventListener("pointercancel", c);
	});
}
function $m(e, t, n) {
	let r;
	Qm(e, () => {
		r = t.getBoundingClientRect(), t.classList.add("dragging");
	}, (e, n) => {
		let i = Zm({
			left: r.left + e,
			top: r.top + n,
			width: r.width,
			height: r.height
		});
		t.style.left = `${i.left.toString()}px`, t.style.top = `${i.top.toString()}px`;
	}, () => {
		t.classList.remove("dragging");
		let { left: e, top: r, width: i, height: a } = t.getBoundingClientRect();
		n({
			left: e,
			top: r,
			width: i,
			height: a
		});
	});
}
function eh(e, t, { edges: n, minWidth: r, minHeight: i = 0, keepHeight: a = !1, onEnd: o }) {
	let s, c = [];
	Qm(e, () => {
		s = t.getBoundingClientRect(), c = n(), t.classList.add("resizing");
	}, (e, n) => {
		c.includes("right") && (t.style.width = `${Math.max(s.width + e, r).toString()}px`), c.includes("left") && (t.style.width = `${Math.max(s.width - e, r).toString()}px`), !a && c.includes("bottom") && (t.style.height = `${Math.max(s.height + n, i).toString()}px`), !a && c.includes("top") && (t.style.height = `${Math.max(s.height - n, i).toString()}px`);
	}, () => {
		t.classList.remove("resizing");
		let { left: e, top: n, width: r, height: i } = t.getBoundingClientRect();
		o({
			left: e,
			top: n,
			width: r,
			height: i
		});
	});
}
//#endregion
//#region src/ui/dock/TileWindow.ts
var th = 160, nh = class {
	tile;
	element;
	title = h("span", { className: "livekit-tile-window-title" });
	constructor(e, { left: t, top: n, width: r, onDock: i, onMove: a }) {
		this.tile = e;
		let o = h("header", {
			className: "livekit-tile-window-header",
			children: [this.title, Gt({
				icon: "fa-arrow-right-to-bracket",
				label: g("returnToDock"),
				onClick: i
			})]
		}), s = h("div", {
			className: "livekit-resize-handle",
			attrs: { "aria-hidden": "true" }
		});
		this.element = Ct(h("section", {
			className: "livekit-tile-window",
			attrs: { "data-user": e.userId },
			children: [o, s]
		}));
		let c = () => {
			let e = this.element.getBoundingClientRect();
			a({
				left: Math.round(e.left),
				top: Math.round(e.top),
				width: Math.round(e.width)
			});
		};
		$m(o, this.element, c), eh(s, this.element, {
			edges: () => ["right"],
			minWidth: th,
			keepHeight: !0,
			onEnd: c
		});
		let l = Zm({
			left: t ?? 100,
			top: n ?? 100,
			width: Math.max(r ?? 320, th),
			height: 0
		});
		this.element.style.left = `${l.left.toString()}px`, this.element.style.top = `${l.top.toString()}px`, this.element.style.width = `${l.width.toString()}px`;
	}
	setTitle(e) {
		this.title.textContent = e, this.element.ariaLabel = e;
	}
}, rh = new m("LiveKitCameraViews"), ih = [
	{
		layout: "grid",
		icon: "fa-table-cells-large"
	},
	{
		layout: "focus",
		icon: "fa-expand"
	},
	{
		layout: "compact",
		icon: "fa-list"
	}
], ah = [
	"left",
	"right",
	"top",
	"bottom"
], oh = 160, sh = 640, ch = {
	left: 0,
	top: 0,
	width: 240,
	height: 160
}, lh = 800, uh = foundry.applications.apps.av.CameraViews, dh = class extends uh {
	static DEFAULT_OPTIONS = {
		classes: ["livekit-dock"],
		window: { positioned: !1 }
	};
	tiles = /* @__PURE__ */ new Map();
	windows = /* @__PURE__ */ new Map();
	contexts = /* @__PURE__ */ new Map();
	focusUserId;
	focusPicked = !1;
	followTimer;
	built = !1;
	title = h("span", { className: "livekit-dock-count" });
	stage = h("div", { className: "livekit-dock-stage" });
	list = h("div", {
		className: "livekit-dock-list",
		attrs: { role: "list" }
	});
	resizeHandle = h("div", {
		className: "livekit-resize-handle",
		attrs: { "aria-hidden": "true" }
	});
	layoutButton = Gt({
		icon: "fa-table-cells-large",
		label: g("dockView"),
		onClick: () => {
			this.viewMenu.toggle(this.layoutButton);
		}
	});
	collapseButton = Gt({
		icon: "fa-chevron-left",
		label: g("dockCollapse"),
		onClick: () => {
			this.setCollapsed(!this.collapsed);
		}
	});
	viewMenu = new Wm("livekit-dock-menu", () => g("dockView"), () => this.viewMenuItems());
	get client() {
		return game.webrtc?.client._liveKitClient;
	}
	get layout() {
		let e = game.settings?.get(l, "dockLayout");
		return e === "focus" || e === "compact" ? e : "grid";
	}
	get floatingState() {
		return game.settings?.get("avclient-livekit", "dockFloating") ?? { floating: !1 };
	}
	get isFloating() {
		return this.floatingState.floating;
	}
	get collapsed() {
		return game.webrtc?.settings.client.hideDock === !0;
	}
	get dockPosition() {
		let e = game.webrtc?.settings.client.dockPosition;
		return ah.find((t) => t === e) ?? "left";
	}
	get isVertical() {
		return !this.isFloating && super.isVertical;
	}
	get isHorizontal() {
		return !this.isFloating && super.isHorizontal;
	}
	getUserCameraView(e) {
		return this.tiles.get(e)?.element ?? null;
	}
	getUserVideoElement(e) {
		return this.tiles.get(e)?.video ?? null;
	}
	setUserIsSpeaking() {}
	_configureRenderParts() {
		return {};
	}
	_configureRenderOptions(e) {
		super._configureRenderOptions(e), e.parts = [];
	}
	_renderHTML() {
		return Promise.resolve({});
	}
	_replaceHTML(e, t) {
		this.built || this.build(t), this.sync();
	}
	async _onRender(e, t) {
		await super._onRender(e, t), this.place(), this.attachMedia(), this.client?.voicePanelIfCreated?.reposition();
	}
	async _onFirstRender(e, t) {
		await super._onFirstRender(e, t), window.addEventListener("resize", this.onWindowResize);
	}
	onWindowResize = foundry.utils.debounce(() => {
		this.isFloating && this.place();
		for (let e of this.windows.values()) {
			let t = Zm(e.element.getBoundingClientRect());
			e.element.style.left = `${t.left.toString()}px`, e.element.style.top = `${t.top.toString()}px`;
		}
	}, 100);
	build(e) {
		this.built = !0, Ct(this.element), this.element.setAttribute("role", "region"), this.element.ariaLabel = g("dock");
		let t = h("header", {
			className: "livekit-dock-header",
			children: [h("span", {
				className: "livekit-dock-title",
				children: [Tt("fa-volume-high"), this.title]
			}), h("div", {
				className: "livekit-dock-tools",
				children: [this.layoutButton, this.collapseButton]
			})]
		});
		this.layoutButton.setAttribute("aria-haspopup", "menu"), $m(t, this.element, (e) => {
			this.isFloating && this.saveFloating(e);
		});
		let n = {
			left: "right",
			right: "left",
			top: "bottom",
			bottom: "top"
		};
		eh(this.resizeHandle, this.element, {
			edges: () => this.isFloating ? ["right", "bottom"] : [n[this.dockPosition]],
			minWidth: oh,
			minHeight: ch.height,
			onEnd: (e) => {
				this.onResized(e);
			}
		}), t.addEventListener("pointerdown", (e) => {
			this.isFloating || e.stopImmediatePropagation();
		}, { capture: !0 }), e.replaceChildren(t, h("div", {
			className: "livekit-dock-body",
			children: [this.stage, this.list]
		}), this.resizeHandle);
	}
	sync() {
		let e = this.client, t = game.webrtc?.client;
		if (!e || !t) return;
		let n = t.getConnectedUsers().map((e) => this._prepareUserContext(e)).filter((e) => !!e && !e.settings.blocked).sort((e, t) => uh._sortUsers(e, t));
		this.contexts.clear();
		for (let e of n) this.contexts.set(e.user.id ?? "", e);
		for (let [e, t] of this.tiles) this.contexts.has(e) || this.removeTile(e, t);
		(!this.focusUserId || !this.contexts.has(this.focusUserId)) && (this.focusPicked = !1), this.focusPicked || (this.focusUserId = this.defaultFocus(n));
		let r = new Map([[this.stage, this.stage.firstElementChild], [this.list, this.list.firstElementChild]]);
		for (let e of n) {
			let t = e.user.id ?? "", n = this.tiles.get(t);
			n || (n = new Jm(t, e.local, this.tileHost), this.tiles.set(t, n)), n.update(e, this.tileState(e)), this.placeTile(n, e, r);
		}
		let i = n.length;
		this.title.textContent = game.i18n?.format("LIVEKITAVCLIENT.dockCount", { count: i.toString() }) ?? i.toString(), this.element.dataset.count = i.toString(), this.updateTools();
	}
	refresh() {
		this.rendered && this.built && this.sync();
	}
	setSpeaking(e, t) {
		this.tiles.get(e)?.setSpeaking(t), !(!t || this.layout !== "focus" || !(game.settings?.get("avclient-livekit", "dockFollowSpeaker") ?? !1) || e === game.user?.id || e === this.focusUserId) && (window.clearTimeout(this.followTimer), this.followTimer = window.setTimeout(() => {
			this.client?.isUserSpeaking(e) && this.focus(e);
		}, lh));
	}
	tileState(e) {
		let t = this.client, n = e.user.id ?? "", r = game.settings?.get(l, "userVideoHidden")[n] === !0, i = t?.liveKitParticipants.get(n)?.connectionQuality ?? Om.Unknown;
		return {
			speaking: t?.isUserSpeaking(n) ?? !1,
			muted: t?.isUserMuted(n) ?? !1,
			deafened: t?.voiceControls.isUserDeafened(n) ?? !1,
			locallyMuted: t?.userAudioMixer.isLocallyMuted(n) ?? !1,
			videoHiddenByMe: r,
			showVideo: e.video.show && !r && (t?.isUserVideoOn(n) ?? !1),
			quality: i,
			borderColor: game.webrtc?.settings.client.borderColors === !0,
			focused: this.layout === "focus" && n === this.focusUserId
		};
	}
	defaultFocus(e) {
		let t = e.filter((e) => !e.local);
		return (t.find((e) => e.hasVideo) ?? t.at(0) ?? e.at(0))?.user.id ?? void 0;
	}
	placeTile(e, t, n) {
		let r = e.userId;
		if (t.settings.popout) {
			let n = this.windows.get(r);
			n || (n = new nh(e, {
				left: t.settings.left,
				top: t.settings.top,
				width: t.settings.width,
				onDock: () => {
					this.setPoppedOut(r, !1);
				},
				onMove: (e) => {
					let t = game.webrtc?.settings.client.users[r] ?? {};
					game.webrtc?.settings.set("client", `users.${r}`, {
						...t,
						...e
					});
				}
			}), this.windows.set(r, n), document.body.append(n.element)), n.setTitle(t.user.name), fh(n.element, e, n.element.lastElementChild);
			return;
		}
		this.closeWindow(r);
		let i = this.layout === "focus" && r === this.focusUserId ? this.stage : this.list, a = n.get(i) ?? null;
		a?.parentElement !== i && (a = null), e.element === a ? n.set(i, a.nextElementSibling) : fh(i, e, a);
	}
	removeTile(e, t) {
		this.client?.getUserVideoTrack(e)?.detach(t.video), t.element.remove(), this.tiles.delete(e), this.closeWindow(e);
	}
	closeWindow(e) {
		this.windows.get(e)?.element.remove(), this.windows.delete(e);
	}
	attachMedia() {
		let e = game.webrtc?.client;
		for (let [t, n] of this.tiles) e?.setUserVideo(t, n.video).catch((e) => {
			rh.error("Error setting the video of", t, e);
		});
	}
	place() {
		let e = this.element, t = this.isFloating;
		e.dataset.layout = this.layout, e.dataset.placement = t ? "float" : this.dockPosition, e.classList.toggle("is-floating", t), e.classList.toggle("is-collapsed", this.collapsed), e.classList.toggle("hide-quality", !(game.settings?.get("avclient-livekit", "displayConnectionQuality") ?? !0));
		let n = mh(game.webrtc?.settings.client.dockWidth);
		if (t) {
			let t = this.floatingState, n = Zm({
				left: t.left ?? window.innerWidth - 480,
				top: t.top ?? 80,
				width: Math.max(t.width ?? 400, ch.width),
				height: Math.max(t.height ?? 320, ch.height)
			});
			Object.assign(e.style, {
				left: `${n.left.toString()}px`,
				top: `${n.top.toString()}px`,
				width: `${n.width.toString()}px`,
				height: `${n.height.toString()}px`
			}), e.style.removeProperty("--av-width");
		} else {
			for (let t of [
				"left",
				"top",
				"width",
				"height"
			]) e.style.removeProperty(t);
			e.style.setProperty("--av-width", `${n.toString()}px`);
		}
	}
	updateTools() {
		let e = ih.find((e) => e.layout === this.layout);
		Kt(this.layoutButton, { icon: e?.icon ?? "fa-table-cells-large" });
		let t = this.collapsed, [n, r] = this.isFloating ? ["up", "down"] : {
			left: ["left", "right"],
			right: ["right", "left"],
			top: ["up", "down"],
			bottom: ["down", "up"]
		}[this.dockPosition];
		Kt(this.collapseButton, {
			icon: `fa-chevron-${t ? r : n}`,
			label: g(t ? "dockExpand" : "dockCollapse"),
			pressed: t
		});
	}
	tileHost = {
		activate: (e) => {
			this.layout !== "compact" && this.focus(e);
		},
		openMenu: (e, t, n, r) => {
			this.client?.userMenu.open(e, t, n, r);
		},
		toggleOwnMute: () => {
			this.client?.voiceControls.toggleMute();
		},
		toggleOwnVideo: () => {
			let e = this.tiles.get(game.user?.id ?? "");
			e && this._onToggleVideo(new Event("click"), e.element).catch((e) => {
				rh.error("Error toggling the camera:", e);
			});
		}
	};
	focus(e) {
		this.focusUserId = e, this.focusPicked = !0, this.layout === "focus" ? this.refresh() : this.setLayout("focus");
	}
	async setLayout(e) {
		await game.settings?.set(l, "dockLayout", e), await this.render();
	}
	async setPlacement(e) {
		e === "float" ? await this.saveFloating({
			...this.floatingState,
			floating: !0
		}) : (await game.settings?.set(l, "dockFloating", {
			...this.floatingState,
			floating: !1
		}), game.webrtc?.settings.set("client", "dockPosition", e)), await this.render(), ph();
	}
	async setCollapsed(e) {
		game.webrtc?.settings.set("client", "hideDock", e), await this.render(), ph();
	}
	async setPoppedOut(e, t) {
		game.webrtc?.settings.set("client", `users.${e}.popout`, t), await this.render();
	}
	isPoppedOut(e) {
		return this.windows.has(e);
	}
	async pictureInPicture(e) {
		let t = this.tiles.get(e)?.video;
		t && document.pictureInPictureEnabled && await t.requestPictureInPicture();
	}
	canPictureInPicture(e) {
		let t = this.tiles.get(e);
		return document.pictureInPictureEnabled && !!t?.video.srcObject && t.element.classList.contains("is-video");
	}
	async saveFloating(e) {
		await game.settings?.set(l, "dockFloating", {
			...this.floatingState,
			...e,
			floating: e.floating ?? this.floatingState.floating
		});
	}
	onResized(e) {
		if (this.isFloating) {
			this.saveFloating(e);
			return;
		}
		let t = this.isHorizontal ? e.height * 4 / 3 : e.width;
		game.webrtc?.settings.set("client", "dockWidth", mh(t)), this.render();
	}
	viewMenuItems() {
		let e = this.layout, t = this.isFloating ? "float" : this.dockPosition;
		return [
			{
				type: "header",
				label: g("dockLayoutTitle")
			},
			...ih.map((t) => ({
				type: "radio",
				label: g(`dockLayout.${t.layout}`),
				checked: e === t.layout,
				onSelect: () => this.setLayout(t.layout)
			})),
			{
				type: "checkbox",
				label: g("dockFollowSpeaker"),
				detail: g("dockFollowSpeakerHint"),
				checked: game.settings?.get("avclient-livekit", "dockFollowSpeaker") ?? !1,
				onSelect: () => game.settings?.set(l, "dockFollowSpeaker", !(game.settings.get("avclient-livekit", "dockFollowSpeaker") ?? !1))
			},
			{ type: "separator" },
			{
				type: "header",
				label: g("clientSetting.dockPosition")
			},
			...[...ah, "float"].map((e) => ({
				type: "radio",
				label: g(e === "float" ? "dockFloating" : `dockPosition.${e}`),
				checked: t === e,
				onSelect: () => this.setPlacement(e)
			}))
		];
	}
};
function fh(e, t, n) {
	let r = t.element;
	if (n?.parentElement !== e && (n = null), "moveBefore" in e && r.isConnected && e.isConnected) try {
		e.moveBefore(r, n);
		return;
	} catch {}
	e.insertBefore(r, n), t.video.srcObject && t.video.play().catch(() => void 0);
}
function ph() {
	ui.hotbar?._onResize?.();
}
function mh(e) {
	return Math.round(Math.min(Math.max(e ?? 240, oh), sh));
}
//#endregion
//#region src/utils/registerModuleSettings.ts
var hh = new m();
function gh() {
	game.settings?.register(l, "displayConnectionQuality", {
		name: "LIVEKITAVCLIENT.displayConnectionQuality",
		hint: "LIVEKITAVCLIENT.displayConnectionQualityHint",
		scope: "client",
		config: !1,
		default: !0,
		type: new foundry.data.fields.BooleanField({ initial: !0 }),
		onChange: () => game.webrtc?.render()
	}), game.settings?.register(l, "discordStyleUI", {
		name: "LIVEKITAVCLIENT.discordStyleUI",
		hint: "LIVEKITAVCLIENT.discordStyleUIHint",
		scope: "client",
		config: !1,
		default: !0,
		type: new foundry.data.fields.BooleanField({ initial: !0 }),
		requiresReload: !0,
		onChange: () => {
			game.webrtc?.client._liveKitClient.applyDiscordStyle();
		}
	}), game.settings?.register(l, "allowDiscordStyleUI", {
		name: "LIVEKITAVCLIENT.allowDiscordStyleUI",
		hint: "LIVEKITAVCLIENT.allowDiscordStyleUIHint",
		scope: "world",
		config: !1,
		default: !0,
		type: new foundry.data.fields.BooleanField({ initial: !0 }),
		requiresReload: !0,
		onChange: () => {
			game.webrtc?.client._liveKitClient.applyDiscordStyle();
		}
	}), game.settings?.register(l, "allowKrisp", {
		name: "LIVEKITAVCLIENT.allowKrisp",
		hint: "LIVEKITAVCLIENT.allowKrispHint",
		scope: "world",
		config: !1,
		default: !0,
		type: new foundry.data.fields.BooleanField({ initial: !0 }),
		onChange: () => {
			game.webrtc?.client._liveKitClient.scheduleAudioProcessingRefresh();
		}
	}), game.settings?.register(l, "defaultNoiseModel", {
		name: "LIVEKITAVCLIENT.defaultNoiseModel",
		hint: "LIVEKITAVCLIENT.defaultNoiseModelHint",
		scope: "world",
		config: !1,
		default: "gtcrn",
		type: new foundry.data.fields.StringField({
			required: !0,
			blank: !1,
			initial: "gtcrn",
			choices: {
				none: "LIVEKITAVCLIENT.noiseSuppressionModelNone",
				speex: "LIVEKITAVCLIENT.noiseSuppressionModelSpeex",
				rnnoise: "LIVEKITAVCLIENT.noiseSuppressionModelRnnoise",
				gtcrn: "LIVEKITAVCLIENT.noiseSuppressionModelGtcrn",
				krisp: "LIVEKITAVCLIENT.noiseSuppressionModelKrisp"
			}
		}),
		onChange: () => {
			game.webrtc?.client._liveKitClient.scheduleAudioProcessingRefresh();
		}
	}), game.settings?.register(l, "voicePanelPosition", {
		scope: "client",
		config: !1,
		default: null
	}), game.settings?.register(l, "dockLayout", {
		scope: "client",
		config: !1,
		default: "grid",
		type: new foundry.data.fields.StringField({
			required: !0,
			blank: !1,
			initial: "grid",
			choices: {
				grid: "grid",
				focus: "focus",
				compact: "compact"
			}
		}),
		onChange: () => {
			game.webrtc?.client._liveKitClient.dock?.render();
		}
	}), game.settings?.register(l, "dockFloating", {
		scope: "client",
		config: !1,
		default: { floating: !1 },
		onChange: () => {
			game.webrtc?.client._liveKitClient.dock?.render();
		}
	}), game.settings?.register(l, "dockFollowSpeaker", {
		scope: "client",
		config: !1,
		default: !1,
		type: new foundry.data.fields.BooleanField({ initial: !1 }),
		onChange: () => {
			game.webrtc?.client._liveKitClient.dock?.render();
		}
	}), game.settings?.register(l, "userVideoHidden", {
		scope: "client",
		config: !1,
		default: {}
	}), game.settings?.register(l, "userVolumes", {
		scope: "client",
		config: !1,
		default: {}
	}), game.settings?.register(l, "userLocalMutes", {
		scope: "client",
		config: !1,
		default: {}
	}), game.settings?.register(l, "mutedByDeafen", {
		scope: "client",
		config: !1,
		default: !1,
		type: new foundry.data.fields.BooleanField({ initial: !1 })
	}), game.settings?.register(l, "liveKitConnectionSettings", {
		name: "LIVEKITAVCLIENT.liveKitConnectionSettings",
		hint: "LIVEKITAVCLIENT.liveKitConnectionSettingsHint",
		scope: "world",
		config: !1,
		default: {},
		requiresReload: !0
	}), game.settings?.register(l, "tavernPatreonToken", {
		name: "LIVEKITAVCLIENT.tavernPatreonToken",
		hint: "LIVEKITAVCLIENT.tavernPatreonTokenHint",
		scope: "world",
		config: !1,
		default: "",
		type: new foundry.data.fields.StringField({
			required: !1,
			blank: !0,
			initial: ""
		}),
		requiresReload: !0
	}), game.settings?.register(l, "breakoutRoomRegistry", {
		name: "LIVEKITAVCLIENT.breakoutRoomRegistry",
		hint: "LIVEKITAVCLIENT.breakoutRoomRegistryHint",
		scope: "client",
		config: !1,
		default: {},
		requiresReload: !1
	}), game.settings?.register(l, "audioMusicMode", {
		name: "LIVEKITAVCLIENT.audioMusicMode",
		hint: "LIVEKITAVCLIENT.audioMusicModeHint",
		scope: "client",
		config: !1,
		default: !1,
		type: new foundry.data.fields.BooleanField({ initial: !1 }),
		onChange: () => {
			game.webrtc?.client._liveKitClient.scheduleAudioSourceChange();
		}
	}), game.settings?.register(l, "enhancedNoiseCancellation", {
		name: "LIVEKITAVCLIENT.enhancedNoiseCancellation",
		hint: "LIVEKITAVCLIENT.enhancedNoiseCancellationHint",
		scope: "client",
		config: !1,
		default: !0,
		type: new foundry.data.fields.BooleanField({ initial: !0 }),
		onChange: () => {
			game.webrtc?.client._liveKitClient.scheduleAudioProcessingRefresh();
		}
	}), game.settings?.register(l, "noiseSuppressionModel", {
		name: "LIVEKITAVCLIENT.noiseSuppressionModel",
		hint: "LIVEKITAVCLIENT.noiseSuppressionModelHint",
		scope: "client",
		config: !1,
		default: "gtcrn",
		type: new foundry.data.fields.StringField({
			required: !0,
			blank: !1,
			initial: "gtcrn",
			choices: {
				rnnoise: "LIVEKITAVCLIENT.noiseSuppressionModelRnnoise",
				speex: "LIVEKITAVCLIENT.noiseSuppressionModelSpeex",
				gtcrn: "LIVEKITAVCLIENT.noiseSuppressionModelGtcrn",
				krisp: "LIVEKITAVCLIENT.noiseSuppressionModelKrisp"
			}
		}),
		onChange: () => {
			game.webrtc?.client._liveKitClient.scheduleAudioProcessingRefresh();
		}
	}), game.settings?.register(l, "audioQualityPreset", {
		name: "LIVEKITAVCLIENT.audioQualityPreset",
		hint: "LIVEKITAVCLIENT.audioQualityPresetHint",
		scope: "client",
		config: !1,
		default: "speech",
		type: new foundry.data.fields.StringField({
			required: !0,
			blank: !1,
			initial: "speech",
			choices: {
				telephone: "LIVEKITAVCLIENT.audioQualityPresetTelephone",
				speech: "LIVEKITAVCLIENT.audioQualityPresetSpeech",
				music: "LIVEKITAVCLIENT.audioQualityPresetMusic",
				musicStereo: "LIVEKITAVCLIENT.audioQualityPresetMusicStereo",
				musicHighQuality: "LIVEKITAVCLIENT.audioQualityPresetMusicHighQuality",
				musicHighQualityStereo: "LIVEKITAVCLIENT.audioQualityPresetMusicHighQualityStereo"
			}
		}),
		onChange: () => {
			game.webrtc?.client._liveKitClient.scheduleAudioSourceChange();
		}
	}), game.settings?.register(l, "audioAutoGainControl", {
		name: "LIVEKITAVCLIENT.audioAutoGainControl",
		hint: "LIVEKITAVCLIENT.audioAutoGainControlHint",
		scope: "client",
		config: !1,
		default: !0,
		type: new foundry.data.fields.BooleanField({ initial: !0 }),
		onChange: () => {
			game.webrtc?.client._liveKitClient.scheduleAudioProcessingRefresh();
		}
	}), game.settings?.register(l, "audioEchoCancellation", {
		name: "LIVEKITAVCLIENT.audioEchoCancellation",
		hint: "LIVEKITAVCLIENT.audioEchoCancellationHint",
		scope: "client",
		config: !1,
		default: !0,
		type: new foundry.data.fields.BooleanField({ initial: !0 }),
		onChange: () => {
			game.webrtc?.client._liveKitClient.scheduleAudioProcessingRefresh();
		}
	}), game.settings?.register(l, "audioNoiseSuppression", {
		name: "LIVEKITAVCLIENT.audioNoiseSuppression",
		hint: "LIVEKITAVCLIENT.audioNoiseSuppressionHint",
		scope: "client",
		config: !1,
		default: !0,
		type: new foundry.data.fields.BooleanField({ initial: !0 }),
		onChange: () => {
			game.webrtc?.client._liveKitClient.scheduleAudioProcessingRefresh();
		}
	}), game.settings?.register(l, "audioAutoSensitivity", {
		name: "LIVEKITAVCLIENT.audioAutoSensitivity",
		scope: "client",
		config: !1,
		default: !0,
		type: new foundry.data.fields.BooleanField({ initial: !0 }),
		onChange: () => {
			game.webrtc?.client._liveKitClient.applyVoiceGateSettings();
		}
	}), game.settings?.register(l, "audioNoiseGateThreshold", {
		name: "LIVEKITAVCLIENT.audioNoiseGateThreshold",
		hint: "LIVEKITAVCLIENT.audioNoiseGateThresholdHint",
		scope: "client",
		config: !1,
		default: -50,
		type: new foundry.data.fields.NumberField({
			required: !0,
			nullable: !1,
			min: -80,
			max: 0,
			step: 1,
			initial: -50
		}),
		onChange: () => {
			game.webrtc?.client._liveKitClient.applyVoiceGateSettings();
		}
	}), game.settings?.register(l, "useExternalAV", {
		name: "LIVEKITAVCLIENT.useExternalAV",
		hint: "LIVEKITAVCLIENT.useExternalAVHint",
		scope: "client",
		config: !1,
		default: !1,
		type: new foundry.data.fields.BooleanField({ initial: !1 }),
		requiresReload: !0
	}), game.settings?.register(l, "resetRoom", {
		name: "LIVEKITAVCLIENT.resetRoom",
		hint: "LIVEKITAVCLIENT.resetRoomHint",
		scope: "world",
		config: !1,
		default: !1,
		type: new foundry.data.fields.BooleanField({ initial: !1 }),
		onChange: (e) => {
			e && game.user?.isGM && (hh.warn("Resetting meeting room ID"), game.settings.set(l, "resetRoom", !1).then(() => {
				let e = game.settings.get(l, "liveKitConnectionSettings");
				e.room = foundry.utils.randomID(32), game.settings.set(l, "liveKitConnectionSettings", e).catch((e) => {
					hh.error("Error setting liveKitConnectionSettings:", e);
				});
			}).catch((e) => {
				hh.error("Error resetting meeting room ID", e);
			}));
		},
		requiresReload: !0
	}), game.settings?.register(l, "debug", {
		name: "LIVEKITAVCLIENT.debug",
		hint: "LIVEKITAVCLIENT.debugHint",
		scope: "world",
		config: !1,
		default: !1,
		type: new foundry.data.fields.BooleanField({ initial: !1 }),
		requiresReload: !0
	}), game.settings?.register(l, "liveKitTrace", {
		name: "LIVEKITAVCLIENT.liveKitTrace",
		hint: "LIVEKITAVCLIENT.liveKitTraceHint",
		scope: "world",
		config: !1,
		default: !1,
		type: new foundry.data.fields.BooleanField({ initial: !1 }),
		requiresReload: !0
	}), game.settings?.register(l, "devMode", {
		name: "LIVEKITAVCLIENT.devMode",
		hint: "LIVEKITAVCLIENT.devModeHint",
		scope: "world",
		config: !1,
		default: !1,
		type: new foundry.data.fields.BooleanField({ initial: !1 }),
		requiresReload: !0
	}), game.settings?.register(l, "authServer", {
		name: "LIVEKITAVCLIENT.authServer",
		hint: "LIVEKITAVCLIENT.authServerHint",
		scope: "world",
		config: !1,
		default: d,
		type: new foundry.data.fields.StringField({
			required: !0,
			blank: !1,
			initial: d
		}),
		requiresReload: !0
	}), game.settings?.register(l, "forceTurn", {
		name: "LIVEKITAVCLIENT.forceTurn",
		hint: "LIVEKITAVCLIENT.forceTurnHint",
		scope: "world",
		config: !1,
		default: !1,
		type: new foundry.data.fields.BooleanField({ initial: !1 }),
		requiresReload: !0
	}), game.settings?.get("avclient-livekit", "debug") ? (game.settings.get("avclient-livekit", "liveKitTrace") ? (p.default.enable("*"), hh.info("Enabling trace logging")) : (p.default.enable(`${l}:DEBUG,${l}:DEBUG:*,${l}:INFO,${l}:INFO:*,${l}:WARN,${l}:WARN:*,${l}:ERROR,${l}:ERROR:*`), hh.info("Enabling debug logging")), CONFIG.debug.av = !0, CONFIG.debug.avclient = !0) : (p.default.enable(`${l}:INFO,${l}:INFO:*,${l}:WARN,${l}:WARN:*,${l}:ERROR,${l}:ERROR:*`), CONFIG.debug.av = !1, CONFIG.debug.avclient = !1);
}
Hooks.on("init", () => {
	foundry.av.AVSettings.VOICE_MODES = {
		ALWAYS: "always",
		PTT: "ptt"
	}, gh(), (game.settings?.get("avclient-livekit", "allowDiscordStyleUI") ?? !0) && (game.settings?.get("avclient-livekit", "discordStyleUI") ?? !0) && !(game.settings?.get("avclient-livekit", "useExternalAV") ?? !1) && (CONFIG.ui.webrtc = dh), game.settings?.registerMenu(l, "avSettings", {
		name: "LIVEKITAVCLIENT.settingsMenu",
		label: "LIVEKITAVCLIENT.settingsMenuLabel",
		hint: "LIVEKITAVCLIENT.settingsMenuHint",
		icon: "fa-solid fa-headset",
		type: ln,
		restricted: !1
	}), Hooks.on("renderCameraViews", (e, t) => {
		game.webrtc?.client._liveKitClient && game.webrtc.client._liveKitClient.onRenderCameraViews(e, t);
	});
}), Hooks.on("ready", () => {
	game.socket?.on(`module.${l}`, (e, t) => {
		game.webrtc?.client._liveKitClient && game.webrtc.client._liveKitClient.onSocketEvent(e, t);
	}), game.settings?.registerMenu("core", "webrtc", {
		name: "WEBRTC.Title",
		label: "WEBRTC.MenuLabel",
		hint: "WEBRTC.MenuHint",
		icon: "fas fa-headset",
		type: ln,
		restricted: !1
	});
}), Hooks.on("getUserContextOptions", (e, t) => {
	game.webrtc?.client && game.webrtc.client._liveKitClient.onGetUserContextOptions(e, t);
}), AudioWorkletNode;
var _h = async (e, t) => await (await fetch(e, t)).arrayBuffer(), vh = async ({ url: e }, t) => await _h(e, t), yh = "@sapphi-red/web-noise-suppressor/gtcrn", bh = class extends AudioWorkletNode {
	constructor(e, { maxChannels: t, wasmBinary: n }) {
		super(e, yh, { processorOptions: {
			maxChannels: t,
			wasmBinary: n
		} });
	}
	destroy() {
		this.port.postMessage("destroy");
	}
}, xh = async () => WebAssembly.validate(new Uint8Array([
	0,
	97,
	115,
	109,
	1,
	0,
	0,
	0,
	1,
	5,
	1,
	96,
	0,
	1,
	123,
	3,
	2,
	1,
	0,
	10,
	10,
	1,
	8,
	0,
	65,
	0,
	253,
	15,
	253,
	98,
	11
])), Sh = async ({ url: e, simdUrl: t }, n) => await _h(await xh() ? t : e, n), Ch = "@sapphi-red/web-noise-suppressor/rnnoise", wh = class extends AudioWorkletNode {
	constructor(e, { maxChannels: t, wasmBinary: n }) {
		super(e, Ch, { processorOptions: {
			maxChannels: t,
			wasmBinary: n
		} });
	}
	destroy() {
		this.port.postMessage("destroy");
	}
}, Th = async ({ url: e }, t) => await _h(e, t), Eh = "@sapphi-red/web-noise-suppressor/speex", Dh = class extends AudioWorkletNode {
	constructor(e, { maxChannels: t, wasmBinary: n }) {
		super(e, Eh, { processorOptions: {
			maxChannels: t,
			wasmBinary: n
		} });
	}
	destroy() {
		this.port.postMessage("destroy");
	}
}, Oh = new m("NoiseSuppressorFilter"), kh = 48e3, Ah = [
	"rnnoise",
	"speex",
	"gtcrn"
], jh = "gtcrn";
function Mh() {
	return typeof AudioWorkletNode < "u" && typeof AudioContext < "u" && typeof WebAssembly < "u";
}
function Nh(e) {
	return e === "krisp" || Ah.includes(e) ? e : jh;
}
async function Ph(e, t) {
	let n = await t;
	if (!WebAssembly.validate(n)) throw Error(`Failed to load a valid WASM binary for ${e}`);
	return n;
}
var Fh = class {
	name;
	processedTrack;
	gate;
	model;
	gateOptions;
	audioContext;
	sourceNode;
	workletNode;
	destinationNode;
	constructor({ model: e, gate: t }) {
		this.model = e, this.gateOptions = t, this.name = `noise-suppressor-${e ?? "none"}${t ? "-gate" : ""}`;
	}
	async init(e) {
		this.audioContext = e.audioContext;
		try {
			await this.buildGraph(this.audioContext, e.track);
		} catch (e) {
			throw await this.destroy(), e;
		}
		Oh.info(`Noise suppression filter initialized (${this.name})`);
	}
	async buildGraph(e, t) {
		this.model && (this.workletNode = await this.createWorkletNode(e, this.model)), this.gateOptions && (this.gate = await Zt.create(e, this.gateOptions)), this.destinationNode = e.createMediaStreamDestination();
		let n = this.destinationNode;
		for (let e of [this.gate?.node, this.workletNode].filter((e) => e !== void 0)) e.connect(n), n = e;
		this.connectSource(e, t, n), this.processedTrack = this.destinationNode.stream.getAudioTracks()[0];
	}
	connectSource(e, t, n) {
		this.sourceNode?.disconnect(), this.sourceNode = e.createMediaStreamSource(new MediaStream([t])), this.sourceNode.connect(n);
	}
	async createWorkletNode(e, t) {
		switch (t) {
			case "speex": {
				let n = await Ph(t, Th({ url: ie("speex/speex.wasm") }));
				return await e.audioWorklet.addModule(ie("speex/speexWorklet.js")), new Dh(e, {
					wasmBinary: n,
					maxChannels: 1
				});
			}
			case "gtcrn": {
				let n = await Ph(t, vh({ url: ie("gtcrn/gtcrn.wasm") }));
				return await e.audioWorklet.addModule(ie("gtcrn/gtcrnWorklet.js")), new bh(e, {
					wasmBinary: n,
					maxChannels: 1
				});
			}
			case "rnnoise": {
				let n = await Ph(t, Sh({
					url: ie("rnnoise/rnnoise.wasm"),
					simdUrl: ie("rnnoise/rnnoise_simd.wasm")
				}));
				return await e.audioWorklet.addModule(ie("rnnoise/rnnoiseWorklet.js")), new wh(e, {
					wasmBinary: n,
					maxChannels: 1
				});
			}
		}
	}
	async restart(e) {
		let t = this.workletNode ?? this.gate?.node;
		if (this.audioContext && t && this.processedTrack) {
			this.connectSource(this.audioContext, e.track, t);
			return;
		}
		let n = e.audioContext ?? this.audioContext;
		await this.destroy(), await this.init({
			...e,
			audioContext: n
		});
	}
	destroy() {
		try {
			this.sourceNode?.disconnect(), this.gate?.destroy(), this.workletNode?.disconnect(), this.workletNode?.destroy(), this.destinationNode?.disconnect();
		} catch (e) {
			Oh.warn("Error while destroying noise suppression filter:", e);
		} finally {
			this.sourceNode = void 0, this.gate = void 0, this.workletNode = void 0, this.destinationNode = void 0, this.audioContext = void 0, this.processedTrack = void 0;
		}
		return Promise.resolve();
	}
}, Ih = new m("KrispNoiseFilter"), Lh = 1, Rh;
function zh() {
	return Rh ??= import("./krisp-noise-filter-C7yITSEN.js").catch((e) => {
		throw Rh = void 0, e;
	}), Rh;
}
async function Bh() {
	try {
		let { isKrispNoiseFilterSupported: e } = await zh();
		return e();
	} catch (e) {
		return Ih.warn("Unable to load the Krisp noise filter:", e), !1;
	}
}
var Vh = ["enable-lk-krisp-noise-filter", "disable-lk-krisp-noise-filter"], Hh = class {
	krisp;
	gateOptions;
	name;
	gate;
	audioContext;
	sourceNode;
	destinationNode;
	krispTrack;
	constructor(e, t) {
		this.krisp = e, this.gateOptions = t, this.name = `${e.name}${t ? "-gate" : ""}`;
	}
	get processedTrack() {
		return this.gateOptions ? this.destinationNode?.stream.getAudioTracks()[0] : this.krisp.processedTrack;
	}
	forwardEvent = (e) => {
		this.processedTrack?.dispatchEvent(new Event(e.type));
	};
	async init(e) {
		this.audioContext = e.audioContext;
		try {
			await this.krisp.init(e), this.gateOptions && (this.gate = await Zt.create(e.audioContext, this.gateOptions), this.destinationNode = e.audioContext.createMediaStreamDestination(), this.gate.node.connect(this.destinationNode), this.connectKrispOutput());
		} catch (e) {
			throw await this.destroy(), e;
		}
	}
	async restart(e) {
		let t = this.krisp.isEnabled();
		await this.krisp.restart(e), this.gateOptions && this.connectKrispOutput(), t && await this.krisp.setEnabled(!0);
	}
	connectKrispOutput() {
		let e = this.krisp.processedTrack;
		if (!e || !this.audioContext || !this.gate) throw Error("The Krisp noise filter has no output");
		for (let t of Vh) this.krispTrack?.removeEventListener(t, this.forwardEvent), e.addEventListener(t, this.forwardEvent);
		this.krispTrack = e, this.sourceNode?.disconnect(), this.sourceNode = this.audioContext.createMediaStreamSource(new MediaStream([e])), this.sourceNode.connect(this.gate.node);
	}
	onPublish(e) {
		return this.krisp.onPublish(e);
	}
	setEnabled(e) {
		return this.krisp.setEnabled(e);
	}
	isEnabled() {
		return this.krisp.isEnabled();
	}
	async destroy() {
		for (let e of Vh) this.krispTrack?.removeEventListener(e, this.forwardEvent);
		this.sourceNode?.disconnect(), this.gate?.destroy(), this.destinationNode?.disconnect(), this.sourceNode = void 0, this.gate = void 0, this.destinationNode = void 0, this.krispTrack = void 0, await this.krisp.destroy();
	}
};
async function Uh(e) {
	let { KrispNoiseFilter: t } = await zh();
	return new Hh(t(), e);
}
function Wh(e, t) {
	if (e?.state !== X.Connected) return !1;
	if (Number(e.serverInfo?.edition) === Lh) return !0;
	if (!t) return !1;
	try {
		let { hostname: e } = new URL(`wss://${t}`);
		return e.endsWith(".livekit.cloud") || e.endsWith(".livekit.run");
	} catch {
		return !1;
	}
}
//#endregion
//#region src/LiveKitBreakout.ts
var Gh = new m("LiveKitBreakout");
function Kh(e) {
	return (game.settings?.get("avclient-livekit", "breakoutRoomRegistry") ?? {})[e];
}
async function qh(e, t) {
	let n = game.settings?.get("avclient-livekit", "breakoutRoomRegistry") ?? {};
	n[e] = t, await game.settings?.set(l, "breakoutRoomRegistry", n);
}
function Jh(e, t) {
	let n = game.user?.isGM === !0, r = e === game.user?.id, i = Kh(e), a = (e) => game.i18n?.localize(`LIVEKITAVCLIENT.${e}`) ?? e;
	return [
		n && !r && !i && {
			label: a("startAVBreakout"),
			icon: "fa-comment",
			run: () => {
				let n = foundry.utils.randomID(32);
				Zh(e, n), Xh(n, t);
			}
		},
		n && !r && !!i && t.breakoutRoom !== i && {
			label: a("joinAVBreakout"),
			icon: "fa-comment-dots",
			run: () => {
				Xh(i, t);
			}
		},
		n && !r && !!t.breakoutRoom && i !== t.breakoutRoom && {
			label: a("pullToAVBreakout"),
			icon: "fa-comments",
			run: () => {
				Zh(e, t.breakoutRoom);
			}
		},
		r && !!t.breakoutRoom && {
			label: a("leaveAVBreakout"),
			icon: "fa-comment-slash",
			run: () => {
				Xh(void 0, t);
			}
		},
		n && !r && !!i && {
			label: a("removeFromAVBreakout"),
			icon: "fa-comment-slash",
			run: () => {
				Qh(e);
			}
		},
		n && r && {
			label: a("endAllAVBreakouts"),
			icon: "fa-ban",
			run: () => {
				$h(t);
			}
		}
	].filter((e) => e !== !1);
}
function Yh(e, t) {
	let n = (e, n) => Jh(e.dataset.userId ?? "", t).find((e) => e.label === n);
	for (let [t, r] of [
		["startAVBreakout", "fa-comment"],
		["joinAVBreakout", "fa-comment-dots"],
		["pullToAVBreakout", "fa-comments"],
		["leaveAVBreakout", "fa-comment-slash"],
		["removeFromAVBreakout", "fa-comment-slash"],
		["endAllAVBreakouts", "fa-ban"]
	]) {
		let i = game.i18n?.localize(`LIVEKITAVCLIENT.${t}`) ?? t;
		e.push({
			name: i,
			icon: `<i class="fa-solid ${r}"></i>`,
			condition: (e) => !!n(e, i),
			callback: (e) => {
				n(e, i)?.run();
			}
		});
	}
}
function Xh(e, t) {
	e !== t.breakoutRoom && (e ? ui.notifications?.info(game.i18n?.localize("LIVEKITAVCLIENT.joiningAVBreakout") ?? "joiningAVBreakout") : ui.notifications?.info(game.i18n?.localize("LIVEKITAVCLIENT.leavingAVBreakout") ?? "leavingAVBreakout"), Gh.debug("Switching to breakout room:", e), t.breakoutRoom = e, game.webrtc?.connect().catch(() => {
		Gh.error("Failed to connect to breakout room"), t.breakoutRoom = void 0, ui.notifications?.error(game.i18n.localize(`${u}.failedToJoinAVBreakout`));
	}));
}
function Zh(e, t) {
	if (!game.user?.isGM) {
		Gh.warn("Only a GM can start a breakout conference room");
		return;
	}
	qh(e, t).catch((e) => {
		Gh.error("Error setting breakout room:", e);
	}), game.socket.emit(`module.${l}`, {
		action: "breakout",
		userId: e,
		breakoutRoom: t
	}, { recipients: [e] });
}
function Qh(e) {
	if (!game.user?.isGM) {
		Gh.warn("Only a GM can end a user's breakout conference");
		return;
	}
	qh(e, void 0).catch((e) => {
		Gh.error("Error clearing breakout room:", e);
	}), game.socket.emit(`module.${l}`, {
		action: "breakout",
		userId: e,
		breakoutRoom: void 0
	}, { recipients: [e] });
}
function $h(e) {
	if (!game.user?.isGM) {
		Gh.warn("Only a GM can end all breakout conference rooms");
		return;
	}
	game.socket.emit(`module.${l}`, {
		action: "breakout",
		userId: void 0,
		breakoutRoom: void 0
	}), e.breakoutRoom && Xh(void 0, e);
}
//#endregion
//#region src/VoiceControls.ts
var eg = new m("VoiceControls"), tg = class {
	client;
	remoteDeafened = /* @__PURE__ */ new Set();
	constructor(e) {
		this.client = e;
	}
	get userId() {
		return game.user?.id ?? "";
	}
	isMuted() {
		return this.client.settings.getUser(this.userId)?.muted === !0;
	}
	isDeafened() {
		return this.client.settings.get("client", "muteAll") === !0;
	}
	isUserDeafened(e) {
		return e === this.userId ? this.isDeafened() : this.remoteDeafened.has(e);
	}
	toggleMute() {
		let e = !this.isMuted();
		!e && this.isDeafened() && this.setDeafenedSetting(!1), this.setMuted(e), this.setMutedByDeafen(!1), this.client.onVoiceStateChanged();
	}
	toggleDeafen() {
		let e = !this.isDeafened();
		e && !this.isMuted() ? (this.setMuted(!0), this.setMutedByDeafen(!0)) : !e && this.wasMutedByDeafen() && (this.setMuted(!1), this.setMutedByDeafen(!1)), this.setDeafenedSetting(e), this.client.onVoiceStateChanged();
	}
	broadcastDeafened() {
		game.socket?.emit(`module.${l}`, {
			action: "deafen",
			deafened: this.isDeafened()
		});
	}
	onRemoteDeafened(e, t) {
		t ? this.remoteDeafened.add(e) : this.remoteDeafened.delete(e), this.client.onVoiceStateChanged(e);
	}
	setMuted(e) {
		this.client.settings.set("client", `users.${this.userId}.muted`, e);
	}
	setDeafenedSetting(e) {
		this.client.settings.set("client", "muteAll", e), this.broadcastDeafened();
	}
	wasMutedByDeafen() {
		return game.settings?.get(l, "mutedByDeafen") === !0;
	}
	setMutedByDeafen(e) {
		game.settings?.set(l, "mutedByDeafen", e).catch((e) => {
			eg.error("Error saving mutedByDeafen:", e);
		});
	}
}, ng = new m("UserAudioMixer"), rg = class {
	client;
	context;
	boosts = /* @__PURE__ */ new Map();
	volumeOverrides = /* @__PURE__ */ new Map();
	constructor(e) {
		this.client = e;
	}
	getVolume(e) {
		let t = this.volumeOverrides.get(e) ?? game.settings?.get("avclient-livekit", "userVolumes")[e] ?? this.client.settings.getUser(e)?.volume ?? 1;
		return Math.min(Math.max(t, 0), 2);
	}
	setVolume(e, t, n = !0) {
		let r = Math.min(Math.max(t, 0), 2), i = {
			...game.settings?.get(l, "userVolumes"),
			[e]: r
		};
		this.volumeOverrides.set(e, r), this.apply(e), n && game.settings?.set(l, "userVolumes", i).catch((e) => {
			ng.error("Error saving user volume:", e);
		}).finally(() => {
			this.volumeOverrides.delete(e);
		});
	}
	isLocallyMuted(e) {
		return game.settings?.get(l, "userLocalMutes")[e] === !0;
	}
	async setLocallyMuted(e, t) {
		let n = {
			...game.settings?.get(l, "userLocalMutes"),
			[e]: t
		};
		try {
			await game.settings?.set(l, "userLocalMutes", n);
		} catch (e) {
			ng.error("Error saving local mute:", e);
		}
		this.apply(e);
	}
	apply(e) {
		if (e === game.user?.id) return;
		let t = this.client.voiceControls.isDeafened() || this.isLocallyMuted(e) || this.client.settings.getUser(e)?.blocked === !0, n = this.getVolume(e), r = this.getMicrophoneTrack(e), i = !t && n > 1 && this.canBoost() ? r : void 0, a = !!i, o = this.client.getUserAudioElements(e);
		for (let e of o) {
			let r = e.classList.contains(`user-${H.Source.Microphone}-audio`);
			e.volume = Math.min(n, 1), e.muted = t || a && r;
		}
		i ? this.startBoost(e, i.mediaStreamTrack, n) : this.stopBoost(e);
	}
	applyAll() {
		for (let e of game.users?.keys() ?? []) this.apply(e);
	}
	stopAll() {
		for (let e of [...this.boosts.keys()]) this.stopBoost(e);
	}
	canBoost() {
		let e = this.client.settings.client.audioSink;
		return !e || e === "default" || "setSinkId" in AudioContext.prototype;
	}
	getMicrophoneTrack(e) {
		let t = this.client.liveKitParticipants.get(e)?.getTrackPublication(H.Source.Microphone)?.track;
		return t instanceof xm ? t : void 0;
	}
	getContext() {
		(!this.context || this.context.state === "closed") && (this.context = new AudioContext(), ae(this.context));
		let e = this.client.settings.client.audioSink, t = this.context, n = !e || e === "default" ? "" : e;
		return t.setSinkId && t.sinkId !== n && t.setSinkId(n).catch((e) => {
			ng.warn("Unable to set the boosted audio output device:", e);
		}), this.context;
	}
	startBoost(e, t, n) {
		let r = this.boosts.get(e);
		if (r?.track !== t) {
			this.stopBoost(e);
			let n = this.getContext(), i = n.createMediaStreamSource(new MediaStream([t])), a = n.createGain();
			i.connect(a).connect(n.destination), r = {
				track: t,
				source: i,
				gain: a
			}, this.boosts.set(e, r);
		}
		r.gain.gain.value = n;
	}
	stopBoost(e) {
		let t = this.boosts.get(e);
		t && (t.source.disconnect(), t.gain.disconnect(), this.boosts.delete(e));
	}
}, ig = class {
	client;
	decoratedViews = /* @__PURE__ */ new WeakSet();
	constructor(e) {
		this.client = e;
	}
	decorate(e) {
		for (let t of e.querySelectorAll(".camera-view[data-user]")) this.decorateView(t);
	}
	refresh(e) {
		let t = this.getView(e);
		t && this.updateView(t, e);
	}
	refreshAll() {
		for (let e of document.querySelectorAll(".camera-view[data-user]")) {
			let t = e.dataset.user;
			t && this.updateView(e, t);
		}
	}
	setSpeaking(e, t) {
		let n = this.getView(e);
		n?.classList.toggle("livekit-speaking", t), n?.querySelector(".livekit-camera-avatar .livekit-avatar")?.classList.toggle("is-speaking", t);
	}
	getView(e) {
		return document.querySelector(`.camera-view[data-user="${e}"]`);
	}
	decorateView(e) {
		let t = e.dataset.user;
		if (t) {
			if (!e.querySelector(".livekit-camera-avatar")) {
				let n = game.users?.get(t), r = h("div", {
					className: "livekit-camera-avatar",
					children: [new qm({
						src: n?.avatar,
						size: "fill"
					}).element]
				}), i = h("div", { className: "livekit-camera-badges" }), a = h("div", { className: "livekit-ring" }), o = e.querySelector("video.user-camera")?.parentElement ?? e;
				getComputedStyle(o).position === "static" && o.classList.add("livekit-positioned"), o.append(r, a, i);
			}
			this.decoratedViews.has(e) || (this.decoratedViews.add(e), e.classList.add("livekit-camera-view"), e.querySelector(".webrtc-volume-slider")?.addEventListener("change", (e) => {
				this.client.onVolumeChange(e);
			}), t !== game.user?.id && e.addEventListener("contextmenu", (n) => {
				document.body.classList.contains("livekit-discord-ui") && (n.preventDefault(), n.stopPropagation(), this.client.userMenu.open(t, n.clientX, n.clientY, e));
			})), this.updateView(e, t);
		}
	}
	updateView(e, t) {
		let n = this.client.isUserSpeaking(t), r = this.client.isUserMuted(t), i = this.client.voiceControls.isUserDeafened(t);
		e.classList.toggle("livekit-speaking", n);
		let a = e.querySelector("video.user-camera");
		e.classList.toggle("livekit-no-video", !this.client.isUserVideoOn(t) || !a || a.hasAttribute("hidden")), e.classList.toggle("livekit-muted", r), e.classList.toggle("livekit-deafened", i), e.querySelector(".livekit-camera-avatar .livekit-avatar")?.classList.toggle("is-speaking", n);
		let o = e.querySelector(".livekit-camera-badges");
		o && (o.replaceChildren(), r && o.append(Km({
			icon: "fa-microphone-slash",
			label: g("muted")
		})), i && o.append(Km({
			icon: "fa-headphones",
			label: g("deafened"),
			slashed: !0
		})));
	}
}, ag = class {
	client;
	menu;
	constructor(e) {
		this.client = e, this.menu = new Wm("livekit-noise-menu", () => g("noiseSuppressionModel"), () => this.items());
	}
	get isOpen() {
		return this.menu.isOpen;
	}
	toggle(e, t = e) {
		this.menu.toggle(e, t);
	}
	close() {
		this.menu.close();
	}
	items() {
		let e = this.client, t = () => {
			e.onNoiseSettingsChanged();
		}, n = e.getNoiseModelOptions().map((n) => ({
			type: "radio",
			label: n.label,
			detail: n.detail,
			checked: n.selected,
			disabled: !n.selectable && !n.selected,
			onSelect: () => e.selectNoiseModel(n.model).then(t)
		})), r = (e) => {
			let n = game.settings?.get("avclient-livekit", e) ?? !1;
			return {
				type: "checkbox",
				label: g(e),
				checked: n,
				onSelect: () => game.settings?.set(l, e, !n).then(t)
			};
		};
		return [
			{
				type: "header",
				label: g("noiseSuppressionModel")
			},
			...n,
			{ type: "separator" },
			{
				type: "header",
				label: g("noiseRefinements")
			},
			r("audioAutoGainControl"),
			r("audioEchoCancellation"),
			{ type: "separator" },
			{
				type: "action",
				label: g("noiseResetDefaults"),
				icon: "fa-rotate-left",
				keepOpen: !0,
				onSelect: () => e.resetNoiseSettings().then(t)
			}
		];
	}
}, og = new m("UserMenu"), sg = class {
	client;
	menu;
	userId;
	constructor(e) {
		this.client = e, this.menu = new Wm("livekit-user-menu", () => game.users?.get(this.userId ?? "")?.name ?? g("userVolume"), () => this.items());
	}
	open(e, t, n, r) {
		game.users?.get(e) && (this.userId = e, this.menu.openAtPoint(t, n, r));
	}
	close() {
		this.menu.close();
	}
	items() {
		let e = this.userId, t = game.users?.get(e ?? "");
		if (!e || !t) return [];
		let n = e === game.user?.id;
		return [
			{
				type: "custom",
				element: h("div", {
					className: "livekit-user-menu-header",
					children: [new qm({
						src: t.avatar,
						size: "sm"
					}).element, h("span", {
						className: "livekit-user-menu-name",
						text: t.name
					})]
				})
			},
			...n ? [] : this.audioItems(e),
			...this.dockItems(e),
			...this.gmItems(e),
			...this.breakoutItems(e)
		];
	}
	audioItems(e) {
		let t = this.client.userAudioMixer, n = t.isLocallyMuted(e);
		return [
			{ type: "separator" },
			{
				type: "custom",
				element: Ft({
					label: g("userVolume"),
					min: 0,
					max: 200,
					value: Math.round(t.getVolume(e) * 100),
					format: (e) => `${Math.round(e).toString()}%`,
					onInput: (n) => {
						t.setVolume(e, n / 100, !1);
					},
					onChange: (n) => {
						t.setVolume(e, n / 100);
					}
				})
			},
			{ type: "separator" },
			{
				type: "checkbox",
				label: g("userLocalMute"),
				checked: n,
				onSelect: () => t.setLocallyMuted(e, !n).then(() => {
					this.client.onVoiceStateChanged(e);
				})
			},
			{
				type: "action",
				label: g("userVolumeReset"),
				icon: "fa-rotate-left",
				keepOpen: !0,
				onSelect: () => {
					t.setVolume(e, 1);
				}
			}
		];
	}
	dockItems(e) {
		let t = this.client.dock;
		if (!t) return [];
		let n = e === game.user?.id, r = game.settings?.get(l, "userVideoHidden")[e] === !0, i = t.isPoppedOut(e);
		return [
			{ type: "separator" },
			!i && {
				type: "action",
				label: g("dockFocusUser"),
				icon: "fa-expand",
				onSelect: () => {
					t.focus(e);
				}
			},
			{
				type: "action",
				label: g(i ? "returnToDock" : "popOut"),
				icon: i ? "fa-arrow-right-to-bracket" : "fa-up-right-from-square",
				onSelect: () => t.setPoppedOut(e, !i)
			},
			t.canPictureInPicture(e) && {
				type: "action",
				label: g("pictureInPicture"),
				icon: "fa-clone",
				onSelect: () => t.pictureInPicture(e)
			},
			!n && {
				type: "checkbox",
				label: g("hideVideoForMe"),
				checked: r,
				onSelect: async () => {
					await game.settings?.set("avclient-livekit", "userVideoHidden", {
						...game.settings.get("avclient-livekit", "userVideoHidden"),
						[e]: !r
					}), t.refresh();
				}
			},
			!n && {
				type: "action",
				label: g("hideFromDock"),
				icon: "fa-user-slash",
				onSelect: async () => {
					game.webrtc?.settings.set("client", `users.${e}.blocked`, !0), await t.render();
				}
			}
		].filter((e) => e !== !1);
	}
	gmItems(e) {
		let t = game.users?.get(e);
		if (!game.user?.isGM || e === game.user.id || !t) return [];
		let n = game.webrtc?.settings.getUser(e), r = (e) => {
			let r = e === "BROADCAST_AUDIO" ? n?.canBroadcastAudio !== !1 : n?.canBroadcastVideo !== !1;
			return t.update({ [`permissions.${e}`]: !r }).then(() => game.webrtc?.render()).catch((e) => {
				og.error("Error changing the user's permissions:", e);
			});
		};
		return [
			{ type: "separator" },
			{
				type: "header",
				label: g("gameMaster")
			},
			{
				type: "checkbox",
				label: g("blockAudio"),
				checked: n?.canBroadcastAudio === !1,
				onSelect: () => r("BROADCAST_AUDIO")
			},
			{
				type: "checkbox",
				label: g("blockVideo"),
				checked: n?.canBroadcastVideo === !1,
				onSelect: () => r("BROADCAST_VIDEO")
			}
		];
	}
	breakoutItems(e) {
		let t = Jh(e, this.client);
		return t.length ? [{ type: "separator" }, ...t.map((e) => ({
			type: "action",
			label: e.label,
			icon: e.icon,
			onSelect: e.run
		}))] : [];
	}
}, cg = new m("VoicePanel"), lg = 2e3, ug = 8, dg = class {
	client;
	element;
	statusText = h("span", {
		className: "livekit-panel-status-text",
		attrs: { role: "status" }
	});
	statusIcon = Tt("fa-signal", "livekit-panel-signal");
	subtext = h("span", { className: "livekit-panel-subtext" });
	connectionButton;
	avatar = new qm({ className: "livekit-panel-avatar" });
	userName = h("span", { className: "livekit-panel-name" });
	userSubtext = h("span", { className: "livekit-panel-subtext" });
	muteButton;
	deafenButton;
	noiseButton;
	settingsButton;
	pingMs;
	pingTimer;
	constructor(e) {
		this.client = e, this.connectionButton = Gt({
			icon: "fa-phone-slash",
			label: g("disconnect"),
			className: "livekit-panel-connection",
			onClick: () => {
				this.toggleConnection();
			}
		}), this.muteButton = Gt({
			icon: "fa-microphone",
			label: g("mute"),
			onClick: () => {
				this.client.voiceControls.toggleMute();
			}
		}), this.deafenButton = Gt({
			icon: "fa-headphones",
			label: g("deafen"),
			onClick: () => {
				this.client.voiceControls.toggleDeafen();
			}
		}), this.noiseButton = Gt({
			icon: "fa-wand-magic-sparkles",
			label: g("enhancedNoiseCancellation"),
			onClick: () => {
				this.client.noiseModelMenu.toggle(this.element, this.noiseButton);
			}
		}), this.noiseButton.setAttribute("aria-haspopup", "menu"), this.settingsButton = Gt({
			icon: "fa-gear",
			label: g("voiceSettings"),
			onClick: () => {
				this.client.audioSettingsPopover.toggle(this.element, this.settingsButton);
			}
		}), this.settingsButton.setAttribute("aria-haspopup", "dialog");
		let t = h("div", {
			className: "livekit-panel-status",
			children: [h("div", {
				className: "livekit-panel-status-info",
				children: [h("div", {
					className: "livekit-panel-status-line",
					children: [this.statusIcon, this.statusText]
				}), this.subtext]
			}), this.connectionButton]
		});
		this.makeDraggable(t), this.element = Ct(h("section", {
			className: "livekit-voice-panel",
			attrs: { "aria-label": g("voicePanel") },
			children: [t, h("div", {
				className: "livekit-panel-user",
				children: [
					this.avatar.element,
					h("div", {
						className: "livekit-panel-user-info",
						children: [this.userName, this.userSubtext]
					}),
					h("div", {
						className: "livekit-panel-buttons",
						attrs: {
							role: "toolbar",
							"aria-label": g("voicePanel")
						},
						children: [
							this.muteButton,
							this.deafenButton,
							this.noiseButton,
							this.settingsButton
						]
					})
				]
			})]
		}));
	}
	sync() {
		let e = document.body.classList.contains("livekit-discord-ui") && !this.client.useExternalAV && this.client.settings.get("world", "mode") !== foundry.av.AVSettings.AV_MODES.DISABLED;
		e && !this.element.isConnected ? (document.body.append(this.element), this.position(), window.addEventListener("resize", this.onResize)) : !e && this.element.isConnected && (this.element.remove(), window.removeEventListener("resize", this.onResize)), this.update();
	}
	update() {
		if (!this.element.isConnected) {
			this.stopPing();
			return;
		}
		let e = this.client.liveKitRoom, t = e?.state ?? X.Disconnected, n = t === X.Connected, r = t === X.Connected ? "connected" : t === X.Disconnected ? "disconnected" : t === X.Connecting ? "connecting" : "reconnecting";
		this.element.dataset.status = r, this.statusText.textContent = g(`voiceStatus${r.charAt(0).toUpperCase()}${r.slice(1)}`);
		let i = e?.localParticipant.connectionQuality, a = n && i ? i : Om.Unknown;
		this.statusIcon.dataset.quality = a, wt(this.statusIcon, game.i18n?.localize(`LIVEKITAVCLIENT.connectionQuality.${a}`) ?? a), this.statusIcon.setAttribute("role", "img");
		let o = this.client.breakoutRoom ? g("breakoutRoom") : game.world?.title ?? "";
		this.subtext.textContent = n && this.pingMs !== void 0 ? `${o} · ${this.pingMs.toString()} ms` : o, Kt(this.connectionButton, {
			icon: n ? "fa-phone-slash" : "fa-phone",
			label: g(n ? "disconnect" : "connect"),
			disabled: t === X.Connecting || t === X.Reconnecting
		}), this.connectionButton.classList.toggle("is-danger", n), this.connectionButton.classList.toggle("is-active", !n), n ? this.startPing() : (this.stopPing(), this.pingMs = void 0);
		let s = game.user?.id ?? "";
		this.avatar.setSource(game.user?.avatar), this.avatar.setSpeaking(this.client.isUserSpeaking(s)), this.userName.textContent = game.user?.name ?? "";
		let c = this.client.getAudioProcessingConfig().model;
		this.userSubtext.textContent = c ? this.client.getNoiseModelLabel(c) : g("noiseSuppressionOff");
		let l = this.client.voiceControls, u = l.isMuted(), d = l.isDeafened();
		Kt(this.muteButton, {
			icon: u ? "fa-microphone-slash" : "fa-microphone",
			label: g(u ? "unmute" : "mute"),
			off: u,
			pressed: u
		}), Kt(this.deafenButton, {
			label: g(d ? "undeafen" : "deafen"),
			off: d,
			slashed: d,
			pressed: d
		}), Kt(this.noiseButton, { active: !!c });
	}
	setSpeaking(e) {
		this.avatar.setSpeaking(e);
	}
	toggleConnection() {
		let e = this.client.liveKitRoom?.state === X.Connected;
		this.connectionButton.disabled = !0, (e ? this.client.avMaster.disconnect().then(() => {
			this.client.render();
		}) : this.client.avMaster.connect()).catch((e) => {
			cg.error("Error changing the voice connection:", e);
		}).finally(() => {
			this.update();
		});
	}
	startPing() {
		if (this.pingTimer !== void 0) return;
		let e = async () => {
			try {
				let e = (await this.client.audioTrack?.getSenderStats())?.roundTripTime, t = e === void 0 ? void 0 : Math.round(e * 1e3);
				t !== this.pingMs && (this.pingMs = t, this.update());
			} catch (e) {
				cg.debug("Unable to read the connection round trip time:", e);
			}
		};
		e(), this.pingTimer = window.setInterval(() => void e(), lg);
	}
	stopPing() {
		this.pingTimer !== void 0 && (window.clearInterval(this.pingTimer), this.pingTimer = void 0);
	}
	position() {
		let e = game.settings?.get(l, "voicePanelPosition"), { width: t, height: n } = this.element.getBoundingClientRect(), r, i;
		if (e && typeof e.left == "number" && typeof e.top == "number") ({left: r, top: i} = e);
		else {
			let e = document.getElementById("players")?.getBoundingClientRect();
			r = e ? e.left : ug * 2, i = (e ? e.top : window.innerHeight) - n - ug;
		}
		this.element.style.left = `${Et(r, ug, window.innerWidth - t - ug).toString()}px`, this.element.style.top = `${Et(i, ug, window.innerHeight - n - ug).toString()}px`;
	}
	reposition() {
		this.element.isConnected && this.position();
	}
	onResize = () => {
		this.position();
	};
	makeDraggable(e) {
		e.addEventListener("pointerdown", (t) => {
			if (t.button !== 0 || t.target.closest("button")) return;
			t.preventDefault();
			let n = this.element.getBoundingClientRect(), r = t.clientX - n.left, i = t.clientY - n.top;
			e.setPointerCapture(t.pointerId), this.element.classList.add("dragging");
			let a = (e) => {
				this.element.style.left = `${Et(e.clientX - r, ug, window.innerWidth - n.width - ug).toString()}px`, this.element.style.top = `${Et(e.clientY - i, ug, window.innerHeight - n.height - ug).toString()}px`;
			}, o = () => {
				e.removeEventListener("pointermove", a), e.removeEventListener("pointerup", o), e.removeEventListener("pointercancel", o), this.element.classList.remove("dragging");
				let { left: t, top: n } = this.element.getBoundingClientRect();
				game.settings?.set(l, "voicePanelPosition", {
					left: t,
					top: n
				}).catch((e) => {
					cg.error("Error saving the voice panel position:", e);
				});
			};
			e.addEventListener("pointermove", a), e.addEventListener("pointerup", o), e.addEventListener("pointercancel", o);
		});
	}
}, Z = new m(), fg = "none", pg = "livekit-audio";
function mg(e) {
	try {
		return (game.settings?.storage.get("client"))?.getItem(`${l}.${e}`) != null;
	} catch {
		return !0;
	}
}
function hg({ model: e, gate: t }) {
	return !e && !t ? fg : `${e ?? fg}|gate:${t ? "on" : "off"}`;
}
var gg = /* @__PURE__ */ function(e) {
	return e.Uninitialized = "uninitialized", e.Initializing = "initializing", e.Initialized = "initialized", e;
}({}), _g = class {
	avMaster;
	liveKitAvClient;
	settings;
	render;
	audioBroadcastEnabled = !1;
	audioTrack = null;
	audioCaptureParams = null;
	audioProcessingQueue = Promise.resolve();
	audioProcessorContext;
	audioProcessorState = null;
	failedAudioProcessors = /* @__PURE__ */ new Set();
	speakingUsers = /* @__PURE__ */ new Set();
	voiceGateFailed = !1;
	voiceGatePreview;
	voiceGateListeners = /* @__PURE__ */ new Set();
	gateSpeaking = !1;
	krispSupported;
	liveKitServerAddress;
	scheduleAudioSourceChange = () => void 0;
	scheduleAudioProcessingRefresh = () => void 0;
	voiceControls = new tg(this);
	userAudioMixer = new rg(this);
	cameraViewDecorator = new ig(this);
	userMenu = new sg(this);
	audioSettingsPopover = new rn(this);
	noiseModelMenu = new ag(this);
	voicePanelInstance;
	breakoutRoom;
	connectionState = X.Disconnected;
	initState = "uninitialized";
	liveKitParticipants = /* @__PURE__ */ new Map();
	liveKitRoom = null;
	screenTracks = [];
	useExternalAV = !1;
	videoTrack = null;
	windowClickListener = null;
	liveKitServerTypes = {
		custom: {
			key: "custom",
			label: `${u}.serverTypeCustom`,
			details: `${u}.serverDetailsCustom`,
			urlRequired: !0,
			usernameRequired: !0,
			passwordRequired: !0,
			tokenFunction: vt
		},
		tavern: {
			key: "tavern",
			label: `${u}.serverTypeTavern`,
			details: `${u}.serverDetailsTavern`,
			url: "livekit.tavern.at",
			urlRequired: !1,
			usernameRequired: !1,
			passwordRequired: !1,
			tokenFunction: yt
		}
	};
	defaultLiveKitServerType = this.liveKitServerTypes.custom;
	constructor(e) {
		this.avMaster = e.master, this.liveKitAvClient = e, this.settings = e.settings, this.render = foundry.utils.debounce(this.avMaster.render.bind(this.liveKitAvClient), 2e3), this.scheduleAudioSourceChange = foundry.utils.debounce(() => {
			this.audioProcessingQueue = this.audioProcessingQueue.then(() => this.changeAudioSource(!0)).catch((e) => {
				Z.error("Error changing audio source:", e);
			});
		}, 300), this.scheduleAudioProcessingRefresh = foundry.utils.debounce(() => {
			this.refreshAudioProcessing(!0);
		}, 300), Hooks.callAll("liveKitClientAvailable", this);
	}
	addAllParticipants() {
		if (!this.liveKitRoom) {
			Z.warn("Attempting to add participants before the LiveKit room is available");
			return;
		}
		let e = game.user?.id;
		e && this.liveKitParticipants.set(e, this.liveKitRoom.localParticipant), this.liveKitRoom.remoteParticipants.forEach((e) => {
			this.onParticipantConnected(e);
		});
	}
	addConnectionButtons(e) {
		if (this.useExternalAV) return;
		let t = document.createElement("button");
		t.type = "button", t.className = "av-control inline-control toggle icon fa-solid fa-fw fa-toggle-off livekit-control connect hidden", t.dataset.tooltip = "", t.ariaLabel = game.i18n?.localize("LIVEKITAVCLIENT.connect") ?? "connect";
		let n = document.createElement("button");
		n.type = "button", n.className = "av-control inline-control toggle icon fa-solid fa-fw fa-toggle-on livekit-control disconnect hidden", n.dataset.tooltip = "", n.ariaLabel = game.i18n?.localize("LIVEKITAVCLIENT.disconnect") ?? "disconnect", t.addEventListener("click", () => {
			t.classList.toggle("disabled", !0), this.avMaster.connect().catch((e) => {
				Z.error("Error connecting:", e);
			});
		}), e.before(t), n.addEventListener("click", () => {
			n.classList.toggle("disabled", !0), this.avMaster.disconnect().then(() => {
				this.render();
			}).catch((e) => {
				Z.error("Error disconnecting:", e);
			});
		}), e.before(n), this.liveKitRoom?.state === X.Connected ? n.classList.toggle("hidden", !1) : t.classList.toggle("hidden", !1);
	}
	addNoiseCancellationButton(e) {
		if (this.useExternalAV || !Mh()) return;
		this.noiseModelMenu.close();
		let t = document.createElement("button");
		t.type = "button", t.className = "av-control inline-control toggle icon fa-solid fa-fw fa-wand-magic-sparkles livekit-control livekit-noise-control", t.dataset.tooltip = "", this.updateNoiseModelButton(t), t.addEventListener("click", (e) => {
			e.preventDefault(), e.stopPropagation(), this.noiseModelMenu.toggle(t);
		}), e.before(t);
	}
	updateNoiseModelButton(e) {
		let t = this.getSelectedNoiseModel();
		e.classList.toggle("active", t !== "none");
		let n = game.i18n?.localize("LIVEKITAVCLIENT.enhancedNoiseCancellation") ?? "Noise Cancellation", r = this.getNoiseModelLabel(t), i = this.getAudioProcessingConfig().model ?? "none";
		t !== "none" && i !== t && (r += ` → ${this.getNoiseModelLabel(i)}`), e.ariaLabel = `${n}: ${r}`;
	}
	getSelectedNoiseModel() {
		return !mg("enhancedNoiseCancellation") && !mg("noiseSuppressionModel") ? this.getDefaultNoiseModel() : game.settings?.get("avclient-livekit", "enhancedNoiseCancellation") ?? !1 ? Nh(game.settings?.get(l, "noiseSuppressionModel")) : "none";
	}
	getDefaultNoiseModel() {
		let e = game.settings?.get(l, "defaultNoiseModel");
		return e === "none" ? "none" : Nh(e);
	}
	isKrispAvailable() {
		return (game.settings?.get("avclient-livekit", "allowKrisp") ?? !0) && this.krispSupported === !0 && Wh(this.liveKitRoom, this.liveKitServerAddress);
	}
	async checkKrispSupport() {
		this.krispSupported === void 0 && (this.krispSupported = await Bh(), !this.krispSupported && this.getSelectedNoiseModel() === "krisp" && ui.notifications?.warn(game.i18n?.format("LIVEKITAVCLIENT.krispUnsupportedFallback", { fallback: this.getNoiseModelLabel("gtcrn") }) ?? "krispUnsupportedFallback"));
	}
	getNoiseModelLabel(e) {
		let t = `${u}.noiseSuppressionModel${e.charAt(0).toUpperCase() + e.slice(1)}`;
		return game.i18n?.localize(t) ?? e;
	}
	getNoiseModelOptions() {
		let e = this.getSelectedNoiseModel(), t = Wh(this.liveKitRoom, this.liveKitServerAddress), n = [
			"none",
			"speex",
			"rnnoise",
			"gtcrn"
		];
		return (t || e === "krisp") && n.push("krisp"), n.map((n) => {
			let r;
			return n === "krisp" && !(game.settings?.get("avclient-livekit", "allowKrisp") ?? !0) ? r = game.i18n?.localize(`${u}.krispDisabledByGM`) : n === "krisp" && !t ? r = game.i18n?.localize(`${u}.krispRequiresCloud`) : n === "krisp" && this.krispSupported === !1 && (r = game.i18n?.localize(`${u}.krispUnsupported`)), {
				model: n,
				label: this.getNoiseModelLabel(n),
				detail: r,
				selectable: r === void 0,
				selected: n === e
			};
		});
	}
	async selectNoiseModel(e) {
		if (e === "none") {
			await game.settings?.set(l, "enhancedNoiseCancellation", !1);
			return;
		}
		await game.settings?.set(l, "noiseSuppressionModel", e), (game.settings?.get("avclient-livekit", "enhancedNoiseCancellation") ?? !1) || await game.settings?.set(l, "enhancedNoiseCancellation", !0);
	}
	async resetNoiseSettings() {
		await this.selectNoiseModel(this.getDefaultNoiseModel()), await game.settings?.set(l, "audioAutoGainControl", !0), await game.settings?.set(l, "audioEchoCancellation", !0), await game.settings?.set(l, "audioNoiseSuppression", !0), await game.settings?.set(l, "audioAutoSensitivity", !0), await game.settings?.set(l, "audioNoiseGateThreshold", -50);
	}
	onNoiseSettingsChanged() {
		for (let e of document.querySelectorAll(".livekit-noise-control")) this.updateNoiseModelButton(e);
		this.onVoiceStateChanged();
	}
	get voicePanelIfCreated() {
		return this.voicePanelInstance;
	}
	get voicePanel() {
		return this.voicePanelInstance ??= new dg(this), this.voicePanelInstance;
	}
	applyDiscordStyle() {
		let e = (game.settings?.get("avclient-livekit", "allowDiscordStyleUI") ?? !0) && (game.settings?.get("avclient-livekit", "discordStyleUI") ?? !0) && !this.useExternalAV;
		document.body.classList.toggle("livekit-discord-ui", e), e || (this.userMenu.close(), this.audioSettingsPopover.close()), this.voicePanel.sync(), this.cameraViewDecorator.refreshAll();
	}
	onVoiceStateChanged(e) {
		e ? (this.userAudioMixer.apply(e), this.cameraViewDecorator.refresh(e)) : (this.userAudioMixer.applyAll(), this.cameraViewDecorator.refreshAll()), this.dock?.refresh(), this.voicePanelInstance?.update();
	}
	get dock() {
		return ui.webrtc instanceof dh ? ui.webrtc : void 0;
	}
	isUserSpeaking(e) {
		return this.speakingUsers.has(e);
	}
	isUserMuted(e) {
		if (e === game.user?.id) return this.voiceControls.isMuted() || !this.audioTrack;
		let t = this.liveKitParticipants.get(e);
		if (!(t instanceof Im)) return !1;
		let n = t.getTrackPublication(H.Source.Microphone);
		return !n || n.isMuted;
	}
	isUserVideoOn(e) {
		let t = e === game.user?.id ? this.videoTrack : this.getUserVideoTrack(e);
		return !!t && !t.isMuted;
	}
	addConnectionQualityIndicator(e) {
		if (!game.settings?.get("avclient-livekit", "displayConnectionQuality")) return;
		let t = document.querySelector(`.camera-view[data-user="${e}"]`), n = t?.querySelector(".player-name");
		if (t?.querySelector(".connection-quality-indicator")) return;
		let r = $(`<div class="connection-quality-indicator unknown" title="${game.i18n?.localize(`LIVEKITAVCLIENT.connectionQuality.${Om.Unknown}`) ?? "Connectin Quality Unknown"}"></div>`);
		n instanceof Element && $(n).after(r), this.setConnectionQualityIndicator(e);
	}
	addLiveKitServerType(e) {
		return this.isLiveKitServerType(e) ? this.liveKitServerTypes[e.key] === void 0 ? (this.liveKitServerTypes[e.key] = e, !0) : (Z.error("Attempted to add a LiveKitServerType with a key that already exists:", e), !1) : (Z.error("Attempted to add a LiveKitServerType that does not meet the requirements:", e), !1);
	}
	async attachAudioTrack(e, t, n) {
		if (t.attachedElements.includes(n)) {
			Z.debug("Audio track", t, "already attached to element", n, "; skipping");
			return;
		}
		if (n.sinkId === void 0) Z.warn("Your web browser does not support output audio sink selection");
		else {
			let e = this.settings.get("client", "audioSink");
			await n.setSinkId(e).catch((t) => {
				let n = t;
				t instanceof Error && (n = t.message), Z.error("An error occurred when requesting the output audio device:", e, n);
			});
		}
		t.detach(), t.attach(n);
		let r = this.settings.getUser(e)?.volume;
		r === void 0 && (r = 1), n.volume = r, n.muted = this.settings.get("client", "muteAll") === !0, this.userAudioMixer.apply(e);
	}
	attachVideoTrack(e, t) {
		if (e.attachedElements.includes(t)) {
			Z.debug("Video track", e, "already attached to element", t, "; skipping");
			return;
		}
		e.detach(), e.attach(t);
	}
	async changeAudioSource(e = !1) {
		if (e && this.audioTrack && (await this.liveKitRoom?.localParticipant.unpublishTrack(this.audioTrack), this.audioTrack.stop(), this.audioTrack = null, game.user?.broadcastActivity({ av: { muted: !0 } })), !this.audioTrack || this.settings.get("client", "audioSrc") === "disabled" || !this.avMaster.canUserBroadcastAudio(game.user?.id ?? "")) this.audioTrack ? (await this.liveKitRoom?.localParticipant.unpublishTrack(this.audioTrack), this.audioTrack.stop(), this.audioTrack = null, game.user?.broadcastActivity({ av: { muted: !0 } })) : (await this.initializeAudioTrack(), this.audioTrack && (await this.liveKitRoom?.localParticipant.publishTrack(this.audioTrack, this.trackPublishOptions), await this.applyAudioProcessors(this.audioTrack), game.user?.broadcastActivity({ av: { muted: !1 } }), this.avMaster.render()));
		else {
			let e = this.getAudioParams();
			e && (await this.audioTrack.restartTrack(e), this.audioCaptureParams = JSON.stringify(e));
		}
	}
	async changeVideoSource() {
		if (!this.videoTrack || this.settings.get("client", "videoSrc") === "disabled" || !this.avMaster.canUserBroadcastVideo(game.user?.id ?? "")) {
			if (this.videoTrack) await this.liveKitRoom?.localParticipant.unpublishTrack(this.videoTrack), this.videoTrack.detach(), this.videoTrack.stop(), this.videoTrack = null, game.user?.broadcastActivity({ av: { hidden: !0 } });
			else if (await this.initializeVideoTrack(), this.videoTrack) {
				await this.liveKitRoom?.localParticipant.publishTrack(this.videoTrack, this.trackPublishOptions);
				let e = this.getUserVideoElement(game.user?.id ?? "");
				e && this.attachVideoTrack(this.videoTrack, e), game.user?.broadcastActivity({ av: { hidden: !1 } }), this.avMaster.render();
			}
		} else {
			let e = this.getVideoParams();
			e && await this.videoTrack.restartTrack(e);
		}
	}
	getAudioParams() {
		let e = this.settings.get("client", "audioSrc"), t = this.avMaster.canUserBroadcastAudio(game.user?.id ?? "");
		if (typeof e != "string" || e === "disabled" || !t) return !1;
		let n = {
			deviceId: { ideal: e },
			channelCount: { ideal: 1 }
		};
		if (game.settings?.get("avclient-livekit", "audioMusicMode")) n.autoGainControl = !1, n.echoCancellation = !1, n.noiseSuppression = !1, n.channelCount = { ideal: 2 };
		else {
			n.autoGainControl = game.settings?.get("avclient-livekit", "audioAutoGainControl") ?? !0, n.echoCancellation = game.settings?.get("avclient-livekit", "audioEchoCancellation") ?? !0, n.noiseSuppression = game.settings?.get("avclient-livekit", "audioNoiseSuppression") ?? !0;
			let { model: e } = this.getAudioProcessingConfig();
			e && (n.noiseSuppression = !1);
		}
		return n;
	}
	getParticipantFVTTUser(e) {
		let { fvttUserId: t } = JSON.parse(e.metadata ?? "{}");
		return game.users?.get(t);
	}
	getParticipantUseExternalAV(e) {
		let { useExternalAV: t } = JSON.parse(e.metadata ?? "{ false }");
		return t;
	}
	getUserAudioTrack(e) {
		let t = null;
		return e && this.liveKitParticipants.get(e)?.audioTrackPublications.forEach((e) => {
			e.kind === H.Kind.Audio && (e.track instanceof cf || e.track instanceof xm) && (t = e.track);
		}), t;
	}
	getUserStatistics(e) {
		let t = this.liveKitParticipants.get(e), n = 0;
		if (!t) return "";
		for (let e of t.trackPublications.values()) e.track && (n += e.track.currentBitrate);
		let r = "";
		return n > 0 && (r = `${Math.round(n / 1024).toLocaleString()} kbps`), r;
	}
	getAllUserStatistics() {
		let e = /* @__PURE__ */ new Map();
		return this.liveKitParticipants.forEach((t, n) => {
			e.set(n, this.getUserStatistics(n));
		}), e;
	}
	getUserVideoTrack(e) {
		let t = null;
		return e && this.liveKitParticipants.get(e)?.videoTrackPublications.forEach((e) => {
			e.kind === H.Kind.Video && (e.track instanceof Df || e.track instanceof Uu) && (t = e.track);
		}), t;
	}
	getUserAudioElement(e, t, n) {
		let r = document.getElementById(pg);
		r || (r = document.createElement("div"), r.id = pg, r.hidden = !0, document.body.append(r));
		let i = r.querySelector(`audio[data-user="${e}"][data-source="${n}"]`);
		return i || (i = document.createElement("audio"), i.className = `user-${n}-audio`, i.dataset.user = e, i.dataset.source = n, i.autoplay = !0, r.append(i)), i;
	}
	getUserAudioElements(e) {
		return [...document.querySelectorAll(`#${pg} audio[data-user="${e}"]`)];
	}
	getUserVideoElement(e) {
		return ui.webrtc?.getUserVideoElement?.(e) ?? null;
	}
	async initializeLocalTracks() {
		await this.initializeAudioTrack(), await this.initializeVideoTrack();
	}
	async initializeAudioTrack() {
		this.audioTrack = null;
		let e = this.getAudioParams();
		if (e) try {
			this.audioTrack = await Em(e), this.audioCaptureParams = JSON.stringify(e), await this.applyAudioProcessors(this.audioTrack);
		} catch (e) {
			let t = e;
			e instanceof Error && (t = e.message), Z.error("Unable to acquire local audio:", t);
		}
		this.audioTrack && !(this.liveKitAvClient.isVoiceAlways && this.avMaster.canUserShareAudio(game.user?.id ?? "")) && await this.audioTrack.mute();
	}
	getAudioProcessorContext() {
		return (!this.audioProcessorContext || this.audioProcessorContext.state === "closed") && (this.audioProcessorContext = new AudioContext({ sampleRate: kh }), ae(this.audioProcessorContext)), this.audioProcessorContext;
	}
	getAudioProcessingConfig() {
		if ((game.settings?.get("avclient-livekit", "audioMusicMode") ?? !1) || !Mh()) return {};
		let e = this.getSelectedNoiseModel(), t = this.settings.get("client", "voice.mode") === "always" && !this.voiceGateFailed, n = [];
		return e === "krisp" ? (this.isKrispAvailable() && n.push({
			model: "krisp",
			gate: t
		}), n.push({
			model: jh,
			gate: t
		})) : n.push({
			model: e === "none" ? void 0 : e,
			gate: t
		}), n.find((e) => !this.failedAudioProcessors.has(hg(e))) ?? {};
	}
	async restartAudioCapture(e) {
		let t = this.getAudioParams();
		if (!t) return;
		let n = JSON.stringify(t);
		n !== this.audioCaptureParams && (await e.restartTrack(t), this.audioCaptureParams = n);
	}
	async applyAudioProcessors(e) {
		let t = this.getAudioProcessingConfig(), n = hg(t), r = this.audioProcessorState?.track === e && this.audioProcessorState.key === n;
		if (n === fg) {
			!r && e.getProcessor() && await e.stopProcessor(), this.audioProcessorState = {
				track: e,
				key: n
			};
			return;
		}
		try {
			if (!r) {
				e.setAudioContext(this.getAudioProcessorContext());
				let r = t.gate ? {
					settings: this.getVoiceGateSettings(),
					onReport: this.onVoiceGateReport
				} : void 0;
				await e.setProcessor(t.model === "krisp" ? await Uh(r) : new Fh({
					model: t.model,
					gate: r
				})), this.audioProcessorState = {
					track: e,
					key: n
				}, Z.info("Audio processor applied to local audio track:", n);
			}
			t.model === "krisp" && await this.verifyKrispNoiseFilter(e);
		} catch (r) {
			if (Z.error("Error applying audio processor", n, r), this.audioProcessorState = {
				track: e,
				key: fg
			}, e.getProcessor() && await e.stopProcessor(), r instanceof Xt) this.voiceGateFailed = !0, ui.notifications?.warn(`${u}.voiceGateFailed`, { localize: !0 });
			else {
				this.failedAudioProcessors.add(n);
				let e = this.getAudioProcessingConfig().model;
				ui.notifications?.warn(game.i18n?.format("LIVEKITAVCLIENT.noiseSuppressionFailed", {
					model: this.getNoiseModelLabel(t.model ?? "none"),
					fallback: e ? this.getNoiseModelLabel(e) : game.i18n.localize("LIVEKITAVCLIENT.noiseSuppressionBrowser")
				}) ?? "noiseSuppressionFailed");
			}
			await this.restartAudioCapture(e), await this.applyAudioProcessors(e);
		}
	}
	async verifyKrispNoiseFilter(e) {
		if (!(!e.sid || this.audioProcessorState?.verified)) {
			if (await e.getProcessor()?.setEnabled(!0) === !1) throw Error("The Krisp noise filter could not be enabled");
			this.audioProcessorState?.track === e && (this.audioProcessorState.verified = !0);
		}
	}
	refreshAudioProcessing(e = !1) {
		let t = async () => {
			e && (this.failedAudioProcessors.clear(), this.voiceGateFailed = !1);
			let t = this.audioTrack;
			if (!t) return;
			let n = hg(this.getAudioProcessingConfig());
			t.getProcessor() && !(this.audioProcessorState?.track === t && this.audioProcessorState.key === n) && (await t.stopProcessor(), this.audioProcessorState = {
				track: t,
				key: fg
			}), await this.restartAudioCapture(t), await this.applyAudioProcessors(t), this.applyVoiceGateSettings(), this.updateGateSpeaking();
		};
		return this.audioProcessingQueue = this.audioProcessingQueue.then(t).catch((e) => {
			Z.error("Error refreshing audio processing:", e);
		}), this.audioProcessingQueue;
	}
	get voiceGate() {
		return this.audioTrack?.getProcessor()?.gate;
	}
	getVoiceGateSettings() {
		return this.voiceGatePreview ?? {
			auto: game.settings?.get("avclient-livekit", "audioAutoSensitivity") ?? !0,
			threshold: game.settings?.get("avclient-livekit", "audioNoiseGateThreshold") ?? -50
		};
	}
	previewVoiceGate(e) {
		this.voiceGatePreview = e, this.applyVoiceGateSettings();
	}
	applyVoiceGateSettings() {
		let e = this.getVoiceGateSettings();
		for (let t of Zt.instances) t.configure(e);
	}
	onVoiceGateReports(e) {
		return this.voiceGateListeners.add(e), () => {
			this.voiceGateListeners.delete(e);
		};
	}
	onVoiceGateReport = (e) => {
		for (let t of this.voiceGateListeners) t(e);
		this.updateGateSpeaking();
	};
	updateGateSpeaking() {
		let e = !!this.voiceGate?.isOpen && !!this.audioTrack && !this.audioTrack.isMuted;
		e !== this.gateSpeaking && (this.gateSpeaking = e, this.onIsSpeakingChanged(game.user?.id, e));
	}
	async initializeVideoTrack() {
		this.videoTrack = null;
		let e = this.getVideoParams();
		if (e) try {
			this.videoTrack = await Tm(e);
		} catch (e) {
			let t = e;
			e instanceof Error && (t = e.message), Z.error("Unable to acquire local video:", t);
		}
		this.videoTrack && !this.avMaster.canUserShareVideo(game.user?.id ?? "") && await this.videoTrack.mute();
	}
	initializeRoom() {
		let e = this.trackPublishOptions, t = {
			adaptiveStream: e.simulcast,
			dynacast: e.simulcast,
			publishDefaults: e
		};
		this.liveKitRoom = new Rm(t), this.setRoomCallbacks();
	}
	isLiveKitServerType(e) {
		return !(typeof e.key != "string" || typeof e.label != "string" || typeof e.urlRequired != "boolean" || typeof e.usernameRequired != "boolean" || typeof e.passwordRequired != "boolean" || !(e.tokenFunction instanceof Function));
	}
	isUserExternal(e) {
		return Z.debug("isUserExternal not yet implemented; userId:", e), !1;
	}
	onAudioPlaybackStatusChanged(e) {
		e || (Z.warn("Cannot play audio/video, waiting for user interaction"), this.windowClickListener = this.windowClickListener ?? this.onWindowClick.bind(this), window.addEventListener("click", this.windowClickListener));
	}
	async onConnected() {
		Z.debug("Client connected"), this.setLocalParticipantCallbacks(), this.addAllParticipants(), this.setConnectionButtons(!0), this.audioTrack && await this.liveKitRoom?.localParticipant.publishTrack(this.audioTrack, this.trackPublishOptions), this.videoTrack && await this.liveKitRoom?.localParticipant.publishTrack(this.videoTrack, this.trackPublishOptions), Wh(this.liveKitRoom, this.liveKitServerAddress) && await this.checkKrispSupport(), await this.refreshAudioProcessing(), this.voiceControls.isDeafened() && this.voiceControls.broadcastDeafened();
	}
	onConnectionQualityChanged(e, t) {
		if (Z.debug("onConnectionQualityChanged:", e, t), t === this.liveKitRoom?.localParticipant && this.voicePanelInstance?.update(), !game.settings?.get("avclient-livekit", "displayConnectionQuality")) return;
		let n = this.getParticipantFVTTUser(t)?.id;
		if (!n) {
			Z.warn("Quality changed participant", t, "is not an FVTT user");
			return;
		}
		this.setConnectionQualityIndicator(n, e);
	}
	onDisconnected(e) {
		Z.debug("Client disconnected", { reason: e });
		let t = game.i18n?.localize("LIVEKITAVCLIENT.onDisconnected") ?? "onDisconnected";
		e && (t += `: ${wi[e]}`), ui.notifications?.warn(t), this.liveKitParticipants.clear(), this.userAudioMixer.stopAll(), this.setConnectionButtons(!1), this.connectionState = X.Disconnected;
	}
	onGetUserContextOptions(e, t) {
		this.settings.get("world", "mode") !== foundry.av.AVSettings.AV_MODES.DISABLED && Yh(t, this);
	}
	onIsSpeakingChanged(e, t) {
		if (!e) return;
		t ? this.speakingUsers.add(e) : this.speakingUsers.delete(e);
		let n = this.dock;
		n ? n.setSpeaking(e, t) : (ui.webrtc?.setUserIsSpeaking(e, t), this.cameraViewDecorator.setSpeaking(e, t)), e === game.user?.id && this.voicePanelInstance?.setSpeaking(t);
	}
	onParticipantConnected(e) {
		Z.debug("onParticipantConnected:", e);
		let t = this.getParticipantFVTTUser(e);
		if (!t?.id) {
			Z.error("Joining participant", e, "is not an FVTT user; cannot display them");
			return;
		}
		t.active || (Z.warn("Joining user", t.id, "is not listed as active. Setting to active."), t.active = !0, ui.players?.render().catch((e) => {
			Z.error("Error rendering players view:", e);
		})), this.liveKitParticipants.set(t.id, e), this.breakoutRoom || this.settings.set("client", `users.${t.id}.liveKitBreakoutRoom`, ""), this.setRemoteParticipantCallbacks(e), this.voiceControls.isDeafened() && this.voiceControls.broadcastDeafened(), this.render();
	}
	onParticipantDisconnected(e) {
		Z.debug("onParticipantDisconnected:", e);
		let t = this.getParticipantFVTTUser(e)?.id;
		if (!t) {
			Z.warn("Leaving participant", e, "is not an FVTT user");
			return;
		}
		this.liveKitParticipants.delete(t);
		for (let e of this.getUserAudioElements(t)) e.remove();
		this.onIsSpeakingChanged(t, !1), this.settings.get("client", `users.${t}.liveKitBreakoutRoom`) === this.liveKitAvClient.room && this.liveKitAvClient.room === this.breakoutRoom && this.settings.set("client", `users.${t}.liveKitBreakoutRoom`, ""), this.render();
	}
	onReconnected() {
		Z.info("Reconnect issued"), this.render(), this.voicePanelInstance?.update();
	}
	onReconnecting() {
		Z.warn("Reconnecting to room"), ui.notifications?.warn(game.i18n?.localize("WEBRTC.ConnectionLostWarning") ?? "ConnectionLostWarning"), this.voicePanelInstance?.update();
	}
	onSocketEvent(e, t) {
		switch (Z.debug("Socket event:", e, "from:", t), e.action) {
			case "breakout":
				game.users?.get(t)?.isGM && (!e.userId || e.userId === game.user.id) && Xh(e.breakoutRoom, this);
				break;
			case "connect":
				game.users?.get(t)?.isGM ? this.avMaster.connect().catch((e) => {
					Z.error("Error connecting:", e);
				}) : Z.warn("Connect socket event from non-GM user; ignoring");
				break;
			case "disconnect":
				game.users?.get(t)?.isGM ? this.avMaster.disconnect().then(() => {
					this.render();
				}).catch((e) => {
					Z.error("Error disconnecting:", e);
				}) : Z.warn("Disconnect socket event from non-GM user; ignoring");
				break;
			case "deafen":
				this.voiceControls.onRemoteDeafened(t, e.deafened === !0);
				break;
			case "render":
				game.users?.get(t)?.isGM ? this.render() : Z.warn("Render socket event from non-GM user; ignoring");
				break;
			default: Z.warn("Unknown socket event:", e);
		}
	}
	onTrackMuteChanged(e, t) {
		Z.debug("onTrackMuteChanged:", e, t);
		let n = t === this.liveKitRoom?.localParticipant ? game.user?.id : this.getParticipantFVTTUser(t)?.id;
		if (n && this.onVoiceStateChanged(n), t === this.liveKitRoom?.localParticipant) {
			Z.debug("Local", e.kind, "track muted:", e.isMuted);
			return;
		}
		let r = this.getParticipantFVTTUser(t)?.id, i = this.getParticipantUseExternalAV(t);
		if (!r) {
			Z.warn("Mute change participant", t, "is not an FVTT user");
			return;
		}
		i && (e.kind === H.Kind.Audio ? this.avMaster.settings.handleUserActivity(r, { muted: e.isMuted }) : e.kind === H.Kind.Video && this.avMaster.settings.handleUserActivity(r, { hidden: e.isMuted }));
	}
	onRenderCameraViews(e, t) {
		if (this.dock) {
			this.applyDiscordStyle();
			return;
		}
		this.decorateCameraViews(t);
		let n = game.user?.id;
		if (!n) {
			Z.error("No user ID found; cannot render camera views");
			return;
		}
		let r = t.querySelector(`[data-user="${n}"].user-controls`);
		if (r?.querySelector(".livekit-control")) return;
		let i = r?.querySelector("[data-action=\"configure\"]");
		if (!(i instanceof HTMLElement)) {
			Z.warn("Can't find CameraView configure element", i);
			return;
		}
		this.addConnectionButtons(i), this.addNoiseCancellationButton(i);
	}
	decorateCameraViews(e) {
		this.applyDiscordStyle(), this.cameraViewDecorator.decorate(e);
	}
	onTrackSubscribed(e, t, n) {
		Z.debug("onTrackSubscribed:", e, t, n);
		let r = this.getParticipantFVTTUser(n)?.id;
		if (!r) {
			Z.warn("Track subscribed participant", n, "is not an FVTT user");
			return;
		}
		if (e instanceof xm) {
			let n = this.getUserAudioElement(r, null, t.source);
			this.attachAudioTrack(r, e, n).catch((e) => {
				Z.error("Error attaching audio track:", e);
			});
		} else if (e instanceof Uu) {
			let t = this.getUserVideoElement(r);
			t && this.attachVideoTrack(e, t);
		} else Z.warn("Unknown track type subscribed from publication", t);
		re(r), this.onVoiceStateChanged(r);
	}
	onTrackUnSubscribed(e, t, n) {
		Z.debug("onTrackUnSubscribed:", e, t, n), e.detach();
		let r = this.getParticipantFVTTUser(n)?.id;
		r && this.onVoiceStateChanged(r);
	}
	onVolumeChange(e) {
		let t = e.currentTarget;
		if (!(t instanceof foundry.applications.elements.HTMLRangePickerElement)) {
			Z.warn("Volume change event did not originate from a range picker element");
			return;
		}
		let n = t.closest(".camera-view"), r = foundry.audio.AudioHelper.inputToVolume(t.value);
		if (!(n instanceof HTMLElement)) {
			Z.warn("Volume change event did not originate from a camera view box");
			return;
		}
		n.dataset.user && (this.userAudioMixer.setVolume(n.dataset.user, r), this.settings.set("client", `users.${n.dataset.user}.volume`, r));
	}
	onWindowClick() {
		this.windowClickListener && (window.removeEventListener("click", this.windowClickListener), this.render());
	}
	getVideoParams() {
		let e = this.settings.get("client", "videoSrc"), t = this.avMaster.canUserBroadcastVideo(game.user?.id ?? ""), n = Vc.h180.resolution;
		return this.trackPublishOptions.simulcast && (n = Vc.h720.resolution), typeof e == "string" && e !== "disabled" && t ? {
			deviceId: { ideal: e },
			resolution: n
		} : !1;
	}
	async sendJoinMessage(e, t) {
		let n = `https://meet.livekit.io/custom?${new URLSearchParams({
			liveKitUrl: `wss://${e}`,
			token: t
		}).toString()}`;
		await foundry.applications.api.DialogV2.confirm({
			window: { title: `${u}.externalAVJoinTitle` },
			content: `<p>${game.i18n?.localize("LIVEKITAVCLIENT.externalAVJoinMessage") ?? "externalAVJoinMessage"}</p>`,
			yes: {
				label: `${u}.externalAVJoinButton`,
				icon: "fa-solid fa-check",
				callback: () => window.open(n)
			},
			no: {
				label: `${u}.externalAVIgnoreButton`,
				icon: "fa-solid fa-xmark",
				callback: () => {
					Z.info("Ignoring external LiveKit join request");
				}
			}
		});
	}
	setAudioEnabledState(e) {
		if (!this.audioTrack) {
			Z.debug("setAudioEnabledState called but no audio track available");
			return;
		}
		if (this.liveKitRoom?.state !== X.Connected) {
			Z.debug("setAudioEnabledState called but LiveKit room is not connected");
			return;
		}
		!e && !this.audioTrack.isMuted ? (Z.debug("Muting audio track", this.audioTrack), this.audioTrack.mute().catch((e) => {
			Z.error("Error muting audio track:", e);
		})) : e && this.audioTrack.isMuted ? (Z.debug("Un-muting audio track", this.audioTrack), this.audioTrack.unmute().catch((e) => {
			Z.error("Error un-muting audio track:", e);
		})) : Z.debug("setAudioEnabledState called but track is already in the current state");
	}
	setConnectionButtons(e) {
		let t = document.querySelector(`.user-controls[data-user="${game.user?.id ?? ""}"]`);
		if (t) {
			let n = t.querySelector(".livekit-control.connect"), r = t.querySelector(".livekit-control.disconnect");
			n?.classList.toggle("hidden", e), n?.classList.toggle("disabled", !1), r?.classList.toggle("hidden", !e), r?.classList.toggle("disabled", !1);
		}
		this.voicePanelInstance?.update();
	}
	setConnectionQualityIndicator(e, t) {
		let n = document.querySelector(`.camera-view[data-user="${e}"]`)?.querySelector(".connection-quality-indicator");
		t ??= this.liveKitParticipants.get(e)?.connectionQuality ?? Om.Unknown, n instanceof HTMLDivElement && (n.classList.remove(...Object.values(Om)), n.classList.add(t), n.title = game.i18n?.localize(`LIVEKITAVCLIENT.connectionQuality.${t}`) ?? t);
	}
	setLocalParticipantCallbacks() {
		this.liveKitRoom?.localParticipant.on(L.IsSpeakingChanged, (e) => {
			this.voiceGate || this.onIsSpeakingChanged(game.user?.id, e);
		}).on(L.ParticipantMetadataChanged, (...e) => {
			Z.debug("Local ParticipantEvent ParticipantMetadataChanged:", e);
		}).on(L.TrackPublished, (...e) => {
			Z.debug("Local ParticipantEvent TrackPublished:", e);
		}).on(L.TrackSubscriptionStatusChanged, (...e) => {
			Z.debug("Local ParticipantEvent TrackSubscriptionStatusChanged:", e);
		});
	}
	setRemoteParticipantCallbacks(e) {
		let t = this.getParticipantFVTTUser(e)?.id;
		if (!t) {
			Z.warn("Participant", e, "is not an FVTT user; skipping setRemoteParticipantCallbacks");
			return;
		}
		e.on(L.IsSpeakingChanged, this.onIsSpeakingChanged.bind(this, t)).on(L.ParticipantMetadataChanged, (...e) => {
			Z.debug("Remote ParticipantEvent ParticipantMetadataChanged:", e);
		});
	}
	setRoomCallbacks() {
		if (!this.liveKitRoom) {
			Z.warn("Attempted to set up room callbacks before the LiveKit room is ready");
			return;
		}
		this.liveKitRoom.on(I.AudioPlaybackStatusChanged, this.onAudioPlaybackStatusChanged.bind(this)).on(I.ParticipantConnected, this.onParticipantConnected.bind(this)).on(I.ParticipantDisconnected, this.onParticipantDisconnected.bind(this)).on(I.TrackSubscribed, this.onTrackSubscribed.bind(this)).on(I.TrackSubscriptionFailed, (...e) => {
			Z.error("RoomEvent TrackSubscriptionFailed:", e);
		}).on(I.TrackUnpublished, (...e) => {
			Z.debug("RoomEvent TrackUnpublished:", e);
		}).on(I.TrackUnsubscribed, this.onTrackUnSubscribed.bind(this)).on(I.LocalTrackUnpublished, (...e) => {
			Z.debug("RoomEvent LocalTrackUnpublished:", e);
		}).on(I.ConnectionQualityChanged, this.onConnectionQualityChanged.bind(this)).on(I.Disconnected, this.onDisconnected.bind(this)).on(I.Reconnecting, this.onReconnecting.bind(this)).on(I.TrackMuted, this.onTrackMuteChanged.bind(this)).on(I.TrackUnmuted, this.onTrackMuteChanged.bind(this)).on(I.ParticipantMetadataChanged, (...e) => {
			Z.debug("RoomEvent ParticipantMetadataChanged:", e);
		}).on(I.RoomMetadataChanged, (...e) => {
			Z.debug("RoomEvent RoomMetadataChanged:", e);
		}).on(I.Reconnected, this.onReconnected.bind(this));
	}
	async shareScreen(e) {
		if (Z.info("shareScreen:", e), e) {
			let e = {
				autoGainControl: !1,
				echoCancellation: !1,
				noiseSuppression: !1,
				channelCount: { ideal: 2 }
			};
			this.screenTracks = await Dm({ audio: e });
			for (let e of this.screenTracks) {
				if (Z.debug("screenTrack enable:", e), e instanceof Df) {
					this.videoTrack && await this.liveKitRoom?.localParticipant.unpublishTrack(this.videoTrack);
					let t = document.querySelector(`.camera-view[data-user="${game.user?.id ?? ""}"]`);
					t instanceof HTMLVideoElement && this.attachVideoTrack(e, t);
				}
				let t = this.trackPublishOptions;
				t.audioPreset = zc.musicHighQuality, await this.liveKitRoom?.localParticipant.publishTrack(e, t);
			}
		} else for (let e of this.screenTracks) Z.debug("screenTrack disable:", e), await this.liveKitRoom?.localParticipant.unpublishTrack(e), e instanceof Df && this.videoTrack && (await this.liveKitRoom?.localParticipant.publishTrack(this.videoTrack, this.trackPublishOptions), this.videoTrack.isMuted || await this.videoTrack.unmute());
	}
	get trackPublishOptions() {
		let e = {
			audioPreset: this.getAudioPreset(),
			simulcast: !0,
			videoCodec: "vp8",
			videoSimulcastLayers: [Vc.h180, Vc.h360]
		};
		return game.settings?.get("avclient-livekit", "audioMusicMode") && (e.audioPreset = zc.musicHighQuality), e;
	}
	getAudioPreset() {
		switch (game.settings?.get(l, "audioQualityPreset")) {
			case "telephone": return zc.telephone;
			case "music": return zc.music;
			case "musicStereo": return zc.musicStereo;
			case "musicHighQuality": return zc.musicHighQuality;
			case "musicHighQualityStereo": return zc.musicHighQualityStereo;
			default: return zc.speech;
		}
	}
}, Q = new m(), vg = class extends foundry.av.AVClient {
	_liveKitClient;
	room;
	tempError;
	constructor(e, t) {
		super(e, t), this._liveKitClient = new _g(this), this.room = null, this.master.config = new ln({ webrtc: e });
	}
	async initialize() {
		Q.debug("LiveKitAVClient initialize"), this._liveKitClient.initState = gg.Initializing, this.settings.get("client", "voice.mode") === "activity" && (Q.debug("Disabling voice activation mode as it is handled natively by LiveKit"), this.settings.set("client", "voice.mode", "always")), game.settings?.get("avclient-livekit", "useExternalAV") ? (Q.debug("useExternalAV set, not initializing LiveKitClient"), this._liveKitClient.useExternalAV = !0, game.user?.broadcastActivity({ av: {
			hidden: !1,
			muted: !1
		} })) : (this._liveKitClient.initializeRoom(), await this._liveKitClient.initializeLocalTracks(), game.user?.broadcastActivity({ av: {
			muted: !this.isAudioEnabled(),
			hidden: !this.isVideoEnabled()
		} })), this._liveKitClient.initState = gg.Initialized, this._liveKitClient.applyDiscordStyle(), Hooks.callAll("liveKitClientInitialized", this._liveKitClient);
	}
	async connect() {
		Q.debug("LiveKitAVClient connect"), this._liveKitClient.connectionState = X.Connecting;
		let e = game.settings?.get(l, "liveKitConnectionSettings"), t = this.settings.get("world", "livekit");
		t && (Q.warn("Migrating legacy livekit connection settings"), e = t, oe(() => {
			game.settings?.set(l, "liveKitConnectionSettings", t).catch((e) => {
				Q.error("Error setting livekit connection settings from legacy value", e);
			}), game.webrtc?.client.settings.set("world", "livekit", void 0);
		})), e ??= {}, e.serverType === void 0 && game.user?.isGM && (Q.warn("livekit serverType setting not found; defaulting to", this._liveKitClient.defaultLiveKitServerType.key), e.serverType = this._liveKitClient.defaultLiveKitServerType.key, oe(() => {
			game.settings.set(l, "liveKitConnectionSettings", e).catch((e) => {
				Q.error("Error setting livekit serverType setting to default", e);
			});
		}));
		let n = this._liveKitClient.defaultLiveKitServerType;
		if (typeof e.serverType == "string" && this._liveKitClient.liveKitServerTypes[e.serverType].tokenFunction instanceof Function ? n = this._liveKitClient.liveKitServerTypes[e.serverType] : Q.warn("liveKitServerType", e.serverType, "not found; defaulting to", this._liveKitClient.defaultLiveKitServerType.key), e.url) {
			let t = /* @__PURE__ */ RegExp("^([a-zA-Z\\d]+://)+(.*)$");
			t.exec(e.url) && (Q.warn("Protocol included in server URL:", e.url, "; removing protocol"), e.url = e.url.replace(t, "$2"), oe(() => {
				game.settings?.set(l, "liveKitConnectionSettings", e).catch((e) => {
					Q.error("Error setting livekit url setting", e);
				});
			}));
		}
		if (game.user?.isGM && (n.urlRequired && (e.url === void 0 || e.url === "") || n.usernameRequired && (e.username === void 0 || e.username === "") || n.passwordRequired && (e.password === void 0 || e.password === ""))) return Q.error("LiveKit connection information missing"), ui.notifications?.error(game.i18n.localize(`${u}.connectionInfoMissing`), { permanent: !0 }), this._liveKitClient.connectionState = X.Disconnected, await this.master.config.render({ force: !0 }), !1;
		if (game.user?.isGM && n.key === "tavern" && game.settings.get("avclient-livekit", "tavernPatreonToken") === "") return Q.error("LiveKit Tavern connection information missing"), ui.notifications?.error(game.i18n.localize(`${u}.tavernAccountMissing`), { permanent: !0 }), this._liveKitClient.connectionState = X.Disconnected, await this.master.config.render({ force: !0 }), !1;
		e.room || (Q.warn("No meeting room set, creating random name."), e.room = foundry.utils.randomID(32), oe(() => {
			game.settings?.set(l, "liveKitConnectionSettings", e).catch((e) => {
				Q.error("Error setting livekit room setting", e);
			});
		})), this._liveKitClient.breakoutRoom ? this.room = this._liveKitClient.breakoutRoom : this.room = e.room, Q.debug("Meeting room name:", this.room);
		let r = JSON.stringify({
			fvttUserId: game.user?.id,
			useExternalAV: this._liveKitClient.useExternalAV
		}), i = game.user?.name;
		if (!this.room || !i) return Q.error("Missing required room information, cannot connect. room:", this.room, "username:", i), this._liveKitClient.connectionState = X.Disconnected, !1;
		let a = await n.tokenFunction(e.username, e.password, this.room, i, r).catch((e) => {
			let t = e;
			return e instanceof Error && (t = e.message), Q.error("An error occurred when calling tokenFunction for liveKitServerType:", n, t), "";
		});
		if (!a) return Q.error("Could not get access token", n.label || n.key), ui.notifications?.error(game.i18n?.localize("LIVEKITAVCLIENT.tokenError") ?? "tokenError", { permanent: !0 }), this._liveKitClient.connectionState = X.Disconnected, !1;
		let o = n.urlRequired ? e.url : n.url;
		if (typeof o != "string") {
			let e = `${game.i18n?.localize(n.label) ?? "liveKitServerType"} doesn't provide a URL`;
			return Q.error(e, n), ui.notifications?.error(`${game.i18n?.localize("LIVEKITAVCLIENT.connectError") ?? "connectError"}: ${e}`, { permanent: !0 }), this._liveKitClient.connectionState = X.Disconnected, !1;
		}
		if (this._liveKitClient.liveKitServerAddress = o, this._liveKitClient.useExternalAV) return Q.debug("useExternalAV set, not connecting to LiveKit"), await this._liveKitClient.sendJoinMessage(o, a), !0;
		let s = { autoSubscribe: !0 };
		game.settings?.get("avclient-livekit", "debug") && game.settings.get("avclient-livekit", "liveKitTrace") && (Q.debug("Setting livekit trace logging"), zo(Fo.trace));
		try {
			await this._liveKitClient.liveKitRoom?.connect(`wss://${o}`, a, s), Q.info("Connected to room", this.room);
		} catch (e) {
			Q.error("Could not connect:", e);
			let t = e;
			return e instanceof Error && (t = e.message), (String(t).includes("validation failed, token is expired") || String(t).includes("validation failed, token not valid yet")) && (t = game.i18n?.localize("LIVEKITAVCLIENT.connectErrorCheckClock") ?? "connectErrorCheckClock"), ui.notifications?.error(`${game.i18n?.localize("LIVEKITAVCLIENT.connectError") ?? "connectError"}: ${String(t)}`, { permanent: !0 }), this._liveKitClient.setConnectionButtons(!1), this._liveKitClient.connectionState = X.Disconnected, !1;
		}
		return this._liveKitClient.liveKitRoom?.state === X.Connected ? (await this._liveKitClient.onConnected(), this._liveKitClient.connectionState = X.Connected, !0) : (Q.error("Not connected to room after attempting to connect"), this._liveKitClient.connectionState = X.Disconnected, !1);
	}
	async disconnect() {
		return Q.debug("LiveKitAVClient disconnect"), this._liveKitClient.liveKitRoom && this._liveKitClient.liveKitRoom.state !== X.Disconnected ? (await this._liveKitClient.liveKitRoom.disconnect(!1), this._liveKitClient.connectionState = X.Disconnected, !0) : (Q.warn("Not currently connected; skipping disconnect"), this._liveKitClient.connectionState = X.Disconnected, !1);
	}
	async getAudioSinks() {
		return this._getSourcesOfType("audiooutput");
	}
	async getAudioSources() {
		return this._getSourcesOfType("audioinput");
	}
	async getVideoSources() {
		return this._getSourcesOfType("videoinput");
	}
	async _getSourcesOfType(e) {
		try {
			return (await Rm.getLocalDevices(e)).reduce((e, t) => (e[t.deviceId] = (t.label || game.i18n?.localize("WEBRTC.UnknownDevice")) ?? "UnknownDevice", e), {});
		} catch (t) {
			return Q.error("Could not get media devices of type", e, "; error:", t), {};
		}
	}
	getConnectedUsers() {
		if (Q.debug("getConnectedUsers"), game.settings?.get("avclient-livekit", "useExternalAV")) return [];
		let e = Array.from(this._liveKitClient.liveKitParticipants.keys());
		if (e.length === 0) {
			Q.debug("No connected users; adding our own user id");
			let t = game.user?.id;
			t && e.push(t);
		}
		return Q.debug("connectedUsers:", e), e;
	}
	getMediaStreamForUser(e) {
		return Q.debug("getMediaStreamForUser called for", e, "but is not used with", l), null;
	}
	getLevelsStreamForUser(e) {
		return Q.debug("getLevelsStreamForUser called for", e, "but is not used with", l), null;
	}
	isAudioEnabled() {
		return !!this._liveKitClient.audioTrack;
	}
	isVideoEnabled() {
		return !!this._liveKitClient.videoTrack;
	}
	toggleAudio(e) {
		Q.debug("Toggling audio:", e), !this._liveKitClient.useExternalAV && (!this._liveKitClient.audioBroadcastEnabled || this.isVoicePTT || this.toggleBroadcast(e));
	}
	toggleBroadcast(e) {
		Q.debug("Toggling broadcast audio:", e), !this._liveKitClient.useExternalAV && (this._liveKitClient.audioBroadcastEnabled = e, this._liveKitClient.setAudioEnabledState(e));
	}
	toggleVideo(e) {
		if (!this._liveKitClient.useExternalAV) {
			if (!this._liveKitClient.videoTrack) {
				Q.debug("toggleVideo called but no video track available");
				return;
			}
			if (!e) Q.debug("Muting video track", this._liveKitClient.videoTrack), this._liveKitClient.videoTrack.mute().catch((e) => {
				Q.error("Error muting video track:", e);
			});
			else {
				if (!this._liveKitClient.videoTrack.sid || !this._liveKitClient.liveKitRoom?.localParticipant.videoTrackPublications.has(this._liveKitClient.videoTrack.sid)) {
					Q.debug("toggleVideo unmute called but video track is not published");
					return;
				}
				Q.debug("Un-muting video track", this._liveKitClient.videoTrack), this._liveKitClient.videoTrack.unmute().catch((e) => {
					Q.error("Error un-muting video track:", e);
				});
			}
			this.master.render();
		}
	}
	async setUserVideo(e, t) {
		if (Q.debug("Setting video element:", t, "for user:", e), e === game.user?.id) {
			let n = this._liveKitClient.videoTrack;
			n && this._liveKitClient.attachVideoTrack(n, t), this._liveKitClient.addConnectionQualityIndicator(e);
			return;
		}
		if (!this._liveKitClient.liveKitRoom) {
			Q.warn("Attempted to set user video with no active room; skipping");
			return;
		}
		let n = this._liveKitClient.getUserAudioTrack(e), r = this._liveKitClient.getUserVideoTrack(e);
		if (r && this._liveKitClient.attachVideoTrack(r, t), n instanceof xm) {
			let r = this._liveKitClient.getUserAudioElement(e, t, n.source);
			await this._liveKitClient.attachAudioTrack(e, n, r);
		}
		this._liveKitClient.addConnectionQualityIndicator(e);
		let i = new CustomEvent("webrtcVideoSet", { detail: e });
		t.dispatchEvent(i);
	}
	onSettingsChanged(e) {
		Q.debug("onSettingsChanged:", e);
		let t = new Set(Object.keys(foundry.utils.flattenObject(e))), n = t.has("client.audioSrc");
		n && this._liveKitClient.changeAudioSource().catch((e) => {
			Q.error("Error chaning audio source:", e);
		});
		let r = t.has("client.videoSrc");
		if (r && this._liveKitClient.changeVideoSource().catch((e) => {
			Q.error("Error changing video source:", e);
		}), t.has("client.voice.mode") && this._liveKitClient.scheduleAudioProcessingRefresh(), ["client.voice.mode", `client.users.${game.user?.id ?? ""}.muted`].some((e) => t.has(e))) {
			let e = this.settings.client.voice.mode === "always";
			this.toggleAudio(e && this.master.canUserShareAudio(game.user?.id ?? "")), this.master.broadcast(e);
		}
		let i = [
			"client.muteAll",
			"client.voice.mode",
			"client.audioSink",
			`client.users.${game.user?.id ?? ""}.muted`
		].some((e) => t.has(e)), a = [...t].some((e) => /^client\.users\.[^.]+\.blocked$/.test(e));
		(i || a) && this._liveKitClient.onVoiceStateChanged();
		let o = [
			"client.audioSink",
			"client.muteAll",
			"client.disableVideo",
			"client.nameplates",
			"client.dockPosition",
			"client.dockWidth",
			"client.hideDock",
			"client.borderColors"
		].some((e) => t.has(e));
		(n || r || o) && this.master.render(), game.settings?.sheet.rendered && game.settings.sheet.render().catch((e) => {
			Q.error("Error redering settings sheet:", e);
		});
	}
	async updateLocalStream() {
		Q.debug("updateLocalStream"), await this._liveKitClient.changeAudioSource(), await this._liveKitClient.changeVideoSource();
	}
};
//#endregion
//#region src/avclient-livekit.ts
CONFIG.WebRTC.clientClass = vg;
//#endregion

//# sourceMappingURL=avclient-livekit.js.map