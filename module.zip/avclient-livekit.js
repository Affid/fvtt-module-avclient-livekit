import { _ as e, a as t, b as n, c as r, d as i, f as a, g as o, h as s, i as c, l, m as u, n as d, o as f, p, r as m, s as ee, t as h, u as te, v as ne } from "./livekit-client.esm-C4uopDNI.js";
//#region \0rolldown/runtime.js
var re = Object.create, ie = Object.defineProperty, ae = Object.getOwnPropertyDescriptor, oe = Object.getOwnPropertyNames, se = Object.getPrototypeOf, ce = Object.prototype.hasOwnProperty, le = (e, t) => () => (t || (e((t = { exports: {} }).exports, t), e = null), t.exports), ue = (e, t, n, r) => {
	if (t && typeof t == "object" || typeof t == "function") for (var i = oe(t), a = 0, o = i.length, s; a < o; a++) s = i[a], !ce.call(e, s) && s !== n && ie(e, s, {
		get: ((e) => t[e]).bind(null, s),
		enumerable: !(r = ae(t, s)) || r.enumerable
	});
	return e;
}, de = (e, t, n) => (n = e == null ? {} : re(se(e)), ue(t || !e || !e.__esModule ? ie(n, "default", {
	value: e,
	enumerable: !0
}) : n, e)), g = "avclient-livekit", _ = "LIVEKITAVCLIENT", fe = "https://patreon-auth.tavern.at", pe = /* @__PURE__ */ le(((e, t) => {
	var n = 1e3, r = n * 60, i = r * 60, a = i * 24, o = a * 7, s = a * 365.25;
	t.exports = function(e, t) {
		t ||= {};
		var n = typeof e;
		if (n === "string" && e.length > 0) return c(e);
		if (n === "number" && isFinite(e)) return t.long ? u(e) : l(e);
		throw Error("val is not a non-empty string or a valid number. val=" + JSON.stringify(e));
	};
	function c(e) {
		if (e = String(e), !(e.length > 100)) {
			var t = /^(-?(?:\d+)?\.?\d+) *(milliseconds?|msecs?|ms|seconds?|secs?|s|minutes?|mins?|m|hours?|hrs?|h|days?|d|weeks?|w|years?|yrs?|y)?$/i.exec(e);
			if (t) {
				var c = parseFloat(t[1]);
				switch ((t[2] || "ms").toLowerCase()) {
					case "years":
					case "year":
					case "yrs":
					case "yr":
					case "y": return c * s;
					case "weeks":
					case "week":
					case "w": return c * o;
					case "days":
					case "day":
					case "d": return c * a;
					case "hours":
					case "hour":
					case "hrs":
					case "hr":
					case "h": return c * i;
					case "minutes":
					case "minute":
					case "mins":
					case "min":
					case "m": return c * r;
					case "seconds":
					case "second":
					case "secs":
					case "sec":
					case "s": return c * n;
					case "milliseconds":
					case "millisecond":
					case "msecs":
					case "msec":
					case "ms": return c;
					default: return;
				}
			}
		}
	}
	function l(e) {
		var t = Math.abs(e);
		return t >= a ? Math.round(e / a) + "d" : t >= i ? Math.round(e / i) + "h" : t >= r ? Math.round(e / r) + "m" : t >= n ? Math.round(e / n) + "s" : e + "ms";
	}
	function u(e) {
		var t = Math.abs(e);
		return t >= a ? d(e, t, a, "day") : t >= i ? d(e, t, i, "hour") : t >= r ? d(e, t, r, "minute") : t >= n ? d(e, t, n, "second") : e + " ms";
	}
	function d(e, t, n, r) {
		var i = t >= n * 1.5;
		return Math.round(e / n) + " " + r + (i ? "s" : "");
	}
})), me = /* @__PURE__ */ le(((e, t) => {
	function n(e) {
		n.debug = n, n.default = n, n.coerce = c, n.disable = o, n.enable = i, n.enabled = s, n.humanize = pe(), n.destroy = l, Object.keys(e).forEach((t) => {
			n[t] = e[t];
		}), n.names = [], n.skips = [], n.formatters = {};
		function t(e) {
			let t = 0;
			for (let n = 0; n < e.length; n++) t = (t << 5) - t + e.charCodeAt(n), t |= 0;
			return n.colors[Math.abs(t) % n.colors.length];
		}
		n.selectColor = t;
		function n(e) {
			let t, i = null, a, o;
			function s(...e) {
				if (!s.enabled) return;
				let r = s, i = Number(/* @__PURE__ */ new Date());
				r.diff = i - (t || i), r.prev = t, r.curr = i, t = i, e[0] = n.coerce(e[0]), typeof e[0] != "string" && e.unshift("%O");
				let a = 0;
				e[0] = e[0].replace(/%([a-zA-Z%])/g, (t, i) => {
					if (t === "%%") return "%";
					a++;
					let o = n.formatters[i];
					if (typeof o == "function") {
						let n = e[a];
						t = o.call(r, n), e.splice(a, 1), a--;
					}
					return t;
				}), n.formatArgs.call(r, e), (r.log || n.log).apply(r, e);
			}
			return s.namespace = e, s.useColors = n.useColors(), s.color = n.selectColor(e), s.extend = r, s.destroy = n.destroy, Object.defineProperty(s, "enabled", {
				enumerable: !0,
				configurable: !1,
				get: () => i === null ? (a !== n.namespaces && (a = n.namespaces, o = n.enabled(e)), o) : i,
				set: (e) => {
					i = e;
				}
			}), typeof n.init == "function" && n.init(s), s;
		}
		function r(e, t) {
			let r = n(this.namespace + (t === void 0 ? ":" : t) + e);
			return r.log = this.log, r;
		}
		function i(e) {
			n.save(e), n.namespaces = e, n.names = [], n.skips = [];
			let t = (typeof e == "string" ? e : "").trim().replace(/\s+/g, ",").split(",").filter(Boolean);
			for (let e of t) e[0] === "-" ? n.skips.push(e.slice(1)) : n.names.push(e);
		}
		function a(e, t) {
			let n = 0, r = 0, i = -1, a = 0;
			for (; n < e.length;) if (r < t.length && (t[r] === e[n] || t[r] === "*")) t[r] === "*" ? (i = r, a = n, r++) : (n++, r++);
			else if (i !== -1) r = i + 1, a++, n = a;
			else return !1;
			for (; r < t.length && t[r] === "*";) r++;
			return r === t.length;
		}
		function o() {
			let e = [...n.names, ...n.skips.map((e) => "-" + e)].join(",");
			return n.enable(""), e;
		}
		function s(e) {
			for (let t of n.skips) if (a(e, t)) return !1;
			for (let t of n.names) if (a(e, t)) return !0;
			return !1;
		}
		function c(e) {
			return e instanceof Error ? e.stack || e.message : e;
		}
		function l() {
			console.warn("Instance method `debug.destroy()` is deprecated and no longer does anything. It will be removed in the next major version of `debug`.");
		}
		return n.enable(n.load()), n;
	}
	t.exports = n;
})), v = /* @__PURE__ */ de((/* @__PURE__ */ le(((e, t) => {
	e.formatArgs = r, e.save = i, e.load = a, e.useColors = n, e.storage = o(), e.destroy = (() => {
		let e = !1;
		return () => {
			e || (e = !0, console.warn("Instance method `debug.destroy()` is deprecated and no longer does anything. It will be removed in the next major version of `debug`."));
		};
	})(), e.colors = /* @__PURE__ */ "#0000CC.#0000FF.#0033CC.#0033FF.#0066CC.#0066FF.#0099CC.#0099FF.#00CC00.#00CC33.#00CC66.#00CC99.#00CCCC.#00CCFF.#3300CC.#3300FF.#3333CC.#3333FF.#3366CC.#3366FF.#3399CC.#3399FF.#33CC00.#33CC33.#33CC66.#33CC99.#33CCCC.#33CCFF.#6600CC.#6600FF.#6633CC.#6633FF.#66CC00.#66CC33.#9900CC.#9900FF.#9933CC.#9933FF.#99CC00.#99CC33.#CC0000.#CC0033.#CC0066.#CC0099.#CC00CC.#CC00FF.#CC3300.#CC3333.#CC3366.#CC3399.#CC33CC.#CC33FF.#CC6600.#CC6633.#CC9900.#CC9933.#CCCC00.#CCCC33.#FF0000.#FF0033.#FF0066.#FF0099.#FF00CC.#FF00FF.#FF3300.#FF3333.#FF3366.#FF3399.#FF33CC.#FF33FF.#FF6600.#FF6633.#FF9900.#FF9933.#FFCC00.#FFCC33".split(".");
	function n() {
		if (typeof window < "u" && window.process && (window.process.type === "renderer" || window.process.__nwjs)) return !0;
		if (typeof navigator < "u" && navigator.userAgent && navigator.userAgent.toLowerCase().match(/(edge|trident)\/(\d+)/)) return !1;
		let e;
		return typeof document < "u" && document.documentElement && document.documentElement.style && document.documentElement.style.WebkitAppearance || typeof window < "u" && window.console && (window.console.firebug || window.console.exception && window.console.table) || typeof navigator < "u" && navigator.userAgent && (e = navigator.userAgent.toLowerCase().match(/firefox\/(\d+)/)) && parseInt(e[1], 10) >= 31 || typeof navigator < "u" && navigator.userAgent && navigator.userAgent.toLowerCase().match(/applewebkit\/(\d+)/);
	}
	function r(e) {
		if (e[0] = (this.useColors ? "%c" : "") + this.namespace + (this.useColors ? " %c" : " ") + e[0] + (this.useColors ? "%c " : " ") + "+" + t.exports.humanize(this.diff), !this.useColors) return;
		let n = "color: " + this.color;
		e.splice(1, 0, n, "color: inherit");
		let r = 0, i = 0;
		e[0].replace(/%[a-zA-Z%]/g, (e) => {
			e !== "%%" && (r++, e === "%c" && (i = r));
		}), e.splice(i, 0, n);
	}
	e.log = console.debug || console.log || (() => {});
	function i(t) {
		try {
			t ? e.storage.setItem("debug", t) : e.storage.removeItem("debug");
		} catch {}
	}
	function a() {
		let t;
		try {
			t = e.storage.getItem("debug") || e.storage.getItem("DEBUG");
		} catch {}
		return !t && typeof process < "u" && "env" in process && (t = process.env.DEBUG), t;
	}
	function o() {
		try {
			return localStorage;
		} catch {}
	}
	t.exports = me()(e);
	var { formatters: s } = t.exports;
	s.j = function(e) {
		try {
			return JSON.stringify(e);
		} catch (e) {
			return "[UnexpectedJSONParseError]: " + e.message;
		}
	};
})))(), 1), y = class {
	_trace;
	_debug;
	_info;
	_warn;
	_error;
	constructor(e) {
		e ? (this._trace = (0, v.debug)(`${g}:TRACE:${e}`), this._debug = (0, v.debug)(`${g}:DEBUG:${e}`), this._info = (0, v.debug)(`${g}:INFO:${e}`), this._warn = (0, v.debug)(`${g}:WARN:${e}`), this._error = (0, v.debug)(`${g}:ERROR:${e}`)) : (this._trace = (0, v.debug)(`${g}:TRACE`), this._debug = (0, v.debug)(`${g}:DEBUG`), this._info = (0, v.debug)(`${g}:INFO`), this._warn = (0, v.debug)(`${g}:WARN`), this._error = (0, v.debug)(`${g}:ERROR`)), this._trace.log = console.trace.bind(console), this._debug.log = console.debug.bind(console), this._info.log = console.info.bind(console), this._warn.log = console.warn.bind(console), this._error.log = console.error.bind(console);
	}
	get trace() {
		return this._trace;
	}
	get debug() {
		return this._debug;
	}
	get info() {
		return this._info;
	}
	get warn() {
		return this._warn;
	}
	get error() {
		return this._error;
	}
}, he = new y(), ge = foundry.utils.debounce(() => {
	window.location.reload();
}, 100);
foundry.utils.debounce(() => game.webrtc?.render(), 200);
var _e = foundry.utils.debounce((e) => {
	ui.webrtc?.render({ parts: [e] }).catch((e) => {
		he.error("Error refreshing user view:", e);
	});
}, 200);
function b(e) {
	let t = `modules/${g}/${e}`, n = foundry.utils?.getRoute;
	return typeof n == "function" ? n(t) : `/${t}`;
}
function ve(e) {
	if (e.state !== "suspended") return;
	let t = () => {
		e.state === "suspended" && e.resume().catch((e) => {
			he.warn("Unable to resume audio context:", e);
		});
	};
	for (let e of ["pointerdown", "keydown"]) window.addEventListener(e, t, {
		once: !0,
		capture: !0
	});
	t();
}
function ye(e) {
	game.ready ? (he.debug("callWhenReady now", e), e()) : (he.debug("callWhenReady ready", e), Hooks.once("ready", e));
}
//#endregion
//#region node_modules/.pnpm/jose@6.2.3/node_modules/jose/dist/webapi/lib/buffer_utils.js
var be = new TextEncoder(), xe = new TextDecoder();
function Se(...e) {
	let t = e.reduce((e, { length: t }) => e + t, 0), n = new Uint8Array(t), r = 0;
	for (let t of e) n.set(t, r), r += t.length;
	return n;
}
function Ce(e) {
	let t = new Uint8Array(e.length);
	for (let n = 0; n < e.length; n++) {
		let r = e.charCodeAt(n);
		if (r > 127) throw TypeError("non-ASCII string encountered in encode()");
		t[n] = r;
	}
	return t;
}
//#endregion
//#region node_modules/.pnpm/jose@6.2.3/node_modules/jose/dist/webapi/lib/base64.js
function we(e) {
	if (Uint8Array.prototype.toBase64) return e.toBase64();
	let t = 32768, n = [];
	for (let r = 0; r < e.length; r += t) n.push(String.fromCharCode.apply(null, e.subarray(r, r + t)));
	return btoa(n.join(""));
}
function Te(e) {
	if (Uint8Array.fromBase64) return Uint8Array.fromBase64(e);
	let t = atob(e), n = new Uint8Array(t.length);
	for (let e = 0; e < t.length; e++) n[e] = t.charCodeAt(e);
	return n;
}
//#endregion
//#region node_modules/.pnpm/jose@6.2.3/node_modules/jose/dist/webapi/util/base64url.js
function Ee(e) {
	if (Uint8Array.fromBase64) return Uint8Array.fromBase64(typeof e == "string" ? e : xe.decode(e), { alphabet: "base64url" });
	let t = e;
	t instanceof Uint8Array && (t = xe.decode(t)), t = t.replace(/-/g, "+").replace(/_/g, "/");
	try {
		return Te(t);
	} catch {
		throw TypeError("The input to be decoded is not correctly encoded.");
	}
}
function De(e) {
	let t = e;
	return typeof t == "string" && (t = be.encode(t)), Uint8Array.prototype.toBase64 ? t.toBase64({
		alphabet: "base64url",
		omitPadding: !0
	}) : we(t).replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_");
}
//#endregion
//#region node_modules/.pnpm/jose@6.2.3/node_modules/jose/dist/webapi/lib/crypto_key.js
var x = (e, t = "algorithm.name") => /* @__PURE__ */ TypeError(`CryptoKey does not support this operation, its ${t} must be ${e}`), S = (e, t) => e.name === t;
function Oe(e) {
	return parseInt(e.name.slice(4), 10);
}
function ke(e, t) {
	if (Oe(e.hash) !== t) throw x(`SHA-${t}`, "algorithm.hash");
}
function Ae(e) {
	switch (e) {
		case "ES256": return "P-256";
		case "ES384": return "P-384";
		case "ES512": return "P-521";
		default: throw Error("unreachable");
	}
}
function je(e, t) {
	if (t && !e.usages.includes(t)) throw TypeError(`CryptoKey does not support this operation, its usages must include ${t}.`);
}
function Me(e, t, n) {
	switch (t) {
		case "HS256":
		case "HS384":
		case "HS512":
			if (!S(e.algorithm, "HMAC")) throw x("HMAC");
			ke(e.algorithm, parseInt(t.slice(2), 10));
			break;
		case "RS256":
		case "RS384":
		case "RS512":
			if (!S(e.algorithm, "RSASSA-PKCS1-v1_5")) throw x("RSASSA-PKCS1-v1_5");
			ke(e.algorithm, parseInt(t.slice(2), 10));
			break;
		case "PS256":
		case "PS384":
		case "PS512":
			if (!S(e.algorithm, "RSA-PSS")) throw x("RSA-PSS");
			ke(e.algorithm, parseInt(t.slice(2), 10));
			break;
		case "Ed25519":
		case "EdDSA":
			if (!S(e.algorithm, "Ed25519")) throw x("Ed25519");
			break;
		case "ML-DSA-44":
		case "ML-DSA-65":
		case "ML-DSA-87":
			if (!S(e.algorithm, t)) throw x(t);
			break;
		case "ES256":
		case "ES384":
		case "ES512": {
			if (!S(e.algorithm, "ECDSA")) throw x("ECDSA");
			let n = Ae(t);
			if (e.algorithm.namedCurve !== n) throw x(n, "algorithm.namedCurve");
			break;
		}
		default: throw TypeError("CryptoKey does not support this operation");
	}
	je(e, n);
}
//#endregion
//#region node_modules/.pnpm/jose@6.2.3/node_modules/jose/dist/webapi/lib/invalid_key_input.js
function Ne(e, t, ...n) {
	if (n = n.filter(Boolean), n.length > 2) {
		let t = n.pop();
		e += `one of type ${n.join(", ")}, or ${t}.`;
	} else n.length === 2 ? e += `one of type ${n[0]} or ${n[1]}.` : e += `of type ${n[0]}.`;
	return t == null ? e += ` Received ${t}` : typeof t == "function" && t.name ? e += ` Received function ${t.name}` : typeof t == "object" && t && t.constructor?.name && (e += ` Received an instance of ${t.constructor.name}`), e;
}
var Pe = (e, ...t) => Ne("Key must be ", e, ...t), Fe = (e, t, ...n) => Ne(`Key for the ${e} algorithm must be `, t, ...n), Ie = class extends Error {
	static code = "ERR_JOSE_GENERIC";
	code = "ERR_JOSE_GENERIC";
	constructor(e, t) {
		super(e, t), this.name = this.constructor.name, Error.captureStackTrace?.(this, this.constructor);
	}
}, C = class extends Ie {
	static code = "ERR_JOSE_NOT_SUPPORTED";
	code = "ERR_JOSE_NOT_SUPPORTED";
}, Le = class extends Ie {
	static code = "ERR_JWS_INVALID";
	code = "ERR_JWS_INVALID";
}, Re = class extends Ie {
	static code = "ERR_JWT_INVALID";
	code = "ERR_JWT_INVALID";
}, ze = (e) => {
	if (e?.[Symbol.toStringTag] === "CryptoKey") return !0;
	try {
		return e instanceof CryptoKey;
	} catch {
		return !1;
	}
}, Be = (e) => e?.[Symbol.toStringTag] === "KeyObject", Ve = (e) => ze(e) || Be(e);
//#endregion
//#region node_modules/.pnpm/jose@6.2.3/node_modules/jose/dist/webapi/lib/helpers.js
function He(e, t) {
	if (e) throw TypeError(`${t} can only be called once`);
}
//#endregion
//#region node_modules/.pnpm/jose@6.2.3/node_modules/jose/dist/webapi/lib/type_checks.js
var Ue = (e) => typeof e == "object" && !!e;
function We(e) {
	if (!Ue(e) || Object.prototype.toString.call(e) !== "[object Object]") return !1;
	if (Object.getPrototypeOf(e) === null) return !0;
	let t = e;
	for (; Object.getPrototypeOf(t) !== null;) t = Object.getPrototypeOf(t);
	return Object.getPrototypeOf(e) === t;
}
function Ge(...e) {
	let t = e.filter(Boolean);
	if (t.length === 0 || t.length === 1) return !0;
	let n;
	for (let e of t) {
		let t = Object.keys(e);
		if (!n || n.size === 0) {
			n = new Set(t);
			continue;
		}
		for (let e of t) {
			if (n.has(e)) return !1;
			n.add(e);
		}
	}
	return !0;
}
var Ke = (e) => We(e) && typeof e.kty == "string", qe = (e) => e.kty !== "oct" && (e.kty === "AKP" && typeof e.priv == "string" || typeof e.d == "string"), Je = (e) => e.kty !== "oct" && e.d === void 0 && e.priv === void 0, Ye = (e) => e.kty === "oct" && typeof e.k == "string";
//#endregion
//#region node_modules/.pnpm/jose@6.2.3/node_modules/jose/dist/webapi/lib/signing.js
function Xe(e, t) {
	if (e.startsWith("RS") || e.startsWith("PS")) {
		let { modulusLength: n } = t.algorithm;
		if (typeof n != "number" || n < 2048) throw TypeError(`${e} requires key modulusLength to be 2048 bits or larger`);
	}
}
function Ze(e, t) {
	let n = `SHA-${e.slice(-3)}`;
	switch (e) {
		case "HS256":
		case "HS384":
		case "HS512": return {
			hash: n,
			name: "HMAC"
		};
		case "PS256":
		case "PS384":
		case "PS512": return {
			hash: n,
			name: "RSA-PSS",
			saltLength: parseInt(e.slice(-3), 10) >> 3
		};
		case "RS256":
		case "RS384":
		case "RS512": return {
			hash: n,
			name: "RSASSA-PKCS1-v1_5"
		};
		case "ES256":
		case "ES384":
		case "ES512": return {
			hash: n,
			name: "ECDSA",
			namedCurve: t.namedCurve
		};
		case "Ed25519":
		case "EdDSA": return { name: "Ed25519" };
		case "ML-DSA-44":
		case "ML-DSA-65":
		case "ML-DSA-87": return { name: e };
		default: throw new C(`alg ${e} is not supported either by JOSE or your javascript runtime`);
	}
}
async function Qe(e, t, n) {
	if (t instanceof Uint8Array) {
		if (!e.startsWith("HS")) throw TypeError(Pe(t, "CryptoKey", "KeyObject", "JSON Web Key"));
		return crypto.subtle.importKey("raw", t, {
			hash: `SHA-${e.slice(-3)}`,
			name: "HMAC"
		}, !1, [n]);
	}
	return Me(t, e, n), t;
}
async function $e(e, t, n) {
	let r = await Qe(e, t, "sign");
	Xe(e, r);
	let i = await crypto.subtle.sign(Ze(e, r.algorithm), r, n);
	return new Uint8Array(i);
}
//#endregion
//#region node_modules/.pnpm/jose@6.2.3/node_modules/jose/dist/webapi/lib/jwk_to_key.js
var et = "Invalid or unsupported JWK \"alg\" (Algorithm) Parameter value";
function tt(e) {
	let t, n;
	switch (e.kty) {
		case "AKP":
			switch (e.alg) {
				case "ML-DSA-44":
				case "ML-DSA-65":
				case "ML-DSA-87":
					t = { name: e.alg }, n = e.priv ? ["sign"] : ["verify"];
					break;
				default: throw new C(et);
			}
			break;
		case "RSA":
			switch (e.alg) {
				case "PS256":
				case "PS384":
				case "PS512":
					t = {
						name: "RSA-PSS",
						hash: `SHA-${e.alg.slice(-3)}`
					}, n = e.d ? ["sign"] : ["verify"];
					break;
				case "RS256":
				case "RS384":
				case "RS512":
					t = {
						name: "RSASSA-PKCS1-v1_5",
						hash: `SHA-${e.alg.slice(-3)}`
					}, n = e.d ? ["sign"] : ["verify"];
					break;
				case "RSA-OAEP":
				case "RSA-OAEP-256":
				case "RSA-OAEP-384":
				case "RSA-OAEP-512":
					t = {
						name: "RSA-OAEP",
						hash: `SHA-${parseInt(e.alg.slice(-3), 10) || 1}`
					}, n = e.d ? ["decrypt", "unwrapKey"] : ["encrypt", "wrapKey"];
					break;
				default: throw new C(et);
			}
			break;
		case "EC":
			switch (e.alg) {
				case "ES256":
				case "ES384":
				case "ES512":
					t = {
						name: "ECDSA",
						namedCurve: {
							ES256: "P-256",
							ES384: "P-384",
							ES512: "P-521"
						}[e.alg]
					}, n = e.d ? ["sign"] : ["verify"];
					break;
				case "ECDH-ES":
				case "ECDH-ES+A128KW":
				case "ECDH-ES+A192KW":
				case "ECDH-ES+A256KW":
					t = {
						name: "ECDH",
						namedCurve: e.crv
					}, n = e.d ? ["deriveBits"] : [];
					break;
				default: throw new C(et);
			}
			break;
		case "OKP":
			switch (e.alg) {
				case "Ed25519":
				case "EdDSA":
					t = { name: "Ed25519" }, n = e.d ? ["sign"] : ["verify"];
					break;
				case "ECDH-ES":
				case "ECDH-ES+A128KW":
				case "ECDH-ES+A192KW":
				case "ECDH-ES+A256KW":
					t = { name: e.crv }, n = e.d ? ["deriveBits"] : [];
					break;
				default: throw new C(et);
			}
			break;
		default: throw new C("Invalid or unsupported JWK \"kty\" (Key Type) Parameter value");
	}
	return {
		algorithm: t,
		keyUsages: n
	};
}
async function nt(e) {
	if (!e.alg) throw TypeError("\"alg\" argument is required when \"jwk.alg\" is not present");
	let { algorithm: t, keyUsages: n } = tt(e), r = { ...e };
	return r.kty !== "AKP" && delete r.alg, delete r.use, crypto.subtle.importKey("jwk", r, t, e.ext ?? !(e.d || e.priv), e.key_ops ?? n);
}
//#endregion
//#region node_modules/.pnpm/jose@6.2.3/node_modules/jose/dist/webapi/lib/normalize_key.js
var w = "given KeyObject instance cannot be used for this algorithm", T, rt = async (e, t, n, r = !1) => {
	T ||= /* @__PURE__ */ new WeakMap();
	let i = T.get(e);
	if (i?.[n]) return i[n];
	let a = await nt({
		...t,
		alg: n
	});
	return r && Object.freeze(e), i ? i[n] = a : T.set(e, { [n]: a }), a;
}, it = (e, t) => {
	T ||= /* @__PURE__ */ new WeakMap();
	let n = T.get(e);
	if (n?.[t]) return n[t];
	let r = e.type === "public", i = !!r, a;
	if (e.asymmetricKeyType === "x25519") {
		switch (t) {
			case "ECDH-ES":
			case "ECDH-ES+A128KW":
			case "ECDH-ES+A192KW":
			case "ECDH-ES+A256KW": break;
			default: throw TypeError(w);
		}
		a = e.toCryptoKey(e.asymmetricKeyType, i, r ? [] : ["deriveBits"]);
	}
	if (e.asymmetricKeyType === "ed25519") {
		if (t !== "EdDSA" && t !== "Ed25519") throw TypeError(w);
		a = e.toCryptoKey(e.asymmetricKeyType, i, [r ? "verify" : "sign"]);
	}
	switch (e.asymmetricKeyType) {
		case "ml-dsa-44":
		case "ml-dsa-65":
		case "ml-dsa-87":
			if (t !== e.asymmetricKeyType.toUpperCase()) throw TypeError(w);
			a = e.toCryptoKey(e.asymmetricKeyType, i, [r ? "verify" : "sign"]);
	}
	if (e.asymmetricKeyType === "rsa") {
		let n;
		switch (t) {
			case "RSA-OAEP":
				n = "SHA-1";
				break;
			case "RS256":
			case "PS256":
			case "RSA-OAEP-256":
				n = "SHA-256";
				break;
			case "RS384":
			case "PS384":
			case "RSA-OAEP-384":
				n = "SHA-384";
				break;
			case "RS512":
			case "PS512":
			case "RSA-OAEP-512":
				n = "SHA-512";
				break;
			default: throw TypeError(w);
		}
		if (t.startsWith("RSA-OAEP")) return e.toCryptoKey({
			name: "RSA-OAEP",
			hash: n
		}, i, r ? ["encrypt"] : ["decrypt"]);
		a = e.toCryptoKey({
			name: t.startsWith("PS") ? "RSA-PSS" : "RSASSA-PKCS1-v1_5",
			hash: n
		}, i, [r ? "verify" : "sign"]);
	}
	if (e.asymmetricKeyType === "ec") {
		let n = new Map([
			["prime256v1", "P-256"],
			["secp384r1", "P-384"],
			["secp521r1", "P-521"]
		]).get(e.asymmetricKeyDetails?.namedCurve);
		if (!n) throw TypeError(w);
		let o = {
			ES256: "P-256",
			ES384: "P-384",
			ES512: "P-521"
		};
		o[t] && n === o[t] && (a = e.toCryptoKey({
			name: "ECDSA",
			namedCurve: n
		}, i, [r ? "verify" : "sign"])), t.startsWith("ECDH-ES") && (a = e.toCryptoKey({
			name: "ECDH",
			namedCurve: n
		}, i, r ? [] : ["deriveBits"]));
	}
	if (!a) throw TypeError(w);
	return n ? n[t] = a : T.set(e, { [t]: a }), a;
};
async function at(e, t) {
	if (e instanceof Uint8Array || ze(e)) return e;
	if (Be(e)) {
		if (e.type === "secret") return e.export();
		if ("toCryptoKey" in e && typeof e.toCryptoKey == "function") try {
			return it(e, t);
		} catch (e) {
			if (e instanceof TypeError) throw e;
		}
		return rt(e, e.export({ format: "jwk" }), t);
	}
	if (Ke(e)) return e.k ? Ee(e.k) : rt(e, e, t, !0);
	throw Error("unreachable");
}
//#endregion
//#region node_modules/.pnpm/jose@6.2.3/node_modules/jose/dist/webapi/lib/validate_crit.js
function ot(e, t, n, r, i) {
	if (i.crit !== void 0 && r?.crit === void 0) throw new e("\"crit\" (Critical) Header Parameter MUST be integrity protected");
	if (!r || r.crit === void 0) return /* @__PURE__ */ new Set();
	if (!Array.isArray(r.crit) || r.crit.length === 0 || r.crit.some((e) => typeof e != "string" || e.length === 0)) throw new e("\"crit\" (Critical) Header Parameter MUST be an array of non-empty strings when present");
	let a;
	a = n === void 0 ? t : new Map([...Object.entries(n), ...t.entries()]);
	for (let t of r.crit) {
		if (!a.has(t)) throw new C(`Extension Header Parameter "${t}" is not recognized`);
		if (i[t] === void 0) throw new e(`Extension Header Parameter "${t}" is missing`);
		if (a.get(t) && r[t] === void 0) throw new e(`Extension Header Parameter "${t}" MUST be integrity protected`);
	}
	return new Set(r.crit);
}
//#endregion
//#region node_modules/.pnpm/jose@6.2.3/node_modules/jose/dist/webapi/lib/check_key_type.js
var E = (e) => e?.[Symbol.toStringTag], st = (e, t, n) => {
	if (t.use !== void 0) {
		let e;
		switch (n) {
			case "sign":
			case "verify":
				e = "sig";
				break;
			case "encrypt":
			case "decrypt":
				e = "enc";
				break;
		}
		if (t.use !== e) throw TypeError(`Invalid key for this operation, its "use" must be "${e}" when present`);
	}
	if (t.alg !== void 0 && t.alg !== e) throw TypeError(`Invalid key for this operation, its "alg" must be "${e}" when present`);
	if (Array.isArray(t.key_ops)) {
		let r;
		switch (!0) {
			case n === "sign" || n === "verify":
			case e === "dir":
			case e.includes("CBC-HS"):
				r = n;
				break;
			case e.startsWith("PBES2"):
				r = "deriveBits";
				break;
			case /^A\d{3}(?:GCM)?(?:KW)?$/.test(e):
				r = !e.includes("GCM") && e.endsWith("KW") ? n === "encrypt" ? "wrapKey" : "unwrapKey" : n;
				break;
			case n === "encrypt" && e.startsWith("RSA"):
				r = "wrapKey";
				break;
			case n === "decrypt":
				r = e.startsWith("RSA") ? "unwrapKey" : "deriveBits";
				break;
		}
		if (r && t.key_ops?.includes?.(r) === !1) throw TypeError(`Invalid key for this operation, its "key_ops" must include "${r}" when present`);
	}
	return !0;
}, ct = (e, t, n) => {
	if (!(t instanceof Uint8Array)) {
		if (Ke(t)) {
			if (Ye(t) && st(e, t, n)) return;
			throw TypeError("JSON Web Key for symmetric algorithms must have JWK \"kty\" (Key Type) equal to \"oct\" and the JWK \"k\" (Key Value) present");
		}
		if (!Ve(t)) throw TypeError(Fe(e, t, "CryptoKey", "KeyObject", "JSON Web Key", "Uint8Array"));
		if (t.type !== "secret") throw TypeError(`${E(t)} instances for symmetric algorithms must be of type "secret"`);
	}
}, lt = (e, t, n) => {
	if (Ke(t)) switch (n) {
		case "decrypt":
		case "sign":
			if (qe(t) && st(e, t, n)) return;
			throw TypeError("JSON Web Key for this operation must be a private JWK");
		case "encrypt":
		case "verify":
			if (Je(t) && st(e, t, n)) return;
			throw TypeError("JSON Web Key for this operation must be a public JWK");
	}
	if (!Ve(t)) throw TypeError(Fe(e, t, "CryptoKey", "KeyObject", "JSON Web Key"));
	if (t.type === "secret") throw TypeError(`${E(t)} instances for asymmetric algorithms must not be of type "secret"`);
	if (t.type === "public") switch (n) {
		case "sign": throw TypeError(`${E(t)} instances for asymmetric algorithm signing must be of type "private"`);
		case "decrypt": throw TypeError(`${E(t)} instances for asymmetric algorithm decryption must be of type "private"`);
	}
	if (t.type === "private") switch (n) {
		case "verify": throw TypeError(`${E(t)} instances for asymmetric algorithm verifying must be of type "public"`);
		case "encrypt": throw TypeError(`${E(t)} instances for asymmetric algorithm encryption must be of type "public"`);
	}
};
function ut(e, t, n) {
	switch (e.substring(0, 2)) {
		case "A1":
		case "A2":
		case "di":
		case "HS":
		case "PB":
			ct(e, t, n);
			break;
		default: lt(e, t, n);
	}
}
//#endregion
//#region node_modules/.pnpm/jose@6.2.3/node_modules/jose/dist/webapi/lib/jwt_claims_set.js
var D = (e) => Math.floor(e.getTime() / 1e3), dt = 60, ft = dt * 60, pt = ft * 24, mt = pt * 7, ht = pt * 365.25, gt = /^(\+|\-)? ?(\d+|\d+\.\d+) ?(seconds?|secs?|s|minutes?|mins?|m|hours?|hrs?|h|days?|d|weeks?|w|years?|yrs?|y)(?: (ago|from now))?$/i;
function _t(e) {
	let t = gt.exec(e);
	if (!t || t[4] && t[1]) throw TypeError("Invalid time period format");
	let n = parseFloat(t[2]), r = t[3].toLowerCase(), i;
	switch (r) {
		case "sec":
		case "secs":
		case "second":
		case "seconds":
		case "s":
			i = Math.round(n);
			break;
		case "minute":
		case "minutes":
		case "min":
		case "mins":
		case "m":
			i = Math.round(n * dt);
			break;
		case "hour":
		case "hours":
		case "hr":
		case "hrs":
		case "h":
			i = Math.round(n * ft);
			break;
		case "day":
		case "days":
		case "d":
			i = Math.round(n * pt);
			break;
		case "week":
		case "weeks":
		case "w":
			i = Math.round(n * mt);
			break;
		default:
			i = Math.round(n * ht);
			break;
	}
	return t[1] === "-" || t[4] === "ago" ? -i : i;
}
function O(e, t) {
	if (!Number.isFinite(t)) throw TypeError(`Invalid ${e} input`);
	return t;
}
var vt = class {
	#e;
	constructor(e) {
		if (!We(e)) throw TypeError("JWT Claims Set MUST be an object");
		this.#e = structuredClone(e);
	}
	data() {
		return be.encode(JSON.stringify(this.#e));
	}
	get iss() {
		return this.#e.iss;
	}
	set iss(e) {
		this.#e.iss = e;
	}
	get sub() {
		return this.#e.sub;
	}
	set sub(e) {
		this.#e.sub = e;
	}
	get aud() {
		return this.#e.aud;
	}
	set aud(e) {
		this.#e.aud = e;
	}
	set jti(e) {
		this.#e.jti = e;
	}
	set nbf(e) {
		typeof e == "number" ? this.#e.nbf = O("setNotBefore", e) : e instanceof Date ? this.#e.nbf = O("setNotBefore", D(e)) : this.#e.nbf = D(/* @__PURE__ */ new Date()) + _t(e);
	}
	set exp(e) {
		typeof e == "number" ? this.#e.exp = O("setExpirationTime", e) : e instanceof Date ? this.#e.exp = O("setExpirationTime", D(e)) : this.#e.exp = D(/* @__PURE__ */ new Date()) + _t(e);
	}
	set iat(e) {
		e === void 0 ? this.#e.iat = D(/* @__PURE__ */ new Date()) : e instanceof Date ? this.#e.iat = O("setIssuedAt", D(e)) : typeof e == "string" ? this.#e.iat = O("setIssuedAt", D(/* @__PURE__ */ new Date()) + _t(e)) : this.#e.iat = O("setIssuedAt", e);
	}
}, yt = class {
	#e;
	#t;
	#n;
	constructor(e) {
		if (!(e instanceof Uint8Array)) throw TypeError("payload must be an instance of Uint8Array");
		this.#e = e;
	}
	setProtectedHeader(e) {
		return He(this.#t, "setProtectedHeader"), this.#t = e, this;
	}
	setUnprotectedHeader(e) {
		return He(this.#n, "setUnprotectedHeader"), this.#n = e, this;
	}
	async sign(e, t) {
		if (!this.#t && !this.#n) throw new Le("either setProtectedHeader or setUnprotectedHeader must be called before #sign()");
		if (!Ge(this.#t, this.#n)) throw new Le("JWS Protected and JWS Unprotected Header Parameter names must be disjoint");
		let n = {
			...this.#t,
			...this.#n
		}, r = ot(Le, new Map([["b64", !0]]), t?.crit, this.#t, n), i = !0;
		if (r.has("b64") && (i = this.#t.b64, typeof i != "boolean")) throw new Le("The \"b64\" (base64url-encode payload) Header Parameter must be a boolean");
		let { alg: a } = n;
		if (typeof a != "string" || !a) throw new Le("JWS \"alg\" (Algorithm) Header Parameter missing or invalid");
		ut(a, e, "sign");
		let o, s;
		i ? (o = De(this.#e), s = Ce(o)) : (s = this.#e, o = "");
		let c, l;
		this.#t ? (c = De(JSON.stringify(this.#t)), l = Ce(c)) : (c = "", l = new Uint8Array());
		let u = Se(l, Ce("."), s), d = {
			signature: De(await $e(a, await at(e, a), u)),
			payload: o
		};
		return this.#n && (d.header = this.#n), this.#t && (d.protected = c), d;
	}
}, bt = class {
	#e;
	constructor(e) {
		this.#e = new yt(e);
	}
	setProtectedHeader(e) {
		return this.#e.setProtectedHeader(e), this;
	}
	async sign(e, t) {
		let n = await this.#e.sign(e, t);
		if (n.payload === void 0) throw TypeError("use the flattened module for creating JWS with b64: false");
		return `${n.protected}.${n.payload}.${n.signature}`;
	}
}, xt = class {
	#e;
	#t;
	constructor(e = {}) {
		this.#t = new vt(e);
	}
	setIssuer(e) {
		return this.#t.iss = e, this;
	}
	setSubject(e) {
		return this.#t.sub = e, this;
	}
	setAudience(e) {
		return this.#t.aud = e, this;
	}
	setJti(e) {
		return this.#t.jti = e, this;
	}
	setNotBefore(e) {
		return this.#t.nbf = e, this;
	}
	setExpirationTime(e) {
		return this.#t.exp = e, this;
	}
	setIssuedAt(e) {
		return this.#t.iat = e, this;
	}
	setProtectedHeader(e) {
		return this.#e = e, this;
	}
	async sign(e, t) {
		let n = new bt(this.#t.data());
		if (n.setProtectedHeader(this.#e), Array.isArray(this.#e?.crit) && this.#e.crit.includes("b64") && this.#e.b64 === !1) throw new Re("JWTs MUST NOT use unencoded payload");
		return n.sign(e, t);
	}
}, k = new y();
async function St(e, t, n, r, i) {
	let a = {
		video: {
			roomJoin: !0,
			room: n
		},
		metadata: i
	}, o = Math.floor((/* @__PURE__ */ new Date(Date.now() - 1e3 * 900)).getTime() / 1e3);
	if (!e || !t) return k.error("API Key or Secret is not set. Please configure the LiveKit API Key and Secret"), "";
	let s = await new xt(a).setIssuer(e).setExpirationTime("10h").setJti(r).setSubject(r).setNotBefore(o).setProtectedHeader({ alg: "HS256" }).sign(new TextEncoder().encode(t));
	return k.debug("AccessToken:", s), s;
}
async function Ct(e, t, n, r, i) {
	let a = game.settings?.get("avclient-livekit", "authServer") ?? "https://patreon-auth.tavern.at", o = game.settings?.get(g, "tavernPatreonToken");
	if (!o) return "";
	let s;
	try {
		s = await fetch(`${a}/livekit/token`, {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify({
				id: o,
				room: n,
				userName: r,
				metadata: i
			})
		});
	} catch (e) {
		return k.error("Error validating Patreon account", e), "";
	}
	if (!s.ok) return k.error("Error validating Patreon account", await s.json()), "";
	let c;
	try {
		c = await s.text();
	} catch (e) {
		return k.warn("Error parsing response", e), "";
	}
	return c;
}
async function wt(e, t) {
	let n;
	try {
		n = await fetch(`${e}/validate`, {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify({ id: t })
		});
	} catch (e) {
		k.error("Error validating authentication account", e);
		let t = "Error validating authentication account";
		return e instanceof Error && (t = e.message), {
			error_id: "",
			status_code: 500,
			error: t
		};
	}
	let r;
	try {
		r = await n.json();
	} catch (e) {
		k.error("Error parsing authentication response", e);
		let t = "Error parsing authentication response";
		return e instanceof Error && (t = e.message), {
			error_id: "",
			status_code: 500,
			error: t
		};
	}
	return n.ok || k.error("Error validating authentication account", r), r;
}
//#endregion
//#region src/ui/dom.ts
var Tt = "livekit-surface", Et = "livekit-tooltip";
function A(e, { className: t, text: n, title: r, attrs: i, children: a } = {}) {
	let o = document.createElement(e);
	t && (o.className = t), n !== void 0 && (o.textContent = n), r && M(o, r);
	for (let [e, t] of Object.entries(i ?? {})) o.setAttribute(e, t);
	for (let e of a ?? []) e && o.append(e);
	return o;
}
function j(e) {
	return e.classList.add(Tt), e.dataset.tooltipClass = Et, e;
}
function M(e, t, n) {
	e.dataset.tooltip = t, e.ariaLabel = t, n && (e.dataset.tooltipDirection = n);
}
function N(e, t = "") {
	return A("i", {
		className: `fa-solid fa-fw ${e} ${t}`.trim(),
		attrs: { "aria-hidden": "true" }
	});
}
function P(e, t, n) {
	return Math.min(Math.max(e, t), n);
}
var Dt = 0;
function F(e) {
	return Dt += 1, `livekit-${e}-${Dt.toString()}`;
}
//#endregion
//#region src/ui/controls.ts
var I = (e) => game.i18n?.localize(`LIVEKITAVCLIENT.${e}`) ?? e;
function L({ label: e, hint: t, control: n, inline: r = !1 }) {
	let i = n instanceof HTMLElement ? n.matches("input, select, textarea") ? n : n.querySelector("input, select, textarea") : null, a = A(i ? "label" : "span", {
		className: "livekit-setting-label",
		text: e
	}), o = t && A("p", {
		className: "livekit-setting-hint",
		attrs: { id: F("hint") },
		children: [t]
	});
	return i && (i.id ||= F("control"), a.setAttribute("for", i.id), i.removeAttribute("aria-label"), o && i.setAttribute("aria-describedby", o.id)), A("div", {
		className: `livekit-setting ${r ? "inline" : ""}`.trim(),
		children: [A("div", {
			className: "livekit-setting-text",
			children: [a, o]
		}), n]
	});
}
function R({ name: e, label: t, options: n, value: r, dtype: i, disabled: a = !1, onChange: o }) {
	let s = A("select", {
		className: "livekit-select",
		attrs: { "aria-label": t },
		children: n.map((e) => {
			let t = A("option", {
				text: e.label,
				attrs: { value: e.value }
			});
			return t.selected = e.value === r, t.disabled = !!e.disabled && e.value !== r, t;
		})
	});
	return e && (s.name = e), i && (s.dataset.dtype = i), s.disabled = a, o && s.addEventListener("change", () => {
		o(s.value);
	}), s;
}
function Ot({ name: e, value: t, type: n = "text", className: r = "", attrs: i = {} }) {
	return A("input", {
		className: `${n === "number" ? "livekit-number" : "livekit-text"} ${r}`.trim(),
		attrs: {
			type: n,
			name: e,
			value: t,
			spellcheck: "false",
			...i
		}
	});
}
function z({ name: e, label: t, hint: n, checked: r, disabled: i = !1, onChange: a }) {
	let o = F("label"), s = n ? F("hint") : void 0, c = A("input", { attrs: {
		type: "checkbox",
		role: "switch",
		"aria-labelledby": o,
		...s ? { "aria-describedby": s } : {}
	} });
	return e && (c.name = e), c.checked = r, c.disabled = i, a && c.addEventListener("change", () => {
		a(c.checked);
	}), A("label", {
		className: `livekit-switch ${i ? "disabled" : ""}`.trim(),
		children: [
			A("span", {
				className: "livekit-setting-text",
				children: [A("span", {
					className: "livekit-setting-label",
					text: t,
					attrs: { id: o }
				}), n && A("span", {
					className: "livekit-setting-hint",
					text: n,
					attrs: { id: s ?? "" }
				})]
			}),
			c,
			A("span", {
				className: "livekit-switch-track",
				attrs: { "aria-hidden": "true" }
			})
		]
	});
}
function kt({ name: e, value: t, options: n, itemClass: r, onChange: i }) {
	return n.map((n) => {
		let a = A("input", { attrs: {
			type: "radio",
			name: e,
			value: n.value
		} });
		return a.checked = n.value === t, a.disabled = !!n.disabled, i && a.addEventListener("change", () => {
			i(n.value);
		}), A("label", {
			className: r,
			children: [a, A("span", { text: n.label })]
		});
	});
}
function At({ name: e, label: t, value: n, options: r, onChange: i }) {
	return A("div", {
		className: "livekit-segmented",
		attrs: {
			role: "radiogroup",
			"aria-label": t
		},
		children: kt({
			name: e,
			value: n,
			options: r,
			itemClass: "livekit-segment",
			onChange: i
		})
	});
}
function jt({ name: e, label: t, min: n, max: r, step: i = 1, value: a, format: o = (e) => e.toString(), onInput: s, onChange: c }) {
	let l = A("input", {
		className: "livekit-slider",
		attrs: {
			type: "range",
			min: n.toString(),
			max: r.toString(),
			step: i.toString(),
			value: a.toString()
		}
	});
	e && (l.name = e);
	let u = A("output", {
		className: "livekit-slider-value",
		text: o(a)
	}), d = () => {
		let e = Number(l.value);
		u.textContent = o(e), l.setAttribute("aria-valuetext", o(e)), l.style.setProperty("--fill", `${((e - n) / (r - n) * 100).toString()}%`);
	};
	return d(), l.addEventListener("input", () => {
		d(), s?.(Number(l.value));
	}), l.addEventListener("change", () => {
		c?.(Number(l.value));
	}), A("label", {
		className: "livekit-slider-field",
		children: [A("span", {
			className: "livekit-slider-header",
			children: [A("span", {
				className: "livekit-setting-label",
				text: t
			}), u]
		}), l]
	});
}
function Mt() {
	let e = game.keybindings;
	return e?.actions.has("core.pushToTalk") ? e : void 0;
}
function Nt() {
	return Mt()?.get("core", "pushToTalk");
}
function Pt(e) {
	return Mt()?.set("core", "pushToTalk", [{
		key: e,
		modifiers: []
	}]) ?? Promise.resolve();
}
function Ft(e) {
	return (foundry.helpers?.interaction?.KeyboardManager)?.getKeycodeDisplayString?.(e) ?? e.replace(/^(Key|Digit)/, "");
}
function It(e) {
	return e.map((e) => [...e.modifiers ?? [], Ft(e.key)].join(" + ")).join(", ") || I("pushToTalkUnbound");
}
function Lt(e, t) {
	let n = A("button", {
		className: "livekit-keybind",
		text: It(e),
		attrs: {
			type: "button",
			"aria-live": "polite"
		}
	});
	return n.addEventListener("click", () => {
		n.textContent = I("pushToTalkRecord"), n.classList.add("recording");
		let r = () => {
			window.removeEventListener("keydown", i, { capture: !0 }), n.removeEventListener("blur", a), n.classList.remove("recording");
		}, i = (i) => {
			if (i.preventDefault(), i.stopPropagation(), r(), i.code === "Escape") {
				n.textContent = It(e);
				return;
			}
			n.textContent = It([{ key: i.code }]), t(i.code);
		}, a = () => {
			r(), n.textContent = It(e);
		};
		window.addEventListener("keydown", i, { capture: !0 }), n.addEventListener("blur", a);
	}), n;
}
//#endregion
//#region src/ui/Popover.ts
var B = 8, Rt = 6, zt = class {
	onClose;
	element;
	anchor = null;
	doc = document;
	expandedControl = null;
	onPointerDown = (e) => {
		let t = e.target;
		t instanceof Node && (this.element.contains(t) || this.anchor?.contains(t) || this.expandedControl?.contains(t)) || this.close();
	};
	onKeyDown = (e) => {
		e.key === "Escape" && (e.preventDefault(), e.stopPropagation(), this.close());
	};
	constructor(e, t, n = "dialog") {
		this.onClose = t, this.element = j(A("div", {
			className: `livekit-popover ${e}`,
			attrs: { role: n }
		}));
	}
	get isOpen() {
		return this.element.isConnected;
	}
	openAt(e, t = e) {
		this.anchor = e, this.setExpandedControl(t), this.show(e.ownerDocument), this.reposition();
	}
	openAtPoint(e, t, n) {
		this.anchor = null, this.setExpandedControl(n ?? null), this.show(n?.ownerDocument ?? document);
		let { width: r, height: i } = this.element.getBoundingClientRect();
		this.place(e, t, r, i);
	}
	reposition() {
		if (!this.anchor || !this.isOpen) return;
		let e = this.anchor.getBoundingClientRect(), t = e.top - B - Rt, n = this.viewport.height - e.bottom - B - Rt;
		this.element.style.removeProperty("--livekit-popover-room");
		let r = t >= this.element.getBoundingClientRect().height || t >= n;
		this.element.style.setProperty("--livekit-popover-room", `${Math.max(r ? t : n, 0).toString()}px`);
		let { width: i, height: a } = this.element.getBoundingClientRect(), o = r ? e.top - a - Rt : e.bottom + Rt;
		this.place(e.left, o, i, a);
	}
	close() {
		if (!this.isOpen) return;
		let e = this.element.contains(this.doc.activeElement);
		this.doc.removeEventListener("pointerdown", this.onPointerDown, !0), this.doc.removeEventListener("keydown", this.onKeyDown, !0), this.element.remove();
		let t = this.expandedControl;
		this.setExpandedControl(null), this.anchor = null, e && t?.isConnected && t.focus({ preventScroll: !0 }), this.onClose?.();
	}
	setExpandedControl(e) {
		this.expandedControl?.hasAttribute("aria-expanded") && this.expandedControl.setAttribute("aria-expanded", "false"), this.expandedControl = e, e instanceof HTMLButtonElement && e.setAttribute("aria-expanded", "true");
	}
	show(e) {
		this.isOpen && e !== this.doc && this.close(), this.isOpen || (this.doc = e, e.body.append(this.element), e.addEventListener("pointerdown", this.onPointerDown, !0), e.addEventListener("keydown", this.onKeyDown, !0));
	}
	get viewport() {
		let e = this.doc.defaultView ?? window;
		return {
			width: e.innerWidth,
			height: e.innerHeight
		};
	}
	place(e, t, n, r) {
		let i = this.viewport;
		this.element.style.left = `${P(e, B, i.width - n - B).toString()}px`, this.element.style.top = `${P(t, B, i.height - r - B).toString()}px`;
	}
};
//#endregion
//#region src/ui/buttons.ts
function V({ icon: e, label: t, onClick: n, className: r = "", danger: i = !1 }) {
	let a = A("button", {
		className: `livekit-icon-button ${i ? "is-danger" : ""} ${r}`.replace(/\s+/g, " ").trim(),
		title: t,
		attrs: { type: "button" },
		children: [N(e)]
	});
	return a.addEventListener("click", (e) => {
		e.preventDefault(), e.stopPropagation(), n(e);
	}), a;
}
function H(e, t) {
	t.icon !== void 0 && e.replaceChildren(N(t.icon)), t.label !== void 0 && M(e, t.label), t.active !== void 0 && e.classList.toggle("is-active", t.active), t.off !== void 0 && e.classList.toggle("is-off", t.off), t.slashed !== void 0 && e.classList.toggle("livekit-slashed", t.slashed), t.pressed !== void 0 && e.setAttribute("aria-pressed", String(t.pressed)), t.disabled !== void 0 && (e.disabled = t.disabled);
}
function U({ label: e, variant: t = "secondary", icon: n, type: r = "button", onClick: i }) {
	let a = A("button", {
		className: t === "link" ? "livekit-link-button" : `livekit-button livekit-button-${t}`,
		attrs: { type: r },
		children: [n, A("span", { text: e })]
	});
	return i && a.addEventListener("click", (e) => {
		e.preventDefault(), i();
	}), a;
}
//#endregion
//#region src/VoiceActivityGate.ts
var Bt = "worklets/voice-activity-gate.js", Vt = "livekit-voice-activity-gate", Ht = class extends Error {
	constructor(e) {
		super("The voice activity gate could not be started", { cause: e }), this.name = "VoiceGateError";
	}
}, Ut = class e {
	node;
	onReport;
	static instances = /* @__PURE__ */ new Set();
	report;
	constructor(t, n) {
		this.node = t, this.onReport = n, t.port.onmessage = (e) => {
			this.report = e.data, this.onReport?.(e.data);
		}, e.instances.add(this);
	}
	static async create(t, { settings: n, onReport: r, analysisOnly: i = !1 }) {
		try {
			return await t.audioWorklet.addModule(b(Bt)), new e(new AudioWorkletNode(t, Vt, {
				numberOfInputs: 1,
				numberOfOutputs: +!i,
				processorOptions: n
			}), r);
		} catch (e) {
			throw new Ht(e);
		}
	}
	get isOpen() {
		return this.report?.open ?? !1;
	}
	configure(e) {
		this.node.port.postMessage(e);
	}
	destroy() {
		e.instances.delete(this), this.node.port.onmessage = null, this.node.port.close(), this.node.disconnect();
	}
}, Wt = new y("LevelMeter"), W = -80, Gt = 0, Kt = class {
	element;
	slider;
	fill = A("div", { className: "livekit-meter-fill" });
	stopMetering;
	constructor({ name: e, settings: t, onInput: n, onChange: r }) {
		this.slider = A("input", {
			className: "livekit-meter-threshold",
			attrs: {
				type: "range",
				min: W.toString(),
				max: Gt.toString(),
				step: "1",
				value: t.threshold.toString(),
				"aria-label": I("audioNoiseGateThreshold"),
				"aria-valuetext": `${t.threshold.toString()} dB`
			}
		}), e && (this.slider.name = e), this.slider.addEventListener("input", () => {
			this.slider.setAttribute("aria-valuetext", `${this.slider.value} dB`), n?.(Number(this.slider.value));
		}), this.slider.addEventListener("change", () => {
			r?.(Number(this.slider.value));
		}), this.element = A("div", {
			className: "livekit-meter",
			children: [A("div", {
				className: "livekit-meter-track",
				attrs: { "aria-hidden": "true" },
				children: [this.fill]
			}), this.slider]
		}), this.setAuto(t.auto);
	}
	setAuto(e) {
		this.element.classList.toggle("is-auto", e), this.slider.tabIndex = e ? -1 : 0, this.slider.setAttribute("aria-hidden", String(e));
	}
	start(e) {
		this.stop();
		let t = e.audioTrack;
		if (e.voiceGate && t && !t.isMuted) {
			this.stopMetering = e.onVoiceGateReports((e) => {
				this.show(e);
			});
			return;
		}
		let n = t?.mediaStream?.getAudioTracks()[0] ?? t?.mediaStreamTrack;
		n && n.readyState !== "ended" && this.startAnalysis(e, n);
	}
	stop() {
		this.stopMetering?.(), this.stopMetering = void 0, this.show(void 0);
	}
	async startAnalysis(e, t) {
		let n = { stopped: !1 }, r = () => {
			n.stopped = !0;
		};
		this.stopMetering = () => {
			r();
		};
		let i = t.clone();
		i.enabled = !0;
		let a = e.getAudioProcessorContext();
		try {
			let t = await Ut.create(a, {
				settings: e.getVoiceGateSettings(),
				onReport: (e) => {
					this.show(e);
				},
				analysisOnly: !0
			}), o = a.createMediaStreamSource(new MediaStream([i]));
			o.connect(t.node), r = () => {
				o.disconnect(), t.destroy(), i.stop();
			}, n.stopped && r();
		} catch (e) {
			i.stop(), Wt.warn("Unable to measure the microphone level:", e);
		}
	}
	show(e) {
		let t = (P(e?.db ?? W, W, Gt) - W) / (Gt - W) * 100;
		this.fill.style.width = `${t.toString()}%`, this.fill.classList.toggle("open", e?.open ?? !1);
	}
}, qt = 100, Jt = .2, Yt = "#version 300 es\nin vec2 position;\nout vec2 uv;\nvoid main() {\n  uv = (position + 1.0) / 2.0;\n  gl_Position = vec4(position, 0.0, 1.0);\n}", Xt = "#version 300 es\nprecision mediump float;\nin vec2 uv;\nuniform sampler2D u_mask;\nuniform sampler2D u_previous;\nuniform float u_weight;\nuniform bool u_invert;\nout vec4 color;\nvoid main() {\n  float value = texture(u_mask, uv).r;\n  if (u_invert) {\n    value = 1.0 - value;\n  }\n  float smoothed = mix(texture(u_previous, uv).r, value, u_weight);\n  color = vec4(smoothed, smoothed, smoothed, 1.0);\n}", Zt = class {
	gl;
	invert;
	program;
	vertexArray;
	buffer;
	uniforms;
	textures = [];
	framebuffers = [];
	width = 0;
	height = 0;
	current = 0;
	lastTime;
	constructor(e, t) {
		this.gl = e, this.invert = t, this.program = en(e), this.uniforms = {
			mask: e.getUniformLocation(this.program, "u_mask"),
			previous: e.getUniformLocation(this.program, "u_previous"),
			weight: e.getUniformLocation(this.program, "u_weight"),
			invert: e.getUniformLocation(this.program, "u_invert")
		};
		let n = e.getParameter(e.VERTEX_ARRAY_BINDING), r = e.getParameter(e.ARRAY_BUFFER_BINDING);
		this.vertexArray = e.createVertexArray(), this.buffer = e.createBuffer(), e.bindVertexArray(this.vertexArray), e.bindBuffer(e.ARRAY_BUFFER, this.buffer), e.bufferData(e.ARRAY_BUFFER, new Float32Array([
			-1,
			-1,
			1,
			-1,
			-1,
			1,
			-1,
			1,
			1,
			-1,
			1,
			1
		]), e.STATIC_DRAW);
		let i = e.getAttribLocation(this.program, "position");
		e.enableVertexAttribArray(i), e.vertexAttribPointer(i, 2, e.FLOAT, !1, 0, 0), e.bindVertexArray(n), e.bindBuffer(e.ARRAY_BUFFER, r);
	}
	update(e, t, n) {
		let r = this.gl, i = performance.now(), a = 1;
		t !== this.width || n !== this.height ? this.resize(t, n) : this.lastTime !== void 0 && (a = Math.max(Jt, 1 - Math.exp(-(i - this.lastTime) / qt))), this.lastTime = i;
		let o = Qt(r), s = this.current, c = 1 - s;
		return r.bindFramebuffer(r.FRAMEBUFFER, this.framebuffers[c]), r.viewport(0, 0, t, n), r.disable(r.BLEND), r.useProgram(this.program), r.bindVertexArray(this.vertexArray), r.activeTexture(r.TEXTURE0), r.bindTexture(r.TEXTURE_2D, e), r.activeTexture(r.TEXTURE1), r.bindTexture(r.TEXTURE_2D, this.textures[s]), r.uniform1i(this.uniforms.mask, 0), r.uniform1i(this.uniforms.previous, 1), r.uniform1f(this.uniforms.weight, a), r.uniform1i(this.uniforms.invert, +!!this.invert), r.drawArrays(r.TRIANGLES, 0, 6), $t(r, o), this.current = c, this.textures[c];
	}
	dispose() {
		let e = this.gl;
		this.deleteTargets(), e.deleteBuffer(this.buffer), e.deleteVertexArray(this.vertexArray), e.deleteProgram(this.program);
	}
	resize(e, t) {
		let n = this.gl;
		this.deleteTargets(), this.width = e, this.height = t;
		let r = Qt(n);
		for (let r = 0; r < 2; r++) {
			let r = n.createTexture();
			n.activeTexture(n.TEXTURE0), n.bindTexture(n.TEXTURE_2D, r), n.texImage2D(n.TEXTURE_2D, 0, n.RGBA, e, t, 0, n.RGBA, n.UNSIGNED_BYTE, null), n.texParameteri(n.TEXTURE_2D, n.TEXTURE_MIN_FILTER, n.LINEAR), n.texParameteri(n.TEXTURE_2D, n.TEXTURE_MAG_FILTER, n.LINEAR), n.texParameteri(n.TEXTURE_2D, n.TEXTURE_WRAP_S, n.CLAMP_TO_EDGE), n.texParameteri(n.TEXTURE_2D, n.TEXTURE_WRAP_T, n.CLAMP_TO_EDGE);
			let i = n.createFramebuffer();
			n.bindFramebuffer(n.FRAMEBUFFER, i), n.framebufferTexture2D(n.FRAMEBUFFER, n.COLOR_ATTACHMENT0, n.TEXTURE_2D, r, 0), this.textures.push(r), this.framebuffers.push(i);
		}
		$t(n, r);
	}
	deleteTargets() {
		for (let e of this.textures) this.gl.deleteTexture(e);
		for (let e of this.framebuffers) this.gl.deleteFramebuffer(e);
		this.textures = [], this.framebuffers = [], this.lastTime = void 0;
	}
};
function Qt(e) {
	let t = e.getParameter(e.ACTIVE_TEXTURE), n = [e.TEXTURE0, e.TEXTURE1].map((t) => (e.activeTexture(t), e.getParameter(e.TEXTURE_BINDING_2D)));
	return {
		program: e.getParameter(e.CURRENT_PROGRAM),
		framebuffer: e.getParameter(e.FRAMEBUFFER_BINDING),
		vertexArray: e.getParameter(e.VERTEX_ARRAY_BINDING),
		viewport: e.getParameter(e.VIEWPORT),
		activeTexture: t,
		textures: n,
		blend: e.isEnabled(e.BLEND)
	};
}
function $t(e, t) {
	[e.TEXTURE0, e.TEXTURE1].forEach((n, r) => {
		e.activeTexture(n), e.bindTexture(e.TEXTURE_2D, t.textures[r] ?? null);
	}), e.activeTexture(t.activeTexture), e.useProgram(t.program), e.bindFramebuffer(e.FRAMEBUFFER, t.framebuffer), e.bindVertexArray(t.vertexArray), e.viewport(t.viewport[0], t.viewport[1], t.viewport[2], t.viewport[3]), t.blend ? e.enable(e.BLEND) : e.disable(e.BLEND);
}
function en(e) {
	let t = e.createProgram();
	for (let [n, r] of [[e.VERTEX_SHADER, Yt], [e.FRAGMENT_SHADER, Xt]]) {
		let i = e.createShader(n);
		if (!i) throw Error("Unable to create a shader for the mask smoother");
		if (e.shaderSource(i, r), e.compileShader(i), !e.getShaderParameter(i, e.COMPILE_STATUS)) throw Error(`Unable to compile the mask smoother: ${e.getShaderInfoLog(i) ?? ""}`);
		e.attachShader(t, i);
	}
	if (e.linkProgram(t), !e.getProgramParameter(t, e.LINK_STATUS)) throw Error(`Unable to link the mask smoother: ${e.getProgramInfoLog(t) ?? ""}`);
	return t;
}
//#endregion
//#region src/VideoBackground.ts
var tn = new y("VideoBackground"), nn = {
	standard: "mediapipe/selfie_segmenter.tflite",
	high: "mediapipe/selfie_multiclass_256x256.tflite"
}, rn = /* @__PURE__ */ new WeakMap(), an = [{
	path: "ui/backgrounds/setup.webp",
	label: "videoBackgroundFantasy"
}, {
	path: "ui/backgrounds/setup-scifi.webp",
	label: "videoBackgroundSciFi"
}], on = class extends Error {}, sn = 60, cn;
function ln() {
	return cn ??= import("./video-background-B_8_In0u.js").catch((e) => {
		throw cn = void 0, e;
	}), cn;
}
var un;
function dn() {
	return un ??= typeof OffscreenCanvas < "u" && typeof VideoFrame < "u" && typeof createImageBitmap < "u" && !!document.createElement("canvas").getContext("webgl2") && ("MediaStreamTrackProcessor" in window || "captureStream" in HTMLCanvasElement.prototype), un;
}
function fn(e) {
	if (/^(https?:|data:|blob:)/.test(e)) return e;
	let t = foundry.utils?.getRoute, n = e.replace(/^\/+/, "");
	return typeof t == "function" ? t(n) : `/${n}`;
}
async function pn(e) {
	let t = new Image();
	t.crossOrigin = "anonymous", t.src = e;
	try {
		await t.decode();
	} catch (t) {
		throw new on(`Unable to load ${e}`, { cause: t });
	}
}
function mn(e) {
	return e.mode === "image" ? {
		mode: "virtual-background",
		imagePath: e.url
	} : {
		mode: "background-blur",
		blurRadius: Math.max(6, Math.round(sn * e.strength))
	};
}
async function hn(e, t) {
	let n = e?.getProcessor();
	vn(n) && n.mode === "background-blur" && await n.switchTo(mn({
		mode: "blur",
		strength: t,
		quality: rn.get(n) ?? "standard"
	}));
}
async function gn(e) {
	let t = e.imageSegmenter, n = e.canvas?.getContext("webgl2");
	if (!t || !n) return;
	let r = t.getLabels().map((e) => e.toLowerCase()), i = r.indexOf("background");
	tn.debug("Segmenter labels:", r);
	let a = new Zt(n, i < 0);
	try {
		await t.setOptions({
			outputCategoryMask: !1,
			outputConfidenceMasks: !0
		});
	} catch (e) {
		throw a.dispose(), e;
	}
	let o = t.segmentForVideo.bind(t);
	return t.segmentForVideo = ((e, t, n) => {
		o(e, t, (e) => {
			let t = e.confidenceMasks ?? [], r = i < 0 ? t.at(-1) : t[i];
			if (!r) {
				n(e);
				return;
			}
			let o = a.update(r.getAsWebGLTexture(), r.width, r.height);
			n({
				categoryMask: { getAsWebGLTexture: () => o },
				close: () => {
					e.close();
				}
			});
		});
	}), () => {
		a.dispose();
	};
}
async function _n(e) {
	let t = globalThis, n = foundry.packages?.Module;
	if (!("Module" in t) || n === void 0) return e();
	t.Module = void 0;
	try {
		return await e();
	} finally {
		t.Module = n;
	}
}
function vn(e) {
	return !!e && "switchTo" in e && typeof e.switchTo == "function";
}
async function yn(e, t) {
	let n = e.getProcessor();
	if (t.mode === "none") {
		n && await e.stopProcessor();
		return;
	}
	if (t.mode === "image" && await pn(t.url), vn(n) && rn.get(n) === t.quality) {
		await n.switchTo(mn(t));
		return;
	}
	let { BackgroundProcessor: r } = await ln(), i = r({
		...mn(t),
		assetPaths: {
			tasksVisionFileSet: b("mediapipe"),
			modelAssetPath: b(nn[t.quality])
		}
	}, "livekit-video-background");
	rn.set(i, t.quality);
	let a = i.transformer, o = a.init.bind(a), s = a.destroy.bind(a), c;
	a.init = async (e) => {
		await _n(() => o(e)), c = await gn(a).catch((e) => {
			tn.warn("Unable to steady the camera background mask:", e);
		});
	}, a.destroy = async (e) => {
		c?.(), c = void 0, await s(e);
	}, await e.setProcessor(i);
}
//#endregion
//#region src/ui/videoBackgroundControl.ts
var bn = new y("videoBackgroundControl");
function xn({ name: e, client: t, showQuality: n = !1 }) {
	let r = A("div", { className: "livekit-video-background" }), i = () => {
		r.replaceChildren(...o());
	}, a = (e, t) => game.settings?.set(g, e, t).then(i).catch((e) => {
		bn.error("Error changing the camera background:", e);
	}), o = () => {
		let r = dn(), i = r ? game.settings?.get("avclient-livekit", "videoBackground") ?? "none" : "none", o = game.settings?.get("avclient-livekit", "videoBackgroundImage") ?? "", s = i === "image" && t?.failedVideoBackgroundImage === fn(o), c = r ? t?.videoBackgroundFailed && i !== "none" ? I("videoBackgroundFailedHint") : I(s ? "videoBackgroundImageFailedHint" : "videoBackgroundHint") : I("videoBackgroundUnsupported");
		return [
			L({
				label: I("videoBackground"),
				hint: c,
				control: At({
					name: e,
					label: I("videoBackground"),
					value: i,
					options: [
						{
							value: "none",
							label: I("videoBackgroundNone")
						},
						{
							value: "blur",
							label: I("videoBackgroundBlur"),
							disabled: !r
						},
						{
							value: "image",
							label: I("videoBackgroundImage"),
							disabled: !r
						}
					],
					onChange: (e) => void a("videoBackground", e)
				})
			}),
			...i === "blur" ? [Sn(t)] : [],
			...i === "image" ? [Cn(o, a)] : [],
			...n && i !== "none" ? [L({
				label: I("videoBackgroundQuality"),
				hint: I("videoBackgroundQualityHint"),
				control: At({
					name: `${e}-quality`,
					label: I("videoBackgroundQuality"),
					value: game.settings?.get("avclient-livekit", "videoBackgroundQuality") ?? "high",
					options: [{
						value: "standard",
						label: I("videoBackgroundQualityStandard")
					}, {
						value: "high",
						label: I("videoBackgroundQualityHigh")
					}],
					onChange: (e) => void a("videoBackgroundQuality", e)
				})
			})] : []
		];
	};
	return i(), r;
}
function Sn(e) {
	let t = game.settings?.get("avclient-livekit", "videoBlurStrength") ?? .5;
	return jt({
		label: I("videoBlurStrength"),
		min: 10,
		max: 100,
		step: 5,
		value: Math.round(t * 100),
		format: (e) => `${Math.round(e).toString()}%`,
		onInput: (t) => {
			e?.previewVideoBlur(t / 100);
		},
		onChange: (e) => {
			game.settings?.set(g, "videoBlurStrength", e / 100).catch((e) => {
				bn.error("Error changing the blur strength:", e);
			});
		}
	});
}
function Cn(e, t) {
	let n = game.settings?.get("avclient-livekit", "videoBackgroundCustomImage") ?? "", r = [...an.map((e) => ({
		path: e.path,
		label: I(e.label)
	})), ...n ? [{
		path: n,
		label: I("videoBackgroundCustom")
	}] : []], i = A("button", {
		className: "livekit-background-choice livekit-background-pick",
		attrs: {
			type: "button",
			"aria-label": I("videoBackgroundPick")
		},
		children: [N("fa-plus")]
	});
	return M(i, I("videoBackgroundPick")), i.addEventListener("click", () => {
		wn(n || e).then(async (e) => {
			e && (await game.settings?.set(g, "videoBackgroundCustomImage", e), await t("videoBackgroundImage", e));
		});
	}), A("div", {
		className: "livekit-background-choices",
		attrs: {
			role: "group",
			"aria-label": I("videoBackgroundImage")
		},
		children: [...r.map((n) => {
			let r = A("button", {
				className: "livekit-background-choice",
				attrs: {
					type: "button",
					"aria-label": n.label,
					"aria-pressed": String(n.path === e)
				},
				children: [A("img", { attrs: {
					src: fn(n.path),
					alt: "",
					loading: "lazy",
					draggable: "false"
				} })]
			});
			return M(r, n.label), r.addEventListener("click", () => {
				t("videoBackgroundImage", n.path);
			}), r;
		}), i]
	});
}
async function wn(e) {
	if (game.user?.can("FILES_BROWSE")) {
		let t = foundry.applications.apps.FilePicker.implementation;
		return new Promise((n) => {
			new t({
				type: "image",
				current: e,
				callback: (e) => {
					n(e);
				}
			}).render({ force: !0 });
		});
	}
	let t = A("input", { attrs: {
		type: "text",
		name: "url",
		placeholder: "https://…",
		value: e,
		"aria-label": I("videoBackgroundAddress")
	} }), n = await foundry.applications.api.DialogV2.prompt({
		window: { title: I("videoBackgroundPick") },
		content: A("div", { children: [A("p", { text: I("videoBackgroundAddressHint") }), t] }).outerHTML,
		ok: {
			label: I("videoBackgroundUse"),
			callback: (e, t) => t.form?.elements.namedItem("url")?.value
		},
		rejectClose: !1
	});
	return typeof n == "string" && n.trim() ? n.trim() : void 0;
}
//#endregion
//#region src/ui/AudioSettingsPopover.ts
var Tn = new y("AudioSettingsPopover"), En = class {
	client;
	popover = new zt("livekit-audio-settings", () => {
		this.meter?.stop(), this.client.previewVoiceGate();
	});
	meter;
	constructor(e) {
		this.client = e;
	}
	get isOpen() {
		return this.popover.isOpen;
	}
	toggle(e, t = e) {
		this.popover.isOpen ? this.popover.close() : this.open(e, t);
	}
	async open(e, t = e) {
		await this.render(), this.popover.openAt(e, t), this.meter?.start(this.client);
	}
	close() {
		this.popover.close();
	}
	async render() {
		let e = this.popover.isOpen;
		this.meter?.stop();
		let t = await this.renderDevices(), n = await this.renderVideo(), r = U({
			label: I("advancedSettings"),
			variant: "link",
			onClick: () => {
				this.close(), this.client.avMaster.config.render({ force: !0 }).catch((e) => {
					Tn.error("Error opening the A/V settings:", e);
				});
			}
		}), i = F("title");
		this.popover.element.setAttribute("aria-labelledby", i);
		let a = [
			A("h3", {
				className: "livekit-popover-title",
				text: I("voiceSettings"),
				attrs: { id: i }
			}),
			t,
			this.renderInputMode(),
			this.renderSensitivity(),
			this.renderNoiseSuppression(),
			n,
			A("footer", {
				className: "livekit-popover-footer",
				children: [r]
			})
		];
		this.popover.element.replaceChildren(...a.filter((e) => e !== !1)), this.popover.reposition(), e && this.meter?.start(this.client);
	}
	section(e, ...t) {
		return A("section", {
			className: "livekit-settings-section",
			children: [A("h4", { text: e }), ...t]
		});
	}
	async renderDevices() {
		let e = this.client.liveKitAvClient, [t, n] = await Promise.all([e.getAudioSources(), e.getAudioSinks()]), r = "setSinkId" in HTMLMediaElement.prototype, i = (e, t) => L({
			label: I(e),
			control: R({
				label: I(e),
				options: Dn(t, this.client.settings.client[e]),
				value: this.client.settings.client[e],
				onChange: (t) => {
					this.client.settings.set("client", e, t), e === "audioSink" && this.client.userAudioMixer.applyAll();
				}
			})
		});
		return this.section(I("devices"), i("audioSrc", t), r && i("audioSink", n));
	}
	async renderVideo() {
		if (!this.client.voiceControls.canUseCamera()) return !1;
		let e = await this.client.liveKitAvClient.getVideoSources(), t = this.client.settings.client.videoSrc;
		return this.section(I("settingsSection.video"), L({
			label: I("videoSrc"),
			control: R({
				label: I("videoSrc"),
				options: [...Dn(e, t).filter((e) => e.value !== "disabled"), {
					value: "disabled",
					label: I("deviceDisabled")
				}],
				value: t,
				onChange: (e) => {
					this.client.settings.set("client", "videoSrc", e);
				}
			})
		}), xn({
			name: "livekit-video-background",
			client: this.client
		}), z({
			label: I("receiveVideo"),
			checked: !this.client.settings.client.disableVideo,
			onChange: (e) => {
				this.client.settings.set("client", "disableVideo", !e);
			}
		}));
	}
	renderInputMode() {
		let e = this.client.settings.client.voice.mode, t = Nt();
		return this.section(I("inputMode"), At({
			name: "livekit-voice-mode",
			label: I("inputMode"),
			value: e,
			options: [{
				value: "always",
				label: I("inputModeVoiceActivity")
			}, {
				value: "ptt",
				label: I("inputModePushToTalk")
			}],
			onChange: (e) => {
				this.client.settings.set("client", "voice.mode", e), this.render();
			}
		}), e === "ptt" && !!t && L({
			label: I("pushToTalkKey"),
			inline: !0,
			control: Lt(t, (e) => {
				Pt(e).then(() => this.render()).catch((e) => {
					Tn.error("Error setting the push to talk key:", e);
				});
			})
		}));
	}
	renderSensitivity() {
		if (this.client.settings.client.voice.mode !== "always") return this.meter = void 0, !1;
		let e = this.client.getVoiceGateSettings(), t = A("span", {
			className: "livekit-meter-caption",
			text: `${e.threshold.toString()} dB`
		});
		return this.meter = new Kt({
			settings: e,
			onInput: (e) => {
				t.textContent = `${e.toString()} dB`, this.client.previewVoiceGate({
					auto: !1,
					threshold: e
				});
			},
			onChange: (e) => {
				game.settings?.set(g, "audioNoiseGateThreshold", e).then(() => {
					this.client.previewVoiceGate();
				}).catch((e) => {
					Tn.error("Error saving the input sensitivity:", e);
				});
			}
		}), this.section(I("inputSensitivity"), z({
			label: I("audioAutoSensitivity"),
			checked: e.auto,
			onChange: (e) => {
				game.settings?.set(g, "audioAutoSensitivity", e).then(() => this.render());
			}
		}), this.meter.element, A("p", {
			className: "livekit-setting-hint",
			text: I(e.auto ? "inputSensitivityAutoHint" : "inputSensitivityHint"),
			children: [!e.auto && t]
		}));
	}
	renderNoiseSuppression() {
		let e = this.client.getNoiseModelOptions(), t = (e) => z({
			label: I(e),
			checked: game.settings?.get("avclient-livekit", e) ?? !1,
			onChange: (t) => {
				game.settings?.set(g, e, t).then(() => this.render());
			}
		});
		return this.section(I("noiseSuppressionModel"), R({
			label: I("noiseSuppressionModel"),
			options: On(e),
			value: e.find((e) => e.selected)?.model ?? "none",
			onChange: (e) => {
				this.client.selectNoiseModel(e).then(() => this.render()).catch((e) => {
					Tn.error("Error selecting the noise suppression model:", e);
				});
			}
		}), t("audioEchoCancellation"), t("audioAutoGainControl"));
	}
};
function Dn(e, t) {
	let n = Object.entries(e).map(([e, t]) => ({
		value: e,
		label: t
	}));
	return t && !(t in e) && n.push({
		value: t,
		label: t === "disabled" ? I("deviceDisabled") : t
	}), n;
}
function On(e) {
	return e.map((e) => ({
		value: e.model,
		label: e.detail ? `${e.label} (${e.detail})` : e.label,
		disabled: !e.selectable
	}));
}
//#endregion
//#region src/LiveKitAVConfig.ts
var G = new y("LiveKitAVConfig");
function kn() {
	return Object.getPrototypeOf(foundry.applications.settings.menus.AVConfig.prototype);
}
var An = class e extends foundry.applications.settings.menus.AVConfig {
	static DEFAULT_OPTIONS = {
		tag: "form",
		id: "av-config",
		classes: ["livekit-settings-app"],
		window: {
			title: "LIVEKITAVCLIENT.settingsWindowTitle",
			icon: "fa-solid fa-headset",
			resizable: !0
		},
		position: {
			width: 860,
			height: 640
		},
		form: {
			closeOnSubmit: !1,
			handler: e.#e
		}
	};
	static PARTS = { content: { template: "modules/avclient-livekit/templates/settings.hbs" } };
	static TABS = {};
	data;
	activeSection = "voice";
	meter;
	dirtyTracking = !1;
	get liveKitClient() {
		return game.webrtc?.client._liveKitClient;
	}
	async _prepareContext(e) {
		let t = await kn()._prepareContext.call(this, e), n = game.webrtc?.client, [r, i, a] = await Promise.all([
			n?.getAudioSources() ?? {},
			n?.getAudioSinks() ?? {},
			n?.getVideoSources() ?? {}
		]), o = game.settings?.get("avclient-livekit", "liveKitConnectionSettings") ?? {}, s;
		if (game.user?.isGM && o.serverType === "tavern") {
			let e = game.settings.get(g, "authServer"), t = game.settings.get(g, "tavernPatreonToken");
			e && t && (s = await wt(e, t));
		}
		return this.data = {
			audioSources: r,
			audioSinks: i,
			videoSources: a,
			connectionSettings: o,
			authResponse: s
		}, t;
	}
	async _preparePartContext(e, t, n) {
		return kn()._preparePartContext.call(this, e, t, n);
	}
	_onChangeForm(e, t) {
		kn()._onChangeForm.call(this, e, t);
	}
	async _onRender(e, t) {
		await kn()._onRender.call(this, e, t), this.meter?.stop(), this.liveKitClient?.previewVoiceGate();
		let n = this.element.querySelector("[data-livekit-settings]");
		if (!(n instanceof HTMLElement) || !this.data) return;
		j(n);
		let r = game.user?.isGM ?? !1, i = this.sections().filter((e) => r || !e.gmOnly);
		i.some((e) => e.id === this.activeSection) || (this.activeSection = i[0].id);
		let a = /* @__PURE__ */ new Map(), o = /* @__PURE__ */ new Map(), s = A("nav", {
			className: "livekit-settings-nav",
			attrs: { "aria-label": I("settingsWindowTitle") }
		});
		for (let e of ["user", "world"]) {
			let t = i.filter((t) => t.gmOnly === (e === "world"));
			if (t.length) {
				s.append(A("h3", {
					className: "livekit-settings-nav-header",
					text: I(e === "world" ? "settingsGroupWorld" : "settingsGroupUser")
				}));
				for (let e of t) {
					let t = A("button", {
						className: "livekit-settings-nav-item",
						attrs: { type: "button" },
						children: [N(e.icon), A("span", { text: I(`settingsSection.${e.id}`) })]
					});
					t.addEventListener("click", () => {
						this.showSection(e.id, a, o);
					}), a.set(e.id, t), s.append(t);
				}
			}
		}
		let c = A("div", { className: "livekit-settings-content" });
		for (let e of i) {
			let t = A("section", {
				className: "livekit-settings-pane",
				children: [A("h2", { text: I(`settingsSection.${e.id}`) }), ...e.build()]
			});
			o.set(e.id, t), c.append(t);
		}
		let l = A("div", {
			className: "livekit-unsaved-bar",
			attrs: {
				hidden: "",
				role: "status"
			},
			children: [A("span", { text: I("unsavedChanges") }), A("div", {
				className: "livekit-unsaved-actions",
				children: [U({
					label: I("unsavedReset"),
					variant: "link",
					onClick: () => {
						this.render();
					}
				}), U({
					label: I("unsavedSave"),
					variant: "primary",
					type: "submit"
				})]
			})]
		});
		if (!this.dirtyTracking) {
			this.dirtyTracking = !0;
			let e = () => {
				let e = this.element.querySelector(".livekit-unsaved-bar");
				e instanceof HTMLElement && (e.hidden = !1);
			};
			this.element.addEventListener("input", e), this.element.addEventListener("change", e);
		}
		n.replaceChildren(s, A("div", {
			className: "livekit-settings-main",
			children: [c, l]
		})), this.showSection(this.activeSection, a, o), this.liveKitClient && this.meter?.start(this.liveKitClient);
	}
	_onClose(e) {
		this.meter?.stop(), this.meter = void 0, this.liveKitClient?.previewVoiceGate(), super._onClose(e);
	}
	showSection(e, t, n) {
		this.activeSection = e;
		for (let [n, r] of t) r.classList.toggle("is-selected", n === e), r.setAttribute("aria-current", n === e ? "page" : "false");
		for (let [t, r] of n) r.hidden = t !== e;
	}
	sections() {
		return [
			{
				id: "voice",
				icon: "fa-microphone",
				gmOnly: !1,
				build: () => this.buildVoice()
			},
			{
				id: "noise",
				icon: "fa-wand-magic-sparkles",
				gmOnly: !1,
				build: () => this.buildNoise()
			},
			{
				id: "video",
				icon: "fa-video",
				gmOnly: !1,
				build: () => this.buildVideo()
			},
			{
				id: "appearance",
				icon: "fa-palette",
				gmOnly: !1,
				build: () => this.buildAppearance()
			},
			{
				id: "advanced",
				icon: "fa-sliders",
				gmOnly: !1,
				build: () => this.buildAdvanced()
			},
			{
				id: "server",
				icon: "fa-server",
				gmOnly: !0,
				build: () => this.buildServer()
			},
			{
				id: "players",
				icon: "fa-users",
				gmOnly: !0,
				build: () => this.buildPlayerOptions()
			},
			{
				id: "troubleshooting",
				icon: "fa-bug",
				gmOnly: !0,
				build: () => this.buildTroubleshooting()
			}
		];
	}
	moduleSwitch(e, { disabled: t = !1, hint: n, label: r } = {}) {
		return z({
			name: `${g}.${e}`,
			label: r ?? I(e),
			hint: n ?? jn(e),
			checked: game.settings?.get(g, e) === !0,
			disabled: t
		});
	}
	clientSwitch(e) {
		return z({
			name: `core.rtcClientSettings.${e}`,
			label: I(`clientSetting.${e}`),
			hint: jn(`clientSetting.${e}`),
			checked: game.webrtc?.settings.client[e] === !0
		});
	}
	group(e, ...t) {
		return A("div", {
			className: "livekit-settings-group",
			children: [A("h4", { text: e }), ...t]
		});
	}
	buildVoice() {
		let e = this.data, t = game.webrtc?.settings.client;
		if (!e || !t) return [];
		let n = (e, n, r) => L({
			label: I(e),
			control: R({
				name: `core.rtcClientSettings.${e}`,
				label: I(e),
				options: [...Dn(n, t[e]).filter((e) => e.value !== "disabled"), ...r ? [{
					value: "disabled",
					label: I("deviceDisabled")
				}] : []],
				value: t[e]
			})
		}), r = Nt(), i = A("input", { attrs: {
			type: "hidden",
			name: "livekit.pushToTalkKey",
			value: ""
		} }), a = A("div", {
			className: "livekit-settings-subgroup",
			children: [
				!!r && L({
					label: I("pushToTalkKey"),
					inline: !0,
					control: Lt(r, (e) => {
						i.value = e, i.dispatchEvent(new Event("change", { bubbles: !0 }));
					})
				}),
				i,
				jt({
					name: "core.rtcClientSettings.voice.pttDelay",
					label: I("pushToTalkDelay"),
					min: 0,
					max: 2e3,
					step: 10,
					value: t.voice.pttDelay,
					format: (e) => `${e.toString()} ms`
				}),
				A("p", {
					className: "livekit-setting-hint livekit-slider-hint",
					text: I("pushToTalkDelayHint")
				})
			]
		}), o = this.liveKitClient?.getVoiceGateSettings() ?? {
			auto: !0,
			threshold: -50
		}, s = A("span", {
			className: "livekit-meter-caption",
			text: `${o.threshold.toString()} dB`
		}), c = A("p", { className: "livekit-setting-hint" }), l = () => {
			this.meter?.setAuto(o.auto), c.replaceChildren(I(o.auto ? "inputSensitivityAutoHint" : "inputSensitivityHint"), o.auto ? "" : s);
		}, u = () => {
			this.liveKitClient?.previewVoiceGate({ ...o }), l();
		};
		this.meter = new Kt({
			name: `${g}.audioNoiseGateThreshold`,
			settings: o,
			onInput: (e) => {
				s.textContent = `${e.toString()} dB`, o.threshold = e, u();
			}
		});
		let d = this.moduleSwitch("audioAutoSensitivity");
		d.querySelector("input")?.addEventListener("change", (e) => {
			o.auto = e.currentTarget.checked, u();
		});
		let f = this.group(I("inputSensitivity"), d, this.meter.element, c);
		l();
		let p = (e) => {
			a.hidden = e !== "ptt", f.hidden = e !== "always";
		}, m = At({
			name: "core.rtcClientSettings.voice.mode",
			label: I("inputMode"),
			value: t.voice.mode,
			options: [{
				value: "always",
				label: I("inputModeVoiceActivity")
			}, {
				value: "ptt",
				label: I("inputModePushToTalk")
			}],
			onChange: p
		});
		return p(t.voice.mode), [
			this.group(I("devices"), n("audioSrc", e.audioSources, !0), "setSinkId" in HTMLMediaElement.prototype && n("audioSink", e.audioSinks, !1)),
			this.group(I("inputMode"), m, a),
			f
		];
	}
	buildNoise() {
		let e = this.liveKitClient;
		if (!e) return [];
		let t = e.getNoiseModelOptions(), n = !!e.getAudioProcessingConfig().model;
		return [this.group(I("noiseSuppressionModel"), L({
			label: I("noiseSuppressionModel"),
			hint: I("noiseSuppressionModelHint"),
			control: R({
				name: "livekit.noiseModel",
				label: I("noiseSuppressionModel"),
				options: On(t),
				value: t.find((e) => e.selected)?.model ?? "none"
			})
		}), this.moduleSwitch("audioEchoCancellation"), this.moduleSwitch("audioAutoGainControl"), this.moduleSwitch("audioNoiseSuppression", { hint: n ? I("audioNoiseSuppressionModelActive") : void 0 })), this.group(I("audioQuality"), L({
			label: I("audioQualityPreset"),
			hint: I("audioQualityPresetHint"),
			control: R({
				name: `${g}.audioQualityPreset`,
				label: I("audioQualityPreset"),
				options: [
					"telephone",
					"speech",
					"music",
					"musicStereo",
					"musicHighQuality",
					"musicHighQualityStereo"
				].map((e) => ({
					value: e,
					label: I(`audioQualityPreset${e.charAt(0).toUpperCase()}${e.slice(1)}`)
				})),
				value: game.settings?.get("avclient-livekit", "audioQualityPreset") ?? "speech"
			})
		}), this.moduleSwitch("audioMusicMode"))];
	}
	buildVideo() {
		let e = this.data, t = game.webrtc?.settings.client;
		return !e || !t ? [] : [
			this.group(I("devices"), L({
				label: I("videoSrc"),
				control: R({
					name: "core.rtcClientSettings.videoSrc",
					label: I("videoSrc"),
					options: [...Dn(e.videoSources, t.videoSrc).filter((e) => e.value !== "disabled"), {
						value: "disabled",
						label: I("deviceDisabled")
					}],
					value: t.videoSrc
				})
			})),
			this.group(I("videoEffects"), xn({
				name: `${g}.videoBackground`,
				client: this.liveKitClient,
				showQuality: !0
			})),
			this.group(I("videoReceiving"), z({
				name: "livekit.showVideo",
				label: I("receiveVideo"),
				checked: !t.disableVideo
			}))
		];
	}
	buildAppearance() {
		let e = game.webrtc?.settings.client;
		if (!e) return [];
		let t = game.settings?.get("avclient-livekit", "allowDiscordStyleUI") ?? !0;
		return [this.group(I("appearanceInterface"), this.moduleSwitch("discordStyleUI", {
			disabled: !t,
			hint: t ? void 0 : I("discordStyleUIDisabledByGM")
		}), this.moduleSwitch("displayConnectionQuality")), this.buildDock(e)];
	}
	buildDock(e) {
		let t = !!this.liveKitClient?.dock, n = t && game.settings?.get("avclient-livekit", "dockFloating").floating === !0;
		return this.group(I("appearanceDock"), L({
			label: I("clientSetting.dockPosition"),
			control: R({
				name: "livekit.dockPlacement",
				label: I("clientSetting.dockPosition"),
				options: [...[
					"left",
					"right",
					"top",
					"bottom"
				].map((e) => ({
					value: e,
					label: I(`dockPosition.${e}`)
				})), ...t ? [{
					value: "float",
					label: I("dockFloating")
				}] : []],
				value: n ? "float" : e.dockPosition
			})
		}), t && L({
			label: I("dockLayoutTitle"),
			control: R({
				name: "avclient-livekit.dockLayout",
				label: I("dockLayoutTitle"),
				options: [
					"grid",
					"focus",
					"compact"
				].map((e) => ({
					value: e,
					label: I(`dockLayout.${e}`)
				})),
				value: game.settings?.get("avclient-livekit", "dockLayout") ?? "grid"
			})
		}), t && this.moduleSwitch("dockFollowSpeaker", {
			label: I("dockFollowSpeaker"),
			hint: I("dockFollowSpeakerHint")
		}), t && this.moduleSwitch("voicePanelInDock", {
			label: I("voicePanelInDock"),
			hint: I("voicePanelInDockHint")
		}), L({
			label: I("clientSetting.nameplates"),
			control: R({
				name: "core.rtcClientSettings.nameplates",
				label: I("clientSetting.nameplates"),
				dtype: "Number",
				options: [
					"off",
					"both",
					"playerOnly",
					"characterOnly"
				].map((e, t) => ({
					value: t.toString(),
					label: I(`nameplates.${e}`)
				})),
				value: String(e.nameplates)
			})
		}), this.clientSwitch("borderColors"), this.clientSwitch("hideDock"), this.clientSwitch("hidePlayerList"));
	}
	buildAdvanced() {
		return [this.group(I("advancedConnection"), this.moduleSwitch("useExternalAV"))];
	}
	buildServer() {
		let e = this.data, t = game.webrtc?.settings.world;
		if (!e || !t) return [];
		let n = e.connectionSettings, r = this.liveKitClient?.liveKitServerTypes ?? {}, i = L({
			label: I("avMode"),
			hint: I("avModeHint"),
			control: R({
				name: "core.rtcWorldSettings.mode",
				label: I("avMode"),
				dtype: "Number",
				options: [
					"disabled",
					"audio",
					"video",
					"audioVideo"
				].map((e, t) => ({
					value: t.toString(),
					label: I(`avModeOption.${e}`)
				})),
				value: String(t.mode)
			})
		}), a = (e, t) => L({
			label: I(`connection.${e}`),
			hint: jn(`connection.${e}`),
			control: Ot({
				type: t,
				name: `${g}.liveKitConnectionSettings.${e}`,
				value: n[e] ?? "",
				attrs: { autocomplete: t === "password" ? "one-time-code" : "off" }
			})
		}), o = A("div", {
			className: "livekit-settings-subgroup",
			children: [
				a("url", "text"),
				a("username", "text"),
				a("password", "password")
			]
		}), s = this.buildTavernAccount(), c = n.serverType, l = (e) => {
			o.hidden = e !== "custom", s.hidden = e !== "tavern", s.classList.toggle("unsaved", c !== "tavern");
		}, u = R({
			name: `${g}.liveKitConnectionSettings.serverType`,
			label: I("serverType"),
			options: Object.values(r).map((e) => ({
				value: e.key,
				label: game.i18n?.localize(e.label) ?? e.key
			})),
			value: c ?? "custom",
			onChange: l
		});
		return l(c ?? "custom"), [this.group(I("serverGroupAV"), i), this.group(I("serverGroupConnection"), L({
			label: I("serverType"),
			hint: I("serverTypeNotes"),
			control: u
		}), o, s)];
	}
	buildTavernAccount() {
		let e = game.settings?.get("avclient-livekit", "tavernPatreonToken") ?? "", t = game.settings?.get("avclient-livekit", "authServer") ?? "", n = this.data?.authResponse, r = A("p", { className: "livekit-setting-hint" });
		n && "error" in n ? r.textContent = `${I("patreonAccountError")}: ${n.error}` : n && r.append(`${I("patreonAccountNote")}: ${n.vanity ?? n.full_name ?? ""} (`, A("a", {
			text: n.active_tier ?? I("patreonAccountNotMember"),
			attrs: {
				href: "https://www.patreon.com/tavern_at",
				target: "_blank"
			}
		}), ")");
		let i = L({
			label: I("tavernAccountToken"),
			hint: I("tavernAccountTokenHint"),
			control: Ot({
				type: "password",
				name: `${g}.tavernPatreonToken`,
				value: e
			})
		}), a = A("i", {
			className: "fa-brands fa-patreon",
			attrs: { "aria-hidden": "true" }
		}), o = U(e ? {
			label: I("tavernAccountLogoutLabel"),
			icon: a,
			onClick: () => {
				this._patreonLogout(t).catch((e) => {
					G.error("Error logging out of Patreon account", e);
				});
			}
		} : {
			label: I("tavernAccountPatreonLabel"),
			variant: "patreon",
			icon: a,
			onClick: () => {
				this.patreonLogin(t), i.hidden = !1;
			}
		});
		return i.hidden = !0, A("div", {
			className: "livekit-settings-subgroup livekit-tavern",
			children: [
				L({
					label: I("tavernAccountLabel"),
					hint: e ? r : I("tavernAccountPatreonHint"),
					control: o,
					inline: !0
				}),
				A("p", {
					className: "livekit-setting-hint livekit-tavern-unsaved",
					text: I("tavernSaveFirst")
				}),
				i
			]
		});
	}
	buildPlayerOptions() {
		return [this.group(I("playerOptions"), this.moduleSwitch("allowDiscordStyleUI"), this.moduleSwitch("allowKrisp"), L({
			label: I("defaultNoiseModel"),
			hint: I("defaultNoiseModelHint"),
			control: R({
				name: `${g}.defaultNoiseModel`,
				label: I("defaultNoiseModel"),
				options: [
					"none",
					"speex",
					"rnnoise",
					"gtcrn",
					"krisp"
				].map((e) => ({
					value: e,
					label: I(`noiseSuppressionModel${e.charAt(0).toUpperCase()}${e.slice(1)}`)
				})),
				value: game.settings?.get("avclient-livekit", "defaultNoiseModel") ?? "gtcrn"
			})
		}))];
	}
	buildTroubleshooting() {
		let e = game.settings?.get("avclient-livekit", "debug") ?? !1, t = game.settings?.get("avclient-livekit", "devMode") ?? !1, n = U({
			label: I("resetRoomButton"),
			variant: "danger",
			onClick: () => {
				game.settings?.set(g, "resetRoom", !0).then(() => {
					ui.notifications?.info(I("resetRoomDone"));
				}).catch((e) => {
					G.error("Error resetting the meeting room", e);
				});
			}
		}), r = this.moduleSwitch("debug"), i = this.moduleSwitch("liveKitTrace", {
			disabled: !e,
			hint: e ? void 0 : I("liveKitTraceNeedsDebug")
		});
		return r.querySelector("input")?.addEventListener("change", (e) => {
			let t = e.currentTarget.checked, n = i.querySelector("input");
			n && (n.disabled = !t), i.classList.toggle("disabled", !t);
		}), [
			this.group(I("troubleshootingRoom"), L({
				label: I("resetRoom"),
				hint: I("resetRoomHint"),
				control: n,
				inline: !0
			})),
			this.group(I("troubleshootingLogging"), r, i),
			t && this.group(I("troubleshootingDeveloper"), !1, t && this.moduleSwitch("forceTurn"), t && L({
				label: I("authServer"),
				hint: I("authServerHint"),
				control: Ot({
					name: "avclient-livekit.authServer",
					value: game.settings?.get("avclient-livekit", "authServer") ?? ""
				})
			}))
		];
	}
	patreonLogin(e) {
		if (!game.user?.isGM || !e) {
			G.error("Auth server is not set");
			return;
		}
		let t = btoa(`{"host": "${window.location.hostname}", "world": "${game.world.id}"}`);
		window.addEventListener("message", (e) => {
			this._patreonLoginListener(e).catch((e) => {
				G.error("Error logging in to Patreon account", e);
			});
		}, { once: !0 }), window.open(`${e}/auth/patreon?id=${t}&clientRole=participant`, void 0, "width=600,height=800");
	}
	async _patreonLogout(e) {
		if (!game.user?.isGM) return;
		let t = game.settings.get(g, "tavernPatreonToken"), n = await fetch(`${e}/logout`, {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify({ id: t })
		});
		n.ok || (ui.notifications?.error(`${_}.liveKitAccountLogoutError`, { localize: !0 }), G.warn("Error signing out of Patreon account", n)), t = "", await game.settings.set(g, "tavernPatreonToken", t), ge();
	}
	async _patreonLoginListener(e) {
		if (!game.user?.isGM) return;
		let t = game.settings.get(g, "authServer");
		if (e.origin !== t) return;
		e.preventDefault();
		let n = e.data.id;
		await game.settings.set(g, "tavernPatreonToken", n), ge();
	}
	static async #e(e, t, n) {
		let r = game.webrtc?.settings;
		if (!r) {
			G.error("WebRTC settings not found");
			return;
		}
		let i = foundry.utils.expandObject(n.object).core, a = foundry.utils.expandObject(n.object)["avclient-livekit"], o = foundry.utils.expandObject(n.object).livekit;
		if (o?.showVideo !== void 0 && (i.rtcClientSettings.disableVideo = !o.showVideo), o?.dockPlacement) {
			let e = o.dockPlacement === "float";
			e || (i.rtcClientSettings.dockPosition = o.dockPlacement), game.webrtc?.client._liveKitClient.dock && (a.dockFloating = { floating: e });
		}
		let s = game.webrtc?.client._liveKitClient, c = s?.getSelectedNoiseModel(), l = [];
		if (game.user?.isGM) {
			let e = foundry.utils.mergeObject(r.world, i.rtcWorldSettings, { inplace: !1 });
			r.world.mode !== e.mode && foundry.applications.settings.SettingsConfig.reloadConfirm({ world: !0 }), l.push(game.settings.set("core", "rtcWorldSettings", e));
		}
		let u = foundry.utils.mergeObject(r.client, i.rtcClientSettings, { inplace: !1 });
		game.settings && l.push(game.settings.set("core", "rtcClientSettings", u)), await Promise.all(l);
		let d = !1, f = !1;
		for (let [e, t] of Object.entries(a ?? {})) {
			let n = game.settings?.settings.get(`${g}.${e}`);
			if (!n) continue;
			let r = game.settings?.get(n.namespace, n.key, { document: !0 })._source.value;
			if (n.key === "liveKitConnectionSettings" || n.key === "dockFloating") {
				let e = game.settings?.get(n.namespace, n.key);
				t = foundry.utils.mergeObject(e, t, { inplace: !1 });
			}
			if (r === JSON.stringify(t)) continue;
			let i;
			try {
				i = await game.settings?.set(n.namespace, n.key, t, { document: !0 });
			} catch (e) {
				ui.notifications?.error(e);
			}
			r !== i?._source.value && (d ||= (n.scope !== "world" && n.requiresReload) ?? !1, f ||= (n.scope === "world" && n.requiresReload) ?? !1);
		}
		o?.noiseModel && s && o.noiseModel !== c && await s.selectNoiseModel(o.noiseModel), o?.pushToTalkKey && await Pt(o.pushToTalkKey), (d || f) && await foundry.applications.settings.SettingsConfig.reloadConfirm({ world: f }), await this.render();
	}
};
function jn(e) {
	let t = `${_}.${e}Hint`, n = game.i18n?.localize(t);
	return n && n !== t ? n : void 0;
}
//#endregion
//#region src/ui/Menu.ts
var Mn = new y("Menu"), Nn = ".livekit-menu-item:not(:disabled), .livekit-menu-custom :is(input, select, button):not(:disabled)", Pn = class {
	label;
	build;
	popover;
	constructor(e, t, n, r) {
		this.label = t, this.build = n, this.popover = new zt(`livekit-menu ${e}`, r, "menu"), this.popover.element.tabIndex = -1, this.popover.element.addEventListener("keydown", this.onKeyDown);
	}
	get element() {
		return this.popover.element;
	}
	get isOpen() {
		return this.popover.isOpen;
	}
	openAt(e, t = e) {
		this.render(), this.popover.openAt(e, t), this.element.focus({ preventScroll: !0 });
	}
	openAtPoint(e, t, n) {
		this.render(), this.popover.openAtPoint(e, t, n), this.element.focus({ preventScroll: !0 });
	}
	toggle(e, t = e) {
		this.isOpen ? this.close() : this.openAt(e, t);
	}
	close() {
		this.popover.close();
	}
	refresh() {
		if (!this.isOpen) return;
		let e = this.focusableItems().findIndex((e) => e === this.element.ownerDocument.activeElement);
		this.render(), this.popover.reposition(), e >= 0 && this.focusableItems()[e]?.focus({ preventScroll: !0 });
	}
	render() {
		this.element.ariaLabel = this.label(), this.element.replaceChildren(...this.build().map((e) => this.renderItem(e)));
	}
	renderItem(e) {
		switch (e.type) {
			case "header": return A("div", {
				className: "livekit-menu-header",
				text: e.label,
				attrs: { role: "presentation" }
			});
			case "separator": return A("div", {
				className: "livekit-menu-separator",
				attrs: { role: "separator" }
			});
			case "custom": return A("div", {
				className: "livekit-menu-custom",
				children: [e.element]
			});
		}
		let t = A("button", {
			className: "livekit-menu-item",
			attrs: {
				type: "button",
				tabindex: "-1"
			},
			children: [A("span", {
				className: "livekit-menu-item-text",
				children: [A("span", {
					className: "livekit-menu-item-label",
					text: e.label
				}), e.detail && A("span", {
					className: "livekit-menu-item-detail",
					text: e.detail
				})]
			})]
		});
		return t.disabled = !!e.disabled, e.type === "action" ? (t.setAttribute("role", "menuitem"), t.classList.toggle("is-danger", !!e.danger), e.icon && t.append(N(e.icon, "livekit-menu-item-icon"))) : (t.setAttribute("role", e.type === "radio" ? "menuitemradio" : "menuitemcheckbox"), t.setAttribute("aria-checked", String(e.checked)), t.classList.toggle("is-checked", e.checked), t.append(A("span", {
			className: `livekit-menu-${e.type}`,
			attrs: { "aria-hidden": "true" },
			children: [e.type === "checkbox" && N("fa-check")]
		}))), t.addEventListener("click", (t) => {
			t.preventDefault(), t.stopPropagation();
			let n = e.type !== "action" || !!e.keepOpen;
			n || this.close(), Promise.resolve(e.onSelect()).catch((e) => {
				Mn.error("Error choosing a menu item:", e);
			}).finally(() => {
				n && this.refresh();
			});
		}), t;
	}
	focusableItems() {
		return [...this.element.querySelectorAll(Nn)];
	}
	onKeyDown = (e) => {
		let t = this.focusableItems();
		if (!t.length) return;
		let n = this.element.ownerDocument.activeElement;
		if (n instanceof HTMLInputElement && n.type === "range" && (e.key === "Home" || e.key === "End")) return;
		let r = t.findIndex((e) => e === n), i;
		switch (e.key) {
			case "ArrowDown":
				i = r < 0 ? 0 : (r + 1) % t.length;
				break;
			case "ArrowUp":
				i = r < 0 ? t.length - 1 : r - 1, i < 0 && (i = t.length - 1);
				break;
			case "Home":
				i = 0;
				break;
			case "End":
				i = t.length - 1;
				break;
			default: return;
		}
		e.preventDefault(), e.stopPropagation(), t[i].focus({ preventScroll: !0 });
	};
}, Fn = "icons/svg/mystery-man.svg";
function K({ icon: e, label: t, slashed: n }) {
	return A("span", {
		className: `livekit-badge ${n ? "livekit-slashed" : ""}`.trim(),
		title: t,
		attrs: { role: "img" },
		children: [N(e)]
	});
}
var In = class {
	element;
	image = A("img", {
		className: "livekit-avatar-image",
		attrs: {
			alt: "",
			draggable: "false"
		}
	});
	badges = A("span", { className: "livekit-avatar-badges" });
	constructor({ src: e, size: t = "md", className: n = "" } = {}) {
		this.element = A("span", {
			className: `livekit-avatar livekit-avatar-${t} ${n}`.trim(),
			children: [this.image, this.badges]
		}), this.setSource(e);
	}
	setSource(e) {
		let t = e?.trim() ? e : Fn;
		this.image.getAttribute("src") !== t && this.image.setAttribute("src", t);
	}
	setSpeaking(e) {
		this.element.classList.toggle("is-speaking", e);
	}
	setBadges(e) {
		this.badges.replaceChildren(...e.map((e) => K(e)));
	}
}, Ln = class {
	userId;
	local;
	element;
	video;
	avatar = new In({ size: "fill" });
	name = A("span", { className: "livekit-tile-name" });
	secondaryName = A("span", { className: "livekit-tile-secondary" });
	badges = A("span", { className: "livekit-tile-badges" });
	quality = A("span", {
		className: "livekit-quality",
		attrs: { role: "img" },
		children: [
			A("span"),
			A("span"),
			A("span")
		]
	});
	muteButton;
	videoButton;
	constructor(e, t, n) {
		this.userId = e, this.local = t, this.video = A("video", {
			className: `user-camera ${t ? "local-camera" : ""}`.trim(),
			attrs: {
				autoplay: "",
				playsinline: ""
			}
		}), this.video.muted = !0;
		let r = A("div", { className: "livekit-tile-controls" });
		if (t) this.muteButton = V({
			icon: "fa-microphone",
			label: I("mute"),
			onClick: () => {
				n.toggleOwnMute();
			}
		}), this.videoButton = V({
			icon: "fa-video",
			label: I("cameraOff"),
			onClick: () => {
				n.toggleOwnVideo();
			}
		}), r.append(this.muteButton, this.videoButton);
		else {
			let t = V({
				icon: "fa-ellipsis",
				label: I("userOptions"),
				onClick: () => {
					let r = t.getBoundingClientRect();
					n.openMenu(e, r.left, r.bottom, t);
				}
			});
			t.setAttribute("aria-haspopup", "menu"), r.append(t);
		}
		this.element = A("div", {
			className: "livekit-tile",
			attrs: {
				"data-user": e,
				role: "listitem",
				tabindex: "0"
			},
			children: [
				A("div", {
					className: "livekit-tile-media",
					children: [this.video, A("div", {
						className: "livekit-tile-avatar",
						children: [this.avatar.element]
					})]
				}),
				A("div", { className: "livekit-tile-ring" }),
				r,
				A("div", {
					className: "livekit-tile-footer",
					children: [
						A("span", {
							className: "livekit-tile-names",
							children: [this.name, this.secondaryName]
						}),
						this.badges,
						this.quality
					]
				})
			]
		}), this.element.addEventListener("click", (t) => {
			t.target.closest("button") || n.activate(e);
		}), this.element.addEventListener("contextmenu", (t) => {
			t.preventDefault(), t.stopPropagation(), n.openMenu(e, t.clientX, t.clientY, this.element);
		}), this.element.addEventListener("keydown", (t) => {
			if (t.target === this.element) {
				if (t.key === "Enter" || t.key === " ") t.preventDefault(), n.activate(e);
				else if (t.key === "ContextMenu" || t.key === "F10" && t.shiftKey) {
					t.preventDefault();
					let r = this.element.getBoundingClientRect();
					n.openMenu(e, r.left, r.bottom, this.element);
				}
			}
		});
	}
	update(e, t) {
		let { user: n, nameplates: r } = e, i = r.charname ? e.charname : "", a = r.playerName || !i ? n.name : i;
		this.name.textContent = a, this.secondaryName.textContent = r.playerName && i ? i : "", this.element.classList.toggle("no-nameplate", r.hidden), this.element.ariaLabel = n.name, this.avatar.setSource(n.avatar), this.element.classList.toggle("is-video", t.showVideo), this.element.classList.toggle("is-focused", t.focused), this.element.classList.toggle("has-color", t.borderColor), this.element.style.setProperty("--lk-tile-color", Rn(n)), this.setSpeaking(t.speaking);
		let o = [];
		if (t.muted && o.push({
			icon: "fa-microphone-slash",
			label: I("muted")
		}), t.deafened && o.push({
			icon: "fa-headphones",
			label: I("deafened"),
			slashed: !0
		}), t.locallyMuted && o.push({
			icon: "fa-volume-xmark",
			label: I("userLocalMute")
		}), t.videoHiddenByMe ? o.push({
			icon: "fa-eye-slash",
			label: I("videoHiddenByMe")
		}) : t.cameraUsed && !e.hasVideo && o.push({
			icon: "fa-video-slash",
			label: I("cameraIsOff")
		}), this.badges.replaceChildren(...o.map((e) => K(e))), this.quality.dataset.quality = t.quality, M(this.quality, game.i18n?.localize(`LIVEKITAVCLIENT.connectionQuality.${t.quality}`) ?? t.quality), this.muteButton && H(this.muteButton, {
			icon: t.muted ? "fa-microphone-slash" : "fa-microphone",
			label: I(t.muted ? "unmute" : "mute"),
			off: t.muted,
			pressed: t.muted
		}), this.videoButton) {
			this.videoButton.hidden = !t.cameraUsed;
			let n = !e.hasVideo;
			H(this.videoButton, {
				icon: n ? "fa-video-slash" : "fa-video",
				label: I(n ? "cameraOn" : "cameraOff"),
				off: n,
				pressed: n
			});
		}
	}
	setSpeaking(e) {
		this.element.classList.toggle("is-speaking", e), this.avatar.setSpeaking(e);
	}
};
function Rn(e) {
	let t = e.color;
	return t && typeof t == "object" && t.css ? t.css : typeof t == "string" ? t : "transparent";
}
//#endregion
//#region src/ui/dock/DockWindow.ts
function zn() {
	return window.documentPictureInPicture;
}
function Bn() {
	return !!zn();
}
var Vn = class e {
	window;
	onClose;
	titled = /* @__PURE__ */ new Set();
	constructor(e, t) {
		this.window = e, this.onClose = t, Hn(e.document), e.addEventListener("pagehide", this.onPageHide, { once: !0 }), e.document.addEventListener("pointerover", this.onPointerOver);
		for (let t of ["keydown", "keyup"]) e.addEventListener(t, this.forwardPushToTalk);
	}
	static async open(t, n, r) {
		let i = zn();
		if (!i) return;
		let a = await i.requestWindow({
			width: Math.round(t.width),
			height: Math.round(t.height)
		});
		return a.document.title = n, new e(a, r);
	}
	get document() {
		return this.window.document;
	}
	close() {
		this.window.close();
	}
	onPageHide = () => {
		for (let e of this.titled) e.removeAttribute("title");
		this.titled.clear(), this.onClose();
	};
	onPointerOver = (e) => {
		let t = e.target, n = typeof t?.closest == "function" ? t.closest("[data-tooltip]") : null, r = n?.dataset.tooltip;
		n && r && n.title !== r && (n.title = r, this.titled.add(n));
	};
	forwardPushToTalk = (e) => {
		(Nt() ?? []).some((t) => t.key === e.code) && (document.body.dispatchEvent(new KeyboardEvent(e.type, {
			key: e.key,
			code: e.code,
			location: e.location,
			repeat: e.repeat,
			altKey: e.altKey,
			ctrlKey: e.ctrlKey,
			metaKey: e.metaKey,
			shiftKey: e.shiftKey,
			bubbles: !0,
			cancelable: !0
		})), e.preventDefault());
	};
};
function Hn(e) {
	let t = e.createElement("base");
	t.href = document.baseURI, e.head.append(t);
	for (let t of Array.from(document.styleSheets)) {
		if (t.href) {
			let n = e.createElement("link");
			n.rel = "stylesheet", n.href = t.href, t.media.mediaText && (n.media = t.media.mediaText), e.head.append(n);
			continue;
		}
		try {
			let n = e.createElement("style");
			n.textContent = Array.from(t.cssRules).map((e) => e.cssText).join("\n"), e.head.append(n);
		} catch {}
	}
	e.documentElement.className = document.documentElement.className;
	let n = document.documentElement.getAttribute("style");
	n && e.documentElement.setAttribute("style", n), e.body.className = `${document.body.className} livekit-dock-window`;
}
//#endregion
//#region src/ui/dock/drag.ts
var q = 8;
function Un(e) {
	let t = Math.min(e.width, window.innerWidth - 2 * q), n = Math.min(e.height, window.innerHeight - 2 * q);
	return {
		width: t,
		height: n,
		left: P(e.left, q, window.innerWidth - t - q),
		top: P(e.top, q, window.innerHeight - n - q)
	};
}
function Wn(e, t, n, r) {
	e.addEventListener("pointerdown", (i) => {
		if (i.button !== 0 || i.target.closest("button, input, select, a")) return;
		i.preventDefault();
		let a = i.clientX, o = i.clientY;
		e.setPointerCapture(i.pointerId), t();
		let s = (e) => {
			n(e.clientX - a, e.clientY - o);
		}, c = () => {
			e.removeEventListener("pointermove", s), e.removeEventListener("pointerup", c), e.removeEventListener("pointercancel", c), r();
		};
		e.addEventListener("pointermove", s), e.addEventListener("pointerup", c), e.addEventListener("pointercancel", c);
	});
}
function Gn(e, t, n) {
	let r;
	Wn(e, () => {
		r = t.getBoundingClientRect(), t.classList.add("dragging");
	}, (e, n) => {
		let i = Un({
			left: r.left + e,
			top: r.top + n,
			width: r.width,
			height: r.height
		});
		t.style.left = `${i.left.toString()}px`, t.style.top = `${i.top.toString()}px`;
	}, () => {
		t.classList.remove("dragging");
		let { left: e, top: r, width: i, height: a } = t.getBoundingClientRect();
		n({
			left: e,
			top: r,
			width: i,
			height: a
		});
	});
}
function Kn(e, t, { edges: n, minWidth: r, minHeight: i = 0, keepHeight: a = !1, onEnd: o }) {
	let s, c = [];
	Wn(e, () => {
		s = t.getBoundingClientRect(), c = n(), t.classList.add("resizing");
	}, (e, n) => {
		c.includes("right") && (t.style.width = `${Math.max(s.width + e, r).toString()}px`), c.includes("left") && (t.style.width = `${Math.max(s.width - e, r).toString()}px`), !a && c.includes("bottom") && (t.style.height = `${Math.max(s.height + n, i).toString()}px`), !a && c.includes("top") && (t.style.height = `${Math.max(s.height - n, i).toString()}px`);
	}, () => {
		t.classList.remove("resizing");
		let { left: e, top: n, width: r, height: i } = t.getBoundingClientRect();
		o({
			left: e,
			top: n,
			width: r,
			height: i
		});
	});
}
//#endregion
//#region src/ui/dock/TileWindow.ts
var qn = 160, Jn = class {
	tile;
	element;
	title = A("span", { className: "livekit-tile-window-title" });
	constructor(e, { left: t, top: n, width: r, onDock: i, onMove: a }) {
		this.tile = e;
		let o = A("header", {
			className: "livekit-tile-window-header",
			children: [this.title, V({
				icon: "fa-arrow-right-to-bracket",
				label: I("returnToDock"),
				onClick: i
			})]
		}), s = A("div", {
			className: "livekit-resize-handle",
			attrs: { "aria-hidden": "true" }
		});
		this.element = j(A("section", {
			className: "livekit-tile-window",
			attrs: { "data-user": e.userId },
			children: [o, s]
		}));
		let c = () => {
			let e = this.element.getBoundingClientRect();
			a({
				left: Math.round(e.left),
				top: Math.round(e.top),
				width: Math.round(e.width)
			});
		};
		Gn(o, this.element, c), Kn(s, this.element, {
			edges: () => ["right"],
			minWidth: qn,
			keepHeight: !0,
			onEnd: c
		});
		let l = Un({
			left: t ?? 100,
			top: n ?? 100,
			width: Math.max(r ?? 320, qn),
			height: 0
		});
		this.element.style.left = `${l.left.toString()}px`, this.element.style.top = `${l.top.toString()}px`, this.element.style.width = `${l.width.toString()}px`;
	}
	setTitle(e) {
		this.title.textContent = e, this.element.ariaLabel = e;
	}
}, Yn = new y("LiveKitCameraViews"), Xn = [
	{
		layout: "grid",
		icon: "fa-table-cells-large"
	},
	{
		layout: "focus",
		icon: "fa-expand"
	},
	{
		layout: "compact",
		icon: "fa-list"
	}
], Zn = [
	"left",
	"right",
	"top",
	"bottom"
], Qn = 160, $n = 640, er = {
	left: 0,
	top: 0,
	width: 240,
	height: 160
}, tr = 800, nr = 16 / 9, rr = 120, ir = foundry.applications.apps.av.CameraViews, ar = class extends ir {
	static DEFAULT_OPTIONS = {
		classes: ["livekit-dock"],
		window: { positioned: !1 }
	};
	tiles = /* @__PURE__ */ new Map();
	windows = /* @__PURE__ */ new Map();
	contexts = /* @__PURE__ */ new Map();
	focusUserId;
	focusPicked = !1;
	followTimer;
	built = !1;
	dockWindow;
	windowHost;
	contentRoot;
	contentNodes = [];
	title = A("span", { className: "livekit-dock-count" });
	stage = A("div", { className: "livekit-dock-stage" });
	list = A("div", {
		className: "livekit-dock-list",
		attrs: { role: "list" }
	});
	panelSlot = A("div", { className: "livekit-dock-panel" });
	resizeHandle = A("div", {
		className: "livekit-resize-handle",
		attrs: { "aria-hidden": "true" }
	});
	layoutButton = V({
		icon: "fa-table-cells-large",
		label: I("dockView"),
		onClick: () => {
			this.viewMenu.toggle(this.layoutButton);
		}
	});
	windowButton = V({
		icon: "fa-up-right-from-square",
		label: I("dockOpenWindow"),
		onClick: () => {
			this.setWindowed(!this.isWindowed);
		}
	});
	collapseButton = V({
		icon: "fa-chevron-left",
		label: I("dockCollapse"),
		onClick: () => {
			this.setCollapsed(!this.collapsed);
		}
	});
	viewMenu = new Pn("livekit-dock-menu", () => I("dockView"), () => this.viewMenuItems());
	listObserver = new ResizeObserver(() => {
		this.fitGrid();
	});
	get client() {
		return game.webrtc?.client._liveKitClient;
	}
	get layout() {
		let e = game.settings?.get(g, "dockLayout");
		return e === "focus" || e === "compact" ? e : "grid";
	}
	get floatingState() {
		return game.settings?.get("avclient-livekit", "dockFloating") ?? { floating: !1 };
	}
	get isFloating() {
		return this.floatingState.floating;
	}
	get isWindowed() {
		return !!this.dockWindow;
	}
	get collapsed() {
		return game.webrtc?.settings.client.hideDock === !0 && !this.isWindowed;
	}
	get dockPosition() {
		let e = game.webrtc?.settings.client.dockPosition;
		return Zn.find((t) => t === e) ?? "left";
	}
	get isVertical() {
		return !this.isFloating && !this.isWindowed && super.isVertical;
	}
	get isHorizontal() {
		return !this.isFloating && !this.isWindowed && super.isHorizontal;
	}
	getUserCameraView(e) {
		return this.tiles.get(e)?.element ?? null;
	}
	getUserVideoElement(e) {
		return this.tiles.get(e)?.video ?? null;
	}
	setUserIsSpeaking() {}
	_configureRenderParts() {
		return {};
	}
	_configureRenderOptions(e) {
		super._configureRenderOptions(e), e.parts = [];
	}
	_renderHTML() {
		return Promise.resolve({});
	}
	_replaceHTML(e, t) {
		this.built || this.build(t), this.sync();
	}
	async _onRender(e, t) {
		await super._onRender(e, t), this.place(), this.attachMedia(), this.client?.voicePanelIfCreated?.sync();
	}
	async _onFirstRender(e, t) {
		await super._onFirstRender(e, t), window.addEventListener("resize", this.onWindowResize);
	}
	onWindowResize = foundry.utils.debounce(() => {
		this.isFloating && this.place();
		for (let e of this.windows.values()) {
			let t = Un(e.element.getBoundingClientRect());
			e.element.style.left = `${t.left.toString()}px`, e.element.style.top = `${t.top.toString()}px`;
		}
	}, 100);
	build(e) {
		this.built = !0, j(this.element), this.element.setAttribute("role", "region"), this.element.ariaLabel = I("dock");
		let t = A("header", {
			className: "livekit-dock-header",
			children: [A("span", {
				className: "livekit-dock-title",
				children: [N("fa-volume-high"), this.title]
			}), A("div", {
				className: "livekit-dock-tools",
				children: [
					...Bn() ? [this.windowButton] : [],
					this.layoutButton,
					this.collapseButton
				]
			})]
		});
		this.layoutButton.setAttribute("aria-haspopup", "menu"), Gn(t, this.element, (e) => {
			this.isFloating && this.saveFloating(e);
		});
		let n = {
			left: "right",
			right: "left",
			top: "bottom",
			bottom: "top"
		};
		Kn(this.resizeHandle, this.element, {
			edges: () => this.isFloating ? ["right", "bottom"] : [n[this.dockPosition]],
			minWidth: Qn,
			minHeight: er.height,
			onEnd: (e) => {
				this.onResized(e);
			}
		}), t.addEventListener("pointerdown", (e) => {
			(!this.isFloating || this.isWindowed) && e.stopImmediatePropagation();
		}, { capture: !0 }), this.listObserver.observe(this.list), this.contentRoot = e, this.contentNodes = [
			t,
			A("div", {
				className: "livekit-dock-body",
				children: [this.stage, this.list]
			}),
			this.panelSlot,
			this.resizeHandle
		], e.replaceChildren(...this.contentNodes);
	}
	sync() {
		let e = this.client, t = game.webrtc?.client;
		if (!e || !t) return;
		let n = t.getConnectedUsers().map((e) => this._prepareUserContext(e)).filter((e) => !!e && !e.settings.blocked).sort((e, t) => ir._sortUsers(e, t));
		this.contexts.clear();
		for (let e of n) this.contexts.set(e.user.id ?? "", e);
		for (let [e, t] of this.tiles) this.contexts.has(e) || this.removeTile(e, t);
		(!this.focusUserId || !this.contexts.has(this.focusUserId)) && (this.focusPicked = !1), this.focusPicked || (this.focusUserId = this.defaultFocus(n));
		let r = new Map([[this.stage, this.stage.firstElementChild], [this.list, this.list.firstElementChild]]);
		for (let e of n) {
			let t = e.user.id ?? "", n = this.tiles.get(t);
			n || (n = new Ln(t, e.local, this.tileHost), this.tiles.set(t, n)), n.update(e, this.tileState(e)), this.placeTile(n, e, r);
		}
		let i = n.length;
		this.title.textContent = game.i18n?.format("LIVEKITAVCLIENT.dockCount", { count: i.toString() }) ?? i.toString(), this.element.dataset.count = i.toString(), this.updateTools(), this.fitGrid();
	}
	fitGrid() {
		let e = this.list, t = e.childElementCount;
		if (this.layout !== "grid" || this.collapsed || !t) {
			e.style.removeProperty("--lk-grid-columns"), e.style.removeProperty("--lk-tile-width");
			return;
		}
		let n = e.ownerDocument.defaultView ?? window, r = parseFloat(n.getComputedStyle(e).columnGap) || 0, i = e.clientWidth, a = e.clientHeight;
		if (!i || !a) return;
		let o = 1, s = 0;
		for (let e = 1; e <= t; e++) {
			let n = Math.ceil(t / e), c = Math.min((i - r * (e - 1)) / e, (a - r * (n - 1)) / n * nr);
			c > s && (o = e, s = c);
		}
		if (s < rr) if (this.isHorizontal) {
			let e = rr / nr, n = Math.max(1, Math.floor((a + r) / (e + r)));
			o = Math.ceil(t / n), s = (a - r * (n - 1)) / n * nr;
		} else o = Math.max(1, Math.floor((i + r) / (rr + r))), s = (i - r * (o - 1)) / o;
		e.style.setProperty("--lk-grid-columns", o.toString()), e.style.setProperty("--lk-tile-width", `${Math.max(Math.floor(s), 1).toString()}px`);
	}
	refresh() {
		this.rendered && this.built && this.sync();
	}
	setSpeaking(e, t) {
		this.tiles.get(e)?.setSpeaking(t), !(!t || this.layout !== "focus" || !(game.settings?.get("avclient-livekit", "dockFollowSpeaker") ?? !1) || e === game.user?.id || e === this.focusUserId) && (window.clearTimeout(this.followTimer), this.followTimer = window.setTimeout(() => {
			this.layout === "focus" && this.client?.isUserSpeaking(e) && this.focus(e);
		}, tr));
	}
	tileState(e) {
		let t = this.client, n = e.user.id ?? "", r = game.settings?.get(g, "userVideoHidden")[n] === !0, i = t?.liveKitParticipants.get(n)?.connectionQuality ?? d.Unknown;
		return {
			speaking: t?.isUserSpeaking(n) ?? !1,
			muted: t?.isUserMuted(n) ?? !1,
			deafened: t?.voiceControls.isUserDeafened(n) ?? !1,
			locallyMuted: t?.userAudioMixer.isLocallyMuted(n) ?? !1,
			videoHiddenByMe: r,
			showVideo: e.video.show && !r && (t?.isUserVideoOn(n) ?? !1),
			quality: i,
			borderColor: game.webrtc?.settings.client.borderColors === !0,
			focused: this.layout === "focus" && n === this.focusUserId,
			cameraUsed: t?.voiceControls.canUseCamera() ?? !0
		};
	}
	defaultFocus(e) {
		let t = e.filter((e) => !e.settings.popout), n = t.filter((e) => !e.local);
		return (n.find((e) => e.hasVideo) ?? n.at(0) ?? t.at(0))?.user.id ?? void 0;
	}
	placeTile(e, t, n) {
		let r = e.userId;
		if (t.settings.popout) {
			let n = this.windows.get(r);
			n || (n = new Jn(e, {
				left: t.settings.left,
				top: t.settings.top,
				width: t.settings.width,
				onDock: () => {
					this.setPoppedOut(r, !1);
				},
				onMove: (e) => {
					let t = game.webrtc?.settings.client.users[r] ?? {};
					game.webrtc?.settings.set("client", `users.${r}`, {
						...t,
						...e
					});
				}
			}), this.windows.set(r, n), document.body.append(n.element)), n.setTitle(t.user.name), or(n.element, e, n.element.lastElementChild);
			return;
		}
		this.closeWindow(r);
		let i = this.layout === "focus" && r === this.focusUserId ? this.stage : this.list, a = n.get(i) ?? null;
		a?.parentElement !== i && (a = null), e.element === a ? n.set(i, a.nextElementSibling) : or(i, e, a);
	}
	removeTile(e, t) {
		this.client?.getUserVideoTrack(e)?.detach(t.video), t.element.remove(), this.tiles.delete(e), this.closeWindow(e);
	}
	closeWindow(e) {
		this.windows.get(e)?.element.remove(), this.windows.delete(e);
	}
	attachMedia() {
		let e = game.webrtc?.client;
		for (let [t, n] of this.tiles) e?.setUserVideo(t, n.video).catch((e) => {
			Yn.error("Error setting the video of", t, e);
		});
	}
	place() {
		let e = this.element, t = this.isFloating;
		e.dataset.layout = this.layout, e.dataset.placement = t ? "float" : this.dockPosition, e.classList.toggle("is-floating", t), e.classList.toggle("is-collapsed", this.collapsed), e.classList.toggle("hide-quality", !(game.settings?.get("avclient-livekit", "displayConnectionQuality") ?? !0));
		let n = this.windowHost;
		n && (n.className = e.className, n.classList.remove("horizontal", "is-collapsed"), n.classList.add("vertical", "is-floating", "is-windowed"), n.dataset.layout = e.dataset.layout, n.dataset.placement = "window", n.dataset.count = e.dataset.count, e.hidden = !0);
		let r = cr(game.webrtc?.settings.client.dockWidth);
		if (t) {
			let t = this.floatingState, n = Un({
				left: t.left ?? window.innerWidth - 480,
				top: t.top ?? 80,
				width: Math.max(t.width ?? 400, er.width),
				height: Math.max(t.height ?? 320, er.height)
			});
			Object.assign(e.style, {
				left: `${n.left.toString()}px`,
				top: `${n.top.toString()}px`,
				width: `${n.width.toString()}px`,
				height: `${n.height.toString()}px`
			}), e.style.removeProperty("--av-width");
		} else {
			for (let t of [
				"left",
				"top",
				"width",
				"height"
			]) e.style.removeProperty(t);
			e.style.setProperty("--av-width", `${r.toString()}px`);
		}
	}
	updateTools() {
		let e = Xn.find((e) => e.layout === this.layout);
		H(this.layoutButton, { icon: e?.icon ?? "fa-table-cells-large" });
		let t = this.collapsed, [n, r] = this.isFloating ? ["up", "down"] : {
			left: ["left", "right"],
			right: ["right", "left"],
			top: ["up", "down"],
			bottom: ["down", "up"]
		}[this.dockPosition];
		H(this.collapseButton, {
			icon: `fa-chevron-${t ? r : n}`,
			label: I(t ? "dockExpand" : "dockCollapse"),
			pressed: t
		}), this.collapseButton.hidden = this.isWindowed, H(this.windowButton, {
			icon: this.isWindowed ? "fa-arrow-right-to-bracket" : "fa-up-right-from-square",
			label: I(this.isWindowed ? "dockCloseWindow" : "dockOpenWindow")
		});
	}
	tileHost = {
		activate: (e) => {
			this.collapsed ? this.setCollapsed(!1) : this.layout !== "compact" && this.focus(e);
		},
		openMenu: (e, t, n, r) => {
			this.client?.userMenu.open(e, t, n, r);
		},
		toggleOwnMute: () => {
			this.client?.voiceControls.toggleMute();
		},
		toggleOwnVideo: () => {
			this.client?.voiceControls.toggleCamera();
		}
	};
	canHostPanel() {
		return this.rendered && this.built && !this.element.hidden && (game.settings?.get("avclient-livekit", "voicePanelInDock") ?? !0);
	}
	focus(e) {
		this.focusUserId = e, this.focusPicked = !0, this.layout === "focus" ? this.refresh() : this.setLayout("focus");
	}
	async setLayout(e) {
		window.clearTimeout(this.followTimer), await game.settings?.set(g, "dockLayout", e), await this.render();
	}
	async setPlacement(e) {
		this.returnFromWindow(), e === "float" ? await this.saveFloating({
			...this.floatingState,
			floating: !0
		}) : (await game.settings?.set(g, "dockFloating", {
			...this.floatingState,
			floating: !1
		}), game.webrtc?.settings.set("client", "dockPosition", e)), await this.render(), sr();
	}
	async setWindowed(e) {
		if (!e) {
			this.returnFromWindow();
			return;
		}
		if (this.dockWindow || !this.contentRoot) return;
		let t = this.floatingState, n = await Vn.open({
			width: Math.max(t.width ?? 480, er.width),
			height: Math.max(t.height ?? 360, er.height)
		}, I("dock"), () => {
			this.returnFromWindow();
		}).catch((e) => {
			Yn.error("Unable to open the dock's own window:", e);
		});
		if (!n) return;
		let r = A("div", { attrs: { id: "camera-views" } });
		n.document.body.append(r), r.append(...this.contentNodes), this.dockWindow = n, this.windowHost = r, n.window.addEventListener("resize", () => {
			this.fitGrid();
		}), this.viewMenu.close(), await this.render(), sr();
	}
	returnFromWindow() {
		let e = this.dockWindow;
		e && (this.dockWindow = void 0, this.windowHost = void 0, this.viewMenu.close(), this.contentRoot?.append(...this.contentNodes), e.close(), this.render().then(sr));
	}
	async setCollapsed(e) {
		game.webrtc?.settings.set("client", "hideDock", e), await this.render(), sr();
	}
	async setPoppedOut(e, t) {
		game.webrtc?.settings.set("client", `users.${e}.popout`, t), await this.render();
	}
	isPoppedOut(e) {
		return this.windows.has(e);
	}
	async pictureInPicture(e) {
		let t = this.tiles.get(e)?.video;
		t && document.pictureInPictureEnabled && await t.requestPictureInPicture();
	}
	canPictureInPicture(e) {
		let t = this.tiles.get(e);
		return !this.isWindowed && document.pictureInPictureEnabled && !!t?.video.srcObject && t.element.classList.contains("is-video");
	}
	async saveFloating(e) {
		await game.settings?.set(g, "dockFloating", {
			...this.floatingState,
			...e,
			floating: e.floating ?? this.floatingState.floating
		});
	}
	onResized(e) {
		if (this.isFloating) {
			this.saveFloating(e);
			return;
		}
		let t = this.isHorizontal ? e.height * 4 / 3 : e.width;
		game.webrtc?.settings.set("client", "dockWidth", cr(t)), this.render();
	}
	viewMenuItems() {
		let e = this.layout, t = this.isWindowed ? "window" : this.isFloating ? "float" : this.dockPosition;
		return [
			{
				type: "header",
				label: I("dockLayoutTitle")
			},
			...Xn.map((t) => ({
				type: "radio",
				label: I(`dockLayout.${t.layout}`),
				checked: e === t.layout,
				onSelect: () => this.setLayout(t.layout)
			})),
			{
				type: "checkbox",
				label: I("dockFollowSpeaker"),
				detail: I("dockFollowSpeakerHint"),
				checked: game.settings?.get("avclient-livekit", "dockFollowSpeaker") ?? !1,
				onSelect: () => game.settings?.set(g, "dockFollowSpeaker", !(game.settings.get("avclient-livekit", "dockFollowSpeaker") ?? !1))
			},
			{
				type: "checkbox",
				label: I("voicePanelInDock"),
				checked: game.settings?.get("avclient-livekit", "voicePanelInDock") ?? !0,
				onSelect: () => game.settings?.set(g, "voicePanelInDock", !(game.settings.get("avclient-livekit", "voicePanelInDock") ?? !0))
			},
			{ type: "separator" },
			{
				type: "header",
				label: I("clientSetting.dockPosition")
			},
			...[...Zn, "float"].map((e) => ({
				type: "radio",
				label: I(e === "float" ? "dockFloating" : `dockPosition.${e}`),
				checked: t === e,
				onSelect: () => this.setPlacement(e)
			})),
			...Bn() ? [{
				type: "radio",
				label: I("dockWindow"),
				checked: t === "window",
				onSelect: () => this.setWindowed(!0)
			}] : []
		];
	}
};
function or(e, t, n) {
	let r = t.element;
	if (n?.parentElement !== e && (n = null), "moveBefore" in e && r.isConnected && e.isConnected) try {
		e.moveBefore(r, n);
		return;
	} catch {}
	e.insertBefore(r, n), t.video.srcObject && t.video.play().catch(() => void 0);
}
function sr() {
	ui.hotbar?._onResize?.();
}
function cr(e) {
	return Math.round(Math.min(Math.max(e ?? 240, Qn), $n));
}
//#endregion
//#region src/utils/registerModuleSettings.ts
var lr = new y();
function ur() {
	game.settings?.register(g, "displayConnectionQuality", {
		name: "LIVEKITAVCLIENT.displayConnectionQuality",
		hint: "LIVEKITAVCLIENT.displayConnectionQualityHint",
		scope: "client",
		config: !1,
		default: !0,
		type: new foundry.data.fields.BooleanField({ initial: !0 }),
		onChange: () => game.webrtc?.render()
	}), game.settings?.register(g, "discordStyleUI", {
		name: "LIVEKITAVCLIENT.discordStyleUI",
		hint: "LIVEKITAVCLIENT.discordStyleUIHint",
		scope: "client",
		config: !1,
		default: !0,
		type: new foundry.data.fields.BooleanField({ initial: !0 }),
		requiresReload: !0,
		onChange: () => {
			game.webrtc?.client._liveKitClient.applyDiscordStyle();
		}
	}), game.settings?.register(g, "allowDiscordStyleUI", {
		name: "LIVEKITAVCLIENT.allowDiscordStyleUI",
		hint: "LIVEKITAVCLIENT.allowDiscordStyleUIHint",
		scope: "world",
		config: !1,
		default: !0,
		type: new foundry.data.fields.BooleanField({ initial: !0 }),
		requiresReload: !0,
		onChange: () => {
			game.webrtc?.client._liveKitClient.applyDiscordStyle();
		}
	}), game.settings?.register(g, "allowKrisp", {
		name: "LIVEKITAVCLIENT.allowKrisp",
		hint: "LIVEKITAVCLIENT.allowKrispHint",
		scope: "world",
		config: !1,
		default: !0,
		type: new foundry.data.fields.BooleanField({ initial: !0 }),
		onChange: () => {
			game.webrtc?.client._liveKitClient.scheduleAudioProcessingRefresh();
		}
	}), game.settings?.register(g, "defaultNoiseModel", {
		name: "LIVEKITAVCLIENT.defaultNoiseModel",
		hint: "LIVEKITAVCLIENT.defaultNoiseModelHint",
		scope: "world",
		config: !1,
		default: "gtcrn",
		type: new foundry.data.fields.StringField({
			required: !0,
			blank: !1,
			initial: "gtcrn",
			choices: {
				none: "LIVEKITAVCLIENT.noiseSuppressionModelNone",
				speex: "LIVEKITAVCLIENT.noiseSuppressionModelSpeex",
				rnnoise: "LIVEKITAVCLIENT.noiseSuppressionModelRnnoise",
				gtcrn: "LIVEKITAVCLIENT.noiseSuppressionModelGtcrn",
				krisp: "LIVEKITAVCLIENT.noiseSuppressionModelKrisp"
			}
		}),
		onChange: () => {
			game.webrtc?.client._liveKitClient.scheduleAudioProcessingRefresh();
		}
	}), game.settings?.register(g, "voicePanelPosition", {
		scope: "client",
		config: !1,
		default: null
	}), game.settings?.register(g, "dockLayout", {
		scope: "client",
		config: !1,
		default: "grid",
		type: new foundry.data.fields.StringField({
			required: !0,
			blank: !1,
			initial: "grid",
			choices: {
				grid: "grid",
				focus: "focus",
				compact: "compact"
			}
		}),
		onChange: () => {
			game.webrtc?.client._liveKitClient.dock?.render();
		}
	}), game.settings?.register(g, "dockFloating", {
		scope: "client",
		config: !1,
		default: { floating: !1 },
		onChange: () => {
			game.webrtc?.client._liveKitClient.dock?.render();
		}
	}), game.settings?.register(g, "dockFollowSpeaker", {
		scope: "client",
		config: !1,
		default: !1,
		type: new foundry.data.fields.BooleanField({ initial: !1 }),
		onChange: () => {
			game.webrtc?.client._liveKitClient.dock?.render();
		}
	}), game.settings?.register(g, "voicePanelInDock", {
		scope: "client",
		config: !1,
		default: !0,
		type: new foundry.data.fields.BooleanField({ initial: !0 }),
		onChange: () => {
			game.webrtc?.client._liveKitClient.voicePanelIfCreated?.sync();
		}
	}), game.settings?.register(g, "videoBackground", {
		scope: "client",
		config: !1,
		default: "none",
		type: new foundry.data.fields.StringField({
			required: !0,
			blank: !1,
			initial: "none",
			choices: {
				none: "none",
				blur: "blur",
				image: "image"
			}
		}),
		onChange: () => {
			game.webrtc?.client._liveKitClient.updateVideoBackground({ retry: !0 });
		}
	}), game.settings?.register(g, "videoBackgroundImage", {
		scope: "client",
		config: !1,
		default: "ui/backgrounds/setup.webp",
		type: new foundry.data.fields.StringField({
			required: !0,
			blank: !1,
			initial: "ui/backgrounds/setup.webp"
		}),
		onChange: () => {
			game.settings.get("avclient-livekit", "videoBackground") === "image" && game.webrtc?.client._liveKitClient.updateVideoBackground({ retry: !0 });
		}
	}), game.settings?.register(g, "videoBackgroundQuality", {
		scope: "client",
		config: !1,
		default: "high",
		type: new foundry.data.fields.StringField({
			required: !0,
			blank: !1,
			initial: "high",
			choices: {
				standard: "standard",
				high: "high"
			}
		}),
		onChange: () => {
			game.webrtc?.client._liveKitClient.updateVideoBackground({ retry: !0 });
		}
	}), game.settings?.register(g, "videoBlurStrength", {
		scope: "client",
		config: !1,
		default: .5,
		type: new foundry.data.fields.NumberField({
			required: !0,
			nullable: !1,
			min: .1,
			max: 1,
			step: .05,
			initial: .5
		}),
		onChange: () => {
			game.settings.get("avclient-livekit", "videoBackground") === "blur" && game.webrtc?.client._liveKitClient.updateVideoBackground();
		}
	}), game.settings?.register(g, "videoBackgroundCustomImage", {
		scope: "client",
		config: !1,
		default: "",
		type: new foundry.data.fields.StringField({ initial: "" })
	}), game.settings?.register(g, "userVideoHidden", {
		scope: "client",
		config: !1,
		default: {}
	}), game.settings?.register(g, "userVolumes", {
		scope: "client",
		config: !1,
		default: {}
	}), game.settings?.register(g, "userLocalMutes", {
		scope: "client",
		config: !1,
		default: {}
	}), game.settings?.register(g, "mutedByDeafen", {
		scope: "client",
		config: !1,
		default: !1,
		type: new foundry.data.fields.BooleanField({ initial: !1 })
	}), game.settings?.register(g, "liveKitConnectionSettings", {
		name: "LIVEKITAVCLIENT.liveKitConnectionSettings",
		hint: "LIVEKITAVCLIENT.liveKitConnectionSettingsHint",
		scope: "world",
		config: !1,
		default: {},
		requiresReload: !0
	}), game.settings?.register(g, "tavernPatreonToken", {
		name: "LIVEKITAVCLIENT.tavernPatreonToken",
		hint: "LIVEKITAVCLIENT.tavernPatreonTokenHint",
		scope: "world",
		config: !1,
		default: "",
		type: new foundry.data.fields.StringField({
			required: !1,
			blank: !0,
			initial: ""
		}),
		requiresReload: !0
	}), game.settings?.register(g, "breakoutRoomRegistry", {
		name: "LIVEKITAVCLIENT.breakoutRoomRegistry",
		hint: "LIVEKITAVCLIENT.breakoutRoomRegistryHint",
		scope: "client",
		config: !1,
		default: {},
		requiresReload: !1
	}), game.settings?.register(g, "audioMusicMode", {
		name: "LIVEKITAVCLIENT.audioMusicMode",
		hint: "LIVEKITAVCLIENT.audioMusicModeHint",
		scope: "client",
		config: !1,
		default: !1,
		type: new foundry.data.fields.BooleanField({ initial: !1 }),
		onChange: () => {
			game.webrtc?.client._liveKitClient.scheduleAudioSourceChange();
		}
	}), game.settings?.register(g, "enhancedNoiseCancellation", {
		name: "LIVEKITAVCLIENT.enhancedNoiseCancellation",
		hint: "LIVEKITAVCLIENT.enhancedNoiseCancellationHint",
		scope: "client",
		config: !1,
		default: !0,
		type: new foundry.data.fields.BooleanField({ initial: !0 }),
		onChange: () => {
			game.webrtc?.client._liveKitClient.scheduleAudioProcessingRefresh();
		}
	}), game.settings?.register(g, "noiseSuppressionModel", {
		name: "LIVEKITAVCLIENT.noiseSuppressionModel",
		hint: "LIVEKITAVCLIENT.noiseSuppressionModelHint",
		scope: "client",
		config: !1,
		default: "gtcrn",
		type: new foundry.data.fields.StringField({
			required: !0,
			blank: !1,
			initial: "gtcrn",
			choices: {
				rnnoise: "LIVEKITAVCLIENT.noiseSuppressionModelRnnoise",
				speex: "LIVEKITAVCLIENT.noiseSuppressionModelSpeex",
				gtcrn: "LIVEKITAVCLIENT.noiseSuppressionModelGtcrn",
				krisp: "LIVEKITAVCLIENT.noiseSuppressionModelKrisp"
			}
		}),
		onChange: () => {
			game.webrtc?.client._liveKitClient.scheduleAudioProcessingRefresh();
		}
	}), game.settings?.register(g, "audioQualityPreset", {
		name: "LIVEKITAVCLIENT.audioQualityPreset",
		hint: "LIVEKITAVCLIENT.audioQualityPresetHint",
		scope: "client",
		config: !1,
		default: "speech",
		type: new foundry.data.fields.StringField({
			required: !0,
			blank: !1,
			initial: "speech",
			choices: {
				telephone: "LIVEKITAVCLIENT.audioQualityPresetTelephone",
				speech: "LIVEKITAVCLIENT.audioQualityPresetSpeech",
				music: "LIVEKITAVCLIENT.audioQualityPresetMusic",
				musicStereo: "LIVEKITAVCLIENT.audioQualityPresetMusicStereo",
				musicHighQuality: "LIVEKITAVCLIENT.audioQualityPresetMusicHighQuality",
				musicHighQualityStereo: "LIVEKITAVCLIENT.audioQualityPresetMusicHighQualityStereo"
			}
		}),
		onChange: () => {
			game.webrtc?.client._liveKitClient.scheduleAudioSourceChange();
		}
	}), game.settings?.register(g, "audioAutoGainControl", {
		name: "LIVEKITAVCLIENT.audioAutoGainControl",
		hint: "LIVEKITAVCLIENT.audioAutoGainControlHint",
		scope: "client",
		config: !1,
		default: !0,
		type: new foundry.data.fields.BooleanField({ initial: !0 }),
		onChange: () => {
			game.webrtc?.client._liveKitClient.scheduleAudioProcessingRefresh();
		}
	}), game.settings?.register(g, "audioEchoCancellation", {
		name: "LIVEKITAVCLIENT.audioEchoCancellation",
		hint: "LIVEKITAVCLIENT.audioEchoCancellationHint",
		scope: "client",
		config: !1,
		default: !0,
		type: new foundry.data.fields.BooleanField({ initial: !0 }),
		onChange: () => {
			game.webrtc?.client._liveKitClient.scheduleAudioProcessingRefresh();
		}
	}), game.settings?.register(g, "audioNoiseSuppression", {
		name: "LIVEKITAVCLIENT.audioNoiseSuppression",
		hint: "LIVEKITAVCLIENT.audioNoiseSuppressionHint",
		scope: "client",
		config: !1,
		default: !0,
		type: new foundry.data.fields.BooleanField({ initial: !0 }),
		onChange: () => {
			game.webrtc?.client._liveKitClient.scheduleAudioProcessingRefresh();
		}
	}), game.settings?.register(g, "audioAutoSensitivity", {
		name: "LIVEKITAVCLIENT.audioAutoSensitivity",
		scope: "client",
		config: !1,
		default: !0,
		type: new foundry.data.fields.BooleanField({ initial: !0 }),
		onChange: () => {
			game.webrtc?.client._liveKitClient.applyVoiceGateSettings();
		}
	}), game.settings?.register(g, "audioNoiseGateThreshold", {
		name: "LIVEKITAVCLIENT.audioNoiseGateThreshold",
		hint: "LIVEKITAVCLIENT.audioNoiseGateThresholdHint",
		scope: "client",
		config: !1,
		default: -50,
		type: new foundry.data.fields.NumberField({
			required: !0,
			nullable: !1,
			min: -80,
			max: 0,
			step: 1,
			initial: -50
		}),
		onChange: () => {
			game.webrtc?.client._liveKitClient.applyVoiceGateSettings();
		}
	}), game.settings?.register(g, "useExternalAV", {
		name: "LIVEKITAVCLIENT.useExternalAV",
		hint: "LIVEKITAVCLIENT.useExternalAVHint",
		scope: "client",
		config: !1,
		default: !1,
		type: new foundry.data.fields.BooleanField({ initial: !1 }),
		requiresReload: !0
	}), game.settings?.register(g, "resetRoom", {
		name: "LIVEKITAVCLIENT.resetRoom",
		hint: "LIVEKITAVCLIENT.resetRoomHint",
		scope: "world",
		config: !1,
		default: !1,
		type: new foundry.data.fields.BooleanField({ initial: !1 }),
		onChange: (e) => {
			e && game.user?.isGM && (lr.warn("Resetting meeting room ID"), game.settings.set(g, "resetRoom", !1).then(() => {
				let e = game.settings.get(g, "liveKitConnectionSettings");
				e.room = foundry.utils.randomID(32), game.settings.set(g, "liveKitConnectionSettings", e).catch((e) => {
					lr.error("Error setting liveKitConnectionSettings:", e);
				});
			}).catch((e) => {
				lr.error("Error resetting meeting room ID", e);
			}));
		},
		requiresReload: !0
	}), game.settings?.register(g, "debug", {
		name: "LIVEKITAVCLIENT.debug",
		hint: "LIVEKITAVCLIENT.debugHint",
		scope: "world",
		config: !1,
		default: !1,
		type: new foundry.data.fields.BooleanField({ initial: !1 }),
		requiresReload: !0
	}), game.settings?.register(g, "liveKitTrace", {
		name: "LIVEKITAVCLIENT.liveKitTrace",
		hint: "LIVEKITAVCLIENT.liveKitTraceHint",
		scope: "world",
		config: !1,
		default: !1,
		type: new foundry.data.fields.BooleanField({ initial: !1 }),
		requiresReload: !0
	}), game.settings?.register(g, "devMode", {
		name: "LIVEKITAVCLIENT.devMode",
		hint: "LIVEKITAVCLIENT.devModeHint",
		scope: "world",
		config: !1,
		default: !1,
		type: new foundry.data.fields.BooleanField({ initial: !1 }),
		requiresReload: !0
	}), game.settings?.register(g, "authServer", {
		name: "LIVEKITAVCLIENT.authServer",
		hint: "LIVEKITAVCLIENT.authServerHint",
		scope: "world",
		config: !1,
		default: fe,
		type: new foundry.data.fields.StringField({
			required: !0,
			blank: !1,
			initial: fe
		}),
		requiresReload: !0
	}), game.settings?.register(g, "forceTurn", {
		name: "LIVEKITAVCLIENT.forceTurn",
		hint: "LIVEKITAVCLIENT.forceTurnHint",
		scope: "world",
		config: !1,
		default: !1,
		type: new foundry.data.fields.BooleanField({ initial: !1 }),
		requiresReload: !0
	}), game.settings?.get("avclient-livekit", "debug") ? (game.settings.get("avclient-livekit", "liveKitTrace") ? (v.default.enable("*"), lr.info("Enabling trace logging")) : (v.default.enable(`${g}:DEBUG,${g}:DEBUG:*,${g}:INFO,${g}:INFO:*,${g}:WARN,${g}:WARN:*,${g}:ERROR,${g}:ERROR:*`), lr.info("Enabling debug logging")), CONFIG.debug.av = !0, CONFIG.debug.avclient = !0) : (v.default.enable(`${g}:INFO,${g}:INFO:*,${g}:WARN,${g}:WARN:*,${g}:ERROR,${g}:ERROR:*`), CONFIG.debug.av = !1, CONFIG.debug.avclient = !1);
}
Hooks.on("init", () => {
	foundry.av.AVSettings.VOICE_MODES = {
		ALWAYS: "always",
		PTT: "ptt"
	}, ur(), (game.settings?.get("avclient-livekit", "allowDiscordStyleUI") ?? !0) && (game.settings?.get("avclient-livekit", "discordStyleUI") ?? !0) && !(game.settings?.get("avclient-livekit", "useExternalAV") ?? !1) && (CONFIG.ui.webrtc = ar), game.settings?.registerMenu(g, "avSettings", {
		name: "LIVEKITAVCLIENT.settingsMenu",
		label: "LIVEKITAVCLIENT.settingsMenuLabel",
		hint: "LIVEKITAVCLIENT.settingsMenuHint",
		icon: "fa-solid fa-headset",
		type: An,
		restricted: !1
	}), Hooks.on("renderCameraViews", (e, t) => {
		game.webrtc?.client._liveKitClient && game.webrtc.client._liveKitClient.onRenderCameraViews(e, t);
	});
}), Hooks.on("ready", () => {
	game.socket?.on(`module.${g}`, (e, t) => {
		game.webrtc?.client._liveKitClient && game.webrtc.client._liveKitClient.onSocketEvent(e, t);
	}), game.settings?.registerMenu("core", "webrtc", {
		name: "WEBRTC.Title",
		label: "WEBRTC.MenuLabel",
		hint: "WEBRTC.MenuHint",
		icon: "fas fa-headset",
		type: An,
		restricted: !1
	});
}), Hooks.on("renderPlayers", (e, t) => {
	game.webrtc?.client._liveKitClient.playersList.decorate(t);
}), Hooks.on("getUserContextOptions", (e, t) => {
	game.webrtc?.client && game.webrtc.client._liveKitClient.onGetUserContextOptions(e, t);
}), AudioWorkletNode;
var dr = async (e, t) => await (await fetch(e, t)).arrayBuffer(), fr = async ({ url: e }, t) => await dr(e, t), pr = "@sapphi-red/web-noise-suppressor/gtcrn", mr = class extends AudioWorkletNode {
	constructor(e, { maxChannels: t, wasmBinary: n }) {
		super(e, pr, { processorOptions: {
			maxChannels: t,
			wasmBinary: n
		} });
	}
	destroy() {
		this.port.postMessage("destroy");
	}
}, hr = async () => WebAssembly.validate(new Uint8Array([
	0,
	97,
	115,
	109,
	1,
	0,
	0,
	0,
	1,
	5,
	1,
	96,
	0,
	1,
	123,
	3,
	2,
	1,
	0,
	10,
	10,
	1,
	8,
	0,
	65,
	0,
	253,
	15,
	253,
	98,
	11
])), gr = async ({ url: e, simdUrl: t }, n) => await dr(await hr() ? t : e, n), _r = "@sapphi-red/web-noise-suppressor/rnnoise", vr = class extends AudioWorkletNode {
	constructor(e, { maxChannels: t, wasmBinary: n }) {
		super(e, _r, { processorOptions: {
			maxChannels: t,
			wasmBinary: n
		} });
	}
	destroy() {
		this.port.postMessage("destroy");
	}
}, yr = async ({ url: e }, t) => await dr(e, t), br = "@sapphi-red/web-noise-suppressor/speex", xr = class extends AudioWorkletNode {
	constructor(e, { maxChannels: t, wasmBinary: n }) {
		super(e, br, { processorOptions: {
			maxChannels: t,
			wasmBinary: n
		} });
	}
	destroy() {
		this.port.postMessage("destroy");
	}
}, Sr = new y("NoiseSuppressorFilter"), Cr = 48e3, wr = [
	"rnnoise",
	"speex",
	"gtcrn"
], Tr = "gtcrn";
function Er() {
	return typeof AudioWorkletNode < "u" && typeof AudioContext < "u" && typeof WebAssembly < "u";
}
function Dr(e) {
	return e === "krisp" || wr.includes(e) ? e : Tr;
}
async function Or(e, t) {
	let n = await t;
	if (!WebAssembly.validate(n)) throw Error(`Failed to load a valid WASM binary for ${e}`);
	return n;
}
var kr = class {
	name;
	processedTrack;
	gate;
	model;
	gateOptions;
	audioContext;
	sourceNode;
	workletNode;
	destinationNode;
	constructor({ model: e, gate: t }) {
		this.model = e, this.gateOptions = t, this.name = `noise-suppressor-${e ?? "none"}${t ? "-gate" : ""}`;
	}
	async init(e) {
		this.audioContext = e.audioContext;
		try {
			await this.buildGraph(this.audioContext, e.track);
		} catch (e) {
			throw await this.destroy(), e;
		}
		Sr.info(`Noise suppression filter initialized (${this.name})`);
	}
	async buildGraph(e, t) {
		this.model && (this.workletNode = await this.createWorkletNode(e, this.model)), this.gateOptions && (this.gate = await Ut.create(e, this.gateOptions)), this.destinationNode = e.createMediaStreamDestination();
		let n = this.destinationNode;
		for (let e of [this.gate?.node, this.workletNode].filter((e) => e !== void 0)) e.connect(n), n = e;
		this.connectSource(e, t, n), this.processedTrack = this.destinationNode.stream.getAudioTracks()[0];
	}
	connectSource(e, t, n) {
		this.sourceNode?.disconnect(), this.sourceNode = e.createMediaStreamSource(new MediaStream([t])), this.sourceNode.connect(n);
	}
	async createWorkletNode(e, t) {
		switch (t) {
			case "speex": {
				let n = await Or(t, yr({ url: b("speex/speex.wasm") }));
				return await e.audioWorklet.addModule(b("speex/speexWorklet.js")), new xr(e, {
					wasmBinary: n,
					maxChannels: 1
				});
			}
			case "gtcrn": {
				let n = await Or(t, fr({ url: b("gtcrn/gtcrn.wasm") }));
				return await e.audioWorklet.addModule(b("gtcrn/gtcrnWorklet.js")), new mr(e, {
					wasmBinary: n,
					maxChannels: 1
				});
			}
			case "rnnoise": {
				let n = await Or(t, gr({
					url: b("rnnoise/rnnoise.wasm"),
					simdUrl: b("rnnoise/rnnoise_simd.wasm")
				}));
				return await e.audioWorklet.addModule(b("rnnoise/rnnoiseWorklet.js")), new vr(e, {
					wasmBinary: n,
					maxChannels: 1
				});
			}
		}
	}
	async restart(e) {
		let t = this.workletNode ?? this.gate?.node;
		if (this.audioContext && t && this.processedTrack) {
			this.connectSource(this.audioContext, e.track, t);
			return;
		}
		let n = e.audioContext ?? this.audioContext;
		await this.destroy(), await this.init({
			...e,
			audioContext: n
		});
	}
	destroy() {
		try {
			this.sourceNode?.disconnect(), this.gate?.destroy(), this.workletNode?.disconnect(), this.workletNode?.destroy(), this.destinationNode?.disconnect();
		} catch (e) {
			Sr.warn("Error while destroying noise suppression filter:", e);
		} finally {
			this.sourceNode = void 0, this.gate = void 0, this.workletNode = void 0, this.destinationNode = void 0, this.audioContext = void 0, this.processedTrack = void 0;
		}
		return Promise.resolve();
	}
}, Ar = new y("KrispNoiseFilter"), jr = 1, Mr;
function Nr() {
	return Mr ??= import("./krisp-noise-filter-C7yITSEN.js").catch((e) => {
		throw Mr = void 0, e;
	}), Mr;
}
async function Pr() {
	try {
		let { isKrispNoiseFilterSupported: e } = await Nr();
		return e();
	} catch (e) {
		return Ar.warn("Unable to load the Krisp noise filter:", e), !1;
	}
}
var Fr = ["enable-lk-krisp-noise-filter", "disable-lk-krisp-noise-filter"], Ir = class {
	krisp;
	gateOptions;
	name;
	gate;
	audioContext;
	sourceNode;
	destinationNode;
	krispTrack;
	constructor(e, t) {
		this.krisp = e, this.gateOptions = t, this.name = `${e.name}${t ? "-gate" : ""}`;
	}
	get processedTrack() {
		return this.gateOptions ? this.destinationNode?.stream.getAudioTracks()[0] : this.krisp.processedTrack;
	}
	forwardEvent = (e) => {
		this.processedTrack?.dispatchEvent(new Event(e.type));
	};
	async init(e) {
		this.audioContext = e.audioContext;
		try {
			await this.krisp.init(e), this.gateOptions && (this.gate = await Ut.create(e.audioContext, this.gateOptions), this.destinationNode = e.audioContext.createMediaStreamDestination(), this.gate.node.connect(this.destinationNode), this.connectKrispOutput());
		} catch (e) {
			throw await this.destroy(), e;
		}
	}
	async restart(e) {
		let t = this.krisp.isEnabled();
		await this.krisp.restart(e), this.gateOptions && this.connectKrispOutput(), t && await this.krisp.setEnabled(!0);
	}
	connectKrispOutput() {
		let e = this.krisp.processedTrack;
		if (!e || !this.audioContext || !this.gate) throw Error("The Krisp noise filter has no output");
		for (let t of Fr) this.krispTrack?.removeEventListener(t, this.forwardEvent), e.addEventListener(t, this.forwardEvent);
		this.krispTrack = e, this.sourceNode?.disconnect(), this.sourceNode = this.audioContext.createMediaStreamSource(new MediaStream([e])), this.sourceNode.connect(this.gate.node);
	}
	onPublish(e) {
		return this.krisp.onPublish(e);
	}
	setEnabled(e) {
		return this.krisp.setEnabled(e);
	}
	isEnabled() {
		return this.krisp.isEnabled();
	}
	async destroy() {
		for (let e of Fr) this.krispTrack?.removeEventListener(e, this.forwardEvent);
		this.sourceNode?.disconnect(), this.gate?.destroy(), this.destinationNode?.disconnect(), this.sourceNode = void 0, this.gate = void 0, this.destinationNode = void 0, this.krispTrack = void 0, await this.krisp.destroy();
	}
};
async function Lr(e) {
	let { KrispNoiseFilter: t } = await Nr();
	return new Ir(t(), e);
}
function Rr(e, t) {
	if (e?.state !== m.Connected) return !1;
	if (Number(e.serverInfo?.edition) === jr) return !0;
	if (!t) return !1;
	try {
		let { hostname: e } = new URL(`wss://${t}`);
		return e.endsWith(".livekit.cloud") || e.endsWith(".livekit.run");
	} catch {
		return !1;
	}
}
//#endregion
//#region src/LiveKitBreakout.ts
var J = new y("LiveKitBreakout");
function zr(e) {
	return (game.settings?.get("avclient-livekit", "breakoutRoomRegistry") ?? {})[e];
}
async function Br(e, t) {
	let n = game.settings?.get("avclient-livekit", "breakoutRoomRegistry") ?? {};
	n[e] = t, await game.settings?.set(g, "breakoutRoomRegistry", n);
}
function Vr(e, t) {
	let n = game.user?.isGM === !0, r = e === game.user?.id, i = zr(e), a = (e) => game.i18n?.localize(`LIVEKITAVCLIENT.${e}`) ?? e;
	return [
		n && !r && !i && {
			label: a("startAVBreakout"),
			icon: "fa-comment",
			run: () => {
				let n = foundry.utils.randomID(32);
				Wr(e, n), Ur(n, t);
			}
		},
		n && !r && !!i && t.breakoutRoom !== i && {
			label: a("joinAVBreakout"),
			icon: "fa-comment-dots",
			run: () => {
				Ur(i, t);
			}
		},
		n && !r && !!t.breakoutRoom && i !== t.breakoutRoom && {
			label: a("pullToAVBreakout"),
			icon: "fa-comments",
			run: () => {
				Wr(e, t.breakoutRoom);
			}
		},
		r && !!t.breakoutRoom && {
			label: a("leaveAVBreakout"),
			icon: "fa-comment-slash",
			run: () => {
				Ur(void 0, t);
			}
		},
		n && !r && !!i && {
			label: a("removeFromAVBreakout"),
			icon: "fa-comment-slash",
			run: () => {
				Gr(e);
			}
		},
		n && r && {
			label: a("endAllAVBreakouts"),
			icon: "fa-ban",
			run: () => {
				Kr(t);
			}
		}
	].filter((e) => e !== !1);
}
function Hr(e, t) {
	let n = (e, n) => Vr(e.dataset.userId ?? "", t).find((e) => e.label === n);
	for (let [t, r] of [
		["startAVBreakout", "fa-comment"],
		["joinAVBreakout", "fa-comment-dots"],
		["pullToAVBreakout", "fa-comments"],
		["leaveAVBreakout", "fa-comment-slash"],
		["removeFromAVBreakout", "fa-comment-slash"],
		["endAllAVBreakouts", "fa-ban"]
	]) {
		let i = game.i18n?.localize(`LIVEKITAVCLIENT.${t}`) ?? t;
		e.push({
			name: i,
			icon: `<i class="fa-solid ${r}"></i>`,
			condition: (e) => !!n(e, i),
			callback: (e) => {
				n(e, i)?.run();
			}
		});
	}
}
function Ur(e, t) {
	e !== t.breakoutRoom && (e ? ui.notifications?.info(game.i18n?.localize("LIVEKITAVCLIENT.joiningAVBreakout") ?? "joiningAVBreakout") : ui.notifications?.info(game.i18n?.localize("LIVEKITAVCLIENT.leavingAVBreakout") ?? "leavingAVBreakout"), J.debug("Switching to breakout room:", e), t.breakoutRoom = e, game.webrtc?.connect().catch(() => {
		J.error("Failed to connect to breakout room"), t.breakoutRoom = void 0, ui.notifications?.error(game.i18n.localize(`${_}.failedToJoinAVBreakout`));
	}));
}
function Wr(e, t) {
	if (!game.user?.isGM) {
		J.warn("Only a GM can start a breakout conference room");
		return;
	}
	Br(e, t).catch((e) => {
		J.error("Error setting breakout room:", e);
	}), game.socket.emit(`module.${g}`, {
		action: "breakout",
		userId: e,
		breakoutRoom: t
	}, { recipients: [e] });
}
function Gr(e) {
	if (!game.user?.isGM) {
		J.warn("Only a GM can end a user's breakout conference");
		return;
	}
	Br(e, void 0).catch((e) => {
		J.error("Error clearing breakout room:", e);
	}), game.socket.emit(`module.${g}`, {
		action: "breakout",
		userId: e,
		breakoutRoom: void 0
	}, { recipients: [e] });
}
function Kr(e) {
	if (!game.user?.isGM) {
		J.warn("Only a GM can end all breakout conference rooms");
		return;
	}
	game.socket.emit(`module.${g}`, {
		action: "breakout",
		userId: void 0,
		breakoutRoom: void 0
	}), e.breakoutRoom && Ur(void 0, e);
}
//#endregion
//#region src/VoiceControls.ts
var qr = new y("VoiceControls"), Jr = class {
	client;
	remoteDeafened = /* @__PURE__ */ new Set();
	constructor(e) {
		this.client = e;
	}
	get userId() {
		return game.user?.id ?? "";
	}
	isMuted() {
		return this.client.settings.getUser(this.userId)?.muted === !0;
	}
	isDeafened() {
		return this.client.settings.get("client", "muteAll") === !0;
	}
	isUserDeafened(e) {
		return e === this.userId ? this.isDeafened() : this.remoteDeafened.has(e);
	}
	isCameraOff() {
		return this.client.settings.getUser(this.userId)?.hidden === !0;
	}
	canUseCamera() {
		let { AUDIO_VIDEO: e, VIDEO: t } = foundry.av.AVSettings.AV_MODES, n = this.client.settings.get("world", "mode");
		return n === e || n === t;
	}
	toggleCamera() {
		let e = this.client.settings.getUser(this.userId), t = e?.hidden === !0;
		if (t && !e.canBroadcastVideo) {
			ui.notifications?.warn("WEBRTC.WarningCannotEnableVideo", { localize: !0 });
			return;
		}
		this.client.settings.set("client", `users.${this.userId}.hidden`, !t), ui.webrtc?.render(), this.client.onVoiceStateChanged();
	}
	toggleMute() {
		let e = !this.isMuted();
		!e && this.isDeafened() && this.setDeafenedSetting(!1), this.setMuted(e), this.setMutedByDeafen(!1), this.client.onVoiceStateChanged();
	}
	toggleDeafen() {
		let e = !this.isDeafened();
		e && !this.isMuted() ? (this.setMuted(!0), this.setMutedByDeafen(!0)) : !e && this.wasMutedByDeafen() && (this.setMuted(!1), this.setMutedByDeafen(!1)), this.setDeafenedSetting(e), this.client.onVoiceStateChanged();
	}
	broadcastDeafened() {
		game.socket?.emit(`module.${g}`, {
			action: "deafen",
			deafened: this.isDeafened()
		});
	}
	onRemoteDeafened(e, t) {
		t ? this.remoteDeafened.add(e) : this.remoteDeafened.delete(e), this.client.onVoiceStateChanged(e);
	}
	setMuted(e) {
		this.client.settings.set("client", `users.${this.userId}.muted`, e);
	}
	setDeafenedSetting(e) {
		this.client.settings.set("client", "muteAll", e), this.broadcastDeafened();
	}
	wasMutedByDeafen() {
		return game.settings?.get(g, "mutedByDeafen") === !0;
	}
	setMutedByDeafen(e) {
		game.settings?.set(g, "mutedByDeafen", e).catch((e) => {
			qr.error("Error saving mutedByDeafen:", e);
		});
	}
}, Yr = new y("UserAudioMixer"), Xr = class {
	client;
	context;
	boosts = /* @__PURE__ */ new Map();
	volumeOverrides = /* @__PURE__ */ new Map();
	constructor(e) {
		this.client = e;
	}
	getVolume(e) {
		let t = this.volumeOverrides.get(e) ?? game.settings?.get("avclient-livekit", "userVolumes")[e] ?? this.client.settings.getUser(e)?.volume ?? 1;
		return Math.min(Math.max(t, 0), 2);
	}
	setVolume(e, t, n = !0) {
		let r = Math.min(Math.max(t, 0), 2), i = {
			...game.settings?.get(g, "userVolumes"),
			[e]: r
		};
		this.volumeOverrides.set(e, r), this.apply(e), n && game.settings?.set(g, "userVolumes", i).catch((e) => {
			Yr.error("Error saving user volume:", e);
		}).finally(() => {
			this.volumeOverrides.delete(e);
		});
	}
	isLocallyMuted(e) {
		return game.settings?.get(g, "userLocalMutes")[e] === !0;
	}
	async setLocallyMuted(e, t) {
		let n = {
			...game.settings?.get(g, "userLocalMutes"),
			[e]: t
		};
		try {
			await game.settings?.set(g, "userLocalMutes", n);
		} catch (e) {
			Yr.error("Error saving local mute:", e);
		}
		this.apply(e);
	}
	apply(e) {
		if (e === game.user?.id) return;
		let t = this.client.voiceControls.isDeafened() || this.isLocallyMuted(e) || this.client.settings.getUser(e)?.blocked === !0, n = this.getVolume(e), r = this.getMicrophoneTrack(e), i = !t && n > 1 && this.canBoost() ? r : void 0, a = !!i, o = this.client.getUserAudioElements(e), s = this.client.settings.client.audioSink, c = s === "default" ? "" : s, l = "setSinkId" in HTMLMediaElement.prototype;
		for (let e of o) {
			l && e.sinkId !== c && e.setSinkId(c).catch((e) => {
				Yr.warn("Unable to change the audio output device:", e);
			});
			let r = e.classList.contains(`user-${u.Source.Microphone}-audio`);
			e.volume = Math.min(n, 1), e.muted = t || a && r;
		}
		i ? this.startBoost(e, i.mediaStreamTrack, n) : this.stopBoost(e);
	}
	applyAll() {
		for (let e of game.users?.keys() ?? []) this.apply(e);
	}
	stopAll() {
		for (let e of [...this.boosts.keys()]) this.stopBoost(e);
	}
	canBoost() {
		let e = this.client.settings.client.audioSink;
		return !e || e === "default" || "setSinkId" in AudioContext.prototype;
	}
	getMicrophoneTrack(e) {
		let t = this.client.liveKitParticipants.get(e)?.getTrackPublication(u.Source.Microphone)?.track;
		return t instanceof l ? t : void 0;
	}
	getContext() {
		(!this.context || this.context.state === "closed") && (this.context = new AudioContext(), ve(this.context));
		let e = this.client.settings.client.audioSink, t = this.context, n = !e || e === "default" ? "" : e;
		return t.setSinkId && t.sinkId !== n && t.setSinkId(n).catch((e) => {
			Yr.warn("Unable to set the boosted audio output device:", e);
		}), this.context;
	}
	startBoost(e, t, n) {
		let r = this.boosts.get(e);
		if (r?.track !== t) {
			this.stopBoost(e);
			let n = this.getContext(), i = n.createMediaStreamSource(new MediaStream([t])), a = n.createGain();
			i.connect(a).connect(n.destination), r = {
				track: t,
				source: i,
				gain: a
			}, this.boosts.set(e, r);
		}
		r.gain.gain.value = n;
	}
	stopBoost(e) {
		let t = this.boosts.get(e);
		t && (t.source.disconnect(), t.gain.disconnect(), this.boosts.delete(e));
	}
}, Zr = class {
	client;
	decoratedViews = /* @__PURE__ */ new WeakSet();
	constructor(e) {
		this.client = e;
	}
	decorate(e) {
		for (let t of e.querySelectorAll(".camera-view[data-user]")) this.decorateView(t);
	}
	refresh(e) {
		let t = this.getView(e);
		t && this.updateView(t, e);
	}
	refreshAll() {
		for (let e of document.querySelectorAll(".camera-view[data-user]")) {
			let t = e.dataset.user;
			t && this.updateView(e, t);
		}
	}
	setSpeaking(e, t) {
		let n = this.getView(e);
		n?.classList.toggle("livekit-speaking", t), n?.querySelector(".livekit-camera-avatar .livekit-avatar")?.classList.toggle("is-speaking", t);
	}
	getView(e) {
		return document.querySelector(`.camera-view[data-user="${e}"]`);
	}
	decorateView(e) {
		let t = e.dataset.user;
		if (t) {
			if (!e.querySelector(".livekit-camera-avatar")) {
				let n = game.users?.get(t), r = A("div", {
					className: "livekit-camera-avatar",
					children: [new In({
						src: n?.avatar,
						size: "fill"
					}).element]
				}), i = A("div", { className: "livekit-camera-badges" }), a = A("div", { className: "livekit-ring" }), o = e.querySelector("video.user-camera")?.parentElement ?? e;
				getComputedStyle(o).position === "static" && o.classList.add("livekit-positioned"), o.append(r, a, i);
			}
			this.decoratedViews.has(e) || (this.decoratedViews.add(e), e.classList.add("livekit-camera-view"), e.querySelector(".webrtc-volume-slider")?.addEventListener("change", (e) => {
				this.client.onVolumeChange(e);
			}), t !== game.user?.id && e.addEventListener("contextmenu", (n) => {
				document.body.classList.contains("livekit-discord-ui") && (n.preventDefault(), n.stopPropagation(), this.client.userMenu.open(t, n.clientX, n.clientY, e));
			})), this.updateView(e, t);
		}
	}
	updateView(e, t) {
		let n = this.client.isUserSpeaking(t), r = this.client.isUserMuted(t), i = this.client.voiceControls.isUserDeafened(t);
		e.classList.toggle("livekit-speaking", n);
		let a = e.querySelector("video.user-camera");
		e.classList.toggle("livekit-no-video", !this.client.isUserVideoOn(t) || !a || a.hasAttribute("hidden")), e.classList.toggle("livekit-muted", r), e.classList.toggle("livekit-deafened", i), e.querySelector(".livekit-camera-avatar .livekit-avatar")?.classList.toggle("is-speaking", n);
		let o = e.querySelector(".livekit-camera-badges");
		o && (o.replaceChildren(), r && o.append(K({
			icon: "fa-microphone-slash",
			label: I("muted")
		})), i && o.append(K({
			icon: "fa-headphones",
			label: I("deafened"),
			slashed: !0
		})));
	}
}, Qr = class {
	client;
	menu;
	constructor(e) {
		this.client = e, this.menu = new Pn("livekit-noise-menu", () => I("noiseSuppressionModel"), () => this.items());
	}
	get isOpen() {
		return this.menu.isOpen;
	}
	toggle(e, t = e) {
		this.menu.toggle(e, t);
	}
	close() {
		this.menu.close();
	}
	items() {
		let e = this.client, t = () => {
			e.onNoiseSettingsChanged();
		}, n = e.getNoiseModelOptions().map((n) => ({
			type: "radio",
			label: n.label,
			detail: n.detail,
			checked: n.selected,
			disabled: !n.selectable && !n.selected,
			onSelect: () => e.selectNoiseModel(n.model).then(t)
		})), r = (e) => {
			let n = game.settings?.get("avclient-livekit", e) ?? !1;
			return {
				type: "checkbox",
				label: I(e),
				checked: n,
				onSelect: () => game.settings?.set(g, e, !n).then(t)
			};
		};
		return [
			{
				type: "header",
				label: I("noiseSuppressionModel")
			},
			...n,
			{ type: "separator" },
			{
				type: "header",
				label: I("noiseRefinements")
			},
			r("audioAutoGainControl"),
			r("audioEchoCancellation"),
			{ type: "separator" },
			{
				type: "action",
				label: I("noiseResetDefaults"),
				icon: "fa-rotate-left",
				keepOpen: !0,
				onSelect: () => e.resetNoiseSettings().then(t)
			}
		];
	}
}, $r = new y("ConnectionPopover"), ei = 2e3, ti = class {
	client;
	popover = new zt("livekit-connection-details", () => {
		window.clearInterval(this.timer);
	});
	timer;
	generation = 0;
	constructor(e) {
		this.client = e;
	}
	get isOpen() {
		return this.popover.isOpen;
	}
	toggle(e, t) {
		if (this.popover.isOpen) {
			this.close();
			return;
		}
		let n = ++this.generation;
		this.render().then(() => {
			n === this.generation && (this.popover.openAt(e, t), window.clearInterval(this.timer), this.timer = window.setInterval(() => {
				this.render();
			}, ei));
		});
	}
	close() {
		this.generation += 1, window.clearInterval(this.timer), this.popover.close();
	}
	async render() {
		let e = this.client, t = e.liveKitRoom, n = t?.state ?? m.Disconnected, r = n === m.Connected, i = [];
		if (i.push([I("connectionStatus"), ni(n)]), r) {
			let n = await e.audioTrack?.getSenderStats().catch((e) => {
				$r.debug("Unable to read the sender statistics:", e);
			}), r = await e.getPingMs().catch(() => void 0);
			r !== void 0 && i.push([I("ping"), `${r.toString()} ms`]);
			let a = t?.localParticipant.connectionQuality ?? "unknown";
			i.push([I("connectionQualityLabel"), game.i18n?.localize(`LIVEKITAVCLIENT.connectionQualityLevel.${a}`) ?? a]);
			let o = t?.serverInfo, s = [Rr(t, e.liveKitServerAddress) ? "LiveKit Cloud" : "LiveKit", o?.version].filter(Boolean).join(" ");
			i.push([I("server"), s]), o?.region && i.push([I("region"), o.region]);
			let c = e.getAudioCodec();
			if (c && i.push([I("audioCodec"), c]), n?.packetsSent !== void 0) {
				let e = n.packetsLost ?? 0, t = n.packetsSent + e;
				i.push([I("packetLoss"), `${(t ? e / t * 100 : 0).toFixed(1)}%`]);
			}
			n?.jitter !== void 0 && i.push([I("jitter"), `${Math.round(n.jitter * 1e3).toString()} ms`]);
		}
		let a = e.getAudioProcessingConfig().model;
		i.push([I("noiseSuppressionModel"), a ? e.getNoiseModelLabel(a) : I("noiseSuppressionOff")]);
		let o = e.settings.client.voice.mode !== "always";
		i.push([I("inputMode"), I(o ? "inputModePushToTalk" : "inputModeVoiceActivity")]), o || i.push([I("inputSensitivity"), this.sensitivityLabel()]);
		let s = F("title");
		this.popover.element.setAttribute("aria-labelledby", s), this.popover.element.dataset.status = r ? "connected" : "other", this.popover.element.replaceChildren(A("h3", {
			className: "livekit-popover-title",
			text: I("connectionDetails"),
			attrs: { id: s }
		}), A("dl", {
			className: "livekit-details",
			children: i.flatMap(([e, t]) => [A("dt", { text: e }), A("dd", { text: t })])
		}), A("footer", {
			className: "livekit-popover-footer",
			children: [U({
				label: I("reconnect"),
				icon: A("i", {
					className: "fa-solid fa-rotate",
					attrs: { "aria-hidden": "true" }
				}),
				onClick: () => {
					this.reconnect();
				}
			})]
		})), this.popover.reposition();
	}
	sensitivityLabel() {
		let e = this.client.voiceGate;
		if (!e) return I("inputSensitivityOff");
		let { auto: t } = this.client.getVoiceGateSettings(), n = e.report?.threshold, r = n === void 0 ? "" : ` (${n.toString()} dB)`;
		return `${I(t ? "inputSensitivityAuto" : "inputSensitivityManual")}${r}`;
	}
	reconnect() {
		let e = this.client.avMaster;
		this.close(), e.disconnect().then(() => e.connect()).catch((e) => {
			$r.error("Error reconnecting:", e);
		});
	}
};
function ni(e) {
	return I(`voiceStatus${e === m.Connected ? "Connected" : e === m.Disconnected ? "Disconnected" : e === m.Connecting ? "Connecting" : "Reconnecting"}`);
}
//#endregion
//#region src/ui/PlayersListDecorator.ts
var ri = class {
	client;
	constructor(e) {
		this.client = e;
	}
	decorate(e) {
		for (let t of e.querySelectorAll("li.player[data-user-id]")) this.updateRow(t);
	}
	refresh(e) {
		let t = e ? `#players li.player[data-user-id="${e}"]` : "#players li.player[data-user-id]";
		for (let e of document.querySelectorAll(t)) this.updateRow(e);
	}
	setSpeaking(e, t) {
		document.querySelector(`#players li.player[data-user-id="${e}"]`)?.classList.toggle("livekit-speaking", t && this.inCall(e));
	}
	updateRow(e) {
		let t = e.dataset.userId ?? "", n = this.client, r = this.inCall(t);
		e.classList.toggle("livekit-in-call", r), e.classList.toggle("livekit-speaking", r && n.isUserSpeaking(t));
		let i = e.querySelector(".livekit-player-status");
		i || (i = A("span", { className: "livekit-player-status" }), e.append(i)), i.replaceChildren(), r && (n.isUserMuted(t) && i.append(K({
			icon: "fa-microphone-slash",
			label: I("muted")
		})), n.voiceControls.isUserDeafened(t) && i.append(K({
			icon: "fa-headphones",
			label: I("deafened"),
			slashed: !0
		})));
	}
	inCall(e) {
		return document.body.classList.contains("livekit-discord-ui") && this.client.liveKitParticipants.has(e);
	}
}, ii = new y("UserMenu"), ai = class {
	client;
	menu;
	userId;
	constructor(e) {
		this.client = e, this.menu = new Pn("livekit-user-menu", () => game.users?.get(this.userId ?? "")?.name ?? I("userVolume"), () => this.items());
	}
	open(e, t, n, r) {
		game.users?.get(e) && (this.userId = e, this.menu.openAtPoint(t, n, r));
	}
	close() {
		this.menu.close();
	}
	items() {
		let e = this.userId, t = game.users?.get(e ?? "");
		if (!e || !t) return [];
		let n = e === game.user?.id;
		return [
			{
				type: "custom",
				element: A("div", {
					className: "livekit-user-menu-header",
					children: [new In({
						src: t.avatar,
						size: "sm"
					}).element, A("span", {
						className: "livekit-user-menu-name",
						text: t.name
					})]
				})
			},
			...n ? [] : this.audioItems(e),
			...this.dockItems(e),
			...this.gmItems(e),
			...this.breakoutItems(e)
		];
	}
	audioItems(e) {
		let t = this.client.userAudioMixer, n = t.isLocallyMuted(e);
		return [
			{ type: "separator" },
			{
				type: "custom",
				element: jt({
					label: I("userVolume"),
					min: 0,
					max: 200,
					value: Math.round(t.getVolume(e) * 100),
					format: (e) => `${Math.round(e).toString()}%`,
					onInput: (n) => {
						t.setVolume(e, n / 100, !1);
					},
					onChange: (n) => {
						t.setVolume(e, n / 100);
					}
				})
			},
			{ type: "separator" },
			{
				type: "checkbox",
				label: I("userLocalMute"),
				checked: n,
				onSelect: () => t.setLocallyMuted(e, !n).then(() => {
					this.client.onVoiceStateChanged(e);
				})
			},
			{
				type: "action",
				label: I("userVolumeReset"),
				icon: "fa-rotate-left",
				keepOpen: !0,
				onSelect: () => {
					t.setVolume(e, 1);
				}
			}
		];
	}
	dockItems(e) {
		let t = this.client.dock;
		if (!t) return [];
		let n = e === game.user?.id, r = game.settings?.get(g, "userVideoHidden")[e] === !0, i = t.isPoppedOut(e);
		return [
			{ type: "separator" },
			!i && {
				type: "action",
				label: I("dockFocusUser"),
				icon: "fa-expand",
				onSelect: () => {
					t.focus(e);
				}
			},
			{
				type: "action",
				label: I(i ? "returnToDock" : "popOut"),
				icon: i ? "fa-arrow-right-to-bracket" : "fa-up-right-from-square",
				onSelect: () => t.setPoppedOut(e, !i)
			},
			t.canPictureInPicture(e) && {
				type: "action",
				label: I("pictureInPicture"),
				icon: "fa-clone",
				onSelect: () => t.pictureInPicture(e)
			},
			!n && {
				type: "checkbox",
				label: I("hideVideoForMe"),
				checked: r,
				onSelect: async () => {
					await game.settings?.set("avclient-livekit", "userVideoHidden", {
						...game.settings.get("avclient-livekit", "userVideoHidden"),
						[e]: !r
					}), t.refresh();
				}
			},
			!n && {
				type: "action",
				label: I("hideFromDock"),
				detail: I("hideFromDockHint"),
				icon: "fa-user-slash",
				onSelect: async () => {
					game.webrtc?.settings.set("client", `users.${e}.blocked`, !0), await t.render();
				}
			}
		].filter((e) => e !== !1);
	}
	gmItems(e) {
		let t = game.users?.get(e);
		if (!game.user?.isGM || e === game.user.id || !t) return [];
		let n = game.webrtc?.settings.getUser(e), r = (e) => {
			let r = e === "BROADCAST_AUDIO" ? n?.canBroadcastAudio !== !1 : n?.canBroadcastVideo !== !1;
			return t.update({ [`permissions.${e}`]: !r }).then(() => game.webrtc?.render()).catch((e) => {
				ii.error("Error changing the user's permissions:", e);
			});
		};
		return [
			{ type: "separator" },
			{
				type: "header",
				label: I("gameMaster")
			},
			{
				type: "checkbox",
				label: I("blockAudio"),
				checked: n?.canBroadcastAudio === !1,
				onSelect: () => r("BROADCAST_AUDIO")
			},
			{
				type: "checkbox",
				label: I("blockVideo"),
				checked: n?.canBroadcastVideo === !1,
				onSelect: () => r("BROADCAST_VIDEO")
			}
		];
	}
	breakoutItems(e) {
		let t = Vr(e, this.client);
		return t.length ? [{ type: "separator" }, ...t.map((e) => ({
			type: "action",
			label: e.label,
			icon: e.icon,
			onSelect: e.run
		}))] : [];
	}
}, oi = new y("VoicePanel"), si = 2e3, Y = 8, ci = 4, li = class {
	client;
	element;
	statusText = A("span", {
		className: "livekit-panel-status-text",
		attrs: { role: "status" }
	});
	statusIcon = N("fa-signal", "livekit-panel-signal");
	subtext = A("span", { className: "livekit-panel-subtext" });
	connectionButton;
	avatar = new In({ className: "livekit-panel-avatar" });
	userName = A("span", { className: "livekit-panel-name" });
	userSubtext = A("span", { className: "livekit-panel-subtext" });
	muteButton;
	deafenButton;
	cameraButton;
	noiseButton;
	settingsButton;
	pingMs;
	pingTimer;
	constructor(e) {
		this.client = e, this.connectionButton = V({
			icon: "fa-phone-slash",
			label: I("disconnect"),
			className: "livekit-panel-connection",
			onClick: () => {
				this.toggleConnection();
			}
		}), this.muteButton = V({
			icon: "fa-microphone",
			label: I("mute"),
			onClick: () => {
				this.client.voiceControls.toggleMute();
			}
		}), this.deafenButton = V({
			icon: "fa-headphones",
			label: I("deafen"),
			onClick: () => {
				this.client.voiceControls.toggleDeafen();
			}
		}), this.cameraButton = V({
			icon: "fa-video",
			label: I("cameraOff"),
			onClick: () => {
				this.client.voiceControls.toggleCamera();
			}
		}), this.noiseButton = V({
			icon: "fa-wand-magic-sparkles",
			label: I("noiseSuppressionModel"),
			onClick: () => {
				this.client.noiseModelMenu.toggle(this.element, this.noiseButton);
			}
		}), this.noiseButton.setAttribute("aria-haspopup", "menu"), this.settingsButton = V({
			icon: "fa-gear",
			label: I("voiceSettings"),
			onClick: () => {
				this.client.audioSettingsPopover.toggle(this.element, this.settingsButton);
			}
		}), this.settingsButton.setAttribute("aria-haspopup", "dialog");
		let t = A("button", {
			className: "livekit-panel-status-info",
			title: I("connectionDetails"),
			attrs: {
				type: "button",
				"aria-haspopup": "dialog"
			},
			children: [A("span", {
				className: "livekit-panel-status-line",
				children: [this.statusIcon, this.statusText]
			}), this.subtext]
		});
		t.addEventListener("click", () => {
			this.client.connectionPopover.toggle(this.element, t);
		});
		let n = A("div", {
			className: "livekit-panel-status",
			children: [t, this.connectionButton]
		});
		this.makeDraggable(n), this.element = j(A("section", {
			className: "livekit-voice-panel",
			attrs: { "aria-label": I("voicePanel") },
			children: [n, A("div", {
				className: "livekit-panel-user",
				children: [
					this.avatar.element,
					A("div", {
						className: "livekit-panel-user-info",
						children: [this.userName, this.userSubtext]
					}),
					A("div", {
						className: "livekit-panel-buttons",
						attrs: {
							role: "toolbar",
							"aria-label": I("voicePanel")
						},
						children: [
							this.muteButton,
							this.deafenButton,
							this.cameraButton,
							this.noiseButton,
							this.settingsButton
						]
					})
				]
			})]
		}));
	}
	sync() {
		let e = document.body.classList.contains("livekit-discord-ui") && !this.client.useExternalAV && this.client.settings.get("world", "mode") !== foundry.av.AVSettings.AV_MODES.DISABLED, t = this.client.dock, n = e && !!t?.canHostPanel();
		e ? n && t ? this.element.parentElement !== t.panelSlot && (t.panelSlot.append(this.element), this.element.style.removeProperty("left"), this.element.style.removeProperty("top")) : this.element.parentElement !== document.body && (document.body.append(this.element), this.element.classList.remove("is-docked"), this.position()) : this.element.isConnected && (this.element.remove(), window.removeEventListener("resize", this.onResize)), this.element.classList.toggle("is-docked", n), e && window.addEventListener("resize", this.onResize), this.update();
	}
	get docked() {
		return this.element.classList.contains("is-docked");
	}
	update() {
		if (!this.element.isConnected) {
			this.stopPing();
			return;
		}
		let e = this.client.liveKitRoom, t = e?.state ?? m.Disconnected, n = t === m.Connected, r = t === m.Connected ? "connected" : t === m.Disconnected ? "disconnected" : t === m.Connecting ? "connecting" : "reconnecting";
		this.element.dataset.status = r, this.statusText.textContent = I(`voiceStatus${r.charAt(0).toUpperCase()}${r.slice(1)}`);
		let i = e?.localParticipant.connectionQuality, a = n && i ? i : d.Unknown;
		this.statusIcon.dataset.quality = a, M(this.statusIcon, game.i18n?.localize(`LIVEKITAVCLIENT.connectionQuality.${a}`) ?? a), this.statusIcon.setAttribute("role", "img");
		let o = this.client.breakoutRoom ? I("breakoutRoom") : game.world?.title ?? "";
		this.subtext.textContent = n && this.pingMs !== void 0 ? `${o} · ${this.pingMs.toString()} ms` : o, H(this.connectionButton, {
			icon: n ? "fa-phone-slash" : "fa-phone",
			label: I(n ? "disconnect" : "connect"),
			disabled: t === m.Connecting || t === m.Reconnecting
		}), this.connectionButton.classList.toggle("is-danger", n), this.connectionButton.classList.toggle("is-active", !n), n ? this.startPing() : (this.stopPing(), this.pingMs = void 0);
		let s = game.user?.id ?? "";
		this.avatar.setSource(game.user?.avatar), this.avatar.setSpeaking(this.client.isUserSpeaking(s)), this.userName.textContent = game.user?.name ?? "";
		let c = this.client.getAudioProcessingConfig().model;
		this.userSubtext.textContent = c ? this.client.getNoiseModelLabel(c) : I("noiseSuppressionOff");
		let l = this.client.voiceControls, u = l.isMuted(), f = l.isDeafened();
		H(this.muteButton, {
			icon: u ? "fa-microphone-slash" : "fa-microphone",
			label: I(u ? "unmute" : "mute"),
			off: u,
			pressed: u
		}), H(this.deafenButton, {
			label: I(f ? "undeafen" : "deafen"),
			off: f,
			slashed: f,
			pressed: f
		}), H(this.noiseButton, { active: !!c });
		let p = l.isCameraOff();
		this.cameraButton.hidden = !l.canUseCamera(), H(this.cameraButton, {
			icon: p ? "fa-video-slash" : "fa-video",
			label: I(p ? "cameraOn" : "cameraOff"),
			off: p,
			pressed: p
		});
	}
	setSpeaking(e) {
		this.avatar.setSpeaking(e);
	}
	toggleConnection() {
		let e = this.client.liveKitRoom?.state === m.Connected;
		this.connectionButton.disabled = !0, (e ? this.client.avMaster.disconnect().then(() => {
			this.client.render();
		}) : this.client.avMaster.connect()).catch((e) => {
			oi.error("Error changing the voice connection:", e);
		}).finally(() => {
			this.update();
		});
	}
	startPing() {
		if (this.pingTimer !== void 0) return;
		let e = async () => {
			try {
				let e = await this.client.getPingMs();
				e !== this.pingMs && (this.pingMs = e, this.update());
			} catch (e) {
				oi.debug("Unable to read the connection round trip time:", e);
			}
		};
		e(), this.pingTimer = window.setInterval(() => void e(), si);
	}
	stopPing() {
		this.pingTimer !== void 0 && (window.clearInterval(this.pingTimer), this.pingTimer = void 0);
	}
	position() {
		if (this.docked) return;
		let e = game.settings?.get(g, "voicePanelPosition"), { width: t, height: n } = this.element.getBoundingClientRect(), r, i;
		if (e && typeof e.left == "number" && typeof e.top == "number") ({left: r, top: i} = e);
		else {
			let e = document.getElementById("players")?.getBoundingClientRect();
			r = e ? e.left : Y * 2, i = (e ? e.top : window.innerHeight) - n - Y;
		}
		this.element.style.left = `${P(r, Y, window.innerWidth - t - Y).toString()}px`, this.element.style.top = `${P(i, Y, window.innerHeight - n - Y).toString()}px`;
	}
	onResize = () => {
		this.position();
	};
	makeDraggable(e) {
		e.addEventListener("pointerdown", (t) => {
			let n = t.target;
			if (this.docked || t.button !== 0 || n.closest("button:not(.livekit-panel-status-info)")) return;
			let r = this.element.getBoundingClientRect(), i = t.clientX - r.left, a = t.clientY - r.top, o = !1, s = (n) => {
				!o && Math.hypot(n.clientX - t.clientX, n.clientY - t.clientY) < ci || (o || (o = !0, e.setPointerCapture(t.pointerId), this.element.classList.add("dragging")), this.element.style.left = `${P(n.clientX - i, Y, window.innerWidth - r.width - Y).toString()}px`, this.element.style.top = `${P(n.clientY - a, Y, window.innerHeight - r.height - Y).toString()}px`);
			}, c = () => {
				if (e.removeEventListener("pointermove", s), e.removeEventListener("pointerup", c), e.removeEventListener("pointercancel", c), !o) return;
				e.addEventListener("click", (e) => {
					e.stopPropagation();
				}, {
					capture: !0,
					once: !0
				}), this.element.classList.remove("dragging");
				let { left: t, top: n } = this.element.getBoundingClientRect();
				game.settings?.set(g, "voicePanelPosition", {
					left: t,
					top: n
				}).catch((e) => {
					oi.error("Error saving the voice panel position:", e);
				});
			};
			e.addEventListener("pointermove", s), e.addEventListener("pointerup", c), e.addEventListener("pointercancel", c);
		});
	}
}, X = new y(), Z = "none", di = "livekit-audio";
function fi(e) {
	try {
		return (game.settings?.storage.get("client"))?.getItem(`${g}.${e}`) != null;
	} catch {
		return !0;
	}
}
function pi({ model: e, gate: t }) {
	return !e && !t ? Z : `${e ?? Z}|gate:${t ? "on" : "off"}`;
}
var mi = /* @__PURE__ */ function(e) {
	return e.Uninitialized = "uninitialized", e.Initializing = "initializing", e.Initialized = "initialized", e;
}({}), hi = class {
	avMaster;
	liveKitAvClient;
	settings;
	render;
	audioBroadcastEnabled = !1;
	audioTrack = null;
	audioCaptureParams = null;
	audioProcessingQueue = Promise.resolve();
	audioProcessorContext;
	audioProcessorState = null;
	failedAudioProcessors = /* @__PURE__ */ new Set();
	speakingUsers = /* @__PURE__ */ new Set();
	voiceGateFailed = !1;
	voiceGatePreview;
	voiceGateListeners = /* @__PURE__ */ new Set();
	gateSpeaking = !1;
	krispSupported;
	liveKitServerAddress;
	scheduleAudioSourceChange = () => void 0;
	scheduleAudioProcessingRefresh = () => void 0;
	voiceControls = new Jr(this);
	userAudioMixer = new Xr(this);
	cameraViewDecorator = new Zr(this);
	userMenu = new ai(this);
	audioSettingsPopover = new En(this);
	noiseModelMenu = new Qr(this);
	connectionPopover = new ti(this);
	playersList = new ri(this);
	voicePanelInstance;
	breakoutRoom;
	connectionState = m.Disconnected;
	initState = "uninitialized";
	liveKitParticipants = /* @__PURE__ */ new Map();
	liveKitRoom = null;
	screenTracks = [];
	useExternalAV = !1;
	videoTrack = null;
	videoBackgroundFailed = !1;
	failedVideoBackgroundImage;
	videoBackgroundQueue = Promise.resolve();
	windowClickListener = null;
	liveKitServerTypes = {
		custom: {
			key: "custom",
			label: `${_}.serverTypeCustom`,
			details: `${_}.serverDetailsCustom`,
			urlRequired: !0,
			usernameRequired: !0,
			passwordRequired: !0,
			tokenFunction: St
		},
		tavern: {
			key: "tavern",
			label: `${_}.serverTypeTavern`,
			details: `${_}.serverDetailsTavern`,
			url: "livekit.tavern.at",
			urlRequired: !1,
			usernameRequired: !1,
			passwordRequired: !1,
			tokenFunction: Ct
		}
	};
	defaultLiveKitServerType = this.liveKitServerTypes.custom;
	constructor(e) {
		this.avMaster = e.master, this.liveKitAvClient = e, this.settings = e.settings, this.render = foundry.utils.debounce(this.avMaster.render.bind(this.liveKitAvClient), 2e3), this.scheduleAudioSourceChange = foundry.utils.debounce(() => {
			this.audioProcessingQueue = this.audioProcessingQueue.then(() => this.changeAudioSource(!0)).catch((e) => {
				X.error("Error changing audio source:", e);
			});
		}, 300), this.scheduleAudioProcessingRefresh = foundry.utils.debounce(() => {
			this.refreshAudioProcessing(!0);
		}, 300), Hooks.callAll("liveKitClientAvailable", this);
	}
	addAllParticipants() {
		if (!this.liveKitRoom) {
			X.warn("Attempting to add participants before the LiveKit room is available");
			return;
		}
		let e = game.user?.id;
		e && this.liveKitParticipants.set(e, this.liveKitRoom.localParticipant), this.liveKitRoom.remoteParticipants.forEach((e) => {
			this.onParticipantConnected(e);
		});
	}
	addConnectionButtons(e) {
		if (this.useExternalAV) return;
		let t = document.createElement("button");
		t.type = "button", t.className = "av-control inline-control toggle icon fa-solid fa-fw fa-toggle-off livekit-control connect hidden", t.dataset.tooltip = "", t.ariaLabel = game.i18n?.localize("LIVEKITAVCLIENT.connect") ?? "connect";
		let n = document.createElement("button");
		n.type = "button", n.className = "av-control inline-control toggle icon fa-solid fa-fw fa-toggle-on livekit-control disconnect hidden", n.dataset.tooltip = "", n.ariaLabel = game.i18n?.localize("LIVEKITAVCLIENT.disconnect") ?? "disconnect", t.addEventListener("click", () => {
			t.classList.toggle("disabled", !0), this.avMaster.connect().catch((e) => {
				X.error("Error connecting:", e);
			});
		}), e.before(t), n.addEventListener("click", () => {
			n.classList.toggle("disabled", !0), this.avMaster.disconnect().then(() => {
				this.render();
			}).catch((e) => {
				X.error("Error disconnecting:", e);
			});
		}), e.before(n), this.liveKitRoom?.state === m.Connected ? n.classList.toggle("hidden", !1) : t.classList.toggle("hidden", !1);
	}
	addNoiseCancellationButton(e) {
		if (this.useExternalAV || !Er()) return;
		this.noiseModelMenu.close();
		let t = document.createElement("button");
		t.type = "button", t.className = "av-control inline-control toggle icon fa-solid fa-fw fa-wand-magic-sparkles livekit-control livekit-noise-control", t.dataset.tooltip = "", this.updateNoiseModelButton(t), t.addEventListener("click", (e) => {
			e.preventDefault(), e.stopPropagation(), this.noiseModelMenu.toggle(t);
		}), e.before(t);
	}
	updateNoiseModelButton(e) {
		let t = this.getSelectedNoiseModel();
		e.classList.toggle("active", t !== "none");
		let n = game.i18n?.localize("LIVEKITAVCLIENT.noiseSuppressionModel") ?? "Noise cancellation", r = this.getNoiseModelLabel(t), i = this.getAudioProcessingConfig().model ?? "none";
		t !== "none" && i !== t && (r += ` → ${this.getNoiseModelLabel(i)}`), e.ariaLabel = `${n}: ${r}`;
	}
	getSelectedNoiseModel() {
		return !fi("enhancedNoiseCancellation") && !fi("noiseSuppressionModel") ? this.getDefaultNoiseModel() : game.settings?.get("avclient-livekit", "enhancedNoiseCancellation") ?? !1 ? Dr(game.settings?.get(g, "noiseSuppressionModel")) : "none";
	}
	getDefaultNoiseModel() {
		let e = game.settings?.get(g, "defaultNoiseModel");
		return e === "none" ? "none" : Dr(e);
	}
	isKrispAvailable() {
		return (game.settings?.get("avclient-livekit", "allowKrisp") ?? !0) && this.krispSupported === !0 && Rr(this.liveKitRoom, this.liveKitServerAddress);
	}
	async checkKrispSupport() {
		this.krispSupported === void 0 && (this.krispSupported = await Pr(), !this.krispSupported && this.getSelectedNoiseModel() === "krisp" && ui.notifications?.warn(game.i18n?.format("LIVEKITAVCLIENT.krispUnsupportedFallback", { fallback: this.getNoiseModelLabel("gtcrn") }) ?? "krispUnsupportedFallback"));
	}
	getNoiseModelLabel(e) {
		let t = `${_}.noiseSuppressionModel${e.charAt(0).toUpperCase() + e.slice(1)}`;
		return game.i18n?.localize(t) ?? e;
	}
	getNoiseModelOptions() {
		let e = this.getSelectedNoiseModel(), t = Rr(this.liveKitRoom, this.liveKitServerAddress), n = [
			"none",
			"speex",
			"rnnoise",
			"gtcrn"
		];
		return (t || e === "krisp") && n.push("krisp"), n.map((n) => {
			let r;
			return n === "krisp" && !(game.settings?.get("avclient-livekit", "allowKrisp") ?? !0) ? r = game.i18n?.localize(`${_}.krispDisabledByGM`) : n === "krisp" && !t ? r = game.i18n?.localize(`${_}.krispRequiresCloud`) : n === "krisp" && this.krispSupported === !1 && (r = game.i18n?.localize(`${_}.krispUnsupported`)), {
				model: n,
				label: this.getNoiseModelLabel(n),
				detail: r,
				selectable: r === void 0,
				selected: n === e
			};
		});
	}
	async selectNoiseModel(e) {
		if (e === "none") {
			await game.settings?.set(g, "enhancedNoiseCancellation", !1);
			return;
		}
		await game.settings?.set(g, "noiseSuppressionModel", e), (game.settings?.get("avclient-livekit", "enhancedNoiseCancellation") ?? !1) || await game.settings?.set(g, "enhancedNoiseCancellation", !0);
	}
	async resetNoiseSettings() {
		await this.selectNoiseModel(this.getDefaultNoiseModel()), await game.settings?.set(g, "audioAutoGainControl", !0), await game.settings?.set(g, "audioEchoCancellation", !0), await game.settings?.set(g, "audioNoiseSuppression", !0), await game.settings?.set(g, "audioAutoSensitivity", !0), await game.settings?.set(g, "audioNoiseGateThreshold", -50);
	}
	onNoiseSettingsChanged() {
		for (let e of document.querySelectorAll(".livekit-noise-control")) this.updateNoiseModelButton(e);
		this.onVoiceStateChanged();
	}
	get voicePanelIfCreated() {
		return this.voicePanelInstance;
	}
	get voicePanel() {
		return this.voicePanelInstance ??= new li(this), this.voicePanelInstance;
	}
	applyDiscordStyle() {
		let e = (game.settings?.get("avclient-livekit", "allowDiscordStyleUI") ?? !0) && (game.settings?.get("avclient-livekit", "discordStyleUI") ?? !0) && !this.useExternalAV;
		document.body.classList.toggle("livekit-discord-ui", e), e || (this.userMenu.close(), this.audioSettingsPopover.close(), this.connectionPopover.close()), this.playersList.refresh(), this.voicePanel.sync(), this.cameraViewDecorator.refreshAll();
	}
	onVoiceStateChanged(e) {
		e ? (this.userAudioMixer.apply(e), this.cameraViewDecorator.refresh(e)) : (this.userAudioMixer.applyAll(), this.cameraViewDecorator.refreshAll()), this.playersList.refresh(e), this.dock?.refresh(), this.voicePanelInstance?.update();
	}
	get dock() {
		return ui.webrtc instanceof ar ? ui.webrtc : void 0;
	}
	isUserSpeaking(e) {
		return this.speakingUsers.has(e);
	}
	isUserMuted(e) {
		if (e === game.user?.id) return this.voiceControls.isMuted() || !this.audioTrack;
		let t = this.liveKitParticipants.get(e);
		if (!(t instanceof te)) return !1;
		let n = t.getTrackPublication(u.Source.Microphone);
		return !n || n.isMuted;
	}
	async getPingMs() {
		let e = (await this.audioTrack?.getSenderStats())?.roundTripTime;
		return e === void 0 && (e = (await this.videoTrack?.getSenderStats())?.find((e) => e.roundTripTime !== void 0)?.roundTripTime), e === void 0 ? void 0 : Math.round(e * 1e3);
	}
	getAudioCodec() {
		let e = this.audioTrack?.sender?.getParameters().codecs ?? [], t = (e) => {
			let t = e?.mimeType.replace(/^audio\//, "");
			return t?.toLowerCase() === "opus" ? "Opus" : t;
		}, n = e.at(0);
		return n?.mimeType.toLowerCase() === "audio/red" ? game.i18n?.format("LIVEKITAVCLIENT.audioCodecRed", { codec: t(e.at(1)) ?? "Opus" }) ?? "RED" : t(n);
	}
	isUserVideoOn(e) {
		let t = e === game.user?.id ? this.videoTrack : this.getUserVideoTrack(e);
		return !!t && !t.isMuted;
	}
	addConnectionQualityIndicator(e) {
		if (!game.settings?.get("avclient-livekit", "displayConnectionQuality")) return;
		let t = document.querySelector(`.camera-view[data-user="${e}"]`), n = t?.querySelector(".player-name");
		if (t?.querySelector(".connection-quality-indicator")) return;
		let r = $(`<div class="connection-quality-indicator unknown" title="${game.i18n?.localize(`LIVEKITAVCLIENT.connectionQuality.${d.Unknown}`) ?? "Connectin Quality Unknown"}"></div>`);
		n instanceof Element && $(n).after(r), this.setConnectionQualityIndicator(e);
	}
	addLiveKitServerType(e) {
		return this.isLiveKitServerType(e) ? this.liveKitServerTypes[e.key] === void 0 ? (this.liveKitServerTypes[e.key] = e, !0) : (X.error("Attempted to add a LiveKitServerType with a key that already exists:", e), !1) : (X.error("Attempted to add a LiveKitServerType that does not meet the requirements:", e), !1);
	}
	async attachAudioTrack(e, t, n) {
		if (t.attachedElements.includes(n)) {
			X.debug("Audio track", t, "already attached to element", n, "; skipping");
			return;
		}
		if (n.sinkId === void 0) X.warn("Your web browser does not support output audio sink selection");
		else {
			let e = this.settings.get("client", "audioSink");
			await n.setSinkId(e).catch((t) => {
				let n = t;
				t instanceof Error && (n = t.message), X.error("An error occurred when requesting the output audio device:", e, n);
			});
		}
		t.detach(), t.attach(n);
		let r = this.settings.getUser(e)?.volume;
		r === void 0 && (r = 1), n.volume = r, n.muted = this.settings.get("client", "muteAll") === !0, this.userAudioMixer.apply(e);
	}
	attachVideoTrack(e, t) {
		if (e.attachedElements.includes(t)) {
			X.debug("Video track", e, "already attached to element", t, "; skipping");
			return;
		}
		e.detach(), e.attach(t);
	}
	async changeAudioSource(e = !1) {
		if (e && this.audioTrack && (await this.liveKitRoom?.localParticipant.unpublishTrack(this.audioTrack), this.audioTrack.stop(), this.audioTrack = null, game.user?.broadcastActivity({ av: { muted: !0 } })), !this.audioTrack || this.settings.get("client", "audioSrc") === "disabled" || !this.avMaster.canUserBroadcastAudio(game.user?.id ?? "")) this.audioTrack ? (await this.liveKitRoom?.localParticipant.unpublishTrack(this.audioTrack), this.audioTrack.stop(), this.audioTrack = null, game.user?.broadcastActivity({ av: { muted: !0 } })) : (await this.initializeAudioTrack(), this.audioTrack && (await this.liveKitRoom?.localParticipant.publishTrack(this.audioTrack, this.trackPublishOptions), await this.applyAudioProcessors(this.audioTrack), game.user?.broadcastActivity({ av: { muted: !1 } }), this.avMaster.render()));
		else {
			let e = this.getAudioParams();
			e && (await this.audioTrack.restartTrack(e), this.audioCaptureParams = JSON.stringify(e));
		}
	}
	async changeVideoSource() {
		if (!this.videoTrack || this.settings.get("client", "videoSrc") === "disabled" || !this.avMaster.canUserBroadcastVideo(game.user?.id ?? "")) {
			if (this.videoTrack) await this.liveKitRoom?.localParticipant.unpublishTrack(this.videoTrack), this.videoTrack.detach(), this.videoTrack.stop(), this.videoTrack = null, game.user?.broadcastActivity({ av: { hidden: !0 } });
			else if (await this.initializeVideoTrack(), this.videoTrack) {
				await this.liveKitRoom?.localParticipant.publishTrack(this.videoTrack, this.trackPublishOptions);
				let e = this.getUserVideoElement(game.user?.id ?? "");
				e && this.attachVideoTrack(this.videoTrack, e), game.user?.broadcastActivity({ av: { hidden: !1 } }), this.avMaster.render();
			}
		} else {
			let e = this.getVideoParams();
			e && await this.videoTrack.restartTrack(e);
		}
	}
	getAudioParams() {
		let e = this.settings.get("client", "audioSrc"), t = this.avMaster.canUserBroadcastAudio(game.user?.id ?? "");
		if (typeof e != "string" || e === "disabled" || !t) return !1;
		let n = {
			deviceId: { ideal: e },
			channelCount: { ideal: 1 }
		};
		if (game.settings?.get("avclient-livekit", "audioMusicMode")) n.autoGainControl = !1, n.echoCancellation = !1, n.noiseSuppression = !1, n.channelCount = { ideal: 2 };
		else {
			n.autoGainControl = game.settings?.get("avclient-livekit", "audioAutoGainControl") ?? !0, n.echoCancellation = game.settings?.get("avclient-livekit", "audioEchoCancellation") ?? !0, n.noiseSuppression = game.settings?.get("avclient-livekit", "audioNoiseSuppression") ?? !0;
			let { model: e } = this.getAudioProcessingConfig();
			e && (n.noiseSuppression = !1);
		}
		return n;
	}
	getParticipantFVTTUser(e) {
		let { fvttUserId: t } = JSON.parse(e.metadata ?? "{}");
		return game.users?.get(t);
	}
	getParticipantUseExternalAV(e) {
		let { useExternalAV: t } = JSON.parse(e.metadata ?? "{ false }");
		return t;
	}
	getUserAudioTrack(e) {
		let n = null;
		return e && this.liveKitParticipants.get(e)?.audioTrackPublications.forEach((e) => {
			e.kind === u.Kind.Audio && (e.track instanceof t || e.track instanceof l) && (n = e.track);
		}), n;
	}
	getUserStatistics(e) {
		let t = this.liveKitParticipants.get(e), n = 0;
		if (!t) return "";
		for (let e of t.trackPublications.values()) e.track && (n += e.track.currentBitrate);
		let r = "";
		return n > 0 && (r = `${Math.round(n / 1024).toLocaleString()} kbps`), r;
	}
	getAllUserStatistics() {
		let e = /* @__PURE__ */ new Map();
		return this.liveKitParticipants.forEach((t, n) => {
			e.set(n, this.getUserStatistics(n));
		}), e;
	}
	getUserVideoTrack(e) {
		let t = null;
		return e && this.liveKitParticipants.get(e)?.videoTrackPublications.forEach((e) => {
			e.kind === u.Kind.Video && (e.track instanceof f || e.track instanceof i) && (t = e.track);
		}), t;
	}
	getUserAudioElement(e, t, n) {
		let r = document.getElementById(di);
		r || (r = document.createElement("div"), r.id = di, r.hidden = !0, document.body.append(r));
		let i = r.querySelector(`audio[data-user="${e}"][data-source="${n}"]`);
		return i || (i = document.createElement("audio"), i.className = `user-${n}-audio`, i.dataset.user = e, i.dataset.source = n, i.autoplay = !0, r.append(i)), i;
	}
	getUserAudioElements(e) {
		return [...document.querySelectorAll(`#${di} audio[data-user="${e}"]`)];
	}
	getUserVideoElement(e) {
		return ui.webrtc?.getUserVideoElement?.(e) ?? null;
	}
	async initializeLocalTracks() {
		await this.initializeAudioTrack(), await this.initializeVideoTrack();
	}
	async initializeAudioTrack() {
		this.audioTrack = null;
		let e = this.getAudioParams();
		if (e) try {
			this.audioTrack = await o(e), this.audioCaptureParams = JSON.stringify(e), await this.applyAudioProcessors(this.audioTrack);
		} catch (e) {
			let t = e;
			e instanceof Error && (t = e.message), X.error("Unable to acquire local audio:", t);
		}
		this.audioTrack && !(this.liveKitAvClient.isVoiceAlways && this.avMaster.canUserShareAudio(game.user?.id ?? "")) && await this.audioTrack.mute();
	}
	getAudioProcessorContext() {
		return (!this.audioProcessorContext || this.audioProcessorContext.state === "closed") && (this.audioProcessorContext = new AudioContext({ sampleRate: Cr }), ve(this.audioProcessorContext)), this.audioProcessorContext;
	}
	getAudioProcessingConfig() {
		if ((game.settings?.get("avclient-livekit", "audioMusicMode") ?? !1) || !Er()) return {};
		let e = this.getSelectedNoiseModel(), t = this.settings.get("client", "voice.mode") === "always" && !this.voiceGateFailed, n = [];
		return e === "krisp" ? (this.isKrispAvailable() && n.push({
			model: "krisp",
			gate: t
		}), n.push({
			model: Tr,
			gate: t
		})) : n.push({
			model: e === "none" ? void 0 : e,
			gate: t
		}), n.find((e) => !this.failedAudioProcessors.has(pi(e))) ?? {};
	}
	async restartAudioCapture(e) {
		let t = this.getAudioParams();
		if (!t) return;
		let n = JSON.stringify(t);
		n !== this.audioCaptureParams && (await e.restartTrack(t), this.audioCaptureParams = n);
	}
	async applyAudioProcessors(e) {
		let t = this.getAudioProcessingConfig(), n = pi(t), r = this.audioProcessorState?.track === e && this.audioProcessorState.key === n;
		if (n === Z) {
			!r && e.getProcessor() && await e.stopProcessor(), this.audioProcessorState = {
				track: e,
				key: n
			};
			return;
		}
		try {
			if (!r) {
				e.setAudioContext(this.getAudioProcessorContext());
				let r = t.gate ? {
					settings: this.getVoiceGateSettings(),
					onReport: this.onVoiceGateReport
				} : void 0;
				await e.setProcessor(t.model === "krisp" ? await Lr(r) : new kr({
					model: t.model,
					gate: r
				})), this.audioProcessorState = {
					track: e,
					key: n
				}, X.info("Audio processor applied to local audio track:", n);
			}
			t.model === "krisp" && await this.verifyKrispNoiseFilter(e);
		} catch (r) {
			if (X.error("Error applying audio processor", n, r), this.audioProcessorState = {
				track: e,
				key: Z
			}, e.getProcessor() && await e.stopProcessor(), r instanceof Ht) this.voiceGateFailed = !0, ui.notifications?.warn(`${_}.voiceGateFailed`, { localize: !0 });
			else {
				this.failedAudioProcessors.add(n);
				let e = this.getAudioProcessingConfig().model;
				ui.notifications?.warn(game.i18n?.format("LIVEKITAVCLIENT.noiseSuppressionFailed", {
					model: this.getNoiseModelLabel(t.model ?? "none"),
					fallback: e ? this.getNoiseModelLabel(e) : game.i18n.localize("LIVEKITAVCLIENT.noiseSuppressionBrowser")
				}) ?? "noiseSuppressionFailed");
			}
			await this.restartAudioCapture(e), await this.applyAudioProcessors(e);
		}
	}
	async verifyKrispNoiseFilter(e) {
		if (!(!e.sid || this.audioProcessorState?.verified)) {
			if (await e.getProcessor()?.setEnabled(!0) === !1) throw Error("The Krisp noise filter could not be enabled");
			this.audioProcessorState?.track === e && (this.audioProcessorState.verified = !0);
		}
	}
	refreshAudioProcessing(e = !1) {
		let t = async () => {
			e && (this.failedAudioProcessors.clear(), this.voiceGateFailed = !1);
			let t = this.audioTrack;
			if (!t) return;
			let n = pi(this.getAudioProcessingConfig());
			t.getProcessor() && !(this.audioProcessorState?.track === t && this.audioProcessorState.key === n) && (await t.stopProcessor(), this.audioProcessorState = {
				track: t,
				key: Z
			}), await this.restartAudioCapture(t), await this.applyAudioProcessors(t), this.applyVoiceGateSettings(), this.updateGateSpeaking();
		};
		return this.audioProcessingQueue = this.audioProcessingQueue.then(t).catch((e) => {
			X.error("Error refreshing audio processing:", e);
		}), this.audioProcessingQueue;
	}
	get voiceGate() {
		return this.audioTrack?.getProcessor()?.gate;
	}
	getVoiceGateSettings() {
		return this.voiceGatePreview ?? {
			auto: game.settings?.get("avclient-livekit", "audioAutoSensitivity") ?? !0,
			threshold: game.settings?.get("avclient-livekit", "audioNoiseGateThreshold") ?? -50
		};
	}
	previewVoiceGate(e) {
		this.voiceGatePreview = e, this.applyVoiceGateSettings();
	}
	applyVoiceGateSettings() {
		let e = this.getVoiceGateSettings();
		for (let t of Ut.instances) t.configure(e);
	}
	onVoiceGateReports(e) {
		return this.voiceGateListeners.add(e), () => {
			this.voiceGateListeners.delete(e);
		};
	}
	onVoiceGateReport = (e) => {
		for (let t of this.voiceGateListeners) t(e);
		this.updateGateSpeaking();
	};
	updateGateSpeaking() {
		let e = !!this.voiceGate?.isOpen && !!this.audioTrack && !this.audioTrack.isMuted;
		e !== this.gateSpeaking && (this.gateSpeaking = e, this.onIsSpeakingChanged(game.user?.id, e));
	}
	async initializeVideoTrack() {
		this.videoTrack = null;
		let e = this.getVideoParams();
		if (e) try {
			this.videoTrack = await ne(e);
		} catch (e) {
			let t = e;
			e instanceof Error && (t = e.message), X.error("Unable to acquire local video:", t);
		}
		this.videoTrack && !this.avMaster.canUserShareVideo(game.user?.id ?? "") && await this.videoTrack.mute(), this.videoTrack && this.updateVideoBackground();
	}
	getVideoBackground() {
		let e = game.settings?.get(g, "videoBackground");
		if (e !== "blur" && e !== "image" || this.videoBackgroundFailed || !dn()) return { mode: "none" };
		let t = game.settings?.get("avclient-livekit", "videoBackgroundQuality") === "standard" ? "standard" : "high";
		if (e === "image") {
			let n = fn(game.settings?.get("avclient-livekit", "videoBackgroundImage") ?? "");
			if (n !== this.failedVideoBackgroundImage) return {
				mode: e,
				url: n,
				quality: t
			};
		}
		return {
			mode: "blur",
			strength: game.settings?.get("avclient-livekit", "videoBlurStrength") ?? .5,
			quality: t
		};
	}
	previewVideoBlur(e) {
		hn(this.videoTrack, e).catch((e) => {
			X.warn("Error previewing the blur strength:", e);
		});
	}
	updateVideoBackground({ retry: e = !1 } = {}) {
		return this.videoBackgroundQueue = this.videoBackgroundQueue.then(async () => {
			e && (this.videoBackgroundFailed = !1, this.failedVideoBackgroundImage = void 0);
			let t = this.videoTrack;
			if (!t) return;
			let n = this.getVideoBackground();
			try {
				try {
					await yn(t, n);
				} catch (e) {
					if (!(e instanceof on) || n.mode !== "image") throw e;
					X.warn("Unable to load the camera background image:", e), this.failedVideoBackgroundImage = n.url, ui.notifications?.warn(`${_}.videoBackgroundImageFailed`, { localize: !0 }), n = this.getVideoBackground(), await yn(t, n);
				}
				X.info("Camera background applied:", n.mode);
			} catch (e) {
				X.error("Error applying the camera background", n, e), this.videoBackgroundFailed = !0, await t.stopProcessor().catch((e) => {
					X.warn("Error removing the camera background:", e);
				}), ui.notifications?.warn(`${_}.videoBackgroundFailed`, { localize: !0 });
			}
		}), this.videoBackgroundQueue;
	}
	initializeRoom() {
		let e = this.trackPublishOptions, t = {
			adaptiveStream: e.simulcast,
			dynacast: e.simulcast,
			publishDefaults: e
		};
		this.liveKitRoom = new a(t), this.setRoomCallbacks();
	}
	isLiveKitServerType(e) {
		return !(typeof e.key != "string" || typeof e.label != "string" || typeof e.urlRequired != "boolean" || typeof e.usernameRequired != "boolean" || typeof e.passwordRequired != "boolean" || !(e.tokenFunction instanceof Function));
	}
	isUserExternal(e) {
		return X.debug("isUserExternal not yet implemented; userId:", e), !1;
	}
	onAudioPlaybackStatusChanged(e) {
		e || (X.warn("Cannot play audio/video, waiting for user interaction"), this.windowClickListener = this.windowClickListener ?? this.onWindowClick.bind(this), window.addEventListener("click", this.windowClickListener));
	}
	async onConnected() {
		X.debug("Client connected"), this.setLocalParticipantCallbacks(), this.addAllParticipants(), this.setConnectionButtons(!0), this.audioTrack && await this.liveKitRoom?.localParticipant.publishTrack(this.audioTrack, this.trackPublishOptions), this.videoTrack && await this.liveKitRoom?.localParticipant.publishTrack(this.videoTrack, this.trackPublishOptions), Rr(this.liveKitRoom, this.liveKitServerAddress) && await this.checkKrispSupport(), await this.refreshAudioProcessing(), this.voiceControls.isDeafened() && this.voiceControls.broadcastDeafened();
	}
	onConnectionQualityChanged(e, t) {
		if (X.debug("onConnectionQualityChanged:", e, t), t === this.liveKitRoom?.localParticipant && this.voicePanelInstance?.update(), !game.settings?.get("avclient-livekit", "displayConnectionQuality")) return;
		let n = this.getParticipantFVTTUser(t)?.id;
		if (!n) {
			X.warn("Quality changed participant", t, "is not an FVTT user");
			return;
		}
		this.setConnectionQualityIndicator(n, e);
	}
	onDisconnected(e) {
		X.debug("Client disconnected", { reason: e });
		let t = game.i18n?.localize("LIVEKITAVCLIENT.onDisconnected") ?? "onDisconnected";
		e && (t += `: ${c[e]}`), ui.notifications?.warn(t), this.liveKitParticipants.clear(), this.userAudioMixer.stopAll();
		for (let e of [...this.speakingUsers]) this.onIsSpeakingChanged(e, !1);
		this.playersList.refresh(), this.dock?.refresh(), this.setConnectionButtons(!1), this.connectionState = m.Disconnected;
	}
	onGetUserContextOptions(e, t) {
		this.settings.get("world", "mode") !== foundry.av.AVSettings.AV_MODES.DISABLED && Hr(t, this);
	}
	onIsSpeakingChanged(e, t) {
		if (!e) return;
		t ? this.speakingUsers.add(e) : this.speakingUsers.delete(e);
		let n = this.dock;
		n ? n.setSpeaking(e, t) : (ui.webrtc?.setUserIsSpeaking(e, t), this.cameraViewDecorator.setSpeaking(e, t)), this.playersList.setSpeaking(e, t), e === game.user?.id && this.voicePanelInstance?.setSpeaking(t);
	}
	onParticipantConnected(e) {
		X.debug("onParticipantConnected:", e);
		let t = this.getParticipantFVTTUser(e);
		if (!t?.id) {
			X.error("Joining participant", e, "is not an FVTT user; cannot display them");
			return;
		}
		t.active || (X.warn("Joining user", t.id, "is not listed as active. Setting to active."), t.active = !0, ui.players?.render().catch((e) => {
			X.error("Error rendering players view:", e);
		})), this.liveKitParticipants.set(t.id, e), this.breakoutRoom || this.settings.set("client", `users.${t.id}.liveKitBreakoutRoom`, ""), this.setRemoteParticipantCallbacks(e), this.playersList.refresh(t.id), this.voiceControls.isDeafened() && this.voiceControls.broadcastDeafened(), this.render();
	}
	onParticipantDisconnected(e) {
		X.debug("onParticipantDisconnected:", e);
		let t = this.getParticipantFVTTUser(e)?.id;
		if (!t) {
			X.warn("Leaving participant", e, "is not an FVTT user");
			return;
		}
		this.liveKitParticipants.delete(t);
		for (let e of this.getUserAudioElements(t)) e.remove();
		this.onIsSpeakingChanged(t, !1), this.playersList.refresh(t), this.settings.get("client", `users.${t}.liveKitBreakoutRoom`) === this.liveKitAvClient.room && this.liveKitAvClient.room === this.breakoutRoom && this.settings.set("client", `users.${t}.liveKitBreakoutRoom`, ""), this.render();
	}
	onReconnected() {
		X.info("Reconnect issued"), this.render(), this.voicePanelInstance?.update();
	}
	onReconnecting() {
		X.warn("Reconnecting to room"), ui.notifications?.warn(game.i18n?.localize("WEBRTC.ConnectionLostWarning") ?? "ConnectionLostWarning"), this.voicePanelInstance?.update();
	}
	onSocketEvent(e, t) {
		switch (X.debug("Socket event:", e, "from:", t), e.action) {
			case "breakout":
				game.users?.get(t)?.isGM && (!e.userId || e.userId === game.user.id) && Ur(e.breakoutRoom, this);
				break;
			case "connect":
				game.users?.get(t)?.isGM ? this.avMaster.connect().catch((e) => {
					X.error("Error connecting:", e);
				}) : X.warn("Connect socket event from non-GM user; ignoring");
				break;
			case "disconnect":
				game.users?.get(t)?.isGM ? this.avMaster.disconnect().then(() => {
					this.render();
				}).catch((e) => {
					X.error("Error disconnecting:", e);
				}) : X.warn("Disconnect socket event from non-GM user; ignoring");
				break;
			case "deafen":
				this.voiceControls.onRemoteDeafened(t, e.deafened === !0);
				break;
			case "render":
				game.users?.get(t)?.isGM ? this.render() : X.warn("Render socket event from non-GM user; ignoring");
				break;
			default: X.warn("Unknown socket event:", e);
		}
	}
	onTrackMuteChanged(e, t) {
		X.debug("onTrackMuteChanged:", e, t);
		let n = t === this.liveKitRoom?.localParticipant ? game.user?.id : this.getParticipantFVTTUser(t)?.id;
		if (n && this.onVoiceStateChanged(n), t === this.liveKitRoom?.localParticipant) {
			X.debug("Local", e.kind, "track muted:", e.isMuted);
			return;
		}
		let r = this.getParticipantFVTTUser(t)?.id, i = this.getParticipantUseExternalAV(t);
		if (!r) {
			X.warn("Mute change participant", t, "is not an FVTT user");
			return;
		}
		i && (e.kind === u.Kind.Audio ? this.avMaster.settings.handleUserActivity(r, { muted: e.isMuted }) : e.kind === u.Kind.Video && this.avMaster.settings.handleUserActivity(r, { hidden: e.isMuted }));
	}
	onRenderCameraViews(e, t) {
		if (this.dock) {
			this.applyDiscordStyle();
			return;
		}
		this.decorateCameraViews(t);
		let n = game.user?.id;
		if (!n) {
			X.error("No user ID found; cannot render camera views");
			return;
		}
		let r = t.querySelector(`[data-user="${n}"].user-controls`);
		if (r?.querySelector(".livekit-control")) return;
		let i = r?.querySelector("[data-action=\"configure\"]");
		if (!(i instanceof HTMLElement)) {
			X.warn("Can't find CameraView configure element", i);
			return;
		}
		this.addConnectionButtons(i), this.addNoiseCancellationButton(i);
	}
	decorateCameraViews(e) {
		this.applyDiscordStyle(), this.cameraViewDecorator.decorate(e);
	}
	onTrackSubscribed(e, t, n) {
		X.debug("onTrackSubscribed:", e, t, n);
		let r = this.getParticipantFVTTUser(n)?.id;
		if (!r) {
			X.warn("Track subscribed participant", n, "is not an FVTT user");
			return;
		}
		if (e instanceof l) {
			let n = this.getUserAudioElement(r, null, t.source);
			this.attachAudioTrack(r, e, n).catch((e) => {
				X.error("Error attaching audio track:", e);
			});
		} else if (e instanceof i) {
			let t = this.getUserVideoElement(r);
			t && this.attachVideoTrack(e, t);
		} else X.warn("Unknown track type subscribed from publication", t);
		_e(r), this.onVoiceStateChanged(r);
	}
	onTrackUnSubscribed(e, t, n) {
		X.debug("onTrackUnSubscribed:", e, t, n), e.detach();
		let r = this.getParticipantFVTTUser(n)?.id;
		r && this.onVoiceStateChanged(r);
	}
	onVolumeChange(e) {
		let t = e.currentTarget;
		if (!(t instanceof foundry.applications.elements.HTMLRangePickerElement)) {
			X.warn("Volume change event did not originate from a range picker element");
			return;
		}
		let n = t.closest(".camera-view"), r = foundry.audio.AudioHelper.inputToVolume(t.value);
		if (!(n instanceof HTMLElement)) {
			X.warn("Volume change event did not originate from a camera view box");
			return;
		}
		n.dataset.user && (this.userAudioMixer.setVolume(n.dataset.user, r), this.settings.set("client", `users.${n.dataset.user}.volume`, r));
	}
	onWindowClick() {
		this.windowClickListener && (window.removeEventListener("click", this.windowClickListener), this.render());
	}
	getVideoParams() {
		let e = this.settings.get("client", "videoSrc"), t = this.avMaster.canUserBroadcastVideo(game.user?.id ?? ""), n = s.h180.resolution;
		return this.trackPublishOptions.simulcast && (n = s.h720.resolution), typeof e == "string" && e !== "disabled" && t ? {
			deviceId: { ideal: e },
			resolution: n
		} : !1;
	}
	async sendJoinMessage(e, t) {
		let n = `https://meet.livekit.io/custom?${new URLSearchParams({
			liveKitUrl: `wss://${e}`,
			token: t
		}).toString()}`;
		await foundry.applications.api.DialogV2.confirm({
			window: { title: `${_}.externalAVJoinTitle` },
			content: `<p>${game.i18n?.localize("LIVEKITAVCLIENT.externalAVJoinMessage") ?? "externalAVJoinMessage"}</p>`,
			yes: {
				label: `${_}.externalAVJoinButton`,
				icon: "fa-solid fa-check",
				callback: () => window.open(n)
			},
			no: {
				label: `${_}.externalAVIgnoreButton`,
				icon: "fa-solid fa-xmark",
				callback: () => {
					X.info("Ignoring external LiveKit join request");
				}
			}
		});
	}
	setAudioEnabledState(e) {
		if (!this.audioTrack) {
			X.debug("setAudioEnabledState called but no audio track available");
			return;
		}
		if (this.liveKitRoom?.state !== m.Connected) {
			X.debug("setAudioEnabledState called but LiveKit room is not connected");
			return;
		}
		!e && !this.audioTrack.isMuted ? (X.debug("Muting audio track", this.audioTrack), this.audioTrack.mute().catch((e) => {
			X.error("Error muting audio track:", e);
		})) : e && this.audioTrack.isMuted ? (X.debug("Un-muting audio track", this.audioTrack), this.audioTrack.unmute().catch((e) => {
			X.error("Error un-muting audio track:", e);
		})) : X.debug("setAudioEnabledState called but track is already in the current state");
	}
	setConnectionButtons(e) {
		let t = document.querySelector(`.user-controls[data-user="${game.user?.id ?? ""}"]`);
		if (t) {
			let n = t.querySelector(".livekit-control.connect"), r = t.querySelector(".livekit-control.disconnect");
			n?.classList.toggle("hidden", e), n?.classList.toggle("disabled", !1), r?.classList.toggle("hidden", !e), r?.classList.toggle("disabled", !1);
		}
		this.voicePanelInstance?.update();
	}
	setConnectionQualityIndicator(e, t) {
		let n = document.querySelector(`.camera-view[data-user="${e}"]`)?.querySelector(".connection-quality-indicator");
		t ??= this.liveKitParticipants.get(e)?.connectionQuality ?? d.Unknown, n instanceof HTMLDivElement && (n.classList.remove(...Object.values(d)), n.classList.add(t), n.title = game.i18n?.localize(`LIVEKITAVCLIENT.connectionQuality.${t}`) ?? t);
	}
	setLocalParticipantCallbacks() {
		this.liveKitRoom?.localParticipant.on(r.IsSpeakingChanged, (e) => {
			this.voiceGate || this.onIsSpeakingChanged(game.user?.id, e);
		}).on(r.ParticipantMetadataChanged, (...e) => {
			X.debug("Local ParticipantEvent ParticipantMetadataChanged:", e);
		}).on(r.TrackPublished, (...e) => {
			X.debug("Local ParticipantEvent TrackPublished:", e);
		}).on(r.TrackSubscriptionStatusChanged, (...e) => {
			X.debug("Local ParticipantEvent TrackSubscriptionStatusChanged:", e);
		});
	}
	setRemoteParticipantCallbacks(e) {
		let t = this.getParticipantFVTTUser(e)?.id;
		if (!t) {
			X.warn("Participant", e, "is not an FVTT user; skipping setRemoteParticipantCallbacks");
			return;
		}
		e.on(r.IsSpeakingChanged, this.onIsSpeakingChanged.bind(this, t)).on(r.ParticipantMetadataChanged, (...e) => {
			X.debug("Remote ParticipantEvent ParticipantMetadataChanged:", e);
		});
	}
	setRoomCallbacks() {
		if (!this.liveKitRoom) {
			X.warn("Attempted to set up room callbacks before the LiveKit room is ready");
			return;
		}
		this.liveKitRoom.on(p.AudioPlaybackStatusChanged, this.onAudioPlaybackStatusChanged.bind(this)).on(p.ParticipantConnected, this.onParticipantConnected.bind(this)).on(p.ParticipantDisconnected, this.onParticipantDisconnected.bind(this)).on(p.TrackSubscribed, this.onTrackSubscribed.bind(this)).on(p.TrackSubscriptionFailed, (...e) => {
			X.error("RoomEvent TrackSubscriptionFailed:", e);
		}).on(p.TrackUnpublished, (...e) => {
			X.debug("RoomEvent TrackUnpublished:", e);
		}).on(p.TrackUnsubscribed, this.onTrackUnSubscribed.bind(this)).on(p.LocalTrackUnpublished, (...e) => {
			X.debug("RoomEvent LocalTrackUnpublished:", e);
		}).on(p.ConnectionQualityChanged, this.onConnectionQualityChanged.bind(this)).on(p.Disconnected, this.onDisconnected.bind(this)).on(p.Reconnecting, this.onReconnecting.bind(this)).on(p.TrackMuted, this.onTrackMuteChanged.bind(this)).on(p.TrackUnmuted, this.onTrackMuteChanged.bind(this)).on(p.ParticipantMetadataChanged, (...e) => {
			X.debug("RoomEvent ParticipantMetadataChanged:", e);
		}).on(p.RoomMetadataChanged, (...e) => {
			X.debug("RoomEvent RoomMetadataChanged:", e);
		}).on(p.Reconnected, this.onReconnected.bind(this));
	}
	async shareScreen(t) {
		if (X.info("shareScreen:", t), t) {
			let t = {
				autoGainControl: !1,
				echoCancellation: !1,
				noiseSuppression: !1,
				channelCount: { ideal: 2 }
			};
			this.screenTracks = await e({ audio: t });
			for (let e of this.screenTracks) {
				if (X.debug("screenTrack enable:", e), e instanceof f) {
					this.videoTrack && await this.liveKitRoom?.localParticipant.unpublishTrack(this.videoTrack);
					let t = document.querySelector(`.camera-view[data-user="${game.user?.id ?? ""}"]`);
					t instanceof HTMLVideoElement && this.attachVideoTrack(e, t);
				}
				let t = this.trackPublishOptions;
				t.audioPreset = h.musicHighQuality, await this.liveKitRoom?.localParticipant.publishTrack(e, t);
			}
		} else for (let e of this.screenTracks) X.debug("screenTrack disable:", e), await this.liveKitRoom?.localParticipant.unpublishTrack(e), e instanceof f && this.videoTrack && (await this.liveKitRoom?.localParticipant.publishTrack(this.videoTrack, this.trackPublishOptions), this.videoTrack.isMuted || await this.videoTrack.unmute());
	}
	get trackPublishOptions() {
		let e = {
			audioPreset: this.getAudioPreset(),
			simulcast: !0,
			videoCodec: "vp8",
			videoSimulcastLayers: [s.h180, s.h360]
		};
		return game.settings?.get("avclient-livekit", "audioMusicMode") && (e.audioPreset = h.musicHighQuality), e;
	}
	getAudioPreset() {
		switch (game.settings?.get(g, "audioQualityPreset")) {
			case "telephone": return h.telephone;
			case "music": return h.music;
			case "musicStereo": return h.musicStereo;
			case "musicHighQuality": return h.musicHighQuality;
			case "musicHighQualityStereo": return h.musicHighQualityStereo;
			default: return h.speech;
		}
	}
}, Q = new y(), gi = class extends foundry.av.AVClient {
	_liveKitClient;
	room;
	tempError;
	constructor(e, t) {
		super(e, t), this._liveKitClient = new hi(this), this.room = null, this.master.config = new An({ webrtc: e });
	}
	async initialize() {
		Q.debug("LiveKitAVClient initialize"), this._liveKitClient.initState = mi.Initializing, this.settings.get("client", "voice.mode") === "activity" && (Q.debug("Disabling voice activation mode as it is handled natively by LiveKit"), this.settings.set("client", "voice.mode", "always")), game.settings?.get("avclient-livekit", "useExternalAV") ? (Q.debug("useExternalAV set, not initializing LiveKitClient"), this._liveKitClient.useExternalAV = !0, game.user?.broadcastActivity({ av: {
			hidden: !1,
			muted: !1
		} })) : (this._liveKitClient.initializeRoom(), await this._liveKitClient.initializeLocalTracks(), game.user?.broadcastActivity({ av: {
			muted: !this.isAudioEnabled(),
			hidden: !this.isVideoEnabled()
		} })), this._liveKitClient.initState = mi.Initialized, this._liveKitClient.applyDiscordStyle(), Hooks.callAll("liveKitClientInitialized", this._liveKitClient);
	}
	async connect() {
		Q.debug("LiveKitAVClient connect"), this._liveKitClient.connectionState = m.Connecting;
		let e = game.settings?.get(g, "liveKitConnectionSettings"), t = this.settings.get("world", "livekit");
		t && (Q.warn("Migrating legacy livekit connection settings"), e = t, ye(() => {
			game.settings?.set(g, "liveKitConnectionSettings", t).catch((e) => {
				Q.error("Error setting livekit connection settings from legacy value", e);
			}), game.webrtc?.client.settings.set("world", "livekit", void 0);
		})), e ??= {}, e.serverType === void 0 && game.user?.isGM && (Q.warn("livekit serverType setting not found; defaulting to", this._liveKitClient.defaultLiveKitServerType.key), e.serverType = this._liveKitClient.defaultLiveKitServerType.key, ye(() => {
			game.settings.set(g, "liveKitConnectionSettings", e).catch((e) => {
				Q.error("Error setting livekit serverType setting to default", e);
			});
		}));
		let r = this._liveKitClient.defaultLiveKitServerType;
		if (typeof e.serverType == "string" && this._liveKitClient.liveKitServerTypes[e.serverType].tokenFunction instanceof Function ? r = this._liveKitClient.liveKitServerTypes[e.serverType] : Q.warn("liveKitServerType", e.serverType, "not found; defaulting to", this._liveKitClient.defaultLiveKitServerType.key), e.url) {
			let t = /* @__PURE__ */ RegExp("^([a-zA-Z\\d]+://)+(.*)$");
			t.exec(e.url) && (Q.warn("Protocol included in server URL:", e.url, "; removing protocol"), e.url = e.url.replace(t, "$2"), ye(() => {
				game.settings?.set(g, "liveKitConnectionSettings", e).catch((e) => {
					Q.error("Error setting livekit url setting", e);
				});
			}));
		}
		if (game.user?.isGM && (r.urlRequired && (e.url === void 0 || e.url === "") || r.usernameRequired && (e.username === void 0 || e.username === "") || r.passwordRequired && (e.password === void 0 || e.password === ""))) return Q.error("LiveKit connection information missing"), ui.notifications?.error(game.i18n.localize(`${_}.connectionInfoMissing`), { permanent: !0 }), this._liveKitClient.connectionState = m.Disconnected, await this.master.config.render({ force: !0 }), !1;
		if (game.user?.isGM && r.key === "tavern" && game.settings.get("avclient-livekit", "tavernPatreonToken") === "") return Q.error("LiveKit Tavern connection information missing"), ui.notifications?.error(game.i18n.localize(`${_}.tavernAccountMissing`), { permanent: !0 }), this._liveKitClient.connectionState = m.Disconnected, await this.master.config.render({ force: !0 }), !1;
		e.room || (Q.warn("No meeting room set, creating random name."), e.room = foundry.utils.randomID(32), ye(() => {
			game.settings?.set(g, "liveKitConnectionSettings", e).catch((e) => {
				Q.error("Error setting livekit room setting", e);
			});
		})), this._liveKitClient.breakoutRoom ? this.room = this._liveKitClient.breakoutRoom : this.room = e.room, Q.debug("Meeting room name:", this.room);
		let i = JSON.stringify({
			fvttUserId: game.user?.id,
			useExternalAV: this._liveKitClient.useExternalAV
		}), a = game.user?.name;
		if (!this.room || !a) return Q.error("Missing required room information, cannot connect. room:", this.room, "username:", a), this._liveKitClient.connectionState = m.Disconnected, !1;
		let o = await r.tokenFunction(e.username, e.password, this.room, a, i).catch((e) => {
			let t = e;
			return e instanceof Error && (t = e.message), Q.error("An error occurred when calling tokenFunction for liveKitServerType:", r, t), "";
		});
		if (!o) return Q.error("Could not get access token", r.label || r.key), ui.notifications?.error(game.i18n?.localize("LIVEKITAVCLIENT.tokenError") ?? "tokenError", { permanent: !0 }), this._liveKitClient.connectionState = m.Disconnected, !1;
		let s = r.urlRequired ? e.url : r.url;
		if (typeof s != "string") {
			let e = `${game.i18n?.localize(r.label) ?? "liveKitServerType"} doesn't provide a URL`;
			return Q.error(e, r), ui.notifications?.error(`${game.i18n?.localize("LIVEKITAVCLIENT.connectError") ?? "connectError"}: ${e}`, { permanent: !0 }), this._liveKitClient.connectionState = m.Disconnected, !1;
		}
		if (this._liveKitClient.liveKitServerAddress = s, this._liveKitClient.useExternalAV) return Q.debug("useExternalAV set, not connecting to LiveKit"), await this._liveKitClient.sendJoinMessage(s, o), !0;
		let c = { autoSubscribe: !0 };
		game.settings?.get("avclient-livekit", "debug") && game.settings.get("avclient-livekit", "liveKitTrace") && (Q.debug("Setting livekit trace logging"), n(ee.trace));
		try {
			await this._liveKitClient.liveKitRoom?.connect(`wss://${s}`, o, c), Q.info("Connected to room", this.room);
		} catch (e) {
			Q.error("Could not connect:", e);
			let t = e;
			return e instanceof Error && (t = e.message), (String(t).includes("validation failed, token is expired") || String(t).includes("validation failed, token not valid yet")) && (t = game.i18n?.localize("LIVEKITAVCLIENT.connectErrorCheckClock") ?? "connectErrorCheckClock"), ui.notifications?.error(`${game.i18n?.localize("LIVEKITAVCLIENT.connectError") ?? "connectError"}: ${String(t)}`, { permanent: !0 }), this._liveKitClient.setConnectionButtons(!1), this._liveKitClient.connectionState = m.Disconnected, !1;
		}
		return this._liveKitClient.liveKitRoom?.state === m.Connected ? (await this._liveKitClient.onConnected(), this._liveKitClient.connectionState = m.Connected, !0) : (Q.error("Not connected to room after attempting to connect"), this._liveKitClient.connectionState = m.Disconnected, !1);
	}
	async disconnect() {
		return Q.debug("LiveKitAVClient disconnect"), this._liveKitClient.liveKitRoom && this._liveKitClient.liveKitRoom.state !== m.Disconnected ? (await this._liveKitClient.liveKitRoom.disconnect(!1), this._liveKitClient.connectionState = m.Disconnected, !0) : (Q.warn("Not currently connected; skipping disconnect"), this._liveKitClient.connectionState = m.Disconnected, !1);
	}
	async getAudioSinks() {
		return this._getSourcesOfType("audiooutput");
	}
	async getAudioSources() {
		return this._getSourcesOfType("audioinput");
	}
	async getVideoSources() {
		return this._getSourcesOfType("videoinput");
	}
	async _getSourcesOfType(e) {
		try {
			return (await a.getLocalDevices(e)).reduce((e, t) => (e[t.deviceId] = (t.label || game.i18n?.localize("WEBRTC.UnknownDevice")) ?? "UnknownDevice", e), {});
		} catch (t) {
			return Q.error("Could not get media devices of type", e, "; error:", t), {};
		}
	}
	getConnectedUsers() {
		if (Q.debug("getConnectedUsers"), game.settings?.get("avclient-livekit", "useExternalAV")) return [];
		let e = Array.from(this._liveKitClient.liveKitParticipants.keys());
		if (e.length === 0) {
			Q.debug("No connected users; adding our own user id");
			let t = game.user?.id;
			t && e.push(t);
		}
		return Q.debug("connectedUsers:", e), e;
	}
	getMediaStreamForUser(e) {
		return Q.debug("getMediaStreamForUser called for", e, "but is not used with", g), null;
	}
	getLevelsStreamForUser(e) {
		return Q.debug("getLevelsStreamForUser called for", e, "but is not used with", g), null;
	}
	isAudioEnabled() {
		return !!this._liveKitClient.audioTrack;
	}
	isVideoEnabled() {
		return !!this._liveKitClient.videoTrack;
	}
	toggleAudio(e) {
		Q.debug("Toggling audio:", e), !this._liveKitClient.useExternalAV && (!this._liveKitClient.audioBroadcastEnabled || this.isVoicePTT || this.toggleBroadcast(e));
	}
	toggleBroadcast(e) {
		Q.debug("Toggling broadcast audio:", e), !this._liveKitClient.useExternalAV && (this._liveKitClient.audioBroadcastEnabled = e, this._liveKitClient.setAudioEnabledState(e));
	}
	toggleVideo(e) {
		if (!this._liveKitClient.useExternalAV) {
			if (!this._liveKitClient.videoTrack) {
				Q.debug("toggleVideo called but no video track available");
				return;
			}
			if (!e) Q.debug("Muting video track", this._liveKitClient.videoTrack), this._liveKitClient.videoTrack.mute().catch((e) => {
				Q.error("Error muting video track:", e);
			});
			else {
				if (!this._liveKitClient.videoTrack.sid || !this._liveKitClient.liveKitRoom?.localParticipant.videoTrackPublications.has(this._liveKitClient.videoTrack.sid)) {
					Q.debug("toggleVideo unmute called but video track is not published");
					return;
				}
				Q.debug("Un-muting video track", this._liveKitClient.videoTrack), this._liveKitClient.videoTrack.unmute().catch((e) => {
					Q.error("Error un-muting video track:", e);
				});
			}
			this.master.render();
		}
	}
	async setUserVideo(e, t) {
		if (Q.debug("Setting video element:", t, "for user:", e), e === game.user?.id) {
			let n = this._liveKitClient.videoTrack;
			n && this._liveKitClient.attachVideoTrack(n, t), this._liveKitClient.addConnectionQualityIndicator(e);
			return;
		}
		if (!this._liveKitClient.liveKitRoom) {
			Q.warn("Attempted to set user video with no active room; skipping");
			return;
		}
		let n = this._liveKitClient.getUserAudioTrack(e), r = this._liveKitClient.getUserVideoTrack(e);
		if (r && this._liveKitClient.attachVideoTrack(r, t), n instanceof l) {
			let r = this._liveKitClient.getUserAudioElement(e, t, n.source);
			await this._liveKitClient.attachAudioTrack(e, n, r);
		}
		this._liveKitClient.addConnectionQualityIndicator(e);
		let i = new CustomEvent("webrtcVideoSet", { detail: e });
		t.dispatchEvent(i);
	}
	onSettingsChanged(e) {
		Q.debug("onSettingsChanged:", e);
		let t = new Set(Object.keys(foundry.utils.flattenObject(e))), n = t.has("client.audioSrc");
		n && this._liveKitClient.changeAudioSource().catch((e) => {
			Q.error("Error chaning audio source:", e);
		});
		let r = t.has("client.videoSrc");
		if (r && this._liveKitClient.changeVideoSource().catch((e) => {
			Q.error("Error changing video source:", e);
		}), t.has("client.voice.mode") && this._liveKitClient.scheduleAudioProcessingRefresh(), ["client.voice.mode", `client.users.${game.user?.id ?? ""}.muted`].some((e) => t.has(e))) {
			let e = this.settings.client.voice.mode === "always";
			this.toggleAudio(e && this.master.canUserShareAudio(game.user?.id ?? "")), this.master.broadcast(e);
		}
		let i = [
			"client.muteAll",
			"client.voice.mode",
			"client.audioSink",
			`client.users.${game.user?.id ?? ""}.muted`
		].some((e) => t.has(e)), a = [...t].some((e) => /^client\.users\.[^.]+\.blocked$/.test(e));
		(i || a) && this._liveKitClient.onVoiceStateChanged();
		let o = [
			"client.audioSink",
			"client.muteAll",
			"client.disableVideo",
			"client.nameplates",
			"client.dockPosition",
			"client.dockWidth",
			"client.hideDock",
			"client.borderColors"
		].some((e) => t.has(e));
		(n || r || o) && this.master.render(), game.settings?.sheet.rendered && game.settings.sheet.render().catch((e) => {
			Q.error("Error redering settings sheet:", e);
		});
	}
	async updateLocalStream() {
		Q.debug("updateLocalStream"), await this._liveKitClient.changeAudioSource(), await this._liveKitClient.changeVideoSource();
	}
};
//#endregion
//#region src/avclient-livekit.ts
CONFIG.WebRTC.clientClass = gi;
//#endregion

//# sourceMappingURL=avclient-livekit.js.map