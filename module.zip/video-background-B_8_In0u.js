import { y as e } from "./livekit-client.esm-C4uopDNI.js";
//#region node_modules/.pnpm/@mediapipe+tasks-vision@0.10.14/node_modules/@mediapipe/tasks-vision/vision_bundle.mjs
var t = typeof self < "u" ? self : {};
function n(e) {
	t: {
		for (var n = ["CLOSURE_FLAGS"], r = t, i = 0; i < n.length; i++) if ((r = r[n[i]]) == null) {
			n = null;
			break t;
		}
		n = r;
	}
	return (e = n && n[e]) != null && e;
}
function r() {
	throw Error("Invalid UTF8");
}
function i(e, t) {
	return t = String.fromCharCode.apply(null, t), e == null ? t : e + t;
}
var a, o, s = typeof TextDecoder < "u", c, l = typeof TextEncoder < "u";
function u(e) {
	if (l) e = (c ||= new TextEncoder()).encode(e);
	else {
		let n = 0, r = new Uint8Array(3 * e.length);
		for (let i = 0; i < e.length; i++) {
			var t = e.charCodeAt(i);
			if (128 > t) r[n++] = t;
			else {
				if (2048 > t) r[n++] = t >> 6 | 192;
				else {
					if (55296 <= t && 57343 >= t) {
						if (56319 >= t && i < e.length) {
							let a = e.charCodeAt(++i);
							if (56320 <= a && 57343 >= a) {
								t = 1024 * (t - 55296) + a - 56320 + 65536, r[n++] = t >> 18 | 240, r[n++] = t >> 12 & 63 | 128, r[n++] = t >> 6 & 63 | 128, r[n++] = 63 & t | 128;
								continue;
							}
							i--;
						}
						t = 65533;
					}
					r[n++] = t >> 12 | 224, r[n++] = t >> 6 & 63 | 128;
				}
				r[n++] = 63 & t | 128;
			}
		}
		e = n === r.length ? r : r.subarray(0, n);
	}
	return e;
}
var d, ee = n(610401301), te = n(188588736), ne = t.navigator;
function re(e) {
	return !!ee && !!d && d.brands.some((({ brand: t }) => t && t.indexOf(e) != -1));
}
function f(e) {
	var n;
	return (n = t.navigator) && (n = n.userAgent) || (n = ""), n.indexOf(e) != -1;
}
function ie() {
	return !!ee && !!d && 0 < d.brands.length;
}
function ae() {
	return ie() ? re("Chromium") : (f("Chrome") || f("CriOS")) && !(!ie() && f("Edge")) || f("Silk");
}
function oe(e) {
	return oe[" "](e), e;
}
d = ne && ne.userAgentData || null, oe[" "] = function() {};
var se = !ie() && (f("Trident") || f("MSIE"));
!f("Android") || ae(), ae(), f("Safari") && (ae() || !ie() && f("Coast") || !ie() && f("Opera") || !ie() && f("Edge") || (ie() ? re("Microsoft Edge") : f("Edg/")) || ie() && re("Opera"));
var ce = {}, le = null;
function ue(e) {
	var t = e.length, n = 3 * t / 4;
	n % 3 ? n = Math.floor(n) : "=.".indexOf(e[t - 1]) != -1 && (n = "=.".indexOf(e[t - 2]) == -1 ? n - 1 : n - 2);
	var r = new Uint8Array(n), i = 0;
	return function(e, t) {
		function n(t) {
			for (; r < e.length;) {
				var n = e.charAt(r++), i = le[n];
				if (i != null) return i;
				if (!/^[\s\xa0]*$/.test(n)) throw Error("Unknown base64 encoding at char: " + n);
			}
			return t;
		}
		de();
		for (var r = 0;;) {
			var i = n(-1), a = n(0), o = n(64), s = n(64);
			if (s === 64 && i === -1) break;
			t(i << 2 | a >> 4), o != 64 && (t(a << 4 & 240 | o >> 2), s != 64 && t(o << 6 & 192 | s));
		}
	}(e, (function(e) {
		r[i++] = e;
	})), i === n ? r : r.subarray(0, i);
}
function de() {
	if (!le) {
		le = {};
		for (var e = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""), t = [
			"+/=",
			"+/",
			"-_=",
			"-_.",
			"-_"
		], n = 0; 5 > n; n++) {
			var r = e.concat(t[n].split(""));
			ce[n] = r;
			for (var i = 0; i < r.length; i++) {
				var a = r[i];
				le[a] === void 0 && (le[a] = i);
			}
		}
	}
}
var fe = typeof Uint8Array < "u", pe = !se && typeof btoa == "function";
function me(e) {
	if (!pe) {
		var t;
		t === void 0 && (t = 0), de(), t = ce[t];
		var n = Array(Math.floor(e.length / 3)), r = t[64] || "";
		let c = 0, l = 0;
		for (; c < e.length - 2; c += 3) {
			var i = e[c], a = e[c + 1], o = e[c + 2], s = t[i >> 2];
			i = t[(3 & i) << 4 | a >> 4], a = t[(15 & a) << 2 | o >> 6], o = t[63 & o], n[l++] = s + i + a + o;
		}
		switch (s = 0, o = r, e.length - c) {
			case 2: o = t[(15 & (s = e[c + 1])) << 2] || r;
			case 1: e = e[c], n[l] = t[e >> 2] + t[(3 & e) << 4 | s >> 4] + o + r;
		}
		return n.join("");
	}
	for (t = "", n = 0, r = e.length - 10240; n < r;) t += String.fromCharCode.apply(null, e.subarray(n, n += 10240));
	return t += String.fromCharCode.apply(null, n ? e.subarray(n) : e), btoa(t);
}
var he = /[-_.]/g, ge = {
	"-": "+",
	_: "/",
	".": "="
};
function _e(e) {
	return ge[e] || "";
}
function ve(e) {
	if (!pe) return ue(e);
	he.test(e) && (e = e.replace(he, _e)), e = atob(e);
	let t = new Uint8Array(e.length);
	for (let n = 0; n < e.length; n++) t[n] = e.charCodeAt(n);
	return t;
}
function ye(e) {
	return fe && e != null && e instanceof Uint8Array;
}
var be;
function xe() {
	return be ||= new Uint8Array();
}
var Se = {}, Ce;
function we(e) {
	if (e !== Se) throw Error("illegal external caller");
}
function Te() {
	return Ce ||= new De(null, Se);
}
function Ee(e) {
	we(Se);
	var t = e.g;
	return (t = t == null || ye(t) ? t : typeof t == "string" ? ve(t) : null) == null ? t : e.g = t;
}
var De = class {
	constructor(e, t) {
		if (we(t), this.g = e, e != null && e.length === 0) throw Error("ByteString should be constructed with non-empty values");
	}
	h() {
		let e = Ee(this);
		return e ? new Uint8Array(e) : xe();
	}
};
function Oe(e, t) {
	return Error(`Invalid wire type: ${e} (at position ${t})`);
}
function ke() {
	return Error("Failed to read varint, encoding is invalid.");
}
function Ae(e, t) {
	return Error(`Tried to read past the end of the data ${t} > ${e}`);
}
function je(e) {
	if (typeof e == "string") return {
		buffer: ve(e),
		P: !1
	};
	if (Array.isArray(e)) return {
		buffer: new Uint8Array(e),
		P: !1
	};
	if (e.constructor === Uint8Array) return {
		buffer: e,
		P: !1
	};
	if (e.constructor === ArrayBuffer) return {
		buffer: new Uint8Array(e),
		P: !1
	};
	if (e.constructor === De) return {
		buffer: Ee(e) || xe(),
		P: !0
	};
	if (e instanceof Uint8Array) return {
		buffer: new Uint8Array(e.buffer, e.byteOffset, e.byteLength),
		P: !1
	};
	throw Error("Type not convertible to a Uint8Array, expected a Uint8Array, an ArrayBuffer, a base64 encoded string, a ByteString or an Array of numbers");
}
function Me() {
	return typeof BigInt == "function";
}
var Ne = typeof Uint8Array.prototype.slice == "function", Pe, p = 0, m = 0;
function Fe(e) {
	let t = 0 > e, n = (e = Math.abs(e)) >>> 0;
	if (e = Math.floor((e - n) / 4294967296), t) {
		let [t, r] = Ue(n, e);
		e = r, n = t;
	}
	p = n >>> 0, m = e >>> 0;
}
function Ie(e) {
	let t = Pe ||= /* @__PURE__ */ new DataView(/* @__PURE__ */ new ArrayBuffer(8));
	t.setFloat32(0, +e, !0), m = 0, p = t.getUint32(0, !0);
}
function Le(e, t) {
	return 4294967296 * t + (e >>> 0);
}
function Re(e, t) {
	let n = 2147483648 & t;
	return n && (t = ~t >>> 0, (e = 1 + ~e >>> 0) == 0 && (t = t + 1 >>> 0)), e = Le(e, t), n ? -e : e;
}
function ze(e, t) {
	if (e >>>= 0, 2097151 >= (t >>>= 0)) var n = "" + (4294967296 * t + e);
	else Me() ? n = "" + (BigInt(t) << BigInt(32) | BigInt(e)) : (e = (16777215 & e) + 6777216 * (n = 16777215 & (e >>> 24 | t << 8)) + 6710656 * (t = t >> 16 & 65535), n += 8147497 * t, t *= 2, 1e7 <= e && (n += Math.floor(e / 1e7), e %= 1e7), 1e7 <= n && (t += Math.floor(n / 1e7), n %= 1e7), n = t + Be(n) + Be(e));
	return n;
}
function Be(e) {
	return e = String(e), "0000000".slice(e.length) + e;
}
function Ve() {
	var e = p, t = m;
	if (2147483648 & t) if (Me()) e = "" + (BigInt(0 | t) << BigInt(32) | BigInt(e >>> 0));
	else {
		let [n, r] = Ue(e, t);
		e = "-" + ze(n, r);
	}
	else e = ze(e, t);
	return e;
}
function He(e) {
	if (16 > e.length) Fe(Number(e));
	else if (Me()) e = BigInt(e), p = Number(e & BigInt(4294967295)) >>> 0, m = Number(e >> BigInt(32) & BigInt(4294967295));
	else {
		let t = +(e[0] === "-");
		m = p = 0;
		let n = e.length;
		for (let r = t, i = (n - t) % 6 + t; i <= n; r = i, i += 6) {
			let t = Number(e.slice(r, i));
			m *= 1e6, p = 1e6 * p + t, 4294967296 <= p && (m += Math.trunc(p / 4294967296), m >>>= 0, p >>>= 0);
		}
		if (t) {
			let [e, t] = Ue(p, m);
			p = e, m = t;
		}
	}
}
function Ue(e, t) {
	return t = ~t, e ? e = 1 + ~e : t += 1, [e, t];
}
function We(e, t) {
	let n, r = 0, i = 0, a = 0, o = e.h, s = e.g;
	do
		n = o[s++], r |= (127 & n) << a, a += 7;
	while (32 > a && 128 & n);
	for (32 < a && (i |= (127 & n) >> 4), a = 3; 32 > a && 128 & n; a += 7) n = o[s++], i |= (127 & n) << a;
	if (Qe(e, s), 128 > n) return t(r >>> 0, i >>> 0);
	throw ke();
}
function Ge(e) {
	let t = 0, n = e.g, r = n + 10, i = e.h;
	for (; n < r;) {
		let r = i[n++];
		if (t |= r, !(128 & r)) return Qe(e, n), !!(127 & t);
	}
	throw ke();
}
function Ke(e) {
	let t = e.h, n = e.g, r = t[n++], i = 127 & r;
	if (128 & r && (r = t[n++], i |= (127 & r) << 7, 128 & r && (r = t[n++], i |= (127 & r) << 14, 128 & r && (r = t[n++], i |= (127 & r) << 21, 128 & r && (r = t[n++], i |= r << 28, 128 & r && 128 & t[n++] && 128 & t[n++] && 128 & t[n++] && 128 & t[n++] && 128 & t[n++]))))) throw ke();
	return Qe(e, n), i;
}
function qe(e) {
	return Ke(e) >>> 0;
}
function Je(e) {
	var t = e.h;
	let n = e.g, r = t[n], i = t[n + 1], a = t[n + 2];
	return t = t[n + 3], Qe(e, e.g + 4), (r << 0 | i << 8 | a << 16 | t << 24) >>> 0;
}
function Ye(e) {
	var t = Je(e);
	e = 2 * (t >> 31) + 1;
	let n = t >>> 23 & 255;
	return t &= 8388607, n == 255 ? t ? NaN : Infinity * e : n == 0 ? e * 2 ** -149 * t : e * 2 ** (n - 150) * (t + 2 ** 23);
}
function Xe(e) {
	return Ke(e);
}
function Ze(e, t, { ca: n = !1 } = {}) {
	e.ca = n, t && (t = je(t), e.h = t.buffer, e.m = t.P, e.j = 0, e.l = e.h.length, e.g = e.j);
}
function Qe(e, t) {
	if (e.g = t, t > e.l) throw Ae(e.l, t);
}
function $e(e, t) {
	if (0 > t) throw Error(`Tried to read a negative byte length: ${t}`);
	let n = e.g, r = n + t;
	if (r > e.l) throw Ae(t, e.l - n);
	return e.g = r, n;
}
function et(e, t) {
	if (t == 0) return Te();
	var n = $e(e, t);
	return e.ca && e.m ? n = e.h.subarray(n, n + t) : (e = e.h, n = n === (t = n + t) ? xe() : Ne ? e.slice(n, t) : new Uint8Array(e.subarray(n, t))), n.length == 0 ? Te() : new De(n, Se);
}
var tt = [];
function nt(e) {
	var t = e.g;
	if (t.g == t.l) return !1;
	e.l = e.g.g;
	var n = qe(e.g);
	if (t = n >>> 3, !(0 <= (n &= 7) && 5 >= n)) throw Oe(n, e.l);
	if (1 > t) throw Error(`Invalid field number: ${t} (at position ${e.l})`);
	return e.m = t, e.h = n, !0;
}
function rt(e) {
	switch (e.h) {
		case 0:
			e.h == 0 ? Ge(e.g) : rt(e);
			break;
		case 1:
			Qe(e = e.g, e.g + 8);
			break;
		case 2:
			if (e.h != 2) rt(e);
			else {
				var t = qe(e.g);
				Qe(e = e.g, e.g + t);
			}
			break;
		case 5:
			Qe(e = e.g, e.g + 4);
			break;
		case 3:
			for (t = e.m;;) {
				if (!nt(e)) throw Error("Unmatched start-group tag: stream EOF");
				if (e.h == 4) {
					if (e.m != t) throw Error("Unmatched end-group tag");
					break;
				}
				rt(e);
			}
			break;
		default: throw Oe(e.h, e.l);
	}
}
function it(e, t, n) {
	let r = e.g.l, i = qe(e.g), a = e.g.g + i, o = a - r;
	if (0 >= o && (e.g.l = a, n(t, e, void 0, void 0, void 0), o = a - e.g.g), o) throw Error(`Message parsing ended unexpectedly. Expected to read ${i} bytes, instead read ${i - o} bytes, either the data ended unexpectedly or the message misreported its own length`);
	return e.g.g = a, e.g.l = r, t;
}
function at(e) {
	var t = qe(e.g), n = $e(e = e.g, t);
	if (e = e.h, s) {
		var c, l = e;
		(c = o) || (c = o = new TextDecoder("utf-8", { fatal: !0 })), t = n + t, l = n === 0 && t === l.length ? l : l.subarray(n, t);
		try {
			var u = c.decode(l);
		} catch (e) {
			if (a === void 0) {
				try {
					c.decode(new Uint8Array([128]));
				} catch {}
				try {
					c.decode(new Uint8Array([97])), a = !0;
				} catch {
					a = !1;
				}
			}
			throw !a && (o = void 0), e;
		}
	} else {
		t = (u = n) + t, n = [];
		let a, o = null;
		for (; u < t;) {
			var d = e[u++];
			128 > d ? n.push(d) : 224 > d ? u >= t ? r() : (a = e[u++], 194 > d || (192 & a) != 128 ? (u--, r()) : n.push((31 & d) << 6 | 63 & a)) : 240 > d ? u >= t - 1 ? r() : (a = e[u++], (192 & a) != 128 || d === 224 && 160 > a || d === 237 && 160 <= a || (192 & (c = e[u++])) != 128 ? (u--, r()) : n.push((15 & d) << 12 | (63 & a) << 6 | 63 & c)) : 244 >= d ? u >= t - 2 ? r() : (a = e[u++], (192 & a) != 128 || a - 144 + (d << 28) >> 30 || (192 & (c = e[u++])) != 128 || (192 & (l = e[u++])) != 128 ? (u--, r()) : (d = (7 & d) << 18 | (63 & a) << 12 | (63 & c) << 6 | 63 & l, d -= 65536, n.push(55296 + (d >> 10 & 1023), 56320 + (1023 & d)))) : r(), 8192 <= n.length && (o = i(o, n), n.length = 0);
		}
		u = i(o, n);
	}
	return u;
}
function ot(e) {
	let t = qe(e.g);
	return et(e.g, t);
}
function st(e, t, n) {
	var r = qe(e.g);
	for (r = e.g.g + r; e.g.g < r;) n.push(t(e.g));
}
var ct = [];
function lt(e) {
	return e ? /^\d+$/.test(e) ? (He(e), new ut(p, m)) : null : dt ||= new ut(0, 0);
}
var ut = class {
	constructor(e, t) {
		this.h = e >>> 0, this.g = t >>> 0;
	}
}, dt;
function ft(e) {
	return e ? /^-?\d+$/.test(e) ? (He(e), new pt(p, m)) : null : mt ||= new pt(0, 0);
}
var pt = class {
	constructor(e, t) {
		this.h = e >>> 0, this.g = t >>> 0;
	}
}, mt;
function ht(e, t, n) {
	for (; 0 < n || 127 < t;) e.g.push(127 & t | 128), t = (t >>> 7 | n << 25) >>> 0, n >>>= 7;
	e.g.push(t);
}
function gt(e, t) {
	for (; 127 < t;) e.g.push(127 & t | 128), t >>>= 7;
	e.g.push(t);
}
function _t(e, t) {
	if (0 <= t) gt(e, t);
	else {
		for (let n = 0; 9 > n; n++) e.g.push(127 & t | 128), t >>= 7;
		e.g.push(1);
	}
}
function vt(e, t) {
	e.g.push(t >>> 0 & 255), e.g.push(t >>> 8 & 255), e.g.push(t >>> 16 & 255), e.g.push(t >>> 24 & 255);
}
function yt(e, t) {
	t.length !== 0 && (e.l.push(t), e.h += t.length);
}
function bt(e, t, n) {
	gt(e.g, 8 * t + n);
}
function xt(e, t) {
	return bt(e, t, 2), t = e.g.end(), yt(e, t), t.push(e.h), t;
}
function St(e, t) {
	var n = t.pop();
	for (n = e.h + e.g.length() - n; 127 < n;) t.push(127 & n | 128), n >>>= 7, e.h++;
	t.push(n), e.h++;
}
function Ct(e, t, n) {
	bt(e, t, 2), gt(e.g, n.length), yt(e, e.g.end()), yt(e, n);
}
function wt(e, t, n, r) {
	n != null && (t = xt(e, t), r(n, e), St(e, t));
}
var Tt = class {
	constructor(e, t, n, r) {
		this.g = e, this.h = t, this.l = n, this.pa = r;
	}
};
function Et(e) {
	return Array.prototype.slice.call(e);
}
function Dt(e) {
	return typeof Symbol == "function" && typeof Symbol() == "symbol" ? Symbol() : e;
}
var Ot = Dt(), kt = Dt("0di"), At = Dt("2ex"), jt = Dt("0dg"), Mt = Ot ? (e, t) => {
	e[Ot] |= t;
} : (e, t) => {
	e.g === void 0 ? Object.defineProperties(e, { g: {
		value: t,
		configurable: !0,
		writable: !0,
		enumerable: !1
	} }) : e.g |= t;
}, Nt = Ot ? (e, t) => {
	e[Ot] &= ~t;
} : (e, t) => {
	e.g !== void 0 && (e.g &= ~t);
};
function h(e, t, n) {
	return n ? e | t : e & ~t;
}
var g = Ot ? (e) => 0 | e[Ot] : (e) => 0 | e.g, _ = Ot ? (e) => e[Ot] : (e) => e.g, v = Ot ? (e, t) => (e[Ot] = t, e) : (e, t) => (e.g === void 0 ? Object.defineProperties(e, { g: {
	value: t,
	configurable: !0,
	writable: !0,
	enumerable: !1
} }) : e.g = t, e);
function Pt(e) {
	return Mt(e, 34), e;
}
function Ft(e, t) {
	v(t, -14591 & (0 | e));
}
function It(e, t) {
	v(t, -14557 & (34 | e));
}
function Lt(e) {
	return (e = e >> 14 & 1023) == 0 ? 536870912 : e;
}
var Rt, zt = {}, Bt = {};
function Vt(e) {
	return !(!e || typeof e != "object" || e.Ja !== Bt);
}
function Ht(e) {
	return typeof e == "object" && !!e && !Array.isArray(e) && e.constructor === Object;
}
function Ut(e, t, n) {
	if (e != null) {
		if (typeof e == "string") e = e ? new De(e, Se) : Te();
		else if (e.constructor !== De) if (ye(e)) e = e.length ? new De(n ? e : new Uint8Array(e), Se) : Te();
		else {
			if (!t) throw Error();
			e = void 0;
		}
	}
	return e;
}
function Wt(e, t, n) {
	if (!Array.isArray(e) || e.length) return !1;
	let r = g(e);
	return !!(1 & r) || !(!t || !(Array.isArray(t) ? t.includes(n) : t.has(n))) && (v(e, 1 | r), !0);
}
var Gt = [];
function Kt(e) {
	if (2 & e) throw Error();
}
v(Gt, 55), Rt = Object.freeze(Gt);
var qt = class e {
	constructor(e, t, n) {
		this.l = 0, this.g = e, this.h = t, this.m = n;
	}
	next() {
		if (this.l < this.g.length) {
			let e = this.g[this.l++];
			return {
				done: !1,
				value: this.h ? this.h.call(this.m, e) : e
			};
		}
		return {
			done: !0,
			value: void 0
		};
	}
	[Symbol.iterator]() {
		return new e(this.g, this.h, this.m);
	}
}, Jt, Yt, Xt;
function Zt(e, t) {
	(t = Jt ? t[Jt] : void 0) && (e[Jt] = Et(t));
}
function Qt(e, t) {
	e.__closure__error__context__984382 ||= {}, e.__closure__error__context__984382.severity = t;
}
function $t() {
	let e = Error();
	Qt(e, "incident"), function(e) {
		t.setTimeout((() => {
			throw e;
		}), 0);
	}(e);
}
function en(e) {
	return Qt(e = Error(e), "warning"), e;
}
function tn(e) {
	return e == null || typeof e == "number" ? e : e === "NaN" || e === "Infinity" || e === "-Infinity" ? Number(e) : void 0;
}
function nn(e) {
	return e == null || typeof e == "boolean" ? e : typeof e == "number" ? !!e : void 0;
}
Object.freeze(new class {}()), Object.freeze(new class {}());
var rn = /^-?([1-9][0-9]*|0)(\.[0-9]+)?$/;
function an(e) {
	let t = typeof e;
	return t === "number" ? Number.isFinite(e) : t === "string" && rn.test(e);
}
function on(e) {
	if (e == null) return e;
	if (typeof e == "string") {
		if (!e) return;
		e = +e;
	}
	return typeof e == "number" && Number.isFinite(e) ? 0 | e : void 0;
}
function sn(e) {
	if (e == null) return e;
	if (typeof e == "string") {
		if (!e) return;
		e = +e;
	}
	return typeof e == "number" && Number.isFinite(e) ? e >>> 0 : void 0;
}
function cn(e) {
	return e[0] !== "-" && (20 > e.length || e.length === 20 && 184467 > Number(e.substring(0, 6)));
}
function ln(e) {
	return e[0] === "-" ? 20 > e.length || e.length === 20 && -922337 < Number(e.substring(0, 7)) : 19 > e.length || e.length === 19 && 922337 > Number(e.substring(0, 6));
}
function un(e) {
	return e = Math.trunc(e), Number.isSafeInteger(e) || (Fe(e), e = Re(p, m)), e;
}
function dn(e) {
	var t = Math.trunc(Number(e));
	return Number.isSafeInteger(t) ? String(t) : ((t = e.indexOf(".")) !== -1 && (e = e.substring(0, t)), ln(e) || (He(e), e = Ve()), e);
}
function fn(e) {
	return e == null ? e : an(e) ? typeof e == "number" ? un(e) : dn(e) : void 0;
}
function pn(e) {
	if (typeof e != "string") throw Error();
	return e;
}
function mn(e) {
	if (e != null && typeof e != "string") throw Error();
	return e;
}
function hn(e) {
	return e == null || typeof e == "string" ? e : void 0;
}
function gn(e, t, n, r) {
	if (typeof e == "object" && e && e.X === zt) return e;
	if (!Array.isArray(e)) return n ? 2 & r ? (e = t[kt]) ? t = e : (Pt((e = new t()).s), t = t[kt] = e) : t = new t() : t = void 0, t;
	let i = n = g(e);
	return i === 0 && (i |= 32 & r), i |= 2 & r, i !== n && v(e, i), new t(e);
}
function _n(e, t, n) {
	if (t) {
		var r = !!r;
		if (!an(t = e)) throw en("int64");
		typeof t == "string" ? r = dn(t) : r ? (r = Math.trunc(t), Number.isSafeInteger(r) ? r = String(r) : ln(t = String(r)) ? r = t : (Fe(r), r = Ve())) : r = un(t);
	} else r = fn(e);
	return typeof (n = (e = r) ?? (n ? 0 : void 0)) == "string" && (r = +n, Number.isSafeInteger(r)) ? r : n;
}
var vn, yn, bn;
function xn(e) {
	switch (typeof e) {
		case "boolean": return yn ||= [
			0,
			void 0,
			!0
		];
		case "number": return 0 < e ? void 0 : e === 0 ? bn ||= [0, void 0] : [-e, void 0];
		case "string": return [0, e];
		case "object": return e;
	}
}
function Sn(e, t) {
	return Cn(e, t[0], t[1]);
}
function Cn(e, t, n) {
	if (e ??= vn, vn = void 0, e == null) {
		var r = 96;
		n ? (e = [n], r |= 512) : e = [], t && (r = -16760833 & r | (1023 & t) << 14);
	} else {
		if (!Array.isArray(e)) throw Error("narr");
		if (2048 & (r = g(e))) throw Error("farr");
		if (64 & r) return e;
		if (r |= 64, n && (r |= 512, n !== e[0])) throw Error("mid");
		t: {
			let i = (n = e).length;
			if (i) {
				let e = i - 1;
				if (Ht(n[e])) {
					if (1024 <= (t = e - (!!(512 & (r |= 256)) - 1))) throw Error("pvtlmt");
					r = -16760833 & r | (1023 & t) << 14;
					break t;
				}
			}
			if (t) {
				if (1024 < (t = Math.max(t, i - (!!(512 & r) - 1)))) throw Error("spvt");
				r = -16760833 & r | (1023 & t) << 14;
			}
		}
	}
	return v(e, r), e;
}
var wn = {}, Tn = function() {
	try {
		return oe(new class extends Map {
			constructor() {
				super();
			}
		}()), !1;
	} catch {
		return !0;
	}
}(), En = class {
	constructor() {
		this.g = /* @__PURE__ */ new Map();
	}
	get(e) {
		return this.g.get(e);
	}
	set(e, t) {
		return this.g.set(e, t), this.size = this.g.size, this;
	}
	delete(e) {
		return e = this.g.delete(e), this.size = this.g.size, e;
	}
	clear() {
		this.g.clear(), this.size = this.g.size;
	}
	has(e) {
		return this.g.has(e);
	}
	entries() {
		return this.g.entries();
	}
	keys() {
		return this.g.keys();
	}
	values() {
		return this.g.values();
	}
	forEach(e, t) {
		return this.g.forEach(e, t);
	}
	[Symbol.iterator]() {
		return this.entries();
	}
}, Dn = Tn ? (Object.setPrototypeOf(En.prototype, Map.prototype), Object.defineProperties(En.prototype, { size: {
	value: 0,
	configurable: !0,
	enumerable: !0,
	writable: !0
} }), En) : class extends Map {
	constructor() {
		super();
	}
};
function On(e) {
	return e;
}
function kn(e) {
	if (2 & e.N) throw Error("Cannot mutate an immutable Map");
}
var An = class extends Dn {
	constructor(e, t, n = On, r = On) {
		super();
		let i = g(e);
		i |= 64, v(e, i), this.N = i, this.U = t, this.S = n, this.Z = this.U ? jn : r;
		for (let a = 0; a < e.length; a++) {
			let o = e[a], s = n(o[0], !1, !0), c = o[1];
			t ? c === void 0 && (c = null) : c = r(o[1], !1, !0, void 0, void 0, i), super.set(s, c);
		}
	}
	oa(e = Mn) {
		if (this.size !== 0) return this.Y(e);
	}
	Y(e = Mn) {
		let t = [], n = super.entries();
		for (var r; !(r = n.next()).done;) (r = r.value)[0] = e(r[0]), r[1] = e(r[1]), t.push(r);
		return t;
	}
	clear() {
		kn(this), super.clear();
	}
	delete(e) {
		return kn(this), super.delete(this.S(e, !0, !1));
	}
	entries() {
		return new qt(this.na(), Nn, this);
	}
	keys() {
		return this.Ia();
	}
	values() {
		return new qt(this.na(), An.prototype.get, this);
	}
	forEach(e, t) {
		super.forEach(((n, r) => {
			e.call(t, this.get(r), r, this);
		}));
	}
	set(e, t) {
		return kn(this), (e = this.S(e, !0, !1)) == null ? this : t == null ? (super.delete(e), this) : super.set(e, this.Z(t, !0, !0, this.U, !1, this.N));
	}
	Oa(e) {
		let t = this.S(e[0], !1, !0);
		e = e[1], e = this.U ? e === void 0 ? null : e : this.Z(e, !1, !0, void 0, !1, this.N), super.set(t, e);
	}
	has(e) {
		return super.has(this.S(e, !1, !1));
	}
	get(e) {
		e = this.S(e, !1, !1);
		let t = super.get(e);
		if (t !== void 0) {
			var n = this.U;
			return n ? ((n = this.Z(t, !1, !0, n, this.ta, this.N)) !== t && super.set(e, n), n) : t;
		}
	}
	na() {
		return Array.from(super.keys());
	}
	Ia() {
		return super.keys();
	}
	[Symbol.iterator]() {
		return this.entries();
	}
};
function jn(e, t, n, r, i, a) {
	return e = gn(e, r, n, a), i && (e = Un(e)), e;
}
function Mn(e) {
	return e;
}
function Nn(e) {
	return [e, this.get(e)];
}
var Pn;
function Fn() {
	return Pn ||= new An(Pt([]), void 0, void 0, void 0, wn);
}
function In(e, t, n, r, i) {
	if (e != null) {
		if (Array.isArray(e)) e = Wt(e, void 0, 0) ? void 0 : i && 2 & g(e) ? e : Ln(e, t, n, r !== void 0, i);
		else if (Ht(e)) {
			let a = {};
			for (let o in e) a[o] = In(e[o], t, n, r, i);
			e = a;
		} else e = t(e, r);
		return e;
	}
}
function Ln(e, t, n, r, i) {
	let a = r || n ? g(e) : 0;
	r = r ? !!(32 & a) : void 0;
	let o = Et(e);
	for (let e = 0; e < o.length; e++) o[e] = In(o[e], t, n, r, i);
	return n && (Zt(o, e), n(a, o)), o;
}
function Rn(e) {
	return In(e, zn, void 0, void 0, !1);
}
function zn(e) {
	return e.X === zt ? e.toJSON() : e instanceof An ? e.oa(Rn) : function(e) {
		switch (typeof e) {
			case "number": return isFinite(e) ? e : String(e);
			case "boolean": return +!!e;
			case "object": if (e) if (Array.isArray(e)) {
				if (Wt(e, void 0, 0)) return;
			} else {
				if (ye(e)) return me(e);
				if (e instanceof De) {
					let t = e.g;
					return t == null ? "" : typeof t == "string" ? t : e.g = me(t);
				}
				if (e instanceof An) return e.oa();
			}
		}
		return e;
	}(e);
}
function Bn(e, t, n = It) {
	if (e != null) {
		if (fe && e instanceof Uint8Array) return t ? e : new Uint8Array(e);
		if (Array.isArray(e)) {
			var r = g(e);
			return 2 & r || (t &&= r === 0 || !!(32 & r) && !(64 & r || !(16 & r)), e = t ? v(e, -12293 & (34 | r)) : Ln(e, Bn, 4 & r ? It : n, !0, !0)), e;
		}
		return e.X === zt ? (n = e.s, e = 2 & (r = _(n)) ? e : Vn(e, n, r, !0)) : e instanceof An && !(2 & e.N) && (n = Pt(e.Y(Bn)), e = new An(n, e.U, e.S, e.Z)), e;
	}
}
function Vn(e, t, n, r) {
	return e = e.constructor, vn = t = Hn(t, n, r), t = new e(t), vn = void 0, t;
}
function Hn(e, t, n) {
	let r = n || 2 & t ? It : Ft, i = !!(32 & t);
	return e = function(e, t, n) {
		let r = Et(e);
		var i = r.length;
		let a = 256 & t ? r[i - 1] : void 0;
		for (i += a ? -1 : 0, t = 512 & t ? 1 : 0; t < i; t++) r[t] = n(r[t]);
		if (a) {
			t = r[t] = {};
			for (let e in a) t[e] = n(a[e]);
		}
		return Zt(r, e), r;
	}(e, t, ((e) => Bn(e, i, r))), Mt(e, 32 | (n ? 2 : 0)), e;
}
function Un(e) {
	let t = e.s, n = _(t);
	return 2 & n ? Vn(e, t, n, !1) : e;
}
function Wn(e, t, n, r) {
	return !(4 & t) || n != null && (!r && n === 0 && (4096 & t || 8192 & t) && 5 > (e.constructor[jt] = 1 + (0 | e.constructor[jt])) && $t(), n !== 0 && !(n & t));
}
function Gn(e, t) {
	return qn(e = e.s, _(e), t);
}
function Kn(e, t, n, r) {
	if (!(0 > (t = r + (!!(512 & t) - 1)) || t >= e.length || t >= n)) return e[t];
}
function qn(e, t, n, r) {
	if (n === -1) return null;
	let i = Lt(t);
	if (!(n >= i)) {
		var a = e.length;
		return r && 256 & t && (r = e[a - 1][n]) != null ? (Kn(e, t, i, n) && At != null && (4 <= (t = (e = Xt ??= {})[At] || 0) || (e[At] = t + 1, $t())), r) : Kn(e, t, i, n);
	}
	return 256 & t ? e[e.length - 1][n] : void 0;
}
function y(e, t, n, r) {
	let i = e.s, a = _(i);
	return Kt(a), b(i, a, t, n, r), e;
}
function b(e, t, n, r, i) {
	let a = Lt(t);
	if (n >= a || i) {
		let o = t;
		if (256 & t) i = e[e.length - 1];
		else {
			if (r == null) return o;
			i = e[a + (!!(512 & t) - 1)] = {}, o |= 256;
		}
		return i[n] = r, n < a && (e[n + (!!(512 & t) - 1)] = void 0), o !== t && v(e, o), o;
	}
	return e[n + (!!(512 & t) - 1)] = r, 256 & t && n in (e = e[e.length - 1]) && delete e[n], t;
}
function Jn(e, t, n, r, i) {
	var a = 2 & t;
	let o = qn(e, t, n, i);
	Array.isArray(o) || (o = Rt);
	let s = !(2 & r);
	r = !(1 & r);
	let c = !!(32 & t), l = g(o);
	return l !== 0 || !c || a || s ? 1 & l || (l |= 1, v(o, l)) : (l |= 33, v(o, l)), a ? (e = !1, 2 & l || (Pt(o), e = !!(4 & l)), (r || e) && Object.freeze(o)) : (a = !!(2 & l) || !!(2048 & l), r && a ? (o = Et(o), r = 1, c && !s && (r |= 32), v(o, r), b(e, t, n, o, i)) : s && 32 & l && !a && Nt(o, 32)), o;
}
function Yn(e, t) {
	e = e.s;
	let n = _(e), r = qn(e, n, t), i = tn(r);
	return i != null && i !== r && b(e, n, t, i), i;
}
function Xn(e) {
	e = e.s;
	let t = _(e), n = qn(e, t, 1), r = Ut(n, !0, !!(34 & t));
	return r != null && r !== n && b(e, t, 1, r), r;
}
function Zn(e, t, n) {
	let r = e.s, i = _(r), a = 2 & i ? 1 : 2, o = Qn(r, i, t);
	var s = g(o);
	if (Wn(e, s, void 0, !1)) {
		(4 & s || Object.isFrozen(o)) && (o = Et(o), s = pr(s, i), i = b(r, i, t, o));
		let a = e = 0;
		for (; e < o.length; e++) {
			let t = n(o[e]);
			t != null && (o[a++] = t);
		}
		a < e && (o.length = a), s = h(s = $n(s, i), 20, !0), s = h(s, 4096, !1), s = h(s, 8192, !1), v(o, s), 2 & s && Object.freeze(o);
	}
	return er(s) || (n = s, (s = (e = a === 1 || a === 4 && !!(32 & s)) ? h(s, 2, !0) : mr(s, i, !1)) !== n && v(o, s), e && Object.freeze(o)), a === 2 && er(s) && (o = Et(o), s = mr(s = pr(s, i), i, !1), v(o, s), b(r, i, t, o)), o;
}
function Qn(e, t, n) {
	return e = qn(e, t, n), Array.isArray(e) ? e : Rt;
}
function $n(e, t) {
	return e === 0 && (e = pr(e, t)), h(e, 1, !0);
}
function er(e) {
	return !!(2 & e) && !!(4 & e) || !!(2048 & e);
}
function tr(e) {
	e = Et(e);
	for (let t = 0; t < e.length; t++) {
		let n = e[t] = Et(e[t]);
		Array.isArray(n[1]) && (n[1] = Pt(n[1]));
	}
	return e;
}
function nr(e, t, n) {
	{
		let s = e.s, c = _(s);
		if (Kt(c), n == null) b(s, c, t);
		else {
			var r, i = g(n), a = i, o = !!(2 & i) || Object.isFrozen(n);
			if ((r = !o) && (r = !1), Wn(e, i)) for (i = 21, o && (n = Et(n), a = 0, i = mr(i = pr(i, c), c, !0)), e = 0; e < n.length; e++) n[e] = pn(n[e]);
			r && (n = Et(n), a = 0, i = mr(i = pr(i, c), c, !0)), i !== a && v(n, i), b(s, c, t, n);
		}
	}
}
function rr(e, t, n, r) {
	e = e.s;
	let i = _(e);
	Kt(i), b(e, i, t, (r === "0" ? Number(n) === 0 : n === r) ? void 0 : n);
}
function ir(e, t, n, r) {
	let i = _(e);
	Kt(i), e = Jn(e, i, t, 2), r = n(r, !!(4 & (t = g(e))) && !!(4096 & t)), e.push(r);
}
function ar(e) {
	return e;
}
function or(e, t) {
	return sr(e = e.s, _(e), Pa) === t ? t : -1;
}
function sr(e, t, n) {
	let r = 0;
	for (let i = 0; i < n.length; i++) {
		let a = n[i];
		qn(e, t, a) != null && (r !== 0 && (t = b(e, t, r)), r = a);
	}
	return r;
}
function cr(e, t, n, r) {
	let i = _(e);
	Kt(i);
	let a = qn(e, i, n, r), o;
	if (a != null && a.X === zt) return (t = Un(a)) !== a && b(e, i, n, t, r), t.s;
	if (Array.isArray(a)) {
		let e = g(a);
		o = 2 & e ? Hn(a, e, !1) : a, o = Sn(o, t);
	} else o = Sn(void 0, t);
	return o !== a && b(e, i, n, o, r), o;
}
function lr(e, t, n, r) {
	e = e.s;
	let i = _(e), a = qn(e, i, n, r);
	return (t = gn(a, t, !1, i)) !== a && t != null && b(e, i, n, t, r), t;
}
function x(e, t, n, r = !1) {
	if ((t = lr(e, t, n, r)) == null) return t;
	e = e.s;
	let i = _(e);
	if (!(2 & i)) {
		let a = Un(t);
		a !== t && b(e, i, n, t = a, r);
	}
	return t;
}
function ur(e, t, n, r, i, a) {
	var o = 2, s = !!(2 & t);
	o = s ? 1 : o, i = !!i, a &&= !s, s = Qn(e, t, r);
	var c = g(s);
	let l = !!(4 & c);
	if (!l) {
		var u = s, d = t;
		let e = !!(2 & (c = $n(c, t)));
		e && (d = h(d, 2, !0));
		let r = !e, i = !0, a = 0, o = 0;
		for (; a < u.length; a++) {
			let t = gn(u[a], n, !1, d);
			if (t instanceof n) {
				if (!e) {
					let e = !!(2 & g(t.s));
					r &&= !e, i &&= e;
				}
				u[o++] = t;
			}
		}
		o < a && (u.length = o), c = h(c, 4, !0), c = h(c, 16, i), c = h(c, 8, r), v(u, c), e && Object.freeze(u);
	}
	if (a && !(8 & c || !s.length && (o === 1 || o === 4 && 32 & c))) {
		for (er(c) && (s = Et(s), c = pr(c, t), t = b(e, t, r, s)), n = s, a = c, u = 0; u < n.length; u++) (c = n[u]) !== (d = Un(c)) && (n[u] = d);
		a = h(a, 8, !0), a = h(a, 16, !n.length), v(n, a), c = a;
	}
	return er(c) || (n = c, (c = (a = o === 1 || o === 4 && !!(32 & c)) ? h(c, !s.length || 16 & c && (!l || 32 & c) ? 2 : 2048, !0) : mr(c, t, i)) !== n && v(s, c), a && Object.freeze(s)), o === 2 && er(c) && (s = Et(s), c = mr(c = pr(c, t), t, i), v(s, c), b(e, t, r, s)), s;
}
function dr(e, t, n) {
	e = e.s;
	let r = _(e);
	return ur(e, r, t, n, !1, !(2 & r));
}
function S(e, t, n, r, i) {
	return r ??= void 0, y(e, n, r, i);
}
function fr(e, t, n, r) {
	r ??= void 0, e = e.s;
	let i = _(e);
	Kt(i), (n = sr(e, i, n)) && n !== t && r != null && (i = b(e, i, n)), b(e, i, t, r);
}
function pr(e, t) {
	return e = h(e, 2, !!(2 & t)), e = h(e, 32, !0), h(e, 2048, !1);
}
function mr(e, t, n) {
	return 32 & t && n || (e = h(e, 32, !1)), e;
}
function hr(e, t, n, r) {
	e = e.s;
	let i = _(e);
	Kt(i), t = ur(e, i, n, t, !0), n = r ?? new n(), t.push(n), 2 & g(n.s) ? Nt(t, 8) : Nt(t, 16);
}
function gr(e, t) {
	return on(Gn(e, t));
}
function _r(e, t) {
	return e ?? t;
}
function C(e, t) {
	return _r(Yn(e, t), 0);
}
function vr(e, t) {
	return _r(hn(Gn(e, t)), "");
}
function yr(e, t, n) {
	if (n != null && typeof n != "boolean") throw e = typeof n, Error(`Expected boolean but got ${e == "object" ? n ? Array.isArray(n) ? "array" : e : "null" : e}: ${n}`);
	y(e, t, n);
}
function br(e, t, n) {
	if (n != null) {
		if (typeof n != "number" || !Number.isFinite(n)) throw en("int32");
		n |= 0;
	}
	y(e, t, n);
}
function w(e, t, n) {
	if (n != null && typeof n != "number") throw Error(`Value of float/double field must be a number, found ${typeof n}: ${n}`);
	y(e, t, n);
}
function xr(e, t, n) {
	t.g ? t.m(e, t.g, t.h, n, !0) : t.m(e, t.h, n, !0);
}
An.prototype.toJSON = void 0, An.prototype.Ja = Bt;
var T = class {
	constructor(e, t) {
		this.s = Cn(e, t);
	}
	toJSON() {
		return Sr(this, Ln(this.s, zn, void 0, void 0, !1), !0);
	}
	l() {
		var e = Io;
		return e.g ? e.l(this, e.g, e.h, !0) : e.l(this, e.h, e.defaultValue, !0);
	}
	clone() {
		let e = this.s;
		return Vn(this, e, _(e), !1);
	}
	P() {
		return !!(2 & g(this.s));
	}
};
function Sr(e, t, n) {
	var r = te ? void 0 : e.constructor.B;
	let i = _(n ? e.s : t);
	if (!(e = t.length)) return t;
	let a, o;
	if (Ht(n = t[e - 1])) {
		t: {
			var s = n;
			let e = {}, t = !1;
			for (var c in s) {
				let n = s[c];
				if (Array.isArray(n)) {
					let e = n;
					(Wt(n, r, +c) || Vt(n) && n.size === 0) && (n = null), n != e && (t = !0);
				}
				n == null ? t = !0 : e[c] = n;
			}
			if (t) {
				for (var l in e) {
					s = e;
					break t;
				}
				s = null;
			}
		}
		s != n && (a = !0), e--;
	}
	for (c = !!(512 & i) - 1; 0 < e && (n = t[l = e - 1], l -= c, n == null || Wt(n, r, l) || Vt(n) && n.size === 0); e--) o = !0;
	return a || o ? (t = Array.prototype.slice.call(t, 0, e), s && t.push(s), t) : t;
}
function Cr(e) {
	return Array.isArray(e) ? e[0] instanceof Tt ? e : [gi, e] : [e, void 0];
}
function wr(e, t) {
	if (Array.isArray(t)) {
		var n = g(t);
		if (4 & n) return t;
		for (var r = 0, i = 0; r < t.length; r++) {
			let n = e(t[r]);
			n != null && (t[i++] = n);
		}
		return i < r && (t.length = i), v(t, -12289 & (5 | n)), 2 & n && Object.freeze(t), t;
	}
}
T.prototype.X = zt, T.prototype.toString = function() {
	return Sr(this, this.s, !1).toString();
};
var Tr = Symbol();
function Er(e) {
	let t = e[Tr];
	if (!t) {
		let n = Pr(e), r = Kr(e), i = r.l;
		t = i ? (e, t) => i(e, t, r) : (e, t) => {
			for (; nt(t) && t.h != 4;) {
				var i = t.m, a = r[i];
				if (!a) {
					var o = r.ea;
					(o &&= o[i]) && (a = r[i] = Dr(o));
				}
				a && a(t, e, i) || (i = (a = t).l, rt(a), a.ia ? a = void 0 : (o = a.g.g - i, a.g.g = i, a = et(a.g, o)), i = e, a && (Jt ||= Symbol(), (o = i[Jt]) ? o.push(a) : i[Jt] = [a]));
			}
			n === kr || n === Ar || n.j || (e[Yt ||= Symbol()] = n);
		}, e[Tr] = t;
	}
	return t;
}
function Dr(e) {
	let t = (e = Cr(e))[0].g;
	if (e = e[1]) {
		let n = Er(e), r = Kr(e).T;
		return (e, i, a) => t(e, i, a, r, n);
	}
	return t;
}
var Or = class {}, kr, Ar, jr = Symbol();
function Mr(e, t, n) {
	let r = n[1], i;
	if (r) {
		let n = r[jr];
		i = n ? n.T : xn(r[0]), e[t] = n ?? r;
	}
	i && i === yn ? (e.g ||= /* @__PURE__ */ new Set()).add(t) : n[0] && (e.h ||= /* @__PURE__ */ new Set()).add(t);
}
function Nr(e, t) {
	return [e.l, !t || 0 < t[0] ? void 0 : t];
}
function Pr(e) {
	var t = e[jr];
	if (t) return t;
	if (!(t = Ir(e, e[jr] = new Or(), Nr, Nr, Mr)).ea && !t.h && !t.g) {
		let n = !0;
		for (let e in t) isNaN(e) || (n = !1);
		n ? (xn(e[0]) === yn ? Ar ? t = Ar : ((t = new Or()).T = xn(!0), t = Ar = t) : t = kr ||= new Or(), t = e[jr] = t) : t.j = !0;
	}
	return t;
}
function Fr(e, t, n) {
	e[t] = n;
}
function Ir(e, t, n, r, i = Fr) {
	t.T = xn(e[0]);
	let a = 0;
	var o = e[++a];
	o && o.constructor === Object && (t.ea = o, typeof (o = e[++a]) == "function" && (t.l = o, t.m = e[++a], o = e[++a]));
	let s = {};
	for (; Array.isArray(o) && typeof o[0] == "number" && 0 < o[0];) {
		for (var c = 0; c < o.length; c++) s[o[c]] = o;
		o = e[++a];
	}
	for (c = 1; o !== void 0;) {
		let d;
		typeof o == "number" && (c += o, o = e[++a]);
		var l = void 0;
		if (o instanceof Tt ? d = o : (d = _i, a--), d.pa) {
			o = e[++a], l = e;
			var u = a;
			typeof o == "function" && (o = o(), l[u] = o), l = o;
		}
		for (u = c + 1, typeof (o = e[++a]) == "number" && 0 > o && (u -= o, o = e[++a]); c < u; c++) {
			let e = s[c];
			i(t, c, l ? r(d, l, e) : n(d, e));
		}
	}
	return t;
}
var Lr = Symbol();
function Rr(e) {
	let t = e[Lr];
	if (!t) {
		let n = Hr(e);
		t = (e, t) => Yr(e, t, n), e[Lr] = t;
	}
	return t;
}
var zr = Symbol();
function Br(e) {
	return e.h;
}
function Vr(e, t) {
	let n, r, i = e.h;
	return (e, a, o) => i(e, a, o, r ||= Hr(t).T, n ||= Rr(t));
}
function Hr(e) {
	let t = e[zr];
	return t || (t = Ir(e, e[zr] = {}, Br, Vr), qr(e), t);
}
var Ur = Symbol();
function Wr(e, t) {
	let n = e.g;
	return t ? (e, r, i) => n(e, r, i, t) : n;
}
function Gr(e, t, n) {
	let r = e.g, i, a;
	return (e, o, s) => r(e, o, s, a ||= Kr(t).T, i ||= Er(t), n);
}
function Kr(e) {
	let t = e[Ur];
	return t || (Pr(e), t = Ir(e, e[Ur] = {}, Wr, Gr), qr(e), t);
}
function qr(e) {
	Ur in e && jr in e && zr in e && (e.length = 0);
}
function Jr(e, t) {
	var n = e[t];
	if (n) return n;
	if ((n = e.ea) && (n = n[t])) {
		var r = (n = Cr(n))[0].h;
		if (n = n[1]) {
			let t = Rr(n), i = Hr(n).T;
			n = (n = e.m) ? n(i, t) : (e, n, a) => r(e, n, a, i, t);
		} else n = r;
		return e[t] = n;
	}
}
function Yr(e, t, n) {
	for (var r = _(e), i = !!(512 & r) - 1, a = e.length, o = 512 & r ? 1 : 0, s = a + (256 & r ? -1 : 0); o < s; o++) {
		let r = e[o];
		if (r == null) continue;
		let a = o - i, s = Jr(n, a);
		s && s(t, r, a);
	}
	if (256 & r) {
		r = e[a - 1];
		for (let e in r) i = +e, Number.isNaN(i) || (a = r[e]) != null && (s = Jr(n, i)) && s(t, a, i);
	}
	if (e = Jt ? e[Jt] : void 0) for (yt(t, t.g.end()), n = 0; n < e.length; n++) yt(t, Ee(e[n]) || xe());
}
function E(e, t) {
	return new Tt(e, t, !1, !1);
}
function Xr(e, t) {
	return new Tt(e, t, !0, !1);
}
function Zr(e, t) {
	return new Tt(e, t, !1, !0);
}
function D(e, t, n) {
	b(e, _(e), t, n);
}
var Qr = Zr((function(e, t, n, r, i) {
	return e.h === 2 && (e = it(e, Sn([void 0, void 0], r), i), Kt(r = _(t)), (i = qn(t, r, n)) instanceof An ? 2 & i.N ? ((i = i.Y()).push(e), b(t, r, n, i)) : i.Oa(e) : Array.isArray(i) ? (2 & g(i) && b(t, r, n, i = tr(i)), i.push(e)) : b(t, r, n, [e]), !0);
}), (function(e, t, n, r, i) {
	if (t instanceof An) t.forEach(((t, a) => {
		wt(e, n, Sn([a, t], r), i);
	}));
	else if (Array.isArray(t)) for (let a = 0; a < t.length; a++) {
		let o = t[a];
		Array.isArray(o) && wt(e, n, Sn(o, r), i);
	}
}));
function $r(e, t, n) {
	t: if (t != null) {
		if (an(t)) {
			if (typeof t == "string") {
				t = dn(t);
				break t;
			}
			if (typeof t == "number") {
				t = un(t);
				break t;
			}
		}
		t = void 0;
	}
	t != null && (typeof t == "string" && ft(t), t != null && (bt(e, n, 0), typeof t == "number" ? (e = e.g, Fe(t), ht(e, p, m)) : (n = ft(t), ht(e.g, n.h, n.g))));
}
function ei(e, t, n) {
	(t = on(t)) != null && t != null && (bt(e, n, 0), _t(e.g, t));
}
function ti(e, t, n) {
	(t = nn(t)) != null && (bt(e, n, 0), e.g.g.push(+!!t));
}
function ni(e, t, n) {
	(t = hn(t)) != null && Ct(e, n, u(t));
}
function ri(e, t, n, r, i) {
	wt(e, n, t instanceof T ? t.s : Array.isArray(t) ? Sn(t, r) : void 0, i);
}
function ii(e, t, n) {
	(t = t == null || typeof t == "string" || ye(t) || t instanceof De ? t : void 0) != null && Ct(e, n, je(t).buffer);
}
function ai(e, t, n) {
	return (e.h === 5 || e.h === 2) && (t = Jn(t, _(t), n, 2, !1), e.h == 2 ? st(e, Ye, t) : t.push(Ye(e.g)), !0);
}
var O, oi = E((function(e, t, n) {
	if (e.h !== 1) return !1;
	var r = e.g;
	e = Je(r);
	let i = Je(r);
	r = 2 * (i >> 31) + 1;
	let a = i >>> 20 & 2047;
	return e = 4294967296 * (1048575 & i) + e, D(t, n, a == 2047 ? e ? NaN : Infinity * r : a == 0 ? r * 2 ** -1074 * e : r * 2 ** (a - 1075) * (e + 4503599627370496)), !0;
}), (function(e, t, n) {
	(t = tn(t)) != null && (bt(e, n, 1), e = e.g, (n = Pe ||= /* @__PURE__ */ new DataView(/* @__PURE__ */ new ArrayBuffer(8))).setFloat64(0, +t, !0), p = n.getUint32(0, !0), m = n.getUint32(4, !0), vt(e, p), vt(e, m));
})), k = E((function(e, t, n) {
	return e.h === 5 && (D(t, n, Ye(e.g)), !0);
}), (function(e, t, n) {
	(t = tn(t)) != null && (bt(e, n, 5), e = e.g, Ie(t), vt(e, p));
})), si = Xr(ai, (function(e, t, n) {
	if ((t = wr(tn, t)) != null) for (let o = 0; o < t.length; o++) {
		var r = e, i = n, a = t[o];
		a != null && (bt(r, i, 5), r = r.g, Ie(a), vt(r, p));
	}
})), ci = Xr(ai, (function(e, t, n) {
	if ((t = wr(tn, t)) != null && t.length) {
		bt(e, n, 2), gt(e.g, 4 * t.length);
		for (let r = 0; r < t.length; r++) n = e.g, Ie(t[r]), vt(n, p);
	}
})), li = E((function(e, t, n) {
	return e.h === 0 && (D(t, n, We(e.g, Re)), !0);
}), $r), ui = E((function(e, t, n) {
	return e.h === 0 && (D(t, n, (e = We(e.g, Re)) === 0 ? void 0 : e), !0);
}), $r), di = E((function(e, t, n) {
	return e.h === 0 && (D(t, n, We(e.g, Le)), !0);
}), (function(e, t, n) {
	t: if (t != null) {
		if (an(t)) {
			if (typeof t == "string") {
				var r = Math.trunc(Number(t));
				Number.isSafeInteger(r) && 0 <= r ? t = String(r) : ((r = t.indexOf(".")) !== -1 && (t = t.substring(0, r)), cn(t) || (He(t), t = ze(p, m)));
				break t;
			}
			if (typeof t == "number") {
				t = 0 <= (t = Math.trunc(t)) && Number.isSafeInteger(t) ? t : function(e) {
					if (0 > e) {
						Fe(e);
						let t = ze(p, m);
						return e = Number(t), Number.isSafeInteger(e) ? e : t;
					}
					return cn(String(e)) ? e : (Fe(e), Le(p, m));
				}(t);
				break t;
			}
		}
		t = void 0;
	}
	t != null && (typeof t == "string" && lt(t), t != null && (bt(e, n, 0), typeof t == "number" ? (e = e.g, Fe(t), ht(e, p, m)) : (n = lt(t), ht(e.g, n.h, n.g))));
})), A = E((function(e, t, n) {
	return e.h === 0 && (D(t, n, Ke(e.g)), !0);
}), ei), fi = Xr((function(e, t, n) {
	return (e.h === 0 || e.h === 2) && (t = Jn(t, _(t), n, 2, !1), e.h == 2 ? st(e, Ke, t) : t.push(Ke(e.g)), !0);
}), (function(e, t, n) {
	if ((t = wr(on, t)) != null && t.length) {
		n = xt(e, n);
		for (let n = 0; n < t.length; n++) _t(e.g, t[n]);
		St(e, n);
	}
})), pi = E((function(e, t, n) {
	return e.h === 0 && (D(t, n, (e = Ke(e.g)) === 0 ? void 0 : e), !0);
}), ei), j = E((function(e, t, n) {
	return e.h === 0 && (D(t, n, Ge(e.g)), !0);
}), ti), mi = E((function(e, t, n) {
	return e.h === 0 && (D(t, n, !1 === (e = Ge(e.g)) ? void 0 : e), !0);
}), ti), M = Xr((function(e, t, n) {
	return e.h === 2 && (ir(t, n, ar, e = at(e)), !0);
}), (function(e, t, n) {
	if ((t = wr(hn, t)) != null) for (let o = 0; o < t.length; o++) {
		var r = e, i = n, a = t[o];
		a != null && Ct(r, i, u(a));
	}
})), hi = E((function(e, t, n) {
	return e.h === 2 && (D(t, n, (e = at(e)) === "" ? void 0 : e), !0);
}), ni), N = E((function(e, t, n) {
	return e.h === 2 && (D(t, n, at(e)), !0);
}), ni), gi = Zr((function(e, t, n, r, i) {
	return e.h === 2 && (it(e, cr(t, r, n, !0), i), !0);
}), ri), _i = Zr((function(e, t, n, r, i) {
	return e.h === 2 && (it(e, cr(t, r, n), i), !0);
}), ri);
O = new Tt((function(e, t, n, r, i) {
	if (e.h !== 2) return !1;
	r = Sn(void 0, r);
	let a = _(t);
	Kt(a);
	let o = Jn(t, a, n, 3);
	return a = _(t), 4 & g(o) && (o = Et(o), v(o, -2079 & (1 | g(o))), b(t, a, n, o)), o.push(r), it(e, r, i), !0;
}), (function(e, t, n, r, i) {
	if (Array.isArray(t)) for (let a = 0; a < t.length; a++) ri(e, t[a], n, r, i);
}), !0, !0);
var P = Zr((function(e, t, n, r, i, a) {
	if (e.h !== 2) return !1;
	let o = _(t);
	return Kt(o), (a = sr(t, o, a)) && n !== a && b(t, o, a), it(e, t = cr(t, r, n), i), !0;
}), ri), vi = E((function(e, t, n) {
	return e.h === 2 && (D(t, n, ot(e)), !0);
}), ii), yi = Xr((function(e, t, n) {
	return (e.h === 0 || e.h === 2) && (t = Jn(t, _(t), n, 2, !1), e.h == 2 ? st(e, qe, t) : t.push(qe(e.g)), !0);
}), (function(e, t, n) {
	if ((t = wr(sn, t)) != null) for (let o = 0; o < t.length; o++) {
		var r = e, i = n, a = t[o];
		a != null && (bt(r, i, 0), gt(r.g, a));
	}
})), bi = E((function(e, t, n) {
	return e.h === 0 && (D(t, n, Ke(e.g)), !0);
}), (function(e, t, n) {
	(t = on(t)) != null && (t = parseInt(t, 10), bt(e, n, 0), _t(e.g, t));
})), xi = Xr((function(e, t, n) {
	return (e.h === 0 || e.h === 2) && (t = Jn(t, _(t), n, 2, !1), e.h == 2 ? st(e, Xe, t) : t.push(Ke(e.g)), !0);
}), (function(e, t, n) {
	if ((t = wr(on, t)) != null && t.length) {
		n = xt(e, n);
		for (let n = 0; n < t.length; n++) _t(e.g, t[n]);
		St(e, n);
	}
})), Si = class {
	constructor(e, t) {
		this.h = e, this.g = t, this.l = x, this.m = S, this.defaultValue = void 0;
	}
};
function Ci(e, t) {
	return new Si(e, t);
}
function wi(e, t) {
	return (n, r) => {
		if (ct.length) {
			let e = ct.pop();
			e.o(r), Ze(e.g, n, r), n = e;
		} else n = new class {
			constructor(e, t) {
				if (tt.length) {
					let n = tt.pop();
					Ze(n, e, t), e = n;
				} else e = new class {
					constructor(e, t) {
						this.h = null, this.m = !1, this.g = this.l = this.j = 0, Ze(this, e, t);
					}
					clear() {
						this.h = null, this.m = !1, this.g = this.l = this.j = 0, this.ca = !1;
					}
				}(e, t);
				this.g = e, this.l = this.g.g, this.h = this.m = -1, this.o(t);
			}
			o({ ia: e = !1 } = {}) {
				this.ia = e;
			}
		}(n, r);
		try {
			let r = new e(), a = r.s;
			Er(t)(a, n);
			var i = r;
		} finally {
			n.g.clear(), n.m = -1, n.h = -1, 100 > ct.length && ct.push(n);
		}
		return i;
	};
}
function Ti(e) {
	return function() {
		let t = new class {
			constructor() {
				this.l = [], this.h = 0, this.g = new class {
					constructor() {
						this.g = [];
					}
					length() {
						return this.g.length;
					}
					end() {
						let e = this.g;
						return this.g = [], e;
					}
				}();
			}
		}();
		Yr(this.s, t, Hr(e)), yt(t, t.g.end());
		let n = new Uint8Array(t.h), r = t.l, i = r.length, a = 0;
		for (let e = 0; e < i; e++) {
			let t = r[e];
			n.set(t, a), a += t.length;
		}
		return t.l = [n], n;
	};
}
var Ei = class extends T {
	constructor(e) {
		super(e);
	}
}, Di = [
	0,
	hi,
	E((function(e, t, n) {
		return e.h === 2 && (D(t, n, (e = ot(e)) === Te() ? void 0 : e), !0);
	}), (function(e, t, n) {
		if (t != null) {
			if (t instanceof T) {
				let r = t.Qa;
				r && (t = r(t), t != null && Ct(e, n, je(t).buffer));
				return;
			}
			if (Array.isArray(t)) return;
		}
		ii(e, t, n);
	}))
], Oi = [0, N], ki = [
	0,
	A,
	bi,
	j,
	-1,
	fi,
	bi,
	-1
], Ai = [
	0,
	j,
	-1
], ji = class extends T {
	constructor() {
		super();
	}
};
ji.B = [6];
var Mi = [
	0,
	j,
	N,
	j,
	bi,
	-1,
	xi,
	N,
	-1,
	Ai,
	bi
], Ni = [
	0,
	N,
	-2
], Pi = class extends T {
	constructor() {
		super();
	}
}, Fi = [0], Ii = [
	0,
	A,
	j,
	-4
], Li = class extends T {
	constructor(e) {
		super(e, 2);
	}
}, F = {}, Ri = [
	-2,
	F,
	j
];
F[336783863] = [
	0,
	N,
	j,
	-1,
	A,
	[
		0,
		[
			1,
			2,
			3,
			4,
			5,
			6
		],
		P,
		Fi,
		P,
		Mi,
		P,
		Ni,
		P,
		Ii,
		P,
		ki,
		P,
		[0, N]
	],
	Oi,
	j,
	[
		0,
		[1, 3],
		[2, 4],
		P,
		[0, fi],
		-1,
		P,
		[0, M],
		-1,
		O,
		[
			0,
			N,
			-1
		]
	],
	N
];
var zi = [
	0,
	hi,
	mi
], Bi = [
	0,
	ui,
	-1,
	mi,
	-3,
	ui,
	fi,
	hi,
	pi,
	ui,
	-1,
	mi,
	pi,
	mi,
	-2,
	hi
], Vi = [-1, {}], Hi = [
	0,
	N,
	1,
	Vi
], Ui = [
	0,
	N,
	M,
	Vi
];
function Wi(e, t) {
	rr(e, 2, mn(t), "");
}
function I(e, t) {
	ir(e.s, 3, pn, t);
}
function L(e, t) {
	ir(e.s, 4, pn, t);
}
var R = class extends T {
	constructor(e) {
		super(e, 500);
	}
	o(e) {
		return S(this, 0, 7, e);
	}
};
R.B = [
	3,
	4,
	5,
	6,
	8,
	13,
	17,
	1005
];
var Gi = [
	-500,
	hi,
	-1,
	M,
	-3,
	Ri,
	O,
	Di,
	pi,
	-1,
	Hi,
	Ui,
	O,
	zi,
	hi,
	Bi,
	pi,
	M,
	987,
	M
], Ki = [
	0,
	hi,
	-1,
	Vi
], qi = [
	-500,
	N,
	-1,
	[-1, {}],
	998,
	N
], Ji = [
	-500,
	N,
	M,
	-1,
	[
		-2,
		{},
		j
	],
	997,
	M,
	-1
], Yi = [
	-500,
	N,
	M,
	Vi,
	998,
	M
];
function Xi(e, t) {
	hr(e, 1, R, t);
}
function z(e, t) {
	ir(e.s, 10, pn, t);
}
function B(e, t) {
	ir(e.s, 15, pn, t);
}
var V = class extends T {
	constructor(e) {
		super(e, 500);
	}
	o(e) {
		return S(this, 0, 1001, e);
	}
};
V.B = [
	1,
	6,
	7,
	9,
	10,
	15,
	16,
	17,
	14,
	1002
];
var Zi = [
	-500,
	O,
	Gi,
	4,
	O,
	qi,
	O,
	Ji,
	pi,
	O,
	Yi,
	M,
	pi,
	Hi,
	Ui,
	O,
	Ki,
	M,
	-2,
	Bi,
	hi,
	-1,
	mi,
	979,
	Vi,
	O,
	Di
], Qi = wi(V, Zi);
V.prototype.g = Ti(Zi);
var $i = [
	0,
	O,
	[
		0,
		A,
		-2
	]
], ea = class extends T {
	constructor(e) {
		super(e);
	}
}, ta = [
	0,
	A,
	k,
	N,
	-1
], na = class extends T {
	constructor(e) {
		super(e);
	}
	g() {
		return dr(this, ea, 1);
	}
};
na.B = [1];
var ra = [
	0,
	O,
	ta
], ia = wi(na, ra), aa = [
	0,
	A,
	k
], oa = [
	0,
	A,
	-1,
	$i
], sa = class extends T {
	constructor(e) {
		super(e);
	}
}, ca = [
	0,
	A,
	-3
], la = [
	0,
	k,
	-3
], ua = class extends T {
	constructor(e) {
		super(e);
	}
}, da = [
	0,
	k,
	-1,
	N,
	k
], fa = class extends T {
	constructor(e) {
		super(e);
	}
	h() {
		return x(this, sa, 2);
	}
	g() {
		return dr(this, ua, 5);
	}
};
fa.B = [5];
var pa = [
	0,
	bi,
	ca,
	la,
	oa,
	O,
	da
], ma = class extends T {
	constructor(e) {
		super(e);
	}
};
ma.B = [
	1,
	2,
	3,
	8,
	9
];
var ha = wi(ma, [
	0,
	M,
	fi,
	ci,
	pa,
	N,
	-1,
	li,
	O,
	aa,
	M,
	li
]), ga = class extends T {
	constructor(e) {
		super(e);
	}
}, _a = [
	0,
	k,
	-4
], va = class extends T {
	constructor(e) {
		super(e);
	}
};
va.B = [1];
var ya = wi(va, [
	0,
	O,
	_a
]), ba = class extends T {
	constructor(e) {
		super(e);
	}
}, xa = [
	0,
	k,
	-4
], Sa = class extends T {
	constructor(e) {
		super(e);
	}
};
Sa.B = [1];
var Ca = wi(Sa, [
	0,
	O,
	xa
]), wa = class extends T {
	constructor(e) {
		super(e);
	}
};
wa.B = [3];
var Ta = [
	0,
	A,
	-1,
	ci,
	bi
], Ea = class extends T {
	constructor() {
		super();
	}
};
Ea.prototype.g = Ti([
	0,
	k,
	-4,
	li
]);
var Da = class extends T {
	constructor(e) {
		super(e);
	}
}, Oa = [
	0,
	1,
	A,
	N,
	ra
], ka = class extends T {
	constructor(e) {
		super(e);
	}
};
ka.B = [1];
var Aa = wi(ka, [
	0,
	O,
	Oa,
	li
]), ja = class extends T {
	constructor(e) {
		super(e);
	}
};
ja.B = [1];
var Ma = class extends T {
	constructor(e) {
		super(e);
	}
	qa() {
		return Xn(this) ?? Te();
	}
}, Na = class extends T {
	constructor(e) {
		super(e);
	}
}, Pa = [1, 2], Fa = [
	0,
	Pa,
	P,
	[0, ci],
	P,
	[0, vi],
	A,
	N
], Ia = class extends T {
	constructor(e) {
		super(e);
	}
};
Ia.B = [1];
var La = wi(Ia, [
	0,
	O,
	Fa,
	li
]), Ra = class extends T {
	constructor(e) {
		super(e);
	}
};
Ra.B = [4, 5];
var za = [
	0,
	N,
	A,
	k,
	M,
	-1
], Ba = class extends T {
	constructor(e) {
		super(e);
	}
}, Va = [
	0,
	j,
	-1
], Ha = class extends T {
	constructor(e) {
		super(e);
	}
}, Ua = [
	1,
	2,
	3,
	4,
	5
], Wa = class extends T {
	constructor(e) {
		super(e);
	}
	g() {
		return Xn(this) != null;
	}
	h() {
		return hn(Gn(this, 2)) != null;
	}
}, Ga = [
	0,
	vi,
	N,
	[
		0,
		A,
		li,
		-1
	],
	[
		0,
		di,
		li
	]
], H = class extends T {
	constructor(e) {
		super(e);
	}
	g() {
		return nn(Gn(this, 2)) ?? !1;
	}
}, U = [
	0,
	Ga,
	j,
	[
		0,
		Ua,
		P,
		Ii,
		P,
		Mi,
		P,
		ki,
		P,
		Fi,
		P,
		Ni
	],
	bi
], Ka = class extends T {
	constructor(e) {
		super(e);
	}
}, qa = [
	0,
	U,
	k,
	-1,
	A
], Ja = Ci(502141897, Ka);
F[502141897] = qa;
var Ya = [0, Ga];
F[512499200] = Ya;
var Xa = [0, Ya];
F[515723506] = Xa;
var Za = wi(class extends T {
	constructor(e) {
		super(e);
	}
}, [
	0,
	[
		0,
		bi,
		-1,
		si,
		yi
	],
	Ta
]), Qa = [0, U];
F[508981768] = Qa;
var $a = class extends T {
	constructor(e) {
		super(e);
	}
}, eo = [
	0,
	U,
	k,
	Qa,
	j
], to = class extends T {
	constructor(e) {
		super(e);
	}
}, no = [
	0,
	U,
	qa,
	eo,
	k,
	Xa
];
F[508968149] = eo;
var ro = Ci(508968150, to);
F[508968150] = no;
var io = class extends T {
	constructor(e) {
		super(e);
	}
}, ao = Ci(513916220, io);
F[513916220] = [
	0,
	U,
	no,
	A
];
var oo = class extends T {
	constructor(e) {
		super(e);
	}
	h() {
		return x(this, Ra, 2);
	}
	g() {
		y(this, 2);
	}
}, so = [
	0,
	U,
	za
];
F[478825465] = so;
var co = [0, U];
F[478825422] = co;
var lo = class extends T {
	constructor(e) {
		super(e);
	}
}, uo = [
	0,
	U,
	co,
	so,
	-1
], fo = class extends T {
	constructor(e) {
		super(e);
	}
}, po = [
	0,
	U,
	k,
	A
], mo = class extends T {
	constructor(e) {
		super(e);
	}
}, ho = [
	0,
	U,
	k
], go = class extends T {
	constructor(e) {
		super(e);
	}
}, _o = [
	0,
	U,
	po,
	ho,
	k
], vo = class extends T {
	constructor(e) {
		super(e);
	}
}, yo = [
	0,
	U,
	_o,
	uo
];
F[463370452] = uo, F[464864288] = po, F[474472470] = ho;
var bo = Ci(462713202, go);
F[462713202] = _o;
var xo = Ci(479097054, vo);
F[479097054] = yo;
var So = class extends T {
	constructor(e) {
		super(e);
	}
}, Co = [0, U], wo = class extends T {
	constructor(e) {
		super(e);
	}
}, To = [
	0,
	U,
	k,
	-1,
	A
];
F[514774813] = To;
var Eo = class extends T {
	constructor(e) {
		super(e);
	}
}, Do = [
	0,
	U,
	k,
	j
];
F[518928384] = Do;
var Oo = class extends T {
	constructor() {
		super();
	}
};
Oo.prototype.g = Ti([
	0,
	U,
	ho,
	Co,
	qa,
	eo,
	To,
	Do
]);
var ko = class extends T {
	constructor(e) {
		super(e);
	}
}, Ao = Ci(456383383, ko);
F[456383383] = [
	0,
	U,
	za
];
var jo = class extends T {
	constructor(e) {
		super(e);
	}
}, Mo = Ci(476348187, jo);
F[476348187] = [
	0,
	U,
	Va
];
var No = class extends T {
	constructor(e) {
		super(e);
	}
}, Po = [
	0,
	bi,
	-1
], Fo = class extends T {
	constructor(e) {
		super(e);
	}
};
Fo.B = [3];
var Io = Ci(458105876, class extends T {
	constructor(e) {
		super(e);
	}
	g() {
		var e = this.s;
		let t = _(e);
		var n = 2 & t;
		return e = function(e, t, n) {
			var r = Fo;
			let i = 2 & t, a = !1;
			if (n == null) {
				if (i) return Fn();
				n = [];
			} else if (n.constructor === An) {
				if (!(2 & n.N) || i) return n;
				n = n.Y();
			} else Array.isArray(n) ? a = !!(2 & g(n)) : n = [];
			if (i) {
				if (!n.length) return Fn();
				a || (a = !0, Pt(n));
			} else a && (a = !1, n = tr(n));
			return a || (64 & g(n) ? Nt(n, 32) : 32 & t && Mt(n, 32)), b(e, t, 2, r = new An(n, r, _n, void 0), !1), r;
		}(e, t, qn(e, t, 2)), e == null || !n && Fo && (e.ta = !0), n = e;
	}
});
F[458105876] = [
	0,
	Po,
	Qr,
	[
		!0,
		li,
		[
			0,
			N,
			-1,
			M
		]
	]
];
var Lo = class extends T {
	constructor(e) {
		super(e);
	}
}, Ro = Ci(458105758, Lo);
F[458105758] = [
	0,
	U,
	N,
	Po
];
var zo = class extends T {
	constructor(e) {
		super(e);
	}
};
zo.B = [5, 6];
var Bo = Ci(443442058, zo);
F[443442058] = [
	0,
	U,
	N,
	A,
	k,
	M,
	-1
];
var Vo = class extends T {
	constructor(e) {
		super(e);
	}
}, Ho = Ci(516587230, Vo);
function Uo(e, t) {
	return t = t ? t.clone() : new Ra(), e.displayNamesLocale === void 0 ? e.displayNamesLocale === void 0 && y(t, 1) : y(t, 1, mn(e.displayNamesLocale)), e.maxResults === void 0 ? "maxResults" in e && y(t, 2) : br(t, 2, e.maxResults), e.scoreThreshold === void 0 ? "scoreThreshold" in e && y(t, 3) : w(t, 3, e.scoreThreshold), e.categoryAllowlist === void 0 ? "categoryAllowlist" in e && y(t, 4) : nr(t, 4, e.categoryAllowlist), e.categoryDenylist === void 0 ? "categoryDenylist" in e && y(t, 5) : nr(t, 5, e.categoryDenylist), t;
}
function Wo(e, t = -1, n = "") {
	return {
		categories: e.map(((e) => ({
			index: _r(gr(e, 1), 0) ?? -1,
			score: C(e, 2) ?? 0,
			categoryName: vr(e, 3) ?? "",
			displayName: vr(e, 4) ?? ""
		}))),
		headIndex: t,
		headName: n
	};
}
function Go(e) {
	var t = Zn(e, 3, tn), n = Zn(e, 2, on), r = Zn(e, 1, hn), i = Zn(e, 9, hn);
	let a = {
		categories: [],
		keypoints: []
	};
	for (let e = 0; e < t.length; e++) a.categories.push({
		score: t[e],
		index: n[e] ?? -1,
		categoryName: r[e] ?? "",
		displayName: i[e] ?? ""
	});
	if ((t = x(e, fa, 4)?.h()) && (a.boundingBox = {
		originX: gr(t, 1) ?? 0,
		originY: gr(t, 2) ?? 0,
		width: gr(t, 3) ?? 0,
		height: gr(t, 4) ?? 0,
		angle: 0
	}), x(e, fa, 4)?.g().length) for (let t of x(e, fa, 4).g()) a.keypoints.push({
		x: Yn(t, 1) ?? 0,
		y: Yn(t, 2) ?? 0,
		score: Yn(t, 4) ?? 0,
		label: hn(Gn(t, 3)) ?? ""
	});
	return a;
}
function Ko(e) {
	let t = [];
	for (let n of dr(e, ba, 1)) t.push({
		x: C(n, 1) ?? 0,
		y: C(n, 2) ?? 0,
		z: C(n, 3) ?? 0,
		visibility: C(n, 4) ?? 0
	});
	return t;
}
function qo(e) {
	let t = [];
	for (let n of dr(e, ga, 1)) t.push({
		x: C(n, 1) ?? 0,
		y: C(n, 2) ?? 0,
		z: C(n, 3) ?? 0,
		visibility: C(n, 4) ?? 0
	});
	return t;
}
function Jo(e) {
	return Array.from(e, ((e) => 127 < e ? e - 256 : e));
}
function Yo(e, t) {
	if (e.length !== t.length) throw Error(`Cannot compute cosine similarity between embeddings of different sizes (${e.length} vs. ${t.length}).`);
	let n = 0, r = 0, i = 0;
	for (let a = 0; a < e.length; a++) n += e[a] * t[a], r += e[a] * e[a], i += t[a] * t[a];
	if (0 >= r || 0 >= i) throw Error("Cannot compute cosine similarity on embedding with 0 norm.");
	return n / Math.sqrt(r * i);
}
var Xo;
F[516587230] = [
	0,
	U,
	To,
	Do,
	k
];
var Zo = new Uint8Array([
	0,
	97,
	115,
	109,
	1,
	0,
	0,
	0,
	1,
	5,
	1,
	96,
	0,
	1,
	123,
	3,
	2,
	1,
	0,
	10,
	10,
	1,
	8,
	0,
	65,
	0,
	253,
	15,
	253,
	98,
	11
]);
async function Qo() {
	if (Xo === void 0) try {
		await WebAssembly.instantiate(Zo), Xo = !0;
	} catch {
		Xo = !1;
	}
	return Xo;
}
async function $o(e, t = "") {
	let n = await Qo() ? "wasm_internal" : "wasm_nosimd_internal";
	return {
		wasmLoaderPath: `${t}/${e}_${n}.js`,
		wasmBinaryPath: `${t}/${e}_${n}.wasm`
	};
}
var es = class {};
function ts() {
	var e = navigator;
	return typeof OffscreenCanvas < "u" && (!function(e = navigator) {
		return (e = e.userAgent).includes("Safari") && !e.includes("Chrome");
	}(e) || !!((e = e.userAgent.match(/Version\/([\d]+).*Safari/)) && 1 <= e.length && 17 <= Number(e[1])));
}
async function ns(e) {
	if (typeof importScripts != "function") {
		let t = document.createElement("script");
		return t.src = e.toString(), t.crossOrigin = "anonymous", new Promise(((e, n) => {
			t.addEventListener("load", (() => {
				e();
			}), !1), t.addEventListener("error", ((e) => {
				n(e);
			}), !1), document.body.appendChild(t);
		}));
	}
	importScripts(e.toString());
}
function rs(e) {
	return e.videoWidth === void 0 ? e.naturalWidth === void 0 ? e.displayWidth === void 0 ? [e.width, e.height] : [e.displayWidth, e.displayHeight] : [e.naturalWidth, e.naturalHeight] : [e.videoWidth, e.videoHeight];
}
function W(e, t, n) {
	e.m || console.error("No wasm multistream support detected: ensure dependency inclusion of :gl_graph_runner_internal_multi_input target"), n(t = e.i.stringToNewUTF8(t)), e.i._free(t);
}
function is(e, t, n) {
	if (!e.i.canvas) throw Error("No OpenGL canvas configured.");
	if (n ? e.i._bindTextureToStream(n) : e.i._bindTextureToCanvas(), !(n = e.i.canvas.getContext("webgl2") || e.i.canvas.getContext("webgl"))) throw Error("Failed to obtain WebGL context from the provided canvas. `getContext()` should only be invoked with `webgl` or `webgl2`.");
	e.i.gpuOriginForWebTexturesIsBottomLeft && n.pixelStorei(n.UNPACK_FLIP_Y_WEBGL, !0), n.texImage2D(n.TEXTURE_2D, 0, n.RGBA, n.RGBA, n.UNSIGNED_BYTE, t), e.i.gpuOriginForWebTexturesIsBottomLeft && n.pixelStorei(n.UNPACK_FLIP_Y_WEBGL, !1);
	let [r, i] = rs(t);
	return !e.l || r === e.i.canvas.width && i === e.i.canvas.height || (e.i.canvas.width = r, e.i.canvas.height = i), [r, i];
}
function as(e, t, n) {
	e.m || console.error("No wasm multistream support detected: ensure dependency inclusion of :gl_graph_runner_internal_multi_input target");
	let r = new Uint32Array(t.length);
	for (let n = 0; n < t.length; n++) r[n] = e.i.stringToNewUTF8(t[n]);
	t = e.i._malloc(4 * r.length), e.i.HEAPU32.set(r, t >> 2), n(t);
	for (let t of r) e.i._free(t);
	e.i._free(t);
}
function os(e, t, n) {
	e.i.simpleListeners = e.i.simpleListeners || {}, e.i.simpleListeners[t] = n;
}
function ss(e, t, n) {
	let r = [];
	e.i.simpleListeners = e.i.simpleListeners || {}, e.i.simpleListeners[t] = (e, t, i) => {
		t ? (n(r, i), r = []) : r.push(e);
	};
}
es.forVisionTasks = function(e) {
	return $o("vision", e);
}, es.forTextTasks = function(e) {
	return $o("text", e);
}, es.forGenAiExperimentalTasks = function(e) {
	return $o("genai_experimental", e);
}, es.forGenAiTasks = function(e) {
	return $o("genai", e);
}, es.forAudioTasks = function(e) {
	return $o("audio", e);
}, es.isSimdSupported = function() {
	return Qo();
};
async function cs(e, t, n, r) {
	return e = await (async (e, t, n, r, i) => {
		if (t && await ns(t), !self.ModuleFactory || n && (await ns(n), !self.ModuleFactory)) throw Error("ModuleFactory not set.");
		return self.Module && i && ((t = self.Module).locateFile = i.locateFile, i.mainScriptUrlOrBlob && (t.mainScriptUrlOrBlob = i.mainScriptUrlOrBlob)), i = await self.ModuleFactory(self.Module || i), self.ModuleFactory = self.Module = void 0, new e(i, r);
	})(e, n.wasmLoaderPath, n.assetLoaderPath, t, { locateFile: (e) => e.endsWith(".wasm") ? n.wasmBinaryPath.toString() : n.assetBinaryPath && e.endsWith(".data") ? n.assetBinaryPath.toString() : e }), await e.o(r), e;
}
function ls(e, t) {
	let n = x(e.baseOptions, Wa, 1) || new Wa();
	typeof t == "string" ? (y(n, 2, mn(t)), y(n, 1)) : t instanceof Uint8Array && (y(n, 1, Ut(t, !1, !1)), y(n, 2)), S(e.baseOptions, 0, 1, n);
}
function us(e) {
	try {
		let t = e.K.length;
		if (t === 1) throw Error(e.K[0].message);
		if (1 < t) throw Error("Encountered multiple errors: " + e.K.map(((e) => e.message)).join(", "));
	} finally {
		e.K = [];
	}
}
function G(e, t) {
	e.J = Math.max(e.J, t);
}
function ds(e, t) {
	e.C = new R(), Wi(e.C, "PassThroughCalculator"), I(e.C, "free_memory"), L(e.C, "free_memory_unused_out"), z(t, "free_memory"), Xi(t, e.C);
}
function fs(e, t) {
	I(e.C, t), L(e.C, t + "_unused_out");
}
function ps(e) {
	e.g.addBoolToStream(!0, "free_memory", e.J);
}
var ms = class {
	constructor(e) {
		this.g = e, this.K = [], this.J = 0, this.g.setAutoRenderToScreen(!1);
	}
	l(e, t = !0) {
		if (t) {
			let t = e.baseOptions || {};
			if (e.baseOptions?.modelAssetBuffer && e.baseOptions?.modelAssetPath) throw Error("Cannot set both baseOptions.modelAssetPath and baseOptions.modelAssetBuffer");
			if (!(x(this.baseOptions, Wa, 1)?.g() || x(this.baseOptions, Wa, 1)?.h() || e.baseOptions?.modelAssetBuffer || e.baseOptions?.modelAssetPath)) throw Error("Either baseOptions.modelAssetPath or baseOptions.modelAssetBuffer must be set");
			if (function(e, t) {
				let n = x(e.baseOptions, Ha, 3);
				if (!n) {
					var r = n = new Ha(), i = new Pi();
					fr(r, 4, Ua, i);
				}
				"delegate" in t && (t.delegate === "GPU" ? (t = n, r = new ji(), fr(t, 2, Ua, r)) : (t = n, r = new Pi(), fr(t, 4, Ua, r))), S(e.baseOptions, 0, 3, n);
			}(this, t), t.modelAssetPath) return fetch(t.modelAssetPath.toString()).then(((e) => {
				if (e.ok) return e.arrayBuffer();
				throw Error(`Failed to fetch model: ${t.modelAssetPath} (${e.status})`);
			})).then(((e) => {
				try {
					this.g.i.FS_unlink("/model.dat");
				} catch {}
				this.g.i.FS_createDataFile("/", "model.dat", new Uint8Array(e), !0, !1, !1), ls(this, "/model.dat"), this.m(), this.L();
			}));
			if (t.modelAssetBuffer instanceof Uint8Array) ls(this, t.modelAssetBuffer);
			else if (t.modelAssetBuffer) return async function(e) {
				let t = [];
				for (var n = 0;;) {
					let { done: r, value: i } = await e.read();
					if (r) break;
					t.push(i), n += i.length;
				}
				if (t.length === 0) return new Uint8Array();
				if (t.length === 1) return t[0];
				e = new Uint8Array(n), n = 0;
				for (let r of t) e.set(r, n), n += r.length;
				return e;
			}(t.modelAssetBuffer).then(((e) => {
				ls(this, e), this.m(), this.L();
			}));
		}
		return this.m(), this.L(), Promise.resolve();
	}
	L() {}
	fa() {
		let e;
		if (this.g.fa(((t) => {
			e = Qi(t);
		})), !e) throw Error("Failed to retrieve CalculatorGraphConfig");
		return e;
	}
	setGraph(e, t) {
		this.g.attachErrorListener(((e, t) => {
			this.K.push(Error(t));
		})), this.g.Ma(), this.g.setGraph(e, t), this.C = void 0, us(this);
	}
	finishProcessing() {
		this.g.finishProcessing(), us(this);
	}
	close() {
		this.C = void 0, this.g.closeGraph();
	}
};
function K(e, t) {
	if (!e) throw Error(`Unable to obtain required WebGL resource: ${t}`);
	return e;
}
ms.prototype.close = ms.prototype.close, function(e, n) {
	e = e.split(".");
	var r, i = t;
	for ((e[0] in i) || i.execScript === void 0 || i.execScript("var " + e[0]); e.length && (r = e.shift());) e.length || n === void 0 ? i = i[r] && i[r] !== Object.prototype[r] ? i[r] : i[r] = {} : i[r] = n;
}("TaskRunner", ms);
var hs = class {
	constructor(e, t, n, r) {
		this.g = e, this.h = t, this.m = n, this.l = r;
	}
	bind() {
		this.g.bindVertexArray(this.h);
	}
	close() {
		this.g.deleteVertexArray(this.h), this.g.deleteBuffer(this.m), this.g.deleteBuffer(this.l);
	}
};
function gs(e, t, n) {
	let r = e.g;
	if (n = K(r.createShader(n), "Failed to create WebGL shader"), r.shaderSource(n, t), r.compileShader(n), !r.getShaderParameter(n, r.COMPILE_STATUS)) throw Error(`Could not compile WebGL shader: ${r.getShaderInfoLog(n)}`);
	return r.attachShader(e.h, n), n;
}
function _s(e, t) {
	let n = e.g, r = K(n.createVertexArray(), "Failed to create vertex array");
	n.bindVertexArray(r);
	let i = K(n.createBuffer(), "Failed to create buffer");
	n.bindBuffer(n.ARRAY_BUFFER, i), n.enableVertexAttribArray(e.K), n.vertexAttribPointer(e.K, 2, n.FLOAT, !1, 0, 0), n.bufferData(n.ARRAY_BUFFER, new Float32Array([
		-1,
		-1,
		-1,
		1,
		1,
		1,
		1,
		-1
	]), n.STATIC_DRAW);
	let a = K(n.createBuffer(), "Failed to create buffer");
	return n.bindBuffer(n.ARRAY_BUFFER, a), n.enableVertexAttribArray(e.J), n.vertexAttribPointer(e.J, 2, n.FLOAT, !1, 0, 0), n.bufferData(n.ARRAY_BUFFER, new Float32Array(t ? [
		0,
		1,
		0,
		0,
		1,
		0,
		1,
		1
	] : [
		0,
		0,
		0,
		1,
		1,
		1,
		1,
		0
	]), n.STATIC_DRAW), n.bindBuffer(n.ARRAY_BUFFER, null), n.bindVertexArray(null), new hs(n, r, i, a);
}
function vs(e, t) {
	if (e.g) {
		if (t !== e.g) throw Error("Cannot change GL context once initialized");
	} else e.g = t;
}
function ys(e, t, n, r) {
	return vs(e, t), e.h || (e.m(), e.D()), n ? (e.v ||= _s(e, !0), n = e.v) : (e.A ||= _s(e, !1), n = e.A), t.useProgram(e.h), n.bind(), e.l(), e = r(), n.g.bindVertexArray(null), e;
}
function bs(e, t, n) {
	return vs(e, t), e = K(t.createTexture(), "Failed to create texture"), t.bindTexture(t.TEXTURE_2D, e), t.texParameteri(t.TEXTURE_2D, t.TEXTURE_WRAP_S, t.CLAMP_TO_EDGE), t.texParameteri(t.TEXTURE_2D, t.TEXTURE_WRAP_T, t.CLAMP_TO_EDGE), t.texParameteri(t.TEXTURE_2D, t.TEXTURE_MIN_FILTER, n ?? t.LINEAR), t.texParameteri(t.TEXTURE_2D, t.TEXTURE_MAG_FILTER, n ?? t.LINEAR), t.bindTexture(t.TEXTURE_2D, null), e;
}
function xs(e, t, n) {
	vs(e, t), e.u ||= K(t.createFramebuffer(), "Failed to create framebuffe."), t.bindFramebuffer(t.FRAMEBUFFER, e.u), t.framebufferTexture2D(t.FRAMEBUFFER, t.COLOR_ATTACHMENT0, t.TEXTURE_2D, n, 0);
}
function Ss(e) {
	e.g?.bindFramebuffer(e.g.FRAMEBUFFER, null);
}
var Cs = class {
	H() {
		return "\n  precision mediump float;\n  varying vec2 vTex;\n  uniform sampler2D inputTexture;\n  void main() {\n    gl_FragColor = texture2D(inputTexture, vTex);\n  }\n ";
	}
	m() {
		let e = this.g;
		if (this.h = K(e.createProgram(), "Failed to create WebGL program"), this.ba = gs(this, "\n  attribute vec2 aVertex;\n  attribute vec2 aTex;\n  varying vec2 vTex;\n  void main(void) {\n    gl_Position = vec4(aVertex, 0.0, 1.0);\n    vTex = aTex;\n  }", e.VERTEX_SHADER), this.aa = gs(this, this.H(), e.FRAGMENT_SHADER), e.linkProgram(this.h), !e.getProgramParameter(this.h, e.LINK_STATUS)) throw Error(`Error during program linking: ${e.getProgramInfoLog(this.h)}`);
		this.K = e.getAttribLocation(this.h, "aVertex"), this.J = e.getAttribLocation(this.h, "aTex");
	}
	D() {}
	l() {}
	close() {
		if (this.h) {
			let e = this.g;
			e.deleteProgram(this.h), e.deleteShader(this.ba), e.deleteShader(this.aa);
		}
		this.u && this.g.deleteFramebuffer(this.u), this.A && this.A.close(), this.v && this.v.close();
	}
}, ws = class extends Cs {
	H() {
		return "\n  precision mediump float;\n  uniform sampler2D backgroundTexture;\n  uniform sampler2D maskTexture;\n  uniform sampler2D colorMappingTexture;\n  varying vec2 vTex;\n  void main() {\n    vec4 backgroundColor = texture2D(backgroundTexture, vTex);\n    float category = texture2D(maskTexture, vTex).r;\n    vec4 categoryColor = texture2D(colorMappingTexture, vec2(category, 0.0));\n    gl_FragColor = mix(backgroundColor, categoryColor, categoryColor.a);\n  }\n ";
	}
	D() {
		let e = this.g;
		e.activeTexture(e.TEXTURE1), this.C = bs(this, e, e.LINEAR), e.activeTexture(e.TEXTURE2), this.j = bs(this, e, e.NEAREST);
	}
	m() {
		super.m();
		let e = this.g;
		this.M = K(e.getUniformLocation(this.h, "backgroundTexture"), "Uniform location"), this.V = K(e.getUniformLocation(this.h, "colorMappingTexture"), "Uniform location"), this.L = K(e.getUniformLocation(this.h, "maskTexture"), "Uniform location");
	}
	l() {
		super.l();
		let e = this.g;
		e.uniform1i(this.L, 0), e.uniform1i(this.M, 1), e.uniform1i(this.V, 2);
	}
	close() {
		this.C && this.g.deleteTexture(this.C), this.j && this.g.deleteTexture(this.j), super.close();
	}
}, Ts = class extends Cs {
	H() {
		return "\n  precision mediump float;\n  uniform sampler2D maskTexture;\n  uniform sampler2D defaultTexture;\n  uniform sampler2D overlayTexture;\n  varying vec2 vTex;\n  void main() {\n    float confidence = texture2D(maskTexture, vTex).r;\n    vec4 defaultColor = texture2D(defaultTexture, vTex);\n    vec4 overlayColor = texture2D(overlayTexture, vTex);\n    // Apply the alpha from the overlay and merge in the default color\n    overlayColor = mix(defaultColor, overlayColor, overlayColor.a);\n    gl_FragColor = mix(defaultColor, overlayColor, confidence);\n  }\n ";
	}
	D() {
		let e = this.g;
		e.activeTexture(e.TEXTURE1), this.j = bs(this, e), e.activeTexture(e.TEXTURE2), this.C = bs(this, e);
	}
	m() {
		super.m();
		let e = this.g;
		this.L = K(e.getUniformLocation(this.h, "defaultTexture"), "Uniform location"), this.M = K(e.getUniformLocation(this.h, "overlayTexture"), "Uniform location"), this.I = K(e.getUniformLocation(this.h, "maskTexture"), "Uniform location");
	}
	l() {
		super.l();
		let e = this.g;
		e.uniform1i(this.I, 0), e.uniform1i(this.L, 1), e.uniform1i(this.M, 2);
	}
	close() {
		this.j && this.g.deleteTexture(this.j), this.C && this.g.deleteTexture(this.C), super.close();
	}
};
function Es(e, t) {
	switch (t) {
		case 0: return e.g.find(((e) => e instanceof Uint8Array));
		case 1: return e.g.find(((e) => e instanceof Float32Array));
		case 2: return e.g.find(((e) => typeof WebGLTexture < "u" && e instanceof WebGLTexture));
		default: throw Error(`Type is not supported: ${t}`);
	}
}
function Ds(e) {
	var t = Es(e, 1);
	if (!t) {
		if (t = Es(e, 0)) t = new Float32Array(t).map(((e) => e / 255));
		else {
			t = new Float32Array(e.width * e.height);
			let r = ks(e);
			var n = js(e);
			if (xs(n, r, Os(e)), "iPad Simulator;iPhone Simulator;iPod Simulator;iPad;iPhone;iPod".split(";").includes(navigator.platform) || navigator.userAgent.includes("Mac") && "ontouchend" in self.document) {
				n = new Float32Array(e.width * e.height * 4), r.readPixels(0, 0, e.width, e.height, r.RGBA, r.FLOAT, n);
				for (let e = 0, r = 0; e < t.length; ++e, r += 4) t[e] = n[r];
			} else r.readPixels(0, 0, e.width, e.height, r.RED, r.FLOAT, t);
		}
		e.g.push(t);
	}
	return t;
}
function Os(e) {
	let t = Es(e, 2);
	if (!t) {
		let n = ks(e);
		t = Ms(e);
		let r = Ds(e), i = As(e);
		n.texImage2D(n.TEXTURE_2D, 0, i, e.width, e.height, 0, n.RED, n.FLOAT, r), Ns(e);
	}
	return t;
}
function ks(e) {
	if (!e.canvas) throw Error("Conversion to different image formats require that a canvas is passed when initializing the image.");
	return e.h ||= K(e.canvas.getContext("webgl2"), "You cannot use a canvas that is already bound to a different type of rendering context."), e.h;
}
function As(e) {
	if (e = ks(e), !Ps) if (e.getExtension("EXT_color_buffer_float") && e.getExtension("OES_texture_float_linear") && e.getExtension("EXT_float_blend")) Ps = e.R32F;
	else {
		if (!e.getExtension("EXT_color_buffer_half_float")) throw Error("GPU does not fully support 4-channel float32 or float16 formats");
		Ps = e.R16F;
	}
	return Ps;
}
function js(e) {
	return e.l ||= new Cs(), e.l;
}
function Ms(e) {
	let t = ks(e);
	t.viewport(0, 0, e.width, e.height), t.activeTexture(t.TEXTURE0);
	let n = Es(e, 2);
	return n || (n = bs(js(e), t, e.m ? t.LINEAR : t.NEAREST), e.g.push(n), e.j = !0), t.bindTexture(t.TEXTURE_2D, n), n;
}
function Ns(e) {
	e.h.bindTexture(e.h.TEXTURE_2D, null);
}
var Ps, q = class {
	constructor(e, t, n, r, i, a, o) {
		this.g = e, this.m = t, this.j = n, this.canvas = r, this.l = i, this.width = a, this.height = o, this.j && --Fs === 0 && console.error("You seem to be creating MPMask instances without invoking .close(). This leaks resources.");
	}
	Ha() {
		return !!Es(this, 0);
	}
	la() {
		return !!Es(this, 1);
	}
	R() {
		return !!Es(this, 2);
	}
	ka() {
		return (t = Es(e = this, 0)) || (t = Ds(e), t = new Uint8Array(t.map(((e) => 255 * e))), e.g.push(t)), t;
		var e, t;
	}
	ja() {
		return Ds(this);
	}
	O() {
		return Os(this);
	}
	clone() {
		let e = [];
		for (let t of this.g) {
			let n;
			if (t instanceof Uint8Array) n = new Uint8Array(t);
			else if (t instanceof Float32Array) n = new Float32Array(t);
			else {
				if (!(t instanceof WebGLTexture)) throw Error(`Type is not supported: ${t}`);
				{
					let e = ks(this), t = js(this);
					e.activeTexture(e.TEXTURE1), n = bs(t, e, this.m ? e.LINEAR : e.NEAREST), e.bindTexture(e.TEXTURE_2D, n);
					let r = As(this);
					e.texImage2D(e.TEXTURE_2D, 0, r, this.width, this.height, 0, e.RED, e.FLOAT, null), e.bindTexture(e.TEXTURE_2D, null), xs(t, e, n), ys(t, e, !1, (() => {
						Ms(this), e.clearColor(0, 0, 0, 0), e.clear(e.COLOR_BUFFER_BIT), e.drawArrays(e.TRIANGLE_FAN, 0, 4), Ns(this);
					})), Ss(t), Ns(this);
				}
			}
			e.push(n);
		}
		return new q(e, this.m, this.R(), this.canvas, this.l, this.width, this.height);
	}
	close() {
		this.j && ks(this).deleteTexture(Es(this, 2)), Fs = -1;
	}
};
q.prototype.close = q.prototype.close, q.prototype.clone = q.prototype.clone, q.prototype.getAsWebGLTexture = q.prototype.O, q.prototype.getAsFloat32Array = q.prototype.ja, q.prototype.getAsUint8Array = q.prototype.ka, q.prototype.hasWebGLTexture = q.prototype.R, q.prototype.hasFloat32Array = q.prototype.la, q.prototype.hasUint8Array = q.prototype.Ha;
var Fs = 250, Is = {
	color: "white",
	lineWidth: 4,
	radius: 6
};
function Ls(e) {
	return {
		...Is,
		fillColor: (e ||= {}).color,
		...e
	};
}
function Rs(e, t) {
	return e instanceof Function ? e(t) : e;
}
function zs(e, t, n) {
	return Math.max(Math.min(t, n), Math.min(Math.max(t, n), e));
}
function Bs(e) {
	if (!e.l) throw Error("CPU rendering requested but CanvasRenderingContext2D not provided.");
	return e.l;
}
function Vs(e) {
	if (!e.j) throw Error("GPU rendering requested but WebGL2RenderingContext not provided.");
	return e.j;
}
function Hs(e, t, n) {
	if (t.R()) n(t.O());
	else {
		let r = t.la() ? t.ja() : t.ka();
		e.m = e.m ?? new Cs();
		let i = Vs(e);
		n((e = new q([r], t.m, !1, i.canvas, e.m, t.width, t.height)).O()), e.close();
	}
}
function Us(e, t, n, r) {
	let i = function(e) {
		return e.g ||= new ws(), e.g;
	}(e), a = Vs(e), o = Array.isArray(n) ? new ImageData(new Uint8ClampedArray(n), 1, 1) : n;
	ys(i, a, !0, (() => {
		(function(e, t, n, r) {
			let i = e.g;
			if (i.activeTexture(i.TEXTURE0), i.bindTexture(i.TEXTURE_2D, t), i.activeTexture(i.TEXTURE1), i.bindTexture(i.TEXTURE_2D, e.C), i.texImage2D(i.TEXTURE_2D, 0, i.RGBA, i.RGBA, i.UNSIGNED_BYTE, n), e.I && function(e, t) {
				if (e !== t) return !1;
				e = e.entries(), t = t.entries();
				for (let [r, i] of e) {
					e = r;
					let a = i;
					var n = t.next();
					if (n.done) return !1;
					let [o, s] = n.value;
					if (n = s, e !== o || a[0] !== n[0] || a[1] !== n[1] || a[2] !== n[2] || a[3] !== n[3]) return !1;
				}
				return !!t.next().done;
			}(e.I, r)) i.activeTexture(i.TEXTURE2), i.bindTexture(i.TEXTURE_2D, e.j);
			else {
				e.I = r;
				let t = Array(1024).fill(0);
				r.forEach(((e, n) => {
					if (e.length !== 4) throw Error(`Color at index ${n} is not a four-channel value.`);
					t[4 * n] = e[0], t[4 * n + 1] = e[1], t[4 * n + 2] = e[2], t[4 * n + 3] = e[3];
				})), i.activeTexture(i.TEXTURE2), i.bindTexture(i.TEXTURE_2D, e.j), i.texImage2D(i.TEXTURE_2D, 0, i.RGBA, 256, 1, 0, i.RGBA, i.UNSIGNED_BYTE, new Uint8Array(t));
			}
		})(i, t, o, r), a.clearColor(0, 0, 0, 0), a.clear(a.COLOR_BUFFER_BIT), a.drawArrays(a.TRIANGLE_FAN, 0, 4);
		let e = i.g;
		e.activeTexture(e.TEXTURE0), e.bindTexture(e.TEXTURE_2D, null), e.activeTexture(e.TEXTURE1), e.bindTexture(e.TEXTURE_2D, null), e.activeTexture(e.TEXTURE2), e.bindTexture(e.TEXTURE_2D, null);
	}));
}
function Ws(e, t, n, r) {
	let i = Vs(e), a = function(e) {
		return e.h ||= new Ts(), e.h;
	}(e), o = Array.isArray(n) ? new ImageData(new Uint8ClampedArray(n), 1, 1) : n, s = Array.isArray(r) ? new ImageData(new Uint8ClampedArray(r), 1, 1) : r;
	ys(a, i, !0, (() => {
		var e = a.g;
		e.activeTexture(e.TEXTURE0), e.bindTexture(e.TEXTURE_2D, t), e.activeTexture(e.TEXTURE1), e.bindTexture(e.TEXTURE_2D, a.j), e.texImage2D(e.TEXTURE_2D, 0, e.RGBA, e.RGBA, e.UNSIGNED_BYTE, o), e.activeTexture(e.TEXTURE2), e.bindTexture(e.TEXTURE_2D, a.C), e.texImage2D(e.TEXTURE_2D, 0, e.RGBA, e.RGBA, e.UNSIGNED_BYTE, s), i.clearColor(0, 0, 0, 0), i.clear(i.COLOR_BUFFER_BIT), i.drawArrays(i.TRIANGLE_FAN, 0, 4), i.bindTexture(i.TEXTURE_2D, null), (e = a.g).activeTexture(e.TEXTURE0), e.bindTexture(e.TEXTURE_2D, null), e.activeTexture(e.TEXTURE1), e.bindTexture(e.TEXTURE_2D, null), e.activeTexture(e.TEXTURE2), e.bindTexture(e.TEXTURE_2D, null);
	}));
}
var J = class {
	constructor(e, t) {
		e instanceof CanvasRenderingContext2D || e instanceof OffscreenCanvasRenderingContext2D ? (this.l = e, this.j = t) : this.j = e;
	}
	Aa(e, t) {
		if (e) {
			var n = Bs(this);
			t = Ls(t), n.save();
			var r = n.canvas, i = 0;
			for (let a of e) n.fillStyle = Rs(t.fillColor, {
				index: i,
				from: a
			}), n.strokeStyle = Rs(t.color, {
				index: i,
				from: a
			}), n.lineWidth = Rs(t.lineWidth, {
				index: i,
				from: a
			}), (e = new Path2D()).arc(a.x * r.width, a.y * r.height, Rs(t.radius, {
				index: i,
				from: a
			}), 0, 2 * Math.PI), n.fill(e), n.stroke(e), ++i;
			n.restore();
		}
	}
	za(e, t, n) {
		if (e && t) {
			var r = Bs(this);
			n = Ls(n), r.save();
			var i = r.canvas, a = 0;
			for (let o of t) {
				r.beginPath(), t = e[o.start];
				let s = e[o.end];
				t && s && (r.strokeStyle = Rs(n.color, {
					index: a,
					from: t,
					to: s
				}), r.lineWidth = Rs(n.lineWidth, {
					index: a,
					from: t,
					to: s
				}), r.moveTo(t.x * i.width, t.y * i.height), r.lineTo(s.x * i.width, s.y * i.height)), ++a, r.stroke();
			}
			r.restore();
		}
	}
	wa(e, t) {
		let n = Bs(this);
		t = Ls(t), n.save(), n.beginPath(), n.lineWidth = Rs(t.lineWidth, {}), n.strokeStyle = Rs(t.color, {}), n.fillStyle = Rs(t.fillColor, {}), n.moveTo(e.originX, e.originY), n.lineTo(e.originX + e.width, e.originY), n.lineTo(e.originX + e.width, e.originY + e.height), n.lineTo(e.originX, e.originY + e.height), n.lineTo(e.originX, e.originY), n.stroke(), n.fill(), n.restore();
	}
	xa(e, t, n = [
		0,
		0,
		0,
		255
	]) {
		this.l ? function(e, t, n, r) {
			let i = Vs(e);
			Hs(e, t, ((t) => {
				Us(e, t, n, r), (t = Bs(e)).drawImage(i.canvas, 0, 0, t.canvas.width, t.canvas.height);
			}));
		}(this, e, n, t) : Us(this, e.O(), n, t);
	}
	ya(e, t, n) {
		this.l ? function(e, t, n, r) {
			let i = Vs(e);
			Hs(e, t, ((t) => {
				Ws(e, t, n, r), (t = Bs(e)).drawImage(i.canvas, 0, 0, t.canvas.width, t.canvas.height);
			}));
		}(this, e, t, n) : Ws(this, e.O(), t, n);
	}
	close() {
		this.g?.close(), this.g = void 0, this.h?.close(), this.h = void 0, this.m?.close(), this.m = void 0;
	}
};
function Gs(e, t) {
	switch (t) {
		case 0: return e.g.find(((e) => e instanceof ImageData));
		case 1: return e.g.find(((e) => typeof ImageBitmap < "u" && e instanceof ImageBitmap));
		case 2: return e.g.find(((e) => typeof WebGLTexture < "u" && e instanceof WebGLTexture));
		default: throw Error(`Type is not supported: ${t}`);
	}
}
function Ks(e) {
	var t = Gs(e, 0);
	if (!t) {
		t = Js(e);
		let n = Ys(e), r = new Uint8Array(e.width * e.height * 4);
		xs(n, t, qs(e)), t.readPixels(0, 0, e.width, e.height, t.RGBA, t.UNSIGNED_BYTE, r), Ss(n), t = new ImageData(new Uint8ClampedArray(r.buffer), e.width, e.height), e.g.push(t);
	}
	return t;
}
function qs(e) {
	let t = Gs(e, 2);
	if (!t) {
		let n = Js(e);
		t = Xs(e);
		let r = Gs(e, 1) || Ks(e);
		n.texImage2D(n.TEXTURE_2D, 0, n.RGBA, n.RGBA, n.UNSIGNED_BYTE, r), Zs(e);
	}
	return t;
}
function Js(e) {
	if (!e.canvas) throw Error("Conversion to different image formats require that a canvas is passed when iniitializing the image.");
	return e.h ||= K(e.canvas.getContext("webgl2"), "You cannot use a canvas that is already bound to a different type of rendering context."), e.h;
}
function Ys(e) {
	return e.l ||= new Cs(), e.l;
}
function Xs(e) {
	let t = Js(e);
	t.viewport(0, 0, e.width, e.height), t.activeTexture(t.TEXTURE0);
	let n = Gs(e, 2);
	return n || (n = bs(Ys(e), t), e.g.push(n), e.m = !0), t.bindTexture(t.TEXTURE_2D, n), n;
}
function Zs(e) {
	e.h.bindTexture(e.h.TEXTURE_2D, null);
}
function Qs(e) {
	let t = Js(e);
	return ys(Ys(e), t, !0, (() => function(e, t) {
		let n = e.canvas;
		if (n.width === e.width && n.height === e.height) return t();
		let r = n.width, i = n.height;
		return n.width = e.width, n.height = e.height, e = t(), n.width = r, n.height = i, e;
	}(e, (() => {
		if (t.bindFramebuffer(t.FRAMEBUFFER, null), t.clearColor(0, 0, 0, 0), t.clear(t.COLOR_BUFFER_BIT), t.drawArrays(t.TRIANGLE_FAN, 0, 4), !(e.canvas instanceof OffscreenCanvas)) throw Error("Conversion to ImageBitmap requires that the MediaPipe Tasks is initialized with an OffscreenCanvas");
		return e.canvas.transferToImageBitmap();
	}))));
}
J.prototype.close = J.prototype.close, J.prototype.drawConfidenceMask = J.prototype.ya, J.prototype.drawCategoryMask = J.prototype.xa, J.prototype.drawBoundingBox = J.prototype.wa, J.prototype.drawConnectors = J.prototype.za, J.prototype.drawLandmarks = J.prototype.Aa, J.lerp = function(e, t, n, r, i) {
	return zs(r * (1 - (e - t) / (n - t)) + i * (1 - (n - e) / (n - t)), r, i);
}, J.clamp = zs;
var Y = class {
	constructor(e, t, n, r, i, a, o) {
		this.g = e, this.j = t, this.m = n, this.canvas = r, this.l = i, this.width = a, this.height = o, (this.j || this.m) && --$s === 0 && console.error("You seem to be creating MPImage instances without invoking .close(). This leaks resources.");
	}
	Ga() {
		return !!Gs(this, 0);
	}
	ma() {
		return !!Gs(this, 1);
	}
	R() {
		return !!Gs(this, 2);
	}
	Ea() {
		return Ks(this);
	}
	Da() {
		var e = Gs(this, 1);
		return e || (qs(this), Xs(this), e = Qs(this), Zs(this), this.g.push(e), this.j = !0), e;
	}
	O() {
		return qs(this);
	}
	clone() {
		let e = [];
		for (let t of this.g) {
			let n;
			if (t instanceof ImageData) n = new ImageData(t.data, this.width, this.height);
			else if (t instanceof WebGLTexture) {
				let e = Js(this), t = Ys(this);
				e.activeTexture(e.TEXTURE1), n = bs(t, e), e.bindTexture(e.TEXTURE_2D, n), e.texImage2D(e.TEXTURE_2D, 0, e.RGBA, this.width, this.height, 0, e.RGBA, e.UNSIGNED_BYTE, null), e.bindTexture(e.TEXTURE_2D, null), xs(t, e, n), ys(t, e, !1, (() => {
					Xs(this), e.clearColor(0, 0, 0, 0), e.clear(e.COLOR_BUFFER_BIT), e.drawArrays(e.TRIANGLE_FAN, 0, 4), Zs(this);
				})), Ss(t), Zs(this);
			} else {
				if (!(t instanceof ImageBitmap)) throw Error(`Type is not supported: ${t}`);
				qs(this), Xs(this), n = Qs(this), Zs(this);
			}
			e.push(n);
		}
		return new Y(e, this.ma(), this.R(), this.canvas, this.l, this.width, this.height);
	}
	close() {
		this.j && Gs(this, 1).close(), this.m && Js(this).deleteTexture(Gs(this, 2)), $s = -1;
	}
};
Y.prototype.close = Y.prototype.close, Y.prototype.clone = Y.prototype.clone, Y.prototype.getAsWebGLTexture = Y.prototype.O, Y.prototype.getAsImageBitmap = Y.prototype.Da, Y.prototype.getAsImageData = Y.prototype.Ea, Y.prototype.hasWebGLTexture = Y.prototype.R, Y.prototype.hasImageBitmap = Y.prototype.ma, Y.prototype.hasImageData = Y.prototype.Ga;
var $s = 250;
function ec(...e) {
	return e.map((([e, t]) => ({
		start: e,
		end: t
	})));
}
var tc = function(e) {
	return class extends e {
		Ma() {
			this.i._registerModelResourcesGraphService();
		}
	};
}((nc = class {
	constructor(e, t) {
		this.l = !0, this.i = e, this.g = null, this.h = 0, this.m = typeof this.i._addIntToInputStream == "function", t === void 0 ? ts() ? this.i.canvas = new OffscreenCanvas(1, 1) : (console.warn("OffscreenCanvas not supported and GraphRunner constructor glCanvas parameter is undefined. Creating backup canvas."), this.i.canvas = document.createElement("canvas")) : this.i.canvas = t;
	}
	async initializeGraph(e) {
		let t = await (await fetch(e)).arrayBuffer();
		e = !(e.endsWith(".pbtxt") || e.endsWith(".textproto")), this.setGraph(new Uint8Array(t), e);
	}
	setGraphFromString(e) {
		this.setGraph(new TextEncoder().encode(e), !1);
	}
	setGraph(e, t) {
		let n = e.length, r = this.i._malloc(n);
		this.i.HEAPU8.set(e, r), t ? this.i._changeBinaryGraph(n, r) : this.i._changeTextGraph(n, r), this.i._free(r);
	}
	configureAudio(e, t, n, r, i) {
		this.i._configureAudio || console.warn("Attempting to use configureAudio without support for input audio. Is build dep \":gl_graph_runner_audio\" missing?"), W(this, r || "input_audio", ((r) => {
			W(this, i ||= "audio_header", ((i) => {
				this.i._configureAudio(r, i, e, t, n);
			}));
		}));
	}
	setAutoResizeCanvas(e) {
		this.l = e;
	}
	setAutoRenderToScreen(e) {
		this.i._setAutoRenderToScreen(e);
	}
	setGpuBufferVerticalFlip(e) {
		this.i.gpuOriginForWebTexturesIsBottomLeft = e;
	}
	fa(e) {
		os(this, "__graph_config__", ((t) => {
			e(t);
		})), W(this, "__graph_config__", ((e) => {
			this.i._getGraphConfig(e, void 0);
		})), delete this.i.simpleListeners.__graph_config__;
	}
	attachErrorListener(e) {
		this.i.errorListener = e;
	}
	attachEmptyPacketListener(e, t) {
		this.i.emptyPacketListeners = this.i.emptyPacketListeners || {}, this.i.emptyPacketListeners[e] = t;
	}
	addAudioToStream(e, t, n) {
		this.addAudioToStreamWithShape(e, 0, 0, t, n);
	}
	addAudioToStreamWithShape(e, t, n, r, i) {
		let a = 4 * e.length;
		this.h !== a && (this.g && this.i._free(this.g), this.g = this.i._malloc(a), this.h = a), this.i.HEAPF32.set(e, this.g / 4), W(this, r, ((e) => {
			this.i._addAudioToInputStream(this.g, t, n, e, i);
		}));
	}
	addGpuBufferToStream(e, t, n) {
		W(this, t, ((t) => {
			let [r, i] = is(this, e, t);
			this.i._addBoundTextureToStream(t, r, i, n);
		}));
	}
	addBoolToStream(e, t, n) {
		W(this, t, ((t) => {
			this.i._addBoolToInputStream(e, t, n);
		}));
	}
	addDoubleToStream(e, t, n) {
		W(this, t, ((t) => {
			this.i._addDoubleToInputStream(e, t, n);
		}));
	}
	addFloatToStream(e, t, n) {
		W(this, t, ((t) => {
			this.i._addFloatToInputStream(e, t, n);
		}));
	}
	addIntToStream(e, t, n) {
		W(this, t, ((t) => {
			this.i._addIntToInputStream(e, t, n);
		}));
	}
	addUintToStream(e, t, n) {
		W(this, t, ((t) => {
			this.i._addUintToInputStream(e, t, n);
		}));
	}
	addStringToStream(e, t, n) {
		W(this, t, ((t) => {
			W(this, e, ((e) => {
				this.i._addStringToInputStream(e, t, n);
			}));
		}));
	}
	addStringRecordToStream(e, t, n) {
		W(this, t, ((t) => {
			as(this, Object.keys(e), ((r) => {
				as(this, Object.values(e), ((i) => {
					this.i._addFlatHashMapToInputStream(r, i, Object.keys(e).length, t, n);
				}));
			}));
		}));
	}
	addProtoToStream(e, t, n, r) {
		W(this, n, ((n) => {
			W(this, t, ((t) => {
				let i = this.i._malloc(e.length);
				this.i.HEAPU8.set(e, i), this.i._addProtoToInputStream(i, e.length, t, n, r), this.i._free(i);
			}));
		}));
	}
	addEmptyPacketToStream(e, t) {
		W(this, e, ((e) => {
			this.i._addEmptyPacketToInputStream(e, t);
		}));
	}
	addBoolVectorToStream(e, t, n) {
		W(this, t, ((t) => {
			let r = this.i._allocateBoolVector(e.length);
			if (!r) throw Error("Unable to allocate new bool vector on heap.");
			for (let t of e) this.i._addBoolVectorEntry(r, t);
			this.i._addBoolVectorToInputStream(r, t, n);
		}));
	}
	addDoubleVectorToStream(e, t, n) {
		W(this, t, ((t) => {
			let r = this.i._allocateDoubleVector(e.length);
			if (!r) throw Error("Unable to allocate new double vector on heap.");
			for (let t of e) this.i._addDoubleVectorEntry(r, t);
			this.i._addDoubleVectorToInputStream(r, t, n);
		}));
	}
	addFloatVectorToStream(e, t, n) {
		W(this, t, ((t) => {
			let r = this.i._allocateFloatVector(e.length);
			if (!r) throw Error("Unable to allocate new float vector on heap.");
			for (let t of e) this.i._addFloatVectorEntry(r, t);
			this.i._addFloatVectorToInputStream(r, t, n);
		}));
	}
	addIntVectorToStream(e, t, n) {
		W(this, t, ((t) => {
			let r = this.i._allocateIntVector(e.length);
			if (!r) throw Error("Unable to allocate new int vector on heap.");
			for (let t of e) this.i._addIntVectorEntry(r, t);
			this.i._addIntVectorToInputStream(r, t, n);
		}));
	}
	addUintVectorToStream(e, t, n) {
		W(this, t, ((t) => {
			let r = this.i._allocateUintVector(e.length);
			if (!r) throw Error("Unable to allocate new unsigned int vector on heap.");
			for (let t of e) this.i._addUintVectorEntry(r, t);
			this.i._addUintVectorToInputStream(r, t, n);
		}));
	}
	addStringVectorToStream(e, t, n) {
		W(this, t, ((t) => {
			let r = this.i._allocateStringVector(e.length);
			if (!r) throw Error("Unable to allocate new string vector on heap.");
			for (let t of e) W(this, t, ((e) => {
				this.i._addStringVectorEntry(r, e);
			}));
			this.i._addStringVectorToInputStream(r, t, n);
		}));
	}
	addBoolToInputSidePacket(e, t) {
		W(this, t, ((t) => {
			this.i._addBoolToInputSidePacket(e, t);
		}));
	}
	addDoubleToInputSidePacket(e, t) {
		W(this, t, ((t) => {
			this.i._addDoubleToInputSidePacket(e, t);
		}));
	}
	addFloatToInputSidePacket(e, t) {
		W(this, t, ((t) => {
			this.i._addFloatToInputSidePacket(e, t);
		}));
	}
	addIntToInputSidePacket(e, t) {
		W(this, t, ((t) => {
			this.i._addIntToInputSidePacket(e, t);
		}));
	}
	addUintToInputSidePacket(e, t) {
		W(this, t, ((t) => {
			this.i._addUintToInputSidePacket(e, t);
		}));
	}
	addStringToInputSidePacket(e, t) {
		W(this, t, ((t) => {
			W(this, e, ((e) => {
				this.i._addStringToInputSidePacket(e, t);
			}));
		}));
	}
	addProtoToInputSidePacket(e, t, n) {
		W(this, n, ((n) => {
			W(this, t, ((t) => {
				let r = this.i._malloc(e.length);
				this.i.HEAPU8.set(e, r), this.i._addProtoToInputSidePacket(r, e.length, t, n), this.i._free(r);
			}));
		}));
	}
	addBoolVectorToInputSidePacket(e, t) {
		W(this, t, ((t) => {
			let n = this.i._allocateBoolVector(e.length);
			if (!n) throw Error("Unable to allocate new bool vector on heap.");
			for (let t of e) this.i._addBoolVectorEntry(n, t);
			this.i._addBoolVectorToInputSidePacket(n, t);
		}));
	}
	addDoubleVectorToInputSidePacket(e, t) {
		W(this, t, ((t) => {
			let n = this.i._allocateDoubleVector(e.length);
			if (!n) throw Error("Unable to allocate new double vector on heap.");
			for (let t of e) this.i._addDoubleVectorEntry(n, t);
			this.i._addDoubleVectorToInputSidePacket(n, t);
		}));
	}
	addFloatVectorToInputSidePacket(e, t) {
		W(this, t, ((t) => {
			let n = this.i._allocateFloatVector(e.length);
			if (!n) throw Error("Unable to allocate new float vector on heap.");
			for (let t of e) this.i._addFloatVectorEntry(n, t);
			this.i._addFloatVectorToInputSidePacket(n, t);
		}));
	}
	addIntVectorToInputSidePacket(e, t) {
		W(this, t, ((t) => {
			let n = this.i._allocateIntVector(e.length);
			if (!n) throw Error("Unable to allocate new int vector on heap.");
			for (let t of e) this.i._addIntVectorEntry(n, t);
			this.i._addIntVectorToInputSidePacket(n, t);
		}));
	}
	addUintVectorToInputSidePacket(e, t) {
		W(this, t, ((t) => {
			let n = this.i._allocateUintVector(e.length);
			if (!n) throw Error("Unable to allocate new unsigned int vector on heap.");
			for (let t of e) this.i._addUintVectorEntry(n, t);
			this.i._addUintVectorToInputSidePacket(n, t);
		}));
	}
	addStringVectorToInputSidePacket(e, t) {
		W(this, t, ((t) => {
			let n = this.i._allocateStringVector(e.length);
			if (!n) throw Error("Unable to allocate new string vector on heap.");
			for (let t of e) W(this, t, ((e) => {
				this.i._addStringVectorEntry(n, e);
			}));
			this.i._addStringVectorToInputSidePacket(n, t);
		}));
	}
	attachBoolListener(e, t) {
		os(this, e, t), W(this, e, ((e) => {
			this.i._attachBoolListener(e);
		}));
	}
	attachBoolVectorListener(e, t) {
		ss(this, e, t), W(this, e, ((e) => {
			this.i._attachBoolVectorListener(e);
		}));
	}
	attachIntListener(e, t) {
		os(this, e, t), W(this, e, ((e) => {
			this.i._attachIntListener(e);
		}));
	}
	attachIntVectorListener(e, t) {
		ss(this, e, t), W(this, e, ((e) => {
			this.i._attachIntVectorListener(e);
		}));
	}
	attachUintListener(e, t) {
		os(this, e, t), W(this, e, ((e) => {
			this.i._attachUintListener(e);
		}));
	}
	attachUintVectorListener(e, t) {
		ss(this, e, t), W(this, e, ((e) => {
			this.i._attachUintVectorListener(e);
		}));
	}
	attachDoubleListener(e, t) {
		os(this, e, t), W(this, e, ((e) => {
			this.i._attachDoubleListener(e);
		}));
	}
	attachDoubleVectorListener(e, t) {
		ss(this, e, t), W(this, e, ((e) => {
			this.i._attachDoubleVectorListener(e);
		}));
	}
	attachFloatListener(e, t) {
		os(this, e, t), W(this, e, ((e) => {
			this.i._attachFloatListener(e);
		}));
	}
	attachFloatVectorListener(e, t) {
		ss(this, e, t), W(this, e, ((e) => {
			this.i._attachFloatVectorListener(e);
		}));
	}
	attachStringListener(e, t) {
		os(this, e, t), W(this, e, ((e) => {
			this.i._attachStringListener(e);
		}));
	}
	attachStringVectorListener(e, t) {
		ss(this, e, t), W(this, e, ((e) => {
			this.i._attachStringVectorListener(e);
		}));
	}
	attachProtoListener(e, t, n) {
		os(this, e, t), W(this, e, ((e) => {
			this.i._attachProtoListener(e, n || !1);
		}));
	}
	attachProtoVectorListener(e, t, n) {
		ss(this, e, t), W(this, e, ((e) => {
			this.i._attachProtoVectorListener(e, n || !1);
		}));
	}
	attachAudioListener(e, t, n) {
		this.i._attachAudioListener || console.warn("Attempting to use attachAudioListener without support for output audio. Is build dep \":gl_graph_runner_audio_out\" missing?"), os(this, e, ((e, n) => {
			e = new Float32Array(e.buffer, e.byteOffset, e.length / 4), t(e, n);
		})), W(this, e, ((e) => {
			this.i._attachAudioListener(e, n || !1);
		}));
	}
	finishProcessing() {
		this.i._waitUntilIdle();
	}
	closeGraph() {
		this.i._closeGraph(), this.i.simpleListeners = void 0, this.i.emptyPacketListeners = void 0;
	}
}, class extends nc {
	get ha() {
		return this.i;
	}
	sa(e, t, n) {
		W(this, t, ((t) => {
			let [r, i] = is(this, e, t);
			this.ha._addBoundTextureAsImageToStream(t, r, i, n);
		}));
	}
	W(e, t) {
		os(this, e, t), W(this, e, ((e) => {
			this.ha._attachImageListener(e);
		}));
	}
	da(e, t) {
		ss(this, e, t), W(this, e, ((e) => {
			this.ha._attachImageVectorListener(e);
		}));
	}
})), nc, rc = class extends tc {};
async function X(e, t, n) {
	return async function(e, t, n, r) {
		return cs(e, t, n, r);
	}(e, n.canvas ?? (ts() ? void 0 : document.createElement("canvas")), t, n);
}
function ic(e, t, n, r) {
	if (e.V) {
		let a = new Ea();
		if (n?.regionOfInterest) {
			if (!e.ra) throw Error("This task doesn't support region-of-interest.");
			var i = n.regionOfInterest;
			if (i.left >= i.right || i.top >= i.bottom) throw Error("Expected RectF with left < right and top < bottom.");
			if (0 > i.left || 0 > i.top || 1 < i.right || 1 < i.bottom) throw Error("Expected RectF values to be in [0,1].");
			w(a, 1, (i.left + i.right) / 2), w(a, 2, (i.top + i.bottom) / 2), w(a, 4, i.right - i.left), w(a, 3, i.bottom - i.top);
		} else w(a, 1, .5), w(a, 2, .5), w(a, 4, 1), w(a, 3, 1);
		if (n?.rotationDegrees) {
			if (n?.rotationDegrees % 90 != 0) throw Error("Expected rotation to be a multiple of 90°.");
			if (w(a, 5, -Math.PI * n.rotationDegrees / 180), n?.rotationDegrees % 180 != 0) {
				let [e, r] = rs(t);
				n = C(a, 3) * r / e, i = C(a, 4) * e / r, w(a, 4, n), w(a, 3, i);
			}
		}
		e.g.addProtoToStream(a.g(), "mediapipe.NormalizedRect", e.V, r);
	}
	e.g.sa(t, e.ba, r ?? performance.now()), e.finishProcessing();
}
function ac(e, t, n) {
	if (e.baseOptions?.g()) throw Error("Task is not initialized with image mode. 'runningMode' must be set to 'IMAGE'.");
	ic(e, t, n, e.J + 1);
}
function oc(e, t, n, r) {
	if (!e.baseOptions?.g()) throw Error("Task is not initialized with video mode. 'runningMode' must be set to 'VIDEO'.");
	ic(e, t, n, r);
}
function sc(e, t, n, r) {
	var i = t.data;
	let a = t.width, o = a * (t = t.height);
	if ((i instanceof Uint8Array || i instanceof Float32Array) && i.length !== o) throw Error("Unsupported channel count: " + i.length / o);
	return e = new q([i], n, !1, e.g.i.canvas, e.M, a, t), r ? e.clone() : e;
}
var cc = class extends ms {
	constructor(e, t, n, r) {
		super(e), this.g = e, this.ba = t, this.V = n, this.ra = r, this.M = new Cs();
	}
	l(e, t = !0) {
		if ("runningMode" in e && yr(this.baseOptions, 2, !!e.runningMode && e.runningMode !== "IMAGE"), e.canvas !== void 0 && this.g.i.canvas !== e.canvas) throw Error("You must create a new task to reset the canvas.");
		return super.l(e, t);
	}
	close() {
		this.M.close(), super.close();
	}
};
cc.prototype.close = cc.prototype.close;
var lc = class extends cc {
	constructor(e, t) {
		super(new rc(e, t), "image_in", "norm_rect_in", !1), this.j = { detections: [] }, S(e = this.h = new Ka(), 0, 1, t = new H()), w(this.h, 2, .5), w(this.h, 3, .3);
	}
	get baseOptions() {
		return x(this.h, H, 1);
	}
	set baseOptions(e) {
		S(this.h, 0, 1, e);
	}
	o(e) {
		return "minDetectionConfidence" in e && w(this.h, 2, e.minDetectionConfidence ?? .5), "minSuppressionThreshold" in e && w(this.h, 3, e.minSuppressionThreshold ?? .3), this.l(e);
	}
	F(e, t) {
		return this.j = { detections: [] }, ac(this, e, t), this.j;
	}
	G(e, t, n) {
		return this.j = { detections: [] }, oc(this, e, n, t), this.j;
	}
	m() {
		var e = new V();
		z(e, "image_in"), z(e, "norm_rect_in"), B(e, "detections");
		let t = new Li();
		xr(t, Ja, this.h);
		let n = new R();
		Wi(n, "mediapipe.tasks.vision.face_detector.FaceDetectorGraph"), I(n, "IMAGE:image_in"), I(n, "NORM_RECT:norm_rect_in"), L(n, "DETECTIONS:detections"), n.o(t), Xi(e, n), this.g.attachProtoVectorListener("detections", ((e, t) => {
			for (let t of e) e = ha(t), this.j.detections.push(Go(e));
			G(this, t);
		})), this.g.attachEmptyPacketListener("detections", ((e) => {
			G(this, e);
		})), e = e.g(), this.setGraph(new Uint8Array(e), !0);
	}
};
lc.prototype.detectForVideo = lc.prototype.G, lc.prototype.detect = lc.prototype.F, lc.prototype.setOptions = lc.prototype.o, lc.createFromModelPath = async function(e, t) {
	return X(lc, e, { baseOptions: { modelAssetPath: t } });
}, lc.createFromModelBuffer = function(e, t) {
	return X(lc, e, { baseOptions: { modelAssetBuffer: t } });
}, lc.createFromOptions = function(e, t) {
	return X(lc, e, t);
};
var uc = ec([61, 146], [146, 91], [91, 181], [181, 84], [84, 17], [17, 314], [314, 405], [405, 321], [321, 375], [375, 291], [61, 185], [185, 40], [40, 39], [39, 37], [37, 0], [0, 267], [267, 269], [269, 270], [270, 409], [409, 291], [78, 95], [95, 88], [88, 178], [178, 87], [87, 14], [14, 317], [317, 402], [402, 318], [318, 324], [324, 308], [78, 191], [191, 80], [80, 81], [81, 82], [82, 13], [13, 312], [312, 311], [311, 310], [310, 415], [415, 308]), dc = ec([263, 249], [249, 390], [390, 373], [373, 374], [374, 380], [380, 381], [381, 382], [382, 362], [263, 466], [466, 388], [388, 387], [387, 386], [386, 385], [385, 384], [384, 398], [398, 362]), fc = ec([276, 283], [283, 282], [282, 295], [295, 285], [300, 293], [293, 334], [334, 296], [296, 336]), pc = ec([474, 475], [475, 476], [476, 477], [477, 474]), mc = ec([33, 7], [7, 163], [163, 144], [144, 145], [145, 153], [153, 154], [154, 155], [155, 133], [33, 246], [246, 161], [161, 160], [160, 159], [159, 158], [158, 157], [157, 173], [173, 133]), hc = ec([46, 53], [53, 52], [52, 65], [65, 55], [70, 63], [63, 105], [105, 66], [66, 107]), gc = ec([469, 470], [470, 471], [471, 472], [472, 469]), _c = ec([10, 338], [338, 297], [297, 332], [332, 284], [284, 251], [251, 389], [389, 356], [356, 454], [454, 323], [323, 361], [361, 288], [288, 397], [397, 365], [365, 379], [379, 378], [378, 400], [400, 377], [377, 152], [152, 148], [148, 176], [176, 149], [149, 150], [150, 136], [136, 172], [172, 58], [58, 132], [132, 93], [93, 234], [234, 127], [127, 162], [162, 21], [21, 54], [54, 103], [103, 67], [67, 109], [109, 10]), vc = [
	...uc,
	...dc,
	...fc,
	...mc,
	...hc,
	..._c
], yc = ec([127, 34], [34, 139], [139, 127], [11, 0], [0, 37], [37, 11], [232, 231], [231, 120], [120, 232], [72, 37], [37, 39], [39, 72], [128, 121], [121, 47], [47, 128], [232, 121], [121, 128], [128, 232], [104, 69], [69, 67], [67, 104], [175, 171], [171, 148], [148, 175], [118, 50], [50, 101], [101, 118], [73, 39], [39, 40], [40, 73], [9, 151], [151, 108], [108, 9], [48, 115], [115, 131], [131, 48], [194, 204], [204, 211], [211, 194], [74, 40], [40, 185], [185, 74], [80, 42], [42, 183], [183, 80], [40, 92], [92, 186], [186, 40], [230, 229], [229, 118], [118, 230], [202, 212], [212, 214], [214, 202], [83, 18], [18, 17], [17, 83], [76, 61], [61, 146], [146, 76], [160, 29], [29, 30], [30, 160], [56, 157], [157, 173], [173, 56], [106, 204], [204, 194], [194, 106], [135, 214], [214, 192], [192, 135], [203, 165], [165, 98], [98, 203], [21, 71], [71, 68], [68, 21], [51, 45], [45, 4], [4, 51], [144, 24], [24, 23], [23, 144], [77, 146], [146, 91], [91, 77], [205, 50], [50, 187], [187, 205], [201, 200], [200, 18], [18, 201], [91, 106], [106, 182], [182, 91], [90, 91], [91, 181], [181, 90], [85, 84], [84, 17], [17, 85], [206, 203], [203, 36], [36, 206], [148, 171], [171, 140], [140, 148], [92, 40], [40, 39], [39, 92], [193, 189], [189, 244], [244, 193], [159, 158], [158, 28], [28, 159], [247, 246], [246, 161], [161, 247], [236, 3], [3, 196], [196, 236], [54, 68], [68, 104], [104, 54], [193, 168], [168, 8], [8, 193], [117, 228], [228, 31], [31, 117], [189, 193], [193, 55], [55, 189], [98, 97], [97, 99], [99, 98], [126, 47], [47, 100], [100, 126], [166, 79], [79, 218], [218, 166], [155, 154], [154, 26], [26, 155], [209, 49], [49, 131], [131, 209], [135, 136], [136, 150], [150, 135], [47, 126], [126, 217], [217, 47], [223, 52], [52, 53], [53, 223], [45, 51], [51, 134], [134, 45], [211, 170], [170, 140], [140, 211], [67, 69], [69, 108], [108, 67], [43, 106], [106, 91], [91, 43], [230, 119], [119, 120], [120, 230], [226, 130], [130, 247], [247, 226], [63, 53], [53, 52], [52, 63], [238, 20], [20, 242], [242, 238], [46, 70], [70, 156], [156, 46], [78, 62], [62, 96], [96, 78], [46, 53], [53, 63], [63, 46], [143, 34], [34, 227], [227, 143], [123, 117], [117, 111], [111, 123], [44, 125], [125, 19], [19, 44], [236, 134], [134, 51], [51, 236], [216, 206], [206, 205], [205, 216], [154, 153], [153, 22], [22, 154], [39, 37], [37, 167], [167, 39], [200, 201], [201, 208], [208, 200], [36, 142], [142, 100], [100, 36], [57, 212], [212, 202], [202, 57], [20, 60], [60, 99], [99, 20], [28, 158], [158, 157], [157, 28], [35, 226], [226, 113], [113, 35], [160, 159], [159, 27], [27, 160], [204, 202], [202, 210], [210, 204], [113, 225], [225, 46], [46, 113], [43, 202], [202, 204], [204, 43], [62, 76], [76, 77], [77, 62], [137, 123], [123, 116], [116, 137], [41, 38], [38, 72], [72, 41], [203, 129], [129, 142], [142, 203], [64, 98], [98, 240], [240, 64], [49, 102], [102, 64], [64, 49], [41, 73], [73, 74], [74, 41], [212, 216], [216, 207], [207, 212], [42, 74], [74, 184], [184, 42], [169, 170], [170, 211], [211, 169], [170, 149], [149, 176], [176, 170], [105, 66], [66, 69], [69, 105], [122, 6], [6, 168], [168, 122], [123, 147], [147, 187], [187, 123], [96, 77], [77, 90], [90, 96], [65, 55], [55, 107], [107, 65], [89, 90], [90, 180], [180, 89], [101, 100], [100, 120], [120, 101], [63, 105], [105, 104], [104, 63], [93, 137], [137, 227], [227, 93], [15, 86], [86, 85], [85, 15], [129, 102], [102, 49], [49, 129], [14, 87], [87, 86], [86, 14], [55, 8], [8, 9], [9, 55], [100, 47], [47, 121], [121, 100], [145, 23], [23, 22], [22, 145], [88, 89], [89, 179], [179, 88], [6, 122], [122, 196], [196, 6], [88, 95], [95, 96], [96, 88], [138, 172], [172, 136], [136, 138], [215, 58], [58, 172], [172, 215], [115, 48], [48, 219], [219, 115], [42, 80], [80, 81], [81, 42], [195, 3], [3, 51], [51, 195], [43, 146], [146, 61], [61, 43], [171, 175], [175, 199], [199, 171], [81, 82], [82, 38], [38, 81], [53, 46], [46, 225], [225, 53], [144, 163], [163, 110], [110, 144], [52, 65], [65, 66], [66, 52], [229, 228], [228, 117], [117, 229], [34, 127], [127, 234], [234, 34], [107, 108], [108, 69], [69, 107], [109, 108], [108, 151], [151, 109], [48, 64], [64, 235], [235, 48], [62, 78], [78, 191], [191, 62], [129, 209], [209, 126], [126, 129], [111, 35], [35, 143], [143, 111], [117, 123], [123, 50], [50, 117], [222, 65], [65, 52], [52, 222], [19, 125], [125, 141], [141, 19], [221, 55], [55, 65], [65, 221], [3, 195], [195, 197], [197, 3], [25, 7], [7, 33], [33, 25], [220, 237], [237, 44], [44, 220], [70, 71], [71, 139], [139, 70], [122, 193], [193, 245], [245, 122], [247, 130], [130, 33], [33, 247], [71, 21], [21, 162], [162, 71], [170, 169], [169, 150], [150, 170], [188, 174], [174, 196], [196, 188], [216, 186], [186, 92], [92, 216], [2, 97], [97, 167], [167, 2], [141, 125], [125, 241], [241, 141], [164, 167], [167, 37], [37, 164], [72, 38], [38, 12], [12, 72], [38, 82], [82, 13], [13, 38], [63, 68], [68, 71], [71, 63], [226, 35], [35, 111], [111, 226], [101, 50], [50, 205], [205, 101], [206, 92], [92, 165], [165, 206], [209, 198], [198, 217], [217, 209], [165, 167], [167, 97], [97, 165], [220, 115], [115, 218], [218, 220], [133, 112], [112, 243], [243, 133], [239, 238], [238, 241], [241, 239], [214, 135], [135, 169], [169, 214], [190, 173], [173, 133], [133, 190], [171, 208], [208, 32], [32, 171], [125, 44], [44, 237], [237, 125], [86, 87], [87, 178], [178, 86], [85, 86], [86, 179], [179, 85], [84, 85], [85, 180], [180, 84], [83, 84], [84, 181], [181, 83], [201, 83], [83, 182], [182, 201], [137, 93], [93, 132], [132, 137], [76, 62], [62, 183], [183, 76], [61, 76], [76, 184], [184, 61], [57, 61], [61, 185], [185, 57], [212, 57], [57, 186], [186, 212], [214, 207], [207, 187], [187, 214], [34, 143], [143, 156], [156, 34], [79, 239], [239, 237], [237, 79], [123, 137], [137, 177], [177, 123], [44, 1], [1, 4], [4, 44], [201, 194], [194, 32], [32, 201], [64, 102], [102, 129], [129, 64], [213, 215], [215, 138], [138, 213], [59, 166], [166, 219], [219, 59], [242, 99], [99, 97], [97, 242], [2, 94], [94, 141], [141, 2], [75, 59], [59, 235], [235, 75], [24, 110], [110, 228], [228, 24], [25, 130], [130, 226], [226, 25], [23, 24], [24, 229], [229, 23], [22, 23], [23, 230], [230, 22], [26, 22], [22, 231], [231, 26], [112, 26], [26, 232], [232, 112], [189, 190], [190, 243], [243, 189], [221, 56], [56, 190], [190, 221], [28, 56], [56, 221], [221, 28], [27, 28], [28, 222], [222, 27], [29, 27], [27, 223], [223, 29], [30, 29], [29, 224], [224, 30], [247, 30], [30, 225], [225, 247], [238, 79], [79, 20], [20, 238], [166, 59], [59, 75], [75, 166], [60, 75], [75, 240], [240, 60], [147, 177], [177, 215], [215, 147], [20, 79], [79, 166], [166, 20], [187, 147], [147, 213], [213, 187], [112, 233], [233, 244], [244, 112], [233, 128], [128, 245], [245, 233], [128, 114], [114, 188], [188, 128], [114, 217], [217, 174], [174, 114], [131, 115], [115, 220], [220, 131], [217, 198], [198, 236], [236, 217], [198, 131], [131, 134], [134, 198], [177, 132], [132, 58], [58, 177], [143, 35], [35, 124], [124, 143], [110, 163], [163, 7], [7, 110], [228, 110], [110, 25], [25, 228], [356, 389], [389, 368], [368, 356], [11, 302], [302, 267], [267, 11], [452, 350], [350, 349], [349, 452], [302, 303], [303, 269], [269, 302], [357, 343], [343, 277], [277, 357], [452, 453], [453, 357], [357, 452], [333, 332], [332, 297], [297, 333], [175, 152], [152, 377], [377, 175], [347, 348], [348, 330], [330, 347], [303, 304], [304, 270], [270, 303], [9, 336], [336, 337], [337, 9], [278, 279], [279, 360], [360, 278], [418, 262], [262, 431], [431, 418], [304, 408], [408, 409], [409, 304], [310, 415], [415, 407], [407, 310], [270, 409], [409, 410], [410, 270], [450, 348], [348, 347], [347, 450], [422, 430], [430, 434], [434, 422], [313, 314], [314, 17], [17, 313], [306, 307], [307, 375], [375, 306], [387, 388], [388, 260], [260, 387], [286, 414], [414, 398], [398, 286], [335, 406], [406, 418], [418, 335], [364, 367], [367, 416], [416, 364], [423, 358], [358, 327], [327, 423], [251, 284], [284, 298], [298, 251], [281, 5], [5, 4], [4, 281], [373, 374], [374, 253], [253, 373], [307, 320], [320, 321], [321, 307], [425, 427], [427, 411], [411, 425], [421, 313], [313, 18], [18, 421], [321, 405], [405, 406], [406, 321], [320, 404], [404, 405], [405, 320], [315, 16], [16, 17], [17, 315], [426, 425], [425, 266], [266, 426], [377, 400], [400, 369], [369, 377], [322, 391], [391, 269], [269, 322], [417, 465], [465, 464], [464, 417], [386, 257], [257, 258], [258, 386], [466, 260], [260, 388], [388, 466], [456, 399], [399, 419], [419, 456], [284, 332], [332, 333], [333, 284], [417, 285], [285, 8], [8, 417], [346, 340], [340, 261], [261, 346], [413, 441], [441, 285], [285, 413], [327, 460], [460, 328], [328, 327], [355, 371], [371, 329], [329, 355], [392, 439], [439, 438], [438, 392], [382, 341], [341, 256], [256, 382], [429, 420], [420, 360], [360, 429], [364, 394], [394, 379], [379, 364], [277, 343], [343, 437], [437, 277], [443, 444], [444, 283], [283, 443], [275, 440], [440, 363], [363, 275], [431, 262], [262, 369], [369, 431], [297, 338], [338, 337], [337, 297], [273, 375], [375, 321], [321, 273], [450, 451], [451, 349], [349, 450], [446, 342], [342, 467], [467, 446], [293, 334], [334, 282], [282, 293], [458, 461], [461, 462], [462, 458], [276, 353], [353, 383], [383, 276], [308, 324], [324, 325], [325, 308], [276, 300], [300, 293], [293, 276], [372, 345], [345, 447], [447, 372], [352, 345], [345, 340], [340, 352], [274, 1], [1, 19], [19, 274], [456, 248], [248, 281], [281, 456], [436, 427], [427, 425], [425, 436], [381, 256], [256, 252], [252, 381], [269, 391], [391, 393], [393, 269], [200, 199], [199, 428], [428, 200], [266, 330], [330, 329], [329, 266], [287, 273], [273, 422], [422, 287], [250, 462], [462, 328], [328, 250], [258, 286], [286, 384], [384, 258], [265, 353], [353, 342], [342, 265], [387, 259], [259, 257], [257, 387], [424, 431], [431, 430], [430, 424], [342, 353], [353, 276], [276, 342], [273, 335], [335, 424], [424, 273], [292, 325], [325, 307], [307, 292], [366, 447], [447, 345], [345, 366], [271, 303], [303, 302], [302, 271], [423, 266], [266, 371], [371, 423], [294, 455], [455, 460], [460, 294], [279, 278], [278, 294], [294, 279], [271, 272], [272, 304], [304, 271], [432, 434], [434, 427], [427, 432], [272, 407], [407, 408], [408, 272], [394, 430], [430, 431], [431, 394], [395, 369], [369, 400], [400, 395], [334, 333], [333, 299], [299, 334], [351, 417], [417, 168], [168, 351], [352, 280], [280, 411], [411, 352], [325, 319], [319, 320], [320, 325], [295, 296], [296, 336], [336, 295], [319, 403], [403, 404], [404, 319], [330, 348], [348, 349], [349, 330], [293, 298], [298, 333], [333, 293], [323, 454], [454, 447], [447, 323], [15, 16], [16, 315], [315, 15], [358, 429], [429, 279], [279, 358], [14, 15], [15, 316], [316, 14], [285, 336], [336, 9], [9, 285], [329, 349], [349, 350], [350, 329], [374, 380], [380, 252], [252, 374], [318, 402], [402, 403], [403, 318], [6, 197], [197, 419], [419, 6], [318, 319], [319, 325], [325, 318], [367, 364], [364, 365], [365, 367], [435, 367], [367, 397], [397, 435], [344, 438], [438, 439], [439, 344], [272, 271], [271, 311], [311, 272], [195, 5], [5, 281], [281, 195], [273, 287], [287, 291], [291, 273], [396, 428], [428, 199], [199, 396], [311, 271], [271, 268], [268, 311], [283, 444], [444, 445], [445, 283], [373, 254], [254, 339], [339, 373], [282, 334], [334, 296], [296, 282], [449, 347], [347, 346], [346, 449], [264, 447], [447, 454], [454, 264], [336, 296], [296, 299], [299, 336], [338, 10], [10, 151], [151, 338], [278, 439], [439, 455], [455, 278], [292, 407], [407, 415], [415, 292], [358, 371], [371, 355], [355, 358], [340, 345], [345, 372], [372, 340], [346, 347], [347, 280], [280, 346], [442, 443], [443, 282], [282, 442], [19, 94], [94, 370], [370, 19], [441, 442], [442, 295], [295, 441], [248, 419], [419, 197], [197, 248], [263, 255], [255, 359], [359, 263], [440, 275], [275, 274], [274, 440], [300, 383], [383, 368], [368, 300], [351, 412], [412, 465], [465, 351], [263, 467], [467, 466], [466, 263], [301, 368], [368, 389], [389, 301], [395, 378], [378, 379], [379, 395], [412, 351], [351, 419], [419, 412], [436, 426], [426, 322], [322, 436], [2, 164], [164, 393], [393, 2], [370, 462], [462, 461], [461, 370], [164, 0], [0, 267], [267, 164], [302, 11], [11, 12], [12, 302], [268, 12], [12, 13], [13, 268], [293, 300], [300, 301], [301, 293], [446, 261], [261, 340], [340, 446], [330, 266], [266, 425], [425, 330], [426, 423], [423, 391], [391, 426], [429, 355], [355, 437], [437, 429], [391, 327], [327, 326], [326, 391], [440, 457], [457, 438], [438, 440], [341, 382], [382, 362], [362, 341], [459, 457], [457, 461], [461, 459], [434, 430], [430, 394], [394, 434], [414, 463], [463, 362], [362, 414], [396, 369], [369, 262], [262, 396], [354, 461], [461, 457], [457, 354], [316, 403], [403, 402], [402, 316], [315, 404], [404, 403], [403, 315], [314, 405], [405, 404], [404, 314], [313, 406], [406, 405], [405, 313], [421, 418], [418, 406], [406, 421], [366, 401], [401, 361], [361, 366], [306, 408], [408, 407], [407, 306], [291, 409], [409, 408], [408, 291], [287, 410], [410, 409], [409, 287], [432, 436], [436, 410], [410, 432], [434, 416], [416, 411], [411, 434], [264, 368], [368, 383], [383, 264], [309, 438], [438, 457], [457, 309], [352, 376], [376, 401], [401, 352], [274, 275], [275, 4], [4, 274], [421, 428], [428, 262], [262, 421], [294, 327], [327, 358], [358, 294], [433, 416], [416, 367], [367, 433], [289, 455], [455, 439], [439, 289], [462, 370], [370, 326], [326, 462], [2, 326], [326, 370], [370, 2], [305, 460], [460, 455], [455, 305], [254, 449], [449, 448], [448, 254], [255, 261], [261, 446], [446, 255], [253, 450], [450, 449], [449, 253], [252, 451], [451, 450], [450, 252], [256, 452], [452, 451], [451, 256], [341, 453], [453, 452], [452, 341], [413, 464], [464, 463], [463, 413], [441, 413], [413, 414], [414, 441], [258, 442], [442, 441], [441, 258], [257, 443], [443, 442], [442, 257], [259, 444], [444, 443], [443, 259], [260, 445], [445, 444], [444, 260], [467, 342], [342, 445], [445, 467], [459, 458], [458, 250], [250, 459], [289, 392], [392, 290], [290, 289], [290, 328], [328, 460], [460, 290], [376, 433], [433, 435], [435, 376], [250, 290], [290, 392], [392, 250], [411, 416], [416, 433], [433, 411], [341, 463], [463, 464], [464, 341], [453, 464], [464, 465], [465, 453], [357, 465], [465, 412], [412, 357], [343, 412], [412, 399], [399, 343], [360, 363], [363, 440], [440, 360], [437, 399], [399, 456], [456, 437], [420, 456], [456, 363], [363, 420], [401, 435], [435, 288], [288, 401], [372, 383], [383, 353], [353, 372], [339, 255], [255, 249], [249, 339], [448, 261], [261, 255], [255, 448], [133, 243], [243, 190], [190, 133], [133, 155], [155, 112], [112, 133], [33, 246], [246, 247], [247, 33], [33, 130], [130, 25], [25, 33], [398, 384], [384, 286], [286, 398], [362, 398], [398, 414], [414, 362], [362, 463], [463, 341], [341, 362], [263, 359], [359, 467], [467, 263], [263, 249], [249, 255], [255, 263], [466, 467], [467, 260], [260, 466], [75, 60], [60, 166], [166, 75], [238, 239], [239, 79], [79, 238], [162, 127], [127, 139], [139, 162], [72, 11], [11, 37], [37, 72], [121, 232], [232, 120], [120, 121], [73, 72], [72, 39], [39, 73], [114, 128], [128, 47], [47, 114], [233, 232], [232, 128], [128, 233], [103, 104], [104, 67], [67, 103], [152, 175], [175, 148], [148, 152], [119, 118], [118, 101], [101, 119], [74, 73], [73, 40], [40, 74], [107, 9], [9, 108], [108, 107], [49, 48], [48, 131], [131, 49], [32, 194], [194, 211], [211, 32], [184, 74], [74, 185], [185, 184], [191, 80], [80, 183], [183, 191], [185, 40], [40, 186], [186, 185], [119, 230], [230, 118], [118, 119], [210, 202], [202, 214], [214, 210], [84, 83], [83, 17], [17, 84], [77, 76], [76, 146], [146, 77], [161, 160], [160, 30], [30, 161], [190, 56], [56, 173], [173, 190], [182, 106], [106, 194], [194, 182], [138, 135], [135, 192], [192, 138], [129, 203], [203, 98], [98, 129], [54, 21], [21, 68], [68, 54], [5, 51], [51, 4], [4, 5], [145, 144], [144, 23], [23, 145], [90, 77], [77, 91], [91, 90], [207, 205], [205, 187], [187, 207], [83, 201], [201, 18], [18, 83], [181, 91], [91, 182], [182, 181], [180, 90], [90, 181], [181, 180], [16, 85], [85, 17], [17, 16], [205, 206], [206, 36], [36, 205], [176, 148], [148, 140], [140, 176], [165, 92], [92, 39], [39, 165], [245, 193], [193, 244], [244, 245], [27, 159], [159, 28], [28, 27], [30, 247], [247, 161], [161, 30], [174, 236], [236, 196], [196, 174], [103, 54], [54, 104], [104, 103], [55, 193], [193, 8], [8, 55], [111, 117], [117, 31], [31, 111], [221, 189], [189, 55], [55, 221], [240, 98], [98, 99], [99, 240], [142, 126], [126, 100], [100, 142], [219, 166], [166, 218], [218, 219], [112, 155], [155, 26], [26, 112], [198, 209], [209, 131], [131, 198], [169, 135], [135, 150], [150, 169], [114, 47], [47, 217], [217, 114], [224, 223], [223, 53], [53, 224], [220, 45], [45, 134], [134, 220], [32, 211], [211, 140], [140, 32], [109, 67], [67, 108], [108, 109], [146, 43], [43, 91], [91, 146], [231, 230], [230, 120], [120, 231], [113, 226], [226, 247], [247, 113], [105, 63], [63, 52], [52, 105], [241, 238], [238, 242], [242, 241], [124, 46], [46, 156], [156, 124], [95, 78], [78, 96], [96, 95], [70, 46], [46, 63], [63, 70], [116, 143], [143, 227], [227, 116], [116, 123], [123, 111], [111, 116], [1, 44], [44, 19], [19, 1], [3, 236], [236, 51], [51, 3], [207, 216], [216, 205], [205, 207], [26, 154], [154, 22], [22, 26], [165, 39], [39, 167], [167, 165], [199, 200], [200, 208], [208, 199], [101, 36], [36, 100], [100, 101], [43, 57], [57, 202], [202, 43], [242, 20], [20, 99], [99, 242], [56, 28], [28, 157], [157, 56], [124, 35], [35, 113], [113, 124], [29, 160], [160, 27], [27, 29], [211, 204], [204, 210], [210, 211], [124, 113], [113, 46], [46, 124], [106, 43], [43, 204], [204, 106], [96, 62], [62, 77], [77, 96], [227, 137], [137, 116], [116, 227], [73, 41], [41, 72], [72, 73], [36, 203], [203, 142], [142, 36], [235, 64], [64, 240], [240, 235], [48, 49], [49, 64], [64, 48], [42, 41], [41, 74], [74, 42], [214, 212], [212, 207], [207, 214], [183, 42], [42, 184], [184, 183], [210, 169], [169, 211], [211, 210], [140, 170], [170, 176], [176, 140], [104, 105], [105, 69], [69, 104], [193, 122], [122, 168], [168, 193], [50, 123], [123, 187], [187, 50], [89, 96], [96, 90], [90, 89], [66, 65], [65, 107], [107, 66], [179, 89], [89, 180], [180, 179], [119, 101], [101, 120], [120, 119], [68, 63], [63, 104], [104, 68], [234, 93], [93, 227], [227, 234], [16, 15], [15, 85], [85, 16], [209, 129], [129, 49], [49, 209], [15, 14], [14, 86], [86, 15], [107, 55], [55, 9], [9, 107], [120, 100], [100, 121], [121, 120], [153, 145], [145, 22], [22, 153], [178, 88], [88, 179], [179, 178], [197, 6], [6, 196], [196, 197], [89, 88], [88, 96], [96, 89], [135, 138], [138, 136], [136, 135], [138, 215], [215, 172], [172, 138], [218, 115], [115, 219], [219, 218], [41, 42], [42, 81], [81, 41], [5, 195], [195, 51], [51, 5], [57, 43], [43, 61], [61, 57], [208, 171], [171, 199], [199, 208], [41, 81], [81, 38], [38, 41], [224, 53], [53, 225], [225, 224], [24, 144], [144, 110], [110, 24], [105, 52], [52, 66], [66, 105], [118, 229], [229, 117], [117, 118], [227, 34], [34, 234], [234, 227], [66, 107], [107, 69], [69, 66], [10, 109], [109, 151], [151, 10], [219, 48], [48, 235], [235, 219], [183, 62], [62, 191], [191, 183], [142, 129], [129, 126], [126, 142], [116, 111], [111, 143], [143, 116], [118, 117], [117, 50], [50, 118], [223, 222], [222, 52], [52, 223], [94, 19], [19, 141], [141, 94], [222, 221], [221, 65], [65, 222], [196, 3], [3, 197], [197, 196], [45, 220], [220, 44], [44, 45], [156, 70], [70, 139], [139, 156], [188, 122], [122, 245], [245, 188], [139, 71], [71, 162], [162, 139], [149, 170], [170, 150], [150, 149], [122, 188], [188, 196], [196, 122], [206, 216], [216, 92], [92, 206], [164, 2], [2, 167], [167, 164], [242, 141], [141, 241], [241, 242], [0, 164], [164, 37], [37, 0], [11, 72], [72, 12], [12, 11], [12, 38], [38, 13], [13, 12], [70, 63], [63, 71], [71, 70], [31, 226], [226, 111], [111, 31], [36, 101], [101, 205], [205, 36], [203, 206], [206, 165], [165, 203], [126, 209], [209, 217], [217, 126], [98, 165], [165, 97], [97, 98], [237, 220], [220, 218], [218, 237], [237, 239], [239, 241], [241, 237], [210, 214], [214, 169], [169, 210], [140, 171], [171, 32], [32, 140], [241, 125], [125, 237], [237, 241], [179, 86], [86, 178], [178, 179], [180, 85], [85, 179], [179, 180], [181, 84], [84, 180], [180, 181], [182, 83], [83, 181], [181, 182], [194, 201], [201, 182], [182, 194], [177, 137], [137, 132], [132, 177], [184, 76], [76, 183], [183, 184], [185, 61], [61, 184], [184, 185], [186, 57], [57, 185], [185, 186], [216, 212], [212, 186], [186, 216], [192, 214], [214, 187], [187, 192], [139, 34], [34, 156], [156, 139], [218, 79], [79, 237], [237, 218], [147, 123], [123, 177], [177, 147], [45, 44], [44, 4], [4, 45], [208, 201], [201, 32], [32, 208], [98, 64], [64, 129], [129, 98], [192, 213], [213, 138], [138, 192], [235, 59], [59, 219], [219, 235], [141, 242], [242, 97], [97, 141], [97, 2], [2, 141], [141, 97], [240, 75], [75, 235], [235, 240], [229, 24], [24, 228], [228, 229], [31, 25], [25, 226], [226, 31], [230, 23], [23, 229], [229, 230], [231, 22], [22, 230], [230, 231], [232, 26], [26, 231], [231, 232], [233, 112], [112, 232], [232, 233], [244, 189], [189, 243], [243, 244], [189, 221], [221, 190], [190, 189], [222, 28], [28, 221], [221, 222], [223, 27], [27, 222], [222, 223], [224, 29], [29, 223], [223, 224], [225, 30], [30, 224], [224, 225], [113, 247], [247, 225], [225, 113], [99, 60], [60, 240], [240, 99], [213, 147], [147, 215], [215, 213], [60, 20], [20, 166], [166, 60], [192, 187], [187, 213], [213, 192], [243, 112], [112, 244], [244, 243], [244, 233], [233, 245], [245, 244], [245, 128], [128, 188], [188, 245], [188, 114], [114, 174], [174, 188], [134, 131], [131, 220], [220, 134], [174, 217], [217, 236], [236, 174], [236, 198], [198, 134], [134, 236], [215, 177], [177, 58], [58, 215], [156, 143], [143, 124], [124, 156], [25, 110], [110, 7], [7, 25], [31, 228], [228, 25], [25, 31], [264, 356], [356, 368], [368, 264], [0, 11], [11, 267], [267, 0], [451, 452], [452, 349], [349, 451], [267, 302], [302, 269], [269, 267], [350, 357], [357, 277], [277, 350], [350, 452], [452, 357], [357, 350], [299, 333], [333, 297], [297, 299], [396, 175], [175, 377], [377, 396], [280, 347], [347, 330], [330, 280], [269, 303], [303, 270], [270, 269], [151, 9], [9, 337], [337, 151], [344, 278], [278, 360], [360, 344], [424, 418], [418, 431], [431, 424], [270, 304], [304, 409], [409, 270], [272, 310], [310, 407], [407, 272], [322, 270], [270, 410], [410, 322], [449, 450], [450, 347], [347, 449], [432, 422], [422, 434], [434, 432], [18, 313], [313, 17], [17, 18], [291, 306], [306, 375], [375, 291], [259, 387], [387, 260], [260, 259], [424, 335], [335, 418], [418, 424], [434, 364], [364, 416], [416, 434], [391, 423], [423, 327], [327, 391], [301, 251], [251, 298], [298, 301], [275, 281], [281, 4], [4, 275], [254, 373], [373, 253], [253, 254], [375, 307], [307, 321], [321, 375], [280, 425], [425, 411], [411, 280], [200, 421], [421, 18], [18, 200], [335, 321], [321, 406], [406, 335], [321, 320], [320, 405], [405, 321], [314, 315], [315, 17], [17, 314], [423, 426], [426, 266], [266, 423], [396, 377], [377, 369], [369, 396], [270, 322], [322, 269], [269, 270], [413, 417], [417, 464], [464, 413], [385, 386], [386, 258], [258, 385], [248, 456], [456, 419], [419, 248], [298, 284], [284, 333], [333, 298], [168, 417], [417, 8], [8, 168], [448, 346], [346, 261], [261, 448], [417, 413], [413, 285], [285, 417], [326, 327], [327, 328], [328, 326], [277, 355], [355, 329], [329, 277], [309, 392], [392, 438], [438, 309], [381, 382], [382, 256], [256, 381], [279, 429], [429, 360], [360, 279], [365, 364], [364, 379], [379, 365], [355, 277], [277, 437], [437, 355], [282, 443], [443, 283], [283, 282], [281, 275], [275, 363], [363, 281], [395, 431], [431, 369], [369, 395], [299, 297], [297, 337], [337, 299], [335, 273], [273, 321], [321, 335], [348, 450], [450, 349], [349, 348], [359, 446], [446, 467], [467, 359], [283, 293], [293, 282], [282, 283], [250, 458], [458, 462], [462, 250], [300, 276], [276, 383], [383, 300], [292, 308], [308, 325], [325, 292], [283, 276], [276, 293], [293, 283], [264, 372], [372, 447], [447, 264], [346, 352], [352, 340], [340, 346], [354, 274], [274, 19], [19, 354], [363, 456], [456, 281], [281, 363], [426, 436], [436, 425], [425, 426], [380, 381], [381, 252], [252, 380], [267, 269], [269, 393], [393, 267], [421, 200], [200, 428], [428, 421], [371, 266], [266, 329], [329, 371], [432, 287], [287, 422], [422, 432], [290, 250], [250, 328], [328, 290], [385, 258], [258, 384], [384, 385], [446, 265], [265, 342], [342, 446], [386, 387], [387, 257], [257, 386], [422, 424], [424, 430], [430, 422], [445, 342], [342, 276], [276, 445], [422, 273], [273, 424], [424, 422], [306, 292], [292, 307], [307, 306], [352, 366], [366, 345], [345, 352], [268, 271], [271, 302], [302, 268], [358, 423], [423, 371], [371, 358], [327, 294], [294, 460], [460, 327], [331, 279], [279, 294], [294, 331], [303, 271], [271, 304], [304, 303], [436, 432], [432, 427], [427, 436], [304, 272], [272, 408], [408, 304], [395, 394], [394, 431], [431, 395], [378, 395], [395, 400], [400, 378], [296, 334], [334, 299], [299, 296], [6, 351], [351, 168], [168, 6], [376, 352], [352, 411], [411, 376], [307, 325], [325, 320], [320, 307], [285, 295], [295, 336], [336, 285], [320, 319], [319, 404], [404, 320], [329, 330], [330, 349], [349, 329], [334, 293], [293, 333], [333, 334], [366, 323], [323, 447], [447, 366], [316, 15], [15, 315], [315, 316], [331, 358], [358, 279], [279, 331], [317, 14], [14, 316], [316, 317], [8, 285], [285, 9], [9, 8], [277, 329], [329, 350], [350, 277], [253, 374], [374, 252], [252, 253], [319, 318], [318, 403], [403, 319], [351, 6], [6, 419], [419, 351], [324, 318], [318, 325], [325, 324], [397, 367], [367, 365], [365, 397], [288, 435], [435, 397], [397, 288], [278, 344], [344, 439], [439, 278], [310, 272], [272, 311], [311, 310], [248, 195], [195, 281], [281, 248], [375, 273], [273, 291], [291, 375], [175, 396], [396, 199], [199, 175], [312, 311], [311, 268], [268, 312], [276, 283], [283, 445], [445, 276], [390, 373], [373, 339], [339, 390], [295, 282], [282, 296], [296, 295], [448, 449], [449, 346], [346, 448], [356, 264], [264, 454], [454, 356], [337, 336], [336, 299], [299, 337], [337, 338], [338, 151], [151, 337], [294, 278], [278, 455], [455, 294], [308, 292], [292, 415], [415, 308], [429, 358], [358, 355], [355, 429], [265, 340], [340, 372], [372, 265], [352, 346], [346, 280], [280, 352], [295, 442], [442, 282], [282, 295], [354, 19], [19, 370], [370, 354], [285, 441], [441, 295], [295, 285], [195, 248], [248, 197], [197, 195], [457, 440], [440, 274], [274, 457], [301, 300], [300, 368], [368, 301], [417, 351], [351, 465], [465, 417], [251, 301], [301, 389], [389, 251], [394, 395], [395, 379], [379, 394], [399, 412], [412, 419], [419, 399], [410, 436], [436, 322], [322, 410], [326, 2], [2, 393], [393, 326], [354, 370], [370, 461], [461, 354], [393, 164], [164, 267], [267, 393], [268, 302], [302, 12], [12, 268], [312, 268], [268, 13], [13, 312], [298, 293], [293, 301], [301, 298], [265, 446], [446, 340], [340, 265], [280, 330], [330, 425], [425, 280], [322, 426], [426, 391], [391, 322], [420, 429], [429, 437], [437, 420], [393, 391], [391, 326], [326, 393], [344, 440], [440, 438], [438, 344], [458, 459], [459, 461], [461, 458], [364, 434], [434, 394], [394, 364], [428, 396], [396, 262], [262, 428], [274, 354], [354, 457], [457, 274], [317, 316], [316, 402], [402, 317], [316, 315], [315, 403], [403, 316], [315, 314], [314, 404], [404, 315], [314, 313], [313, 405], [405, 314], [313, 421], [421, 406], [406, 313], [323, 366], [366, 361], [361, 323], [292, 306], [306, 407], [407, 292], [306, 291], [291, 408], [408, 306], [291, 287], [287, 409], [409, 291], [287, 432], [432, 410], [410, 287], [427, 434], [434, 411], [411, 427], [372, 264], [264, 383], [383, 372], [459, 309], [309, 457], [457, 459], [366, 352], [352, 401], [401, 366], [1, 274], [274, 4], [4, 1], [418, 421], [421, 262], [262, 418], [331, 294], [294, 358], [358, 331], [435, 433], [433, 367], [367, 435], [392, 289], [289, 439], [439, 392], [328, 462], [462, 326], [326, 328], [94, 2], [2, 370], [370, 94], [289, 305], [305, 455], [455, 289], [339, 254], [254, 448], [448, 339], [359, 255], [255, 446], [446, 359], [254, 253], [253, 449], [449, 254], [253, 252], [252, 450], [450, 253], [252, 256], [256, 451], [451, 252], [256, 341], [341, 452], [452, 256], [414, 413], [413, 463], [463, 414], [286, 441], [441, 414], [414, 286], [286, 258], [258, 441], [441, 286], [258, 257], [257, 442], [442, 258], [257, 259], [259, 443], [443, 257], [259, 260], [260, 444], [444, 259], [260, 467], [467, 445], [445, 260], [309, 459], [459, 250], [250, 309], [305, 289], [289, 290], [290, 305], [305, 290], [290, 460], [460, 305], [401, 376], [376, 435], [435, 401], [309, 250], [250, 392], [392, 309], [376, 411], [411, 433], [433, 376], [453, 341], [341, 464], [464, 453], [357, 453], [453, 465], [465, 357], [343, 357], [357, 412], [412, 343], [437, 343], [343, 399], [399, 437], [344, 360], [360, 440], [440, 344], [420, 437], [437, 456], [456, 420], [360, 420], [420, 363], [363, 360], [361, 401], [401, 288], [288, 361], [265, 372], [372, 353], [353, 265], [390, 339], [339, 249], [249, 390], [339, 448], [448, 255], [255, 339]);
function bc(e) {
	e.u = {
		faceLandmarks: [],
		faceBlendshapes: [],
		facialTransformationMatrixes: []
	};
}
var Z = class extends cc {
	constructor(e, t) {
		super(new rc(e, t), "image_in", "norm_rect", !1), this.u = {
			faceLandmarks: [],
			faceBlendshapes: [],
			facialTransformationMatrixes: []
		}, this.outputFacialTransformationMatrixes = this.outputFaceBlendshapes = !1, S(e = this.h = new to(), 0, 1, t = new H()), this.H = new $a(), S(this.h, 0, 3, this.H), this.j = new Ka(), S(this.h, 0, 2, this.j), br(this.j, 4, 1), w(this.j, 2, .5), w(this.H, 2, .5), w(this.h, 4, .5);
	}
	get baseOptions() {
		return x(this.h, H, 1);
	}
	set baseOptions(e) {
		S(this.h, 0, 1, e);
	}
	o(e) {
		return "numFaces" in e && br(this.j, 4, e.numFaces ?? 1), "minFaceDetectionConfidence" in e && w(this.j, 2, e.minFaceDetectionConfidence ?? .5), "minTrackingConfidence" in e && w(this.h, 4, e.minTrackingConfidence ?? .5), "minFacePresenceConfidence" in e && w(this.H, 2, e.minFacePresenceConfidence ?? .5), "outputFaceBlendshapes" in e && (this.outputFaceBlendshapes = !!e.outputFaceBlendshapes), "outputFacialTransformationMatrixes" in e && (this.outputFacialTransformationMatrixes = !!e.outputFacialTransformationMatrixes), this.l(e);
	}
	F(e, t) {
		return bc(this), ac(this, e, t), this.u;
	}
	G(e, t, n) {
		return bc(this), oc(this, e, n, t), this.u;
	}
	m() {
		var e = new V();
		z(e, "image_in"), z(e, "norm_rect"), B(e, "face_landmarks");
		let t = new Li();
		xr(t, ro, this.h);
		let n = new R();
		Wi(n, "mediapipe.tasks.vision.face_landmarker.FaceLandmarkerGraph"), I(n, "IMAGE:image_in"), I(n, "NORM_RECT:norm_rect"), L(n, "NORM_LANDMARKS:face_landmarks"), n.o(t), Xi(e, n), this.g.attachProtoVectorListener("face_landmarks", ((e, t) => {
			for (let t of e) e = Ca(t), this.u.faceLandmarks.push(Ko(e));
			G(this, t);
		})), this.g.attachEmptyPacketListener("face_landmarks", ((e) => {
			G(this, e);
		})), this.outputFaceBlendshapes && (B(e, "blendshapes"), L(n, "BLENDSHAPES:blendshapes"), this.g.attachProtoVectorListener("blendshapes", ((e, t) => {
			if (this.outputFaceBlendshapes) for (let t of e) e = ia(t), this.u.faceBlendshapes.push(Wo(e.g() ?? []));
			G(this, t);
		})), this.g.attachEmptyPacketListener("blendshapes", ((e) => {
			G(this, e);
		}))), this.outputFacialTransformationMatrixes && (B(e, "face_geometry"), L(n, "FACE_GEOMETRY:face_geometry"), this.g.attachProtoVectorListener("face_geometry", ((e, t) => {
			if (this.outputFacialTransformationMatrixes) for (let t of e) (e = x(Za(t), wa, 2)) && this.u.facialTransformationMatrixes.push({
				rows: _r(gr(e, 1), 0) ?? 0,
				columns: _r(gr(e, 2), 0) ?? 0,
				data: Zn(e, 3, tn).slice() ?? []
			});
			G(this, t);
		})), this.g.attachEmptyPacketListener("face_geometry", ((e) => {
			G(this, e);
		}))), e = e.g(), this.setGraph(new Uint8Array(e), !0);
	}
};
Z.prototype.detectForVideo = Z.prototype.G, Z.prototype.detect = Z.prototype.F, Z.prototype.setOptions = Z.prototype.o, Z.createFromModelPath = function(e, t) {
	return X(Z, e, { baseOptions: { modelAssetPath: t } });
}, Z.createFromModelBuffer = function(e, t) {
	return X(Z, e, { baseOptions: { modelAssetBuffer: t } });
}, Z.createFromOptions = function(e, t) {
	return X(Z, e, t);
}, Z.FACE_LANDMARKS_LIPS = uc, Z.FACE_LANDMARKS_LEFT_EYE = dc, Z.FACE_LANDMARKS_LEFT_EYEBROW = fc, Z.FACE_LANDMARKS_LEFT_IRIS = pc, Z.FACE_LANDMARKS_RIGHT_EYE = mc, Z.FACE_LANDMARKS_RIGHT_EYEBROW = hc, Z.FACE_LANDMARKS_RIGHT_IRIS = gc, Z.FACE_LANDMARKS_FACE_OVAL = _c, Z.FACE_LANDMARKS_CONTOURS = vc, Z.FACE_LANDMARKS_TESSELATION = yc;
var xc = class extends cc {
	constructor(e, t) {
		super(new rc(e, t), "image_in", "norm_rect", !0), S(e = this.j = new io(), 0, 1, t = new H());
	}
	get baseOptions() {
		return x(this.j, H, 1);
	}
	set baseOptions(e) {
		S(this.j, 0, 1, e);
	}
	o(e) {
		return super.l(e);
	}
	Pa(e, t, n) {
		let r = typeof t == "function" ? {} : t;
		if (this.h = typeof t == "function" ? t : n, ac(this, e, r ?? {}), !this.h) return this.u;
	}
	m() {
		var e = new V();
		z(e, "image_in"), z(e, "norm_rect"), B(e, "stylized_image");
		let t = new Li();
		xr(t, ao, this.j);
		let n = new R();
		Wi(n, "mediapipe.tasks.vision.face_stylizer.FaceStylizerGraph"), I(n, "IMAGE:image_in"), I(n, "NORM_RECT:norm_rect"), L(n, "STYLIZED_IMAGE:stylized_image"), n.o(t), Xi(e, n), this.g.W("stylized_image", ((e, t) => {
			var n = !this.h, r = e.data, i = e.width;
			let a = i * (e = e.height);
			if (r instanceof Uint8Array) if (r.length === 3 * a) {
				let t = new Uint8ClampedArray(4 * a);
				for (let e = 0; e < a; ++e) t[4 * e] = r[3 * e], t[4 * e + 1] = r[3 * e + 1], t[4 * e + 2] = r[3 * e + 2], t[4 * e + 3] = 255;
				r = new ImageData(t, i, e);
			} else {
				if (r.length !== 4 * a) throw Error("Unsupported channel count: " + r.length / a);
				r = new ImageData(new Uint8ClampedArray(r.buffer, r.byteOffset, r.length), i, e);
			}
			else if (!(r instanceof WebGLTexture)) throw Error(`Unsupported format: ${r.constructor.name}`);
			i = new Y([r], !1, !1, this.g.i.canvas, this.M, i, e), this.u = n = n ? i.clone() : i, this.h && this.h(n), G(this, t);
		})), this.g.attachEmptyPacketListener("stylized_image", ((e) => {
			this.u = null, this.h && this.h(null), G(this, e);
		})), e = e.g(), this.setGraph(new Uint8Array(e), !0);
	}
};
xc.prototype.stylize = xc.prototype.Pa, xc.prototype.setOptions = xc.prototype.o, xc.createFromModelPath = function(e, t) {
	return X(xc, e, { baseOptions: { modelAssetPath: t } });
}, xc.createFromModelBuffer = function(e, t) {
	return X(xc, e, { baseOptions: { modelAssetBuffer: t } });
}, xc.createFromOptions = function(e, t) {
	return X(xc, e, t);
};
var Sc = ec([0, 1], [1, 2], [2, 3], [3, 4], [0, 5], [5, 6], [6, 7], [7, 8], [5, 9], [9, 10], [10, 11], [11, 12], [9, 13], [13, 14], [14, 15], [15, 16], [13, 17], [0, 17], [17, 18], [18, 19], [19, 20]);
function Cc(e) {
	e.gestures = [], e.landmarks = [], e.worldLandmarks = [], e.handedness = [];
}
function wc(e) {
	return e.gestures.length === 0 ? {
		gestures: [],
		landmarks: [],
		worldLandmarks: [],
		handedness: [],
		handednesses: []
	} : {
		gestures: e.gestures,
		landmarks: e.landmarks,
		worldLandmarks: e.worldLandmarks,
		handedness: e.handedness,
		handednesses: e.handedness
	};
}
function Tc(e, t = !0) {
	let n = [];
	for (let i of e) {
		var r = ia(i);
		e = [];
		for (let n of r.g()) r = t && gr(n, 1) != null ? _r(gr(n, 1), 0) : -1, e.push({
			score: C(n, 2) ?? 0,
			index: r,
			categoryName: vr(n, 3) ?? "",
			displayName: vr(n, 4) ?? ""
		});
		n.push(e);
	}
	return n;
}
var Ec = class extends cc {
	constructor(e, t) {
		super(new rc(e, t), "image_in", "norm_rect", !1), this.gestures = [], this.landmarks = [], this.worldLandmarks = [], this.handedness = [], S(e = this.v = new vo(), 0, 1, t = new H()), this.A = new go(), S(this.v, 0, 2, this.A), this.u = new mo(), S(this.A, 0, 3, this.u), this.h = new fo(), S(this.A, 0, 2, this.h), this.j = new lo(), S(this.v, 0, 3, this.j), w(this.h, 2, .5), w(this.A, 4, .5), w(this.u, 2, .5);
	}
	get baseOptions() {
		return x(this.v, H, 1);
	}
	set baseOptions(e) {
		S(this.v, 0, 1, e);
	}
	o(e) {
		if (br(this.h, 3, e.numHands ?? 1), "minHandDetectionConfidence" in e && w(this.h, 2, e.minHandDetectionConfidence ?? .5), "minTrackingConfidence" in e && w(this.A, 4, e.minTrackingConfidence ?? .5), "minHandPresenceConfidence" in e && w(this.u, 2, e.minHandPresenceConfidence ?? .5), e.cannedGesturesClassifierOptions) {
			var t = new oo(), n = t, r = Uo(e.cannedGesturesClassifierOptions, x(this.j, oo, 3)?.h());
			S(n, 0, 2, r), S(this.j, 0, 3, t);
		} else e.cannedGesturesClassifierOptions === void 0 && x(this.j, oo, 3)?.g();
		return e.customGesturesClassifierOptions ? (S(n = t = new oo(), 0, 2, r = Uo(e.customGesturesClassifierOptions, x(this.j, oo, 4)?.h())), S(this.j, 0, 4, t)) : e.customGesturesClassifierOptions === void 0 && x(this.j, oo, 4)?.g(), this.l(e);
	}
	Ka(e, t) {
		return Cc(this), ac(this, e, t), wc(this);
	}
	La(e, t, n) {
		return Cc(this), oc(this, e, n, t), wc(this);
	}
	m() {
		var e = new V();
		z(e, "image_in"), z(e, "norm_rect"), B(e, "hand_gestures"), B(e, "hand_landmarks"), B(e, "world_hand_landmarks"), B(e, "handedness");
		let t = new Li();
		xr(t, xo, this.v);
		let n = new R();
		Wi(n, "mediapipe.tasks.vision.gesture_recognizer.GestureRecognizerGraph"), I(n, "IMAGE:image_in"), I(n, "NORM_RECT:norm_rect"), L(n, "HAND_GESTURES:hand_gestures"), L(n, "LANDMARKS:hand_landmarks"), L(n, "WORLD_LANDMARKS:world_hand_landmarks"), L(n, "HANDEDNESS:handedness"), n.o(t), Xi(e, n), this.g.attachProtoVectorListener("hand_landmarks", ((e, t) => {
			for (let t of e) {
				e = Ca(t);
				let n = [];
				for (let t of dr(e, ba, 1)) n.push({
					x: C(t, 1) ?? 0,
					y: C(t, 2) ?? 0,
					z: C(t, 3) ?? 0,
					visibility: C(t, 4) ?? 0
				});
				this.landmarks.push(n);
			}
			G(this, t);
		})), this.g.attachEmptyPacketListener("hand_landmarks", ((e) => {
			G(this, e);
		})), this.g.attachProtoVectorListener("world_hand_landmarks", ((e, t) => {
			for (let t of e) {
				e = ya(t);
				let n = [];
				for (let t of dr(e, ga, 1)) n.push({
					x: C(t, 1) ?? 0,
					y: C(t, 2) ?? 0,
					z: C(t, 3) ?? 0,
					visibility: C(t, 4) ?? 0
				});
				this.worldLandmarks.push(n);
			}
			G(this, t);
		})), this.g.attachEmptyPacketListener("world_hand_landmarks", ((e) => {
			G(this, e);
		})), this.g.attachProtoVectorListener("hand_gestures", ((e, t) => {
			this.gestures.push(...Tc(e, !1)), G(this, t);
		})), this.g.attachEmptyPacketListener("hand_gestures", ((e) => {
			G(this, e);
		})), this.g.attachProtoVectorListener("handedness", ((e, t) => {
			this.handedness.push(...Tc(e)), G(this, t);
		})), this.g.attachEmptyPacketListener("handedness", ((e) => {
			G(this, e);
		})), e = e.g(), this.setGraph(new Uint8Array(e), !0);
	}
};
function Dc(e) {
	return {
		landmarks: e.landmarks,
		worldLandmarks: e.worldLandmarks,
		handednesses: e.handedness,
		handedness: e.handedness
	};
}
Ec.prototype.recognizeForVideo = Ec.prototype.La, Ec.prototype.recognize = Ec.prototype.Ka, Ec.prototype.setOptions = Ec.prototype.o, Ec.createFromModelPath = function(e, t) {
	return X(Ec, e, { baseOptions: { modelAssetPath: t } });
}, Ec.createFromModelBuffer = function(e, t) {
	return X(Ec, e, { baseOptions: { modelAssetBuffer: t } });
}, Ec.createFromOptions = function(e, t) {
	return X(Ec, e, t);
}, Ec.HAND_CONNECTIONS = Sc;
var Oc = class extends cc {
	constructor(e, t) {
		super(new rc(e, t), "image_in", "norm_rect", !1), this.landmarks = [], this.worldLandmarks = [], this.handedness = [], S(e = this.j = new go(), 0, 1, t = new H()), this.u = new mo(), S(this.j, 0, 3, this.u), this.h = new fo(), S(this.j, 0, 2, this.h), br(this.h, 3, 1), w(this.h, 2, .5), w(this.u, 2, .5), w(this.j, 4, .5);
	}
	get baseOptions() {
		return x(this.j, H, 1);
	}
	set baseOptions(e) {
		S(this.j, 0, 1, e);
	}
	o(e) {
		return "numHands" in e && br(this.h, 3, e.numHands ?? 1), "minHandDetectionConfidence" in e && w(this.h, 2, e.minHandDetectionConfidence ?? .5), "minTrackingConfidence" in e && w(this.j, 4, e.minTrackingConfidence ?? .5), "minHandPresenceConfidence" in e && w(this.u, 2, e.minHandPresenceConfidence ?? .5), this.l(e);
	}
	F(e, t) {
		return this.landmarks = [], this.worldLandmarks = [], this.handedness = [], ac(this, e, t), Dc(this);
	}
	G(e, t, n) {
		return this.landmarks = [], this.worldLandmarks = [], this.handedness = [], oc(this, e, n, t), Dc(this);
	}
	m() {
		var e = new V();
		z(e, "image_in"), z(e, "norm_rect"), B(e, "hand_landmarks"), B(e, "world_hand_landmarks"), B(e, "handedness");
		let t = new Li();
		xr(t, bo, this.j);
		let n = new R();
		Wi(n, "mediapipe.tasks.vision.hand_landmarker.HandLandmarkerGraph"), I(n, "IMAGE:image_in"), I(n, "NORM_RECT:norm_rect"), L(n, "LANDMARKS:hand_landmarks"), L(n, "WORLD_LANDMARKS:world_hand_landmarks"), L(n, "HANDEDNESS:handedness"), n.o(t), Xi(e, n), this.g.attachProtoVectorListener("hand_landmarks", ((e, t) => {
			for (let t of e) e = Ca(t), this.landmarks.push(Ko(e));
			G(this, t);
		})), this.g.attachEmptyPacketListener("hand_landmarks", ((e) => {
			G(this, e);
		})), this.g.attachProtoVectorListener("world_hand_landmarks", ((e, t) => {
			for (let t of e) e = ya(t), this.worldLandmarks.push(qo(e));
			G(this, t);
		})), this.g.attachEmptyPacketListener("world_hand_landmarks", ((e) => {
			G(this, e);
		})), this.g.attachProtoVectorListener("handedness", ((e, t) => {
			var n = this.handedness, r = n.push;
			let i = [];
			for (let t of e) {
				e = ia(t);
				let n = [];
				for (let t of e.g()) n.push({
					score: C(t, 2) ?? 0,
					index: _r(gr(t, 1), 0) ?? -1,
					categoryName: vr(t, 3) ?? "",
					displayName: vr(t, 4) ?? ""
				});
				i.push(n);
			}
			r.call(n, ...i), G(this, t);
		})), this.g.attachEmptyPacketListener("handedness", ((e) => {
			G(this, e);
		})), e = e.g(), this.setGraph(new Uint8Array(e), !0);
	}
};
Oc.prototype.detectForVideo = Oc.prototype.G, Oc.prototype.detect = Oc.prototype.F, Oc.prototype.setOptions = Oc.prototype.o, Oc.createFromModelPath = function(e, t) {
	return X(Oc, e, { baseOptions: { modelAssetPath: t } });
}, Oc.createFromModelBuffer = function(e, t) {
	return X(Oc, e, { baseOptions: { modelAssetBuffer: t } });
}, Oc.createFromOptions = function(e, t) {
	return X(Oc, e, t);
}, Oc.HAND_CONNECTIONS = Sc;
var kc = ec([0, 1], [1, 2], [2, 3], [3, 7], [0, 4], [4, 5], [5, 6], [6, 8], [9, 10], [11, 12], [11, 13], [13, 15], [15, 17], [15, 19], [15, 21], [17, 19], [12, 14], [14, 16], [16, 18], [16, 20], [16, 22], [18, 20], [11, 23], [12, 24], [23, 24], [23, 25], [24, 26], [25, 27], [26, 28], [27, 29], [28, 30], [29, 31], [30, 32], [27, 31], [28, 32]);
function Ac(e) {
	e.h = {
		faceLandmarks: [],
		faceBlendshapes: [],
		poseLandmarks: [],
		poseWorldLandmarks: [],
		poseSegmentationMasks: [],
		leftHandLandmarks: [],
		leftHandWorldLandmarks: [],
		rightHandLandmarks: [],
		rightHandWorldLandmarks: []
	};
}
function jc(e) {
	try {
		if (!e.I) return e.h;
		e.I(e.h);
	} finally {
		ps(e);
	}
}
function Mc(e, t) {
	e = Ca(e), t.push(Ko(e));
}
var Q = class extends cc {
	constructor(e, t) {
		super(new rc(e, t), "input_frames_image", null, !1), this.h = {
			faceLandmarks: [],
			faceBlendshapes: [],
			poseLandmarks: [],
			poseWorldLandmarks: [],
			poseSegmentationMasks: [],
			leftHandLandmarks: [],
			leftHandWorldLandmarks: [],
			rightHandLandmarks: [],
			rightHandWorldLandmarks: []
		}, this.outputPoseSegmentationMasks = this.outputFaceBlendshapes = !1, S(e = this.A = new Oo(), 0, 1, t = new H()), this.u = new mo(), S(this.A, 0, 2, this.u), this.aa = new So(), S(this.A, 0, 3, this.aa), this.j = new Ka(), S(this.A, 0, 4, this.j), this.H = new $a(), S(this.A, 0, 5, this.H), this.v = new wo(), S(this.A, 0, 6, this.v), this.D = new Eo(), S(this.A, 0, 7, this.D), w(this.j, 2, .5), w(this.j, 3, .3), w(this.H, 2, .5), w(this.v, 2, .5), w(this.v, 3, .3), w(this.D, 2, .5), w(this.u, 2, .5);
	}
	get baseOptions() {
		return x(this.A, H, 1);
	}
	set baseOptions(e) {
		S(this.A, 0, 1, e);
	}
	o(e) {
		return "minFaceDetectionConfidence" in e && w(this.j, 2, e.minFaceDetectionConfidence ?? .5), "minFaceSuppressionThreshold" in e && w(this.j, 3, e.minFaceSuppressionThreshold ?? .3), "minFacePresenceConfidence" in e && w(this.H, 2, e.minFacePresenceConfidence ?? .5), "outputFaceBlendshapes" in e && (this.outputFaceBlendshapes = !!e.outputFaceBlendshapes), "minPoseDetectionConfidence" in e && w(this.v, 2, e.minPoseDetectionConfidence ?? .5), "minPoseSuppressionThreshold" in e && w(this.v, 3, e.minPoseSuppressionThreshold ?? .3), "minPosePresenceConfidence" in e && w(this.D, 2, e.minPosePresenceConfidence ?? .5), "outputPoseSegmentationMasks" in e && (this.outputPoseSegmentationMasks = !!e.outputPoseSegmentationMasks), "minHandLandmarksConfidence" in e && w(this.u, 2, e.minHandLandmarksConfidence ?? .5), this.l(e);
	}
	F(e, t, n) {
		let r = typeof t == "function" ? {} : t;
		return this.I = typeof t == "function" ? t : n, Ac(this), ac(this, e, r), jc(this);
	}
	G(e, t, n, r) {
		let i = typeof n == "function" ? {} : n;
		return this.I = typeof n == "function" ? n : r, Ac(this), oc(this, e, i, t), jc(this);
	}
	m() {
		var e = new V();
		z(e, "input_frames_image"), B(e, "pose_landmarks"), B(e, "pose_world_landmarks"), B(e, "face_landmarks"), B(e, "left_hand_landmarks"), B(e, "left_hand_world_landmarks"), B(e, "right_hand_landmarks"), B(e, "right_hand_world_landmarks");
		let t = new Li(), n = new Ei();
		rr(n, 1, mn("type.googleapis.com/mediapipe.tasks.vision.holistic_landmarker.proto.HolisticLandmarkerGraphOptions"), ""), function(e, t) {
			if (t != null) if (Array.isArray(t)) y(e, 2, Ln(t, zn, void 0, void 0, !1));
			else {
				if (!(typeof t == "string" || t instanceof De || ye(t))) throw Error("invalid value in Any.value field: " + t + " expected a ByteString, a base64 encoded string, a Uint8Array or a jspb array");
				rr(e, 2, Ut(t, !1, !1), Te());
			}
		}(n, this.A.g());
		let r = new R();
		Wi(r, "mediapipe.tasks.vision.holistic_landmarker.HolisticLandmarkerGraph"), hr(r, 8, Ei, n), I(r, "IMAGE:input_frames_image"), L(r, "POSE_LANDMARKS:pose_landmarks"), L(r, "POSE_WORLD_LANDMARKS:pose_world_landmarks"), L(r, "FACE_LANDMARKS:face_landmarks"), L(r, "LEFT_HAND_LANDMARKS:left_hand_landmarks"), L(r, "LEFT_HAND_WORLD_LANDMARKS:left_hand_world_landmarks"), L(r, "RIGHT_HAND_LANDMARKS:right_hand_landmarks"), L(r, "RIGHT_HAND_WORLD_LANDMARKS:right_hand_world_landmarks"), r.o(t), Xi(e, r), ds(this, e), this.g.attachProtoListener("pose_landmarks", ((e, t) => {
			Mc(e, this.h.poseLandmarks), G(this, t);
		})), this.g.attachEmptyPacketListener("pose_landmarks", ((e) => {
			G(this, e);
		})), this.g.attachProtoListener("pose_world_landmarks", ((e, t) => {
			var n = this.h.poseWorldLandmarks;
			e = ya(e), n.push(qo(e)), G(this, t);
		})), this.g.attachEmptyPacketListener("pose_world_landmarks", ((e) => {
			G(this, e);
		})), this.outputPoseSegmentationMasks && (L(r, "POSE_SEGMENTATION_MASK:pose_segmentation_mask"), fs(this, "pose_segmentation_mask"), this.g.W("pose_segmentation_mask", ((e, t) => {
			this.h.poseSegmentationMasks = [sc(this, e, !0, !this.I)], G(this, t);
		})), this.g.attachEmptyPacketListener("pose_segmentation_mask", ((e) => {
			this.h.poseSegmentationMasks = [], G(this, e);
		}))), this.g.attachProtoListener("face_landmarks", ((e, t) => {
			Mc(e, this.h.faceLandmarks), G(this, t);
		})), this.g.attachEmptyPacketListener("face_landmarks", ((e) => {
			G(this, e);
		})), this.outputFaceBlendshapes && (B(e, "extra_blendshapes"), L(r, "FACE_BLENDSHAPES:extra_blendshapes"), this.g.attachProtoListener("extra_blendshapes", ((e, t) => {
			var n = this.h.faceBlendshapes;
			this.outputFaceBlendshapes && (e = ia(e), n.push(Wo(e.g() ?? []))), G(this, t);
		})), this.g.attachEmptyPacketListener("extra_blendshapes", ((e) => {
			G(this, e);
		}))), this.g.attachProtoListener("left_hand_landmarks", ((e, t) => {
			Mc(e, this.h.leftHandLandmarks), G(this, t);
		})), this.g.attachEmptyPacketListener("left_hand_landmarks", ((e) => {
			G(this, e);
		})), this.g.attachProtoListener("left_hand_world_landmarks", ((e, t) => {
			var n = this.h.leftHandWorldLandmarks;
			e = ya(e), n.push(qo(e)), G(this, t);
		})), this.g.attachEmptyPacketListener("left_hand_world_landmarks", ((e) => {
			G(this, e);
		})), this.g.attachProtoListener("right_hand_landmarks", ((e, t) => {
			Mc(e, this.h.rightHandLandmarks), G(this, t);
		})), this.g.attachEmptyPacketListener("right_hand_landmarks", ((e) => {
			G(this, e);
		})), this.g.attachProtoListener("right_hand_world_landmarks", ((e, t) => {
			var n = this.h.rightHandWorldLandmarks;
			e = ya(e), n.push(qo(e)), G(this, t);
		})), this.g.attachEmptyPacketListener("right_hand_world_landmarks", ((e) => {
			G(this, e);
		})), e = e.g(), this.setGraph(new Uint8Array(e), !0);
	}
};
Q.prototype.detectForVideo = Q.prototype.G, Q.prototype.detect = Q.prototype.F, Q.prototype.setOptions = Q.prototype.o, Q.createFromModelPath = function(e, t) {
	return X(Q, e, { baseOptions: { modelAssetPath: t } });
}, Q.createFromModelBuffer = function(e, t) {
	return X(Q, e, { baseOptions: { modelAssetBuffer: t } });
}, Q.createFromOptions = function(e, t) {
	return X(Q, e, t);
}, Q.HAND_CONNECTIONS = Sc, Q.POSE_CONNECTIONS = kc, Q.FACE_LANDMARKS_LIPS = uc, Q.FACE_LANDMARKS_LEFT_EYE = dc, Q.FACE_LANDMARKS_LEFT_EYEBROW = fc, Q.FACE_LANDMARKS_LEFT_IRIS = pc, Q.FACE_LANDMARKS_RIGHT_EYE = mc, Q.FACE_LANDMARKS_RIGHT_EYEBROW = hc, Q.FACE_LANDMARKS_RIGHT_IRIS = gc, Q.FACE_LANDMARKS_FACE_OVAL = _c, Q.FACE_LANDMARKS_CONTOURS = vc, Q.FACE_LANDMARKS_TESSELATION = yc;
var Nc = class extends cc {
	constructor(e, t) {
		super(new rc(e, t), "input_image", "norm_rect", !0), this.j = { classifications: [] }, S(e = this.h = new ko(), 0, 1, t = new H());
	}
	get baseOptions() {
		return x(this.h, H, 1);
	}
	set baseOptions(e) {
		S(this.h, 0, 1, e);
	}
	o(e) {
		return S(this.h, 0, 2, Uo(e, x(this.h, Ra, 2))), this.l(e);
	}
	ua(e, t) {
		return this.j = { classifications: [] }, ac(this, e, t), this.j;
	}
	va(e, t, n) {
		return this.j = { classifications: [] }, oc(this, e, n, t), this.j;
	}
	m() {
		var e = new V();
		z(e, "input_image"), z(e, "norm_rect"), B(e, "classifications");
		let t = new Li();
		xr(t, Ao, this.h);
		let n = new R();
		Wi(n, "mediapipe.tasks.vision.image_classifier.ImageClassifierGraph"), I(n, "IMAGE:input_image"), I(n, "NORM_RECT:norm_rect"), L(n, "CLASSIFICATIONS:classifications"), n.o(t), Xi(e, n), this.g.attachProtoListener("classifications", ((e, t) => {
			this.j = function(e) {
				let t = { classifications: dr(e, Da, 1).map(((e) => Wo(x(e, na, 4)?.g() ?? [], _r(gr(e, 2), 0), vr(e, 3)))) };
				return fn(Gn(e, 2)) != null && (t.timestampMs = _r(fn(Gn(e, 2)), 0)), t;
			}(Aa(e)), G(this, t);
		})), this.g.attachEmptyPacketListener("classifications", ((e) => {
			G(this, e);
		})), e = e.g(), this.setGraph(new Uint8Array(e), !0);
	}
};
Nc.prototype.classifyForVideo = Nc.prototype.va, Nc.prototype.classify = Nc.prototype.ua, Nc.prototype.setOptions = Nc.prototype.o, Nc.createFromModelPath = function(e, t) {
	return X(Nc, e, { baseOptions: { modelAssetPath: t } });
}, Nc.createFromModelBuffer = function(e, t) {
	return X(Nc, e, { baseOptions: { modelAssetBuffer: t } });
}, Nc.createFromOptions = function(e, t) {
	return X(Nc, e, t);
};
var Pc = class extends cc {
	constructor(e, t) {
		super(new rc(e, t), "image_in", "norm_rect", !0), this.h = new jo(), this.embeddings = { embeddings: [] }, S(e = this.h, 0, 1, t = new H());
	}
	get baseOptions() {
		return x(this.h, H, 1);
	}
	set baseOptions(e) {
		S(this.h, 0, 1, e);
	}
	o(e) {
		var t = this.h, n = x(this.h, Ba, 2);
		return n = n ? n.clone() : new Ba(), e.l2Normalize === void 0 ? "l2Normalize" in e && y(n, 1) : yr(n, 1, e.l2Normalize), e.quantize === void 0 ? "quantize" in e && y(n, 2) : yr(n, 2, e.quantize), S(t, 0, 2, n), this.l(e);
	}
	Ba(e, t) {
		return ac(this, e, t), this.embeddings;
	}
	Ca(e, t, n) {
		return oc(this, e, n, t), this.embeddings;
	}
	m() {
		var e = new V();
		z(e, "image_in"), z(e, "norm_rect"), B(e, "embeddings_out");
		let t = new Li();
		xr(t, Mo, this.h);
		let n = new R();
		Wi(n, "mediapipe.tasks.vision.image_embedder.ImageEmbedderGraph"), I(n, "IMAGE:image_in"), I(n, "NORM_RECT:norm_rect"), L(n, "EMBEDDINGS:embeddings_out"), n.o(t), Xi(e, n), this.g.attachProtoListener("embeddings_out", ((e, t) => {
			e = La(e), this.embeddings = function(e) {
				return {
					embeddings: dr(e, Na, 1).map(((e) => {
						let t = {
							headIndex: _r(gr(e, 3), 0) ?? -1,
							headName: vr(e, 4) ?? ""
						};
						if (lr(e, ja, or(e, 1)) !== void 0) e = Zn(e = x(e, ja, or(e, 1)), 1, tn), t.floatEmbedding = e.slice();
						else {
							let n = new Uint8Array();
							t.quantizedEmbedding = x(e, Ma, or(e, 2))?.qa()?.h() ?? n;
						}
						return t;
					})),
					timestampMs: _r(fn(Gn(e, 2)), 0)
				};
			}(e), G(this, t);
		})), this.g.attachEmptyPacketListener("embeddings_out", ((e) => {
			G(this, e);
		})), e = e.g(), this.setGraph(new Uint8Array(e), !0);
	}
};
Pc.cosineSimilarity = function(e, t) {
	if (e.floatEmbedding && t.floatEmbedding) e = Yo(e.floatEmbedding, t.floatEmbedding);
	else {
		if (!e.quantizedEmbedding || !t.quantizedEmbedding) throw Error("Cannot compute cosine similarity between quantized and float embeddings.");
		e = Yo(Jo(e.quantizedEmbedding), Jo(t.quantizedEmbedding));
	}
	return e;
}, Pc.prototype.embedForVideo = Pc.prototype.Ca, Pc.prototype.embed = Pc.prototype.Ba, Pc.prototype.setOptions = Pc.prototype.o, Pc.createFromModelPath = function(e, t) {
	return X(Pc, e, { baseOptions: { modelAssetPath: t } });
}, Pc.createFromModelBuffer = function(e, t) {
	return X(Pc, e, { baseOptions: { modelAssetBuffer: t } });
}, Pc.createFromOptions = function(e, t) {
	return X(Pc, e, t);
};
var Fc = class {
	constructor(e, t, n) {
		this.confidenceMasks = e, this.categoryMask = t, this.qualityScores = n;
	}
	close() {
		this.confidenceMasks?.forEach(((e) => {
			e.close();
		})), this.categoryMask?.close();
	}
};
function Ic(e) {
	e.categoryMask = void 0, e.confidenceMasks = void 0, e.qualityScores = void 0;
}
function Lc(e) {
	try {
		let t = new Fc(e.confidenceMasks, e.categoryMask, e.qualityScores);
		if (!e.j) return t;
		e.j(t);
	} finally {
		ps(e);
	}
}
Fc.prototype.close = Fc.prototype.close;
var $ = class extends cc {
	constructor(e, t) {
		super(new rc(e, t), "image_in", "norm_rect", !1), this.u = [], this.outputCategoryMask = !1, this.outputConfidenceMasks = !0, this.h = new Lo(), this.v = new No(), S(this.h, 0, 3, this.v), S(e = this.h, 0, 1, t = new H());
	}
	get baseOptions() {
		return x(this.h, H, 1);
	}
	set baseOptions(e) {
		S(this.h, 0, 1, e);
	}
	o(e) {
		return e.displayNamesLocale === void 0 ? "displayNamesLocale" in e && y(this.h, 2) : y(this.h, 2, mn(e.displayNamesLocale)), "outputCategoryMask" in e && (this.outputCategoryMask = e.outputCategoryMask ?? !1), "outputConfidenceMasks" in e && (this.outputConfidenceMasks = e.outputConfidenceMasks ?? !0), super.l(e);
	}
	L() {
		(function(e) {
			let t = dr(e.fa(), R, 1).filter(((e) => vr(e, 1).includes("mediapipe.tasks.TensorsToSegmentationCalculator")));
			if (e.u = [], 1 < t.length) throw Error("The graph has more than one mediapipe.tasks.TensorsToSegmentationCalculator.");
			t.length === 1 && (x(t[0], Li, 7)?.l()?.g() ?? /* @__PURE__ */ new Map()).forEach(((t, n) => {
				e.u[Number(n)] = vr(t, 1);
			}));
		})(this);
	}
	ga(e, t, n) {
		let r = typeof t == "function" ? {} : t;
		return this.j = typeof t == "function" ? t : n, Ic(this), ac(this, e, r), Lc(this);
	}
	Na(e, t, n, r) {
		let i = typeof n == "function" ? {} : n;
		return this.j = typeof n == "function" ? n : r, Ic(this), oc(this, e, i, t), Lc(this);
	}
	Fa() {
		return this.u;
	}
	m() {
		var e = new V();
		z(e, "image_in"), z(e, "norm_rect");
		let t = new Li();
		xr(t, Ro, this.h);
		let n = new R();
		Wi(n, "mediapipe.tasks.vision.image_segmenter.ImageSegmenterGraph"), I(n, "IMAGE:image_in"), I(n, "NORM_RECT:norm_rect"), n.o(t), Xi(e, n), ds(this, e), this.outputConfidenceMasks && (B(e, "confidence_masks"), L(n, "CONFIDENCE_MASKS:confidence_masks"), fs(this, "confidence_masks"), this.g.da("confidence_masks", ((e, t) => {
			this.confidenceMasks = e.map(((e) => sc(this, e, !0, !this.j))), G(this, t);
		})), this.g.attachEmptyPacketListener("confidence_masks", ((e) => {
			this.confidenceMasks = [], G(this, e);
		}))), this.outputCategoryMask && (B(e, "category_mask"), L(n, "CATEGORY_MASK:category_mask"), fs(this, "category_mask"), this.g.W("category_mask", ((e, t) => {
			this.categoryMask = sc(this, e, !1, !this.j), G(this, t);
		})), this.g.attachEmptyPacketListener("category_mask", ((e) => {
			this.categoryMask = void 0, G(this, e);
		}))), B(e, "quality_scores"), L(n, "QUALITY_SCORES:quality_scores"), this.g.attachFloatVectorListener("quality_scores", ((e, t) => {
			this.qualityScores = e, G(this, t);
		})), this.g.attachEmptyPacketListener("quality_scores", ((e) => {
			this.categoryMask = void 0, G(this, e);
		})), e = e.g(), this.setGraph(new Uint8Array(e), !0);
	}
};
$.prototype.getLabels = $.prototype.Fa, $.prototype.segmentForVideo = $.prototype.Na, $.prototype.segment = $.prototype.ga, $.prototype.setOptions = $.prototype.o, $.createFromModelPath = function(e, t) {
	return X($, e, { baseOptions: { modelAssetPath: t } });
}, $.createFromModelBuffer = function(e, t) {
	return X($, e, { baseOptions: { modelAssetBuffer: t } });
}, $.createFromOptions = function(e, t) {
	return X($, e, t);
};
var Rc = class {
	constructor(e, t, n) {
		this.confidenceMasks = e, this.categoryMask = t, this.qualityScores = n;
	}
	close() {
		this.confidenceMasks?.forEach(((e) => {
			e.close();
		})), this.categoryMask?.close();
	}
};
Rc.prototype.close = Rc.prototype.close;
var zc = class extends T {
	constructor(e) {
		super(e);
	}
}, Bc = [
	0,
	A,
	-2
], Vc = [
	0,
	oi,
	-3,
	j
], Hc = [
	0,
	oi,
	-3,
	j,
	oi,
	-1
], Uc = [0, Hc], Wc = [
	0,
	Uc,
	Bc
], Gc = [
	0,
	Hc,
	Bc
], Kc = [
	0,
	Hc,
	A,
	-1
], qc = [
	0,
	Kc,
	Bc
], Jc = [
	0,
	oi,
	-3,
	j,
	Bc,
	-1
], Yc = [
	0,
	oi,
	-3,
	j,
	bi
], Xc = class extends T {
	constructor(e) {
		super(e);
	}
}, Zc = [
	0,
	oi,
	-1,
	j
], Qc = class extends T {
	constructor() {
		super();
	}
};
Qc.B = [1];
var $c = class extends T {
	constructor(e) {
		super(e);
	}
}, el = [
	1,
	2,
	3,
	4,
	5,
	6,
	7,
	8,
	9,
	10,
	14,
	15
], tl = [
	0,
	el,
	P,
	Hc,
	P,
	Gc,
	P,
	Uc,
	P,
	Wc,
	P,
	Zc,
	P,
	Yc,
	P,
	Vc,
	P,
	[
		0,
		N,
		oi,
		-2,
		j,
		A,
		j,
		-1,
		2,
		oi,
		Bc
	],
	P,
	Kc,
	P,
	qc,
	oi,
	Bc,
	N,
	P,
	Jc,
	P,
	[
		0,
		O,
		Zc
	]
], nl = [
	0,
	N,
	A,
	-1,
	j
], rl = class extends T {
	constructor() {
		super();
	}
};
rl.B = [1], rl.prototype.g = Ti([
	0,
	O,
	tl,
	N,
	nl
]);
var il = class extends cc {
	constructor(e, t) {
		super(new rc(e, t), "image_in", "norm_rect_in", !1), this.outputCategoryMask = !1, this.outputConfidenceMasks = !0, this.h = new Lo(), this.v = new No(), S(this.h, 0, 3, this.v), S(e = this.h, 0, 1, t = new H());
	}
	get baseOptions() {
		return x(this.h, H, 1);
	}
	set baseOptions(e) {
		S(this.h, 0, 1, e);
	}
	o(e) {
		return "outputCategoryMask" in e && (this.outputCategoryMask = e.outputCategoryMask ?? !1), "outputConfidenceMasks" in e && (this.outputConfidenceMasks = e.outputConfidenceMasks ?? !0), super.l(e);
	}
	ga(e, t, n, r) {
		let i = typeof n == "function" ? {} : n;
		this.j = typeof n == "function" ? n : r, this.qualityScores = this.categoryMask = this.confidenceMasks = void 0, n = this.J + 1, r = new rl();
		let a = new $c();
		var o = new zc();
		if (br(o, 1, 255), S(a, 0, 12, o), t.keypoint && t.scribble) throw Error("Cannot provide both keypoint and scribble.");
		if (t.keypoint) {
			var s = new Xc();
			yr(s, 3, !0), w(s, 1, t.keypoint.x), w(s, 2, t.keypoint.y), fr(a, 5, el, s);
		} else {
			if (!t.scribble) throw Error("Must provide either a keypoint or a scribble.");
			for (s of (o = new Qc(), t.scribble)) yr(t = new Xc(), 3, !0), w(t, 1, s.x), w(t, 2, s.y), hr(o, 1, Xc, t);
			fr(a, 15, el, o);
		}
		hr(r, 1, $c, a), this.g.addProtoToStream(r.g(), "drishti.RenderData", "roi_in", n), ac(this, e, i);
		t: {
			try {
				let e = new Rc(this.confidenceMasks, this.categoryMask, this.qualityScores);
				if (!this.j) {
					var c = e;
					break t;
				}
				this.j(e);
			} finally {
				ps(this);
			}
			c = void 0;
		}
		return c;
	}
	m() {
		var e = new V();
		z(e, "image_in"), z(e, "roi_in"), z(e, "norm_rect_in");
		let t = new Li();
		xr(t, Ro, this.h);
		let n = new R();
		Wi(n, "mediapipe.tasks.vision.interactive_segmenter.InteractiveSegmenterGraph"), I(n, "IMAGE:image_in"), I(n, "ROI:roi_in"), I(n, "NORM_RECT:norm_rect_in"), n.o(t), Xi(e, n), ds(this, e), this.outputConfidenceMasks && (B(e, "confidence_masks"), L(n, "CONFIDENCE_MASKS:confidence_masks"), fs(this, "confidence_masks"), this.g.da("confidence_masks", ((e, t) => {
			this.confidenceMasks = e.map(((e) => sc(this, e, !0, !this.j))), G(this, t);
		})), this.g.attachEmptyPacketListener("confidence_masks", ((e) => {
			this.confidenceMasks = [], G(this, e);
		}))), this.outputCategoryMask && (B(e, "category_mask"), L(n, "CATEGORY_MASK:category_mask"), fs(this, "category_mask"), this.g.W("category_mask", ((e, t) => {
			this.categoryMask = sc(this, e, !1, !this.j), G(this, t);
		})), this.g.attachEmptyPacketListener("category_mask", ((e) => {
			this.categoryMask = void 0, G(this, e);
		}))), B(e, "quality_scores"), L(n, "QUALITY_SCORES:quality_scores"), this.g.attachFloatVectorListener("quality_scores", ((e, t) => {
			this.qualityScores = e, G(this, t);
		})), this.g.attachEmptyPacketListener("quality_scores", ((e) => {
			this.categoryMask = void 0, G(this, e);
		})), e = e.g(), this.setGraph(new Uint8Array(e), !0);
	}
};
il.prototype.segment = il.prototype.ga, il.prototype.setOptions = il.prototype.o, il.createFromModelPath = function(e, t) {
	return X(il, e, { baseOptions: { modelAssetPath: t } });
}, il.createFromModelBuffer = function(e, t) {
	return X(il, e, { baseOptions: { modelAssetBuffer: t } });
}, il.createFromOptions = function(e, t) {
	return X(il, e, t);
};
var al = class extends cc {
	constructor(e, t) {
		super(new rc(e, t), "input_frame_gpu", "norm_rect", !1), this.j = { detections: [] }, S(e = this.h = new zo(), 0, 1, t = new H());
	}
	get baseOptions() {
		return x(this.h, H, 1);
	}
	set baseOptions(e) {
		S(this.h, 0, 1, e);
	}
	o(e) {
		return e.displayNamesLocale === void 0 ? "displayNamesLocale" in e && y(this.h, 2) : y(this.h, 2, mn(e.displayNamesLocale)), e.maxResults === void 0 ? "maxResults" in e && y(this.h, 3) : br(this.h, 3, e.maxResults), e.scoreThreshold === void 0 ? "scoreThreshold" in e && y(this.h, 4) : w(this.h, 4, e.scoreThreshold), e.categoryAllowlist === void 0 ? "categoryAllowlist" in e && y(this.h, 5) : nr(this.h, 5, e.categoryAllowlist), e.categoryDenylist === void 0 ? "categoryDenylist" in e && y(this.h, 6) : nr(this.h, 6, e.categoryDenylist), this.l(e);
	}
	F(e, t) {
		return this.j = { detections: [] }, ac(this, e, t), this.j;
	}
	G(e, t, n) {
		return this.j = { detections: [] }, oc(this, e, n, t), this.j;
	}
	m() {
		var e = new V();
		z(e, "input_frame_gpu"), z(e, "norm_rect"), B(e, "detections");
		let t = new Li();
		xr(t, Bo, this.h);
		let n = new R();
		Wi(n, "mediapipe.tasks.vision.ObjectDetectorGraph"), I(n, "IMAGE:input_frame_gpu"), I(n, "NORM_RECT:norm_rect"), L(n, "DETECTIONS:detections"), n.o(t), Xi(e, n), this.g.attachProtoVectorListener("detections", ((e, t) => {
			for (let t of e) e = ha(t), this.j.detections.push(Go(e));
			G(this, t);
		})), this.g.attachEmptyPacketListener("detections", ((e) => {
			G(this, e);
		})), e = e.g(), this.setGraph(new Uint8Array(e), !0);
	}
};
al.prototype.detectForVideo = al.prototype.G, al.prototype.detect = al.prototype.F, al.prototype.setOptions = al.prototype.o, al.createFromModelPath = async function(e, t) {
	return X(al, e, { baseOptions: { modelAssetPath: t } });
}, al.createFromModelBuffer = function(e, t) {
	return X(al, e, { baseOptions: { modelAssetBuffer: t } });
}, al.createFromOptions = function(e, t) {
	return X(al, e, t);
};
var ol = class {
	constructor(e, t, n) {
		this.landmarks = e, this.worldLandmarks = t, this.segmentationMasks = n;
	}
	close() {
		this.segmentationMasks?.forEach(((e) => {
			e.close();
		}));
	}
};
function sl(e) {
	e.landmarks = [], e.worldLandmarks = [], e.segmentationMasks = void 0;
}
function cl(e) {
	try {
		let t = new ol(e.landmarks, e.worldLandmarks, e.segmentationMasks);
		if (!e.j) return t;
		e.j(t);
	} finally {
		ps(e);
	}
}
ol.prototype.close = ol.prototype.close;
var ll = class extends cc {
	constructor(e, t) {
		super(new rc(e, t), "image_in", "norm_rect", !1), this.landmarks = [], this.worldLandmarks = [], this.outputSegmentationMasks = !1, S(e = this.h = new Vo(), 0, 1, t = new H()), this.D = new Eo(), S(this.h, 0, 3, this.D), this.v = new wo(), S(this.h, 0, 2, this.v), br(this.v, 4, 1), w(this.v, 2, .5), w(this.D, 2, .5), w(this.h, 4, .5);
	}
	get baseOptions() {
		return x(this.h, H, 1);
	}
	set baseOptions(e) {
		S(this.h, 0, 1, e);
	}
	o(e) {
		return "numPoses" in e && br(this.v, 4, e.numPoses ?? 1), "minPoseDetectionConfidence" in e && w(this.v, 2, e.minPoseDetectionConfidence ?? .5), "minTrackingConfidence" in e && w(this.h, 4, e.minTrackingConfidence ?? .5), "minPosePresenceConfidence" in e && w(this.D, 2, e.minPosePresenceConfidence ?? .5), "outputSegmentationMasks" in e && (this.outputSegmentationMasks = e.outputSegmentationMasks ?? !1), this.l(e);
	}
	F(e, t, n) {
		let r = typeof t == "function" ? {} : t;
		return this.j = typeof t == "function" ? t : n, sl(this), ac(this, e, r), cl(this);
	}
	G(e, t, n, r) {
		let i = typeof n == "function" ? {} : n;
		return this.j = typeof n == "function" ? n : r, sl(this), oc(this, e, i, t), cl(this);
	}
	m() {
		var e = new V();
		z(e, "image_in"), z(e, "norm_rect"), B(e, "normalized_landmarks"), B(e, "world_landmarks"), B(e, "segmentation_masks");
		let t = new Li();
		xr(t, Ho, this.h);
		let n = new R();
		Wi(n, "mediapipe.tasks.vision.pose_landmarker.PoseLandmarkerGraph"), I(n, "IMAGE:image_in"), I(n, "NORM_RECT:norm_rect"), L(n, "NORM_LANDMARKS:normalized_landmarks"), L(n, "WORLD_LANDMARKS:world_landmarks"), n.o(t), Xi(e, n), ds(this, e), this.g.attachProtoVectorListener("normalized_landmarks", ((e, t) => {
			this.landmarks = [];
			for (let t of e) e = Ca(t), this.landmarks.push(Ko(e));
			G(this, t);
		})), this.g.attachEmptyPacketListener("normalized_landmarks", ((e) => {
			this.landmarks = [], G(this, e);
		})), this.g.attachProtoVectorListener("world_landmarks", ((e, t) => {
			this.worldLandmarks = [];
			for (let t of e) e = ya(t), this.worldLandmarks.push(qo(e));
			G(this, t);
		})), this.g.attachEmptyPacketListener("world_landmarks", ((e) => {
			this.worldLandmarks = [], G(this, e);
		})), this.outputSegmentationMasks && (L(n, "SEGMENTATION_MASK:segmentation_masks"), fs(this, "segmentation_masks"), this.g.da("segmentation_masks", ((e, t) => {
			this.segmentationMasks = e.map(((e) => sc(this, e, !0, !this.j))), G(this, t);
		})), this.g.attachEmptyPacketListener("segmentation_masks", ((e) => {
			this.segmentationMasks = [], G(this, e);
		}))), e = e.g(), this.setGraph(new Uint8Array(e), !0);
	}
};
ll.prototype.detectForVideo = ll.prototype.G, ll.prototype.detect = ll.prototype.F, ll.prototype.setOptions = ll.prototype.o, ll.createFromModelPath = function(e, t) {
	return X(ll, e, { baseOptions: { modelAssetPath: t } });
}, ll.createFromModelBuffer = function(e, t) {
	return X(ll, e, { baseOptions: { modelAssetBuffer: t } });
}, ll.createFromOptions = function(e, t) {
	return X(ll, e, t);
}, ll.POSE_CONNECTIONS = kc;
//#endregion
//#region node_modules/.pnpm/@livekit+track-processors@0.8.1_@types+dom-mediacapture-transform@0.1.12_livekit-client_03ef71a89a07356592b34222bacb8438/node_modules/@livekit/track-processors/dist/index.mjs
var ul = /* @__PURE__ */ ((e) => (e[e.trace = 0] = "trace", e[e.debug = 1] = "debug", e[e.info = 2] = "info", e[e.warn = 3] = "warn", e[e.error = 4] = "error", e[e.silent = 5] = "silent", e))(ul || {}), dl = /* @__PURE__ */ ((e) => (e.ProcessorWrapper = "livekit-processor-wrapper", e.BackgroundProcessor = "livekit-background-processor", e.WebGl = "livekit-track-processor-web-gl", e))(dl || {}), fl = ml("livekit"), pl = Object.values(dl).map((e) => ml(e));
fl.setDefaultLevel(2);
function ml(t) {
	return e(t);
}
function hl(e, t) {
	if (t) ml(t).setLevel(e);
	else for (let t of pl) t.setLevel(e);
}
function gl(e, t) {
	(t ? [t] : pl).forEach((t) => {
		let n = t.methodFactory;
		t.methodFactory = (t, r, i) => {
			let a = n(t, r, i), o = ul[t], s = o >= r && o < 5;
			return (t, n) => {
				n ? a(t, n) : a(t), s && e(o, t, n);
			};
		}, t.setLevel(t.getLevel());
	});
}
var _l = ml("livekit-processor-wrapper"), vl = "onmessage = (e) => { setTimeout(() => postMessage(0), e.data); };";
function yl(e, t) {
	let n = bl(e, t), r;
	try {
		let e = URL.createObjectURL(new Blob([vl], { type: "text/javascript" }));
		r = new Worker(e), URL.revokeObjectURL(e);
	} catch (e) {
		return _l.warn("Frame ticker worker could not be created, falling back to a window timer", e), n;
	}
	return r.onmessage = () => {
		n?.stop(), n = void 0;
		try {
			t();
		} finally {
			r.postMessage(e);
		}
	}, r.onerror = (i) => {
		r.terminate(), _l.warn("Frame ticker worker failed, falling back to a window timer", i), n ??= bl(e, t);
	}, r.postMessage(e), { stop() {
		r.terminate(), n?.stop();
	} };
}
function bl(e, t) {
	let n = setTimeout(function r() {
		n = setTimeout(r, e), t();
	}, e);
	return { stop() {
		clearTimeout(n);
	} };
}
var xl = () => typeof OffscreenCanvas < "u";
async function Sl(e) {
	return new Promise((t) => setTimeout(t, e));
}
async function Cl(e) {
	await Sl(10);
	let t = Date.now();
	for (; Date.now() - t < 500;) {
		let { width: t, height: n } = e.getSettings();
		if (t && n) return {
			width: t,
			height: n
		};
		await Sl(50);
	}
	return {
		width: void 0,
		height: void 0
	};
}
function wl(e, t) {
	if (xl()) return new OffscreenCanvas(e, t);
	let n = document.createElement("canvas");
	return n.width = e, n.height = t, n;
}
var Tl = class e {
	constructor(e, t, n = {}) {
		if (this.useStreamFallback = !1, this.processingEnabled = !1, this.log = ml("livekit-processor-wrapper"), this.lifecycleState = "idle", this.name = t, this.transformer = e, this.maxFps = n.maxFps ?? 30, !Number.isFinite(this.maxFps) || this.maxFps <= 0) throw RangeError(`maxFps must be a positive number, got ${this.maxFps}`);
	}
	static get isSupported() {
		let e = typeof MediaStreamTrackGenerator < "u" && typeof MediaStreamTrackProcessor < "u", t = typeof HTMLCanvasElement < "u" && typeof VideoFrame < "u" && "captureStream" in HTMLCanvasElement.prototype;
		return e || t;
	}
	static get hasModernApiSupport() {
		return typeof MediaStreamTrackGenerator < "u" && typeof MediaStreamTrackProcessor < "u";
	}
	async setup(t) {
		this.source = t.track;
		let { width: n, height: r } = await Cl(this.source);
		if (this.sourceDummy = t.element, !(this.sourceDummy instanceof HTMLVideoElement)) throw TypeError("Currently only video transformers are supported");
		if (this.sourceDummy instanceof HTMLVideoElement && (this.sourceDummy.height = r ?? 300, this.sourceDummy.width = n ?? 300), this.useStreamFallback = !e.hasModernApiSupport, this.useStreamFallback) {
			let e = document.querySelector("canvas[data-livekit-processor=\"" + this.name + "\"]");
			e ? (this.displayCanvas = e, this.displayCanvas.width = n ?? 300, this.displayCanvas.height = r ?? 300) : (this.displayCanvas = document.createElement("canvas"), this.displayCanvas.width = n ?? 300, this.displayCanvas.height = r ?? 300, this.displayCanvas.style.display = "none", this.displayCanvas.dataset.livekitProcessor = this.name, document.body.appendChild(this.displayCanvas)), this.renderContext = this.displayCanvas.getContext("2d"), this.capturedStream = this.displayCanvas.captureStream(), this.canvas = wl(n ?? 300, r ?? 300);
		} else this.processor = new MediaStreamTrackProcessor({ track: this.source }), this.trackGenerator = new MediaStreamTrackGenerator({
			kind: "video",
			signalTarget: this.source
		}), this.canvas = wl(n ?? 300, r ?? 300);
	}
	async init(e) {
		if (this.log.debug("Init called"), this.lifecycleState = "initializing", await this.setup(e), !this.canvas) throw TypeError("Expected canvas to be defined after setup");
		await this.transformer.init({
			outputCanvas: this.canvas,
			inputElement: this.sourceDummy
		}), this.useStreamFallback ? this.initFallbackPath() : this.initStreamProcessorPath(), this.lifecycleState = "running";
	}
	initStreamProcessorPath() {
		if (!this.processor || !this.trackGenerator) throw TypeError("Expected processor and trackGenerator to be defined for stream processor path");
		this.processor.readable.pipeThrough(this.transformer.transformer).pipeTo(this.trackGenerator.writable).then(() => this.handleMediaExhausted()).catch((e) => {
			e instanceof DOMException && e.name === "AbortError" ? this.log.log("stream processor path aborted") : e instanceof DOMException && e.name === "InvalidStateError" && e.message === "Stream closed" ? (this.log.log("stream processor underlying stream closed"), this.handleMediaExhausted()) : (this.log.error("error when trying to pipe", e), this.destroy());
		}), this.processedTrack = this.trackGenerator;
	}
	initFallbackPath() {
		if (!this.capturedStream || !this.source || !this.canvas || !this.renderContext) throw TypeError("Missing required components for fallback implementation");
		this.processedTrack = this.capturedStream.getVideoTracks()[0], this.processingEnabled = !0, this.frameCallback = (e) => {
			if (!this.processingEnabled || !e) {
				e.close();
				return;
			}
			let t = { enqueue: (e) => {
				if (this.renderContext && this.displayCanvas) {
					let { videoWidth: t, videoHeight: n } = this.sourceDummy;
					t && n && (this.displayCanvas.width !== t || this.displayCanvas.height !== n) && (this.displayCanvas.width = t, this.displayCanvas.height = n), this.renderContext.drawImage(e, 0, 0, this.displayCanvas.width, this.displayCanvas.height), e.close();
				}
			} };
			try {
				this.transformer.transform(e, t);
			} catch (t) {
				this.log.error("Error in transform:", t), e.close();
			}
		}, this.startRenderLoop();
	}
	startRenderLoop() {
		if (!this.sourceDummy || !(this.sourceDummy instanceof HTMLVideoElement)) {
			this.handleMediaExhausted();
			return;
		}
		let e = -1, t = performance.now(), n = this.sourceDummy, r = 1e3 / this.maxFps, i = this.maxFps, a = [], o = 0, s = 0, c = 0, l = -Infinity, u = () => {
			if (!this.processingEnabled || !this.sourceDummy || !(this.sourceDummy instanceof HTMLVideoElement)) {
				this.handleMediaExhausted();
				return;
			}
			if (this.sourceDummy.paused) {
				performance.now() - l > 1e3 && (l = performance.now(), this.log.warn("Video is paused, trying to play"), this.sourceDummy.play().catch((e) => this.log.warn("Unable to play video", e)));
				return;
			}
			let u = n.currentTime, d = performance.now(), ee = u !== e;
			if (ee) {
				if (o > 0) {
					let e = d - o;
					a.push(e), a.length > 10 && a.shift(), a.length > 2 && (i = 1e3 / (a.reduce((e, t) => e + t, 0) / a.length), (typeof window < "u" && window.location.hostname === "localhost" || window.location.hostname === "127.0.0.1") && d - c > 5e3 && (this.log.debug(`[${this.name}] Estimated video FPS: ${i.toFixed(1)}, Processing at: ${(s / 5).toFixed(1)} FPS`), s = 0, c = d));
				}
				o = d;
			}
			if (ee && d >= t) {
				e = u, t = Math.max(d, t + r), s++;
				try {
					if (n.readyState >= HTMLMediaElement.HAVE_CURRENT_DATA) {
						let e = new VideoFrame(n);
						this.frameCallback ? this.frameCallback(e) : e.close();
					}
				} catch (e) {
					this.log.error("Error in render loop:", e);
				}
			}
		};
		this.frameTicker = yl(1e3 / (this.maxFps * 2), u);
	}
	async restart(e) {
		this.log.debug("Restart called"), await this.destroy({ willProcessorRestart: !0 }), await this.init(e);
	}
	async restartTransformer(...e) {
		await this.transformer.restart(e[0]);
	}
	async updateTransformerOptions(...e) {
		await this.transformer.update(e[0]);
	}
	async handleMediaExhausted() {
		this.log.debug("Media was exhausted from source"), this.lifecycleState === "running" && (this.lifecycleState = "media-exhausted", await this.cleanup());
	}
	async cleanup() {
		var e, t, n;
		this.useStreamFallback ? (this.processingEnabled = !1, (e = this.frameTicker) == null || e.stop(), this.frameTicker = void 0, this.displayCanvas && this.displayCanvas.parentNode && this.displayCanvas.parentNode.removeChild(this.displayCanvas), (t = this.capturedStream) == null || t.getTracks().forEach((e) => e.stop())) : (await (this.processor?.writableControl)?.close(), (n = this.trackGenerator) == null || n.stop());
	}
	async destroy(e = { willProcessorRestart: !1 }) {
		switch (this.log.debug(`Destroy called - lifecycleState=${this.lifecycleState}, transformerDestroyOptions=${JSON.stringify(e)}`), this.lifecycleState) {
			case "running":
			case "media-exhausted":
				this.lifecycleState = "destroying", await this.cleanup(), await this.transformer.destroy(e), this.lifecycleState = "destroyed";
				break;
			default: break;
		}
	}
}, El = { "@mediapipe/tasks-vision": "0.10.14" }, Dl = ml("livekit-track-processor-web-gl");
function Ol(e, t) {
	let n = e.TEXTURE0 + t;
	e.activeTexture(n);
	let r = e.createTexture();
	return e.bindTexture(e.TEXTURE_2D, r), e.texParameteri(e.TEXTURE_2D, e.TEXTURE_WRAP_S, e.CLAMP_TO_EDGE), e.texParameteri(e.TEXTURE_2D, e.TEXTURE_WRAP_T, e.CLAMP_TO_EDGE), e.texParameteri(e.TEXTURE_2D, e.TEXTURE_MIN_FILTER, e.LINEAR), e.texParameteri(e.TEXTURE_2D, e.TEXTURE_MAG_FILTER, e.LINEAR), e.bindTexture(e.TEXTURE_2D, r), r;
}
function kl(e, t, n) {
	let r = e.createShader(t);
	if (e.shaderSource(r, n), e.compileShader(r), !e.getShaderParameter(r, e.COMPILE_STATUS)) throw Dl.error("Shader compile failed:", e.getShaderInfoLog(r)), e.deleteShader(r), Error("Shader compile failed");
	return r;
}
function Al(e, t, n) {
	let r = e.createProgram();
	if (e.attachShader(r, t), e.attachShader(r, n), e.linkProgram(r), !e.getProgramParameter(r, e.LINK_STATUS)) throw Dl.error("Program link failed:", e.getProgramInfoLog(r)), Error("Program link failed");
	return r;
}
function jl(e, t, n, r) {
	e.bindTexture(e.TEXTURE_2D, t), e.texImage2D(e.TEXTURE_2D, 0, e.RGBA, n, r, 0, e.RGBA, e.UNSIGNED_BYTE, null);
}
function Ml(e, t, n, r) {
	let i = e.createFramebuffer();
	if (e.bindFramebuffer(e.FRAMEBUFFER, i), e.framebufferTexture2D(e.FRAMEBUFFER, e.COLOR_ATTACHMENT0, e.TEXTURE_2D, t, 0), jl(e, t, n, r), e.checkFramebufferStatus(e.FRAMEBUFFER) !== e.FRAMEBUFFER_COMPLETE) throw Error("Framebuffer not complete");
	return e.bindFramebuffer(e.FRAMEBUFFER, null), i;
}
function Nl(e) {
	let t = e.createBuffer();
	return e.bindBuffer(e.ARRAY_BUFFER, t), e.bufferData(e.ARRAY_BUFFER, new Float32Array([
		-1,
		-1,
		-1,
		1,
		1,
		1,
		-1,
		-1,
		1,
		1,
		1,
		-1
	]), e.STATIC_DRAW), t;
}
async function Pl(e, t, n) {
	let r = e.width / e.height, i = t / n, a = 0, o = 0, s = e.width, c = e.height;
	return r > i ? (s = Math.round(e.height * i), a = Math.round((e.width - s) / 2)) : r < i && (c = Math.round(e.width / i), o = Math.round((e.height - c) / 2)), createImageBitmap(e, a, o, s, c, {
		resizeWidth: t,
		resizeHeight: n,
		resizeQuality: "medium"
	});
}
var Fl;
function Il() {
	return Fl || (Fl = new ImageData(2, 2), Fl.data[0] = 0, Fl.data[1] = 0, Fl.data[2] = 0, Fl.data[3] = 0), Fl;
}
var Ll = (e) => e, Rl = (e = !0) => `#version 300 es
  in vec2 position;
  out vec2 texCoords;

  void main() {
    texCoords = (position + 1.0) / 2.0;
    texCoords.y = ${e ? "1.0 - texCoords.y" : "texCoords.y"};
    gl_Position = vec4(position, 0, 1.0);
  }
`, zl = Ll`#version 300 es
  precision mediump float;
  in vec2 texCoords;
  uniform sampler2D u_texture;
  uniform vec2 u_texelSize;
  uniform vec2 u_direction;
  uniform float u_radius;
  out vec4 fragColor;

  void main() {
    float sigma = u_radius;
    float twoSigmaSq = 2.0 * sigma * sigma;
    float totalWeight = 0.0;
    vec3 result = vec3(0.0);
    const int MAX_SAMPLES = 16;
    int radius = int(min(float(MAX_SAMPLES), ceil(u_radius)));

    for (int i = -MAX_SAMPLES; i <= MAX_SAMPLES; ++i) {
      float offset = float(i);
      if (abs(offset) > float(radius)) continue;
      float weight = exp(-(offset * offset) / twoSigmaSq);
      vec2 sampleCoord = texCoords + u_direction * u_texelSize * offset;
      result += texture(u_texture, sampleCoord).rgb * weight;
      totalWeight += weight;
    }

    fragColor = vec4(result / totalWeight, 1.0);
  }
`;
function Bl(e) {
	let t = kl(e, e.VERTEX_SHADER, Rl()), n = kl(e, e.FRAGMENT_SHADER, zl), r = Al(e, t, n);
	return {
		program: r,
		shader: n,
		vertexShader: t,
		uniforms: {
			position: e.getAttribLocation(r, "position"),
			texture: e.getUniformLocation(r, "u_texture"),
			texelSize: e.getUniformLocation(r, "u_texelSize"),
			direction: e.getUniformLocation(r, "u_direction"),
			radius: e.getUniformLocation(r, "u_radius")
		}
	};
}
function Vl(e, t, n, r, i, a, o, s, c, l) {
	e.useProgram(a), e.bindBuffer(e.ARRAY_BUFFER, s), e.vertexAttribPointer(o.position, 2, e.FLOAT, !1, 0, 0), e.enableVertexAttribArray(o.position);
	let u = 1 / n, d = 1 / r;
	return e.bindFramebuffer(e.FRAMEBUFFER, c[0]), e.viewport(0, 0, n, r), e.activeTexture(e.TEXTURE0), e.bindTexture(e.TEXTURE_2D, t), e.uniform1i(o.texture, 0), e.uniform2f(o.texelSize, u, d), e.uniform2f(o.direction, 1, 0), e.uniform1f(o.radius, i), e.drawArrays(e.TRIANGLES, 0, 6), e.bindFramebuffer(e.FRAMEBUFFER, c[1]), e.viewport(0, 0, n, r), e.activeTexture(e.TEXTURE0), e.bindTexture(e.TEXTURE_2D, l[0]), e.uniform1i(o.texture, 0), e.uniform2f(o.direction, 0, 1), e.drawArrays(e.TRIANGLES, 0, 6), e.bindFramebuffer(e.FRAMEBUFFER, null), l[1];
}
var Hl = Ll`#version 300 es
precision mediump float;

in vec2 texCoords;

uniform sampler2D u_texture;
uniform vec2 u_texelSize;    // 1.0 / texture size
uniform vec2 u_direction;    // (1.0, 0.0) for horizontal, (0.0, 1.0) for vertical
uniform float u_radius;      // blur radius in texels

out vec4 fragColor;

void main() {
    vec3 sum = vec3(0.0);
    float count = 0.0;

    // Limit radius to avoid excessive loop cost
    const int MAX_RADIUS = 16;
    int radius = int(min(float(MAX_RADIUS), u_radius));

    for (int i = -MAX_RADIUS; i <= MAX_RADIUS; ++i) {
        if (abs(i) > radius) continue;

        vec2 offset = u_direction * u_texelSize * float(i);
        sum += texture(u_texture, texCoords + offset).rgb;
        count += 1.0;
  }

  fragColor = vec4(sum / count, 1.0);
}
`;
function Ul(e) {
	let t = kl(e, e.VERTEX_SHADER, Rl()), n = kl(e, e.FRAGMENT_SHADER, Hl), r = Al(e, t, n);
	return {
		program: r,
		vertexShader: t,
		fragmentShader: n,
		uniforms: {
			position: e.getAttribLocation(r, "position"),
			texture: e.getUniformLocation(r, "u_texture"),
			texelSize: e.getUniformLocation(r, "u_texelSize"),
			direction: e.getUniformLocation(r, "u_direction"),
			radius: e.getUniformLocation(r, "u_radius")
		}
	};
}
var Wl = Ll`#version 300 es
  precision mediump float;
  in vec2 texCoords;
  uniform sampler2D background;
  uniform bool disableBackground;
  uniform sampler2D frame;
  uniform sampler2D mask;
  out vec4 fragColor;
  
  void main() {
    vec4 frameTex = texture(frame, texCoords);

    if (disableBackground) {
      fragColor = frameTex;
    } else {
      vec4 bgTex = texture(background, texCoords);

      float maskVal = texture(mask, texCoords).r;

      // Compute screen-space gradient to detect edge sharpness
      float grad = length(vec2(dFdx(maskVal), dFdy(maskVal)));

      float edgeSoftness = 2.0; // higher = softer

      // Create a smooth edge around binary transition
      float smoothAlpha = smoothstep(0.5 - grad * edgeSoftness, 0.5 + grad * edgeSoftness, maskVal);

      // Optional: preserve frame alpha, or override as fully opaque
      vec4 blended = mix(bgTex, vec4(frameTex.rgb, 1.0), 1.0 - smoothAlpha);
      fragColor = blended;
    }
  
  }
`;
function Gl(e) {
	let t = kl(e, e.VERTEX_SHADER, Rl()), n = kl(e, e.FRAGMENT_SHADER, Wl), r = Al(e, t, n);
	return {
		program: r,
		vertexShader: t,
		fragmentShader: n,
		attribLocations: { position: e.getAttribLocation(r, "position") },
		uniformLocations: {
			mask: e.getUniformLocation(r, "mask"),
			frame: e.getUniformLocation(r, "frame"),
			background: e.getUniformLocation(r, "background"),
			disableBackground: e.getUniformLocation(r, "disableBackground"),
			stepWidth: e.getUniformLocation(r, "u_stepWidth")
		}
	};
}
function Kl(e, t, n) {
	let r = e.createTexture();
	e.bindTexture(e.TEXTURE_2D, r), e.texImage2D(e.TEXTURE_2D, 0, e.RGBA, t, n, 0, e.RGBA, e.UNSIGNED_BYTE, null), e.texParameteri(e.TEXTURE_2D, e.TEXTURE_MIN_FILTER, e.LINEAR), e.texParameteri(e.TEXTURE_2D, e.TEXTURE_MAG_FILTER, e.LINEAR), e.texParameteri(e.TEXTURE_2D, e.TEXTURE_WRAP_S, e.CLAMP_TO_EDGE), e.texParameteri(e.TEXTURE_2D, e.TEXTURE_WRAP_T, e.CLAMP_TO_EDGE);
	let i = e.createFramebuffer();
	e.bindFramebuffer(e.FRAMEBUFFER, i), e.framebufferTexture2D(e.FRAMEBUFFER, e.COLOR_ATTACHMENT0, e.TEXTURE_2D, r, 0);
	let a = Al(e, kl(e, e.VERTEX_SHADER, "\n      attribute vec2 position;\n      varying vec2 v_uv;\n      void main() {\n        v_uv = (position + 1.0) * 0.5;\n        gl_Position = vec4(position, 0.0, 1.0);\n      }\n    "), kl(e, e.FRAGMENT_SHADER, "\n      precision mediump float;\n      varying vec2 v_uv;\n      uniform sampler2D u_texture;\n      void main() {\n        gl_FragColor = texture2D(u_texture, v_uv);\n      }\n    "));
	return {
		framebuffer: i,
		texture: r,
		program: a,
		uniforms: {
			texture: e.getUniformLocation(a, "u_texture"),
			position: e.getAttribLocation(a, "position")
		}
	};
}
function ql(e, t, n, r, i, a) {
	return e.useProgram(n.program), e.bindFramebuffer(e.FRAMEBUFFER, n.framebuffer), e.viewport(0, 0, i, a), e.bindBuffer(e.ARRAY_BUFFER, r), e.enableVertexAttribArray(n.uniforms.position), e.vertexAttribPointer(n.uniforms.position, 2, e.FLOAT, !1, 0, 0), e.activeTexture(e.TEXTURE0), e.bindTexture(e.TEXTURE_2D, t), e.uniform1i(n.uniforms.texture, 0), e.drawArrays(e.TRIANGLES, 0, 6), e.bindFramebuffer(e.FRAMEBUFFER, null), n.texture;
}
var Jl = ml("livekit-track-processor-web-gl"), Yl = (e) => {
	let t = e.getContext("webgl2", {
		antialias: !0,
		premultipliedAlpha: !0
	}), n = null;
	if (!t) {
		Jl.error("Failed to create WebGL context");
		return;
	}
	t.enable(t.BLEND), t.blendFunc(t.SRC_ALPHA, t.ONE_MINUS_SRC_ALPHA);
	let r = Gl(t), i = r.program, a = r.attribLocations.position, { mask: o, frame: s, background: c, disableBackground: l } = r.uniformLocations, u = Bl(t), d = u.program, ee = u.uniforms, te = Ul(t), ne = te.program, re = te.uniforms, f = Ol(t, 0), ie = Ol(t, 1), ae = Nl(t);
	if (!ae) throw Error("Failed to create vertex buffer");
	let oe = [], se = [], ce = [], le = 0, ue = 1;
	oe.push(Ol(t, 3)), oe.push(Ol(t, 4));
	let de = Math.floor(e.width / 4), fe = Math.floor(e.height / 4), pe = Kl(t, de, fe);
	se.push(Ml(t, oe[0], de, fe)), se.push(Ml(t, oe[1], de, fe));
	let me = Ol(t, 5), he = Ml(t, me, e.width, e.height);
	ce.push(Ol(t, 6)), ce.push(Ol(t, 7));
	let ge = [Ml(t, ce[0], e.width, e.height), Ml(t, ce[1], e.width, e.height)], _e = null, ve = null, ye = e.width, be = e.height;
	function xe() {
		if (!(e.width === ye && e.height === be)) {
			ye = e.width, be = e.height, de = Math.floor(ye / 4), fe = Math.floor(be / 4);
			for (let e of [pe.texture, ...oe]) jl(t, e, de, fe);
			for (let e of [me, ...ce]) jl(t, e, ye, be);
			ve && we(ve);
		}
	}
	let Se = !1;
	t.useProgram(i), t.uniform1i(l, +!!Se), t.uniform1i(c, 0), t.uniform1i(s, 1), t.uniform1i(o, 2);
	function Ce(e) {
		if (e.codedWidth === 0 || ce.length === 0) return;
		let r = e.displayWidth, u = e.displayHeight;
		xe(), t.activeTexture(t.TEXTURE1), t.bindTexture(t.TEXTURE_2D, ie), t.texImage2D(t.TEXTURE_2D, 0, t.RGBA, t.RGBA, t.UNSIGNED_BYTE, e);
		let te = f;
		n ? te = Vl(t, ql(t, ie, pe, ae, de, fe), de, fe, n, d, ee, ae, se, oe) : _e && (t.activeTexture(t.TEXTURE0), t.bindTexture(t.TEXTURE_2D, f), t.texImage2D(t.TEXTURE_2D, 0, t.RGBA, t.RGBA, t.UNSIGNED_BYTE, _e), te = f), t.viewport(0, 0, r, u), t.clearColor(1, 1, 1, 1), t.clear(t.COLOR_BUFFER_BIT), t.useProgram(i), t.bindBuffer(t.ARRAY_BUFFER, ae), t.vertexAttribPointer(a, 2, t.FLOAT, !1, 0, 0), t.enableVertexAttribArray(a), t.activeTexture(t.TEXTURE0), t.bindTexture(t.TEXTURE_2D, te), t.uniform1i(c, 0), t.uniform1i(l, +!!Se), t.activeTexture(t.TEXTURE1), t.bindTexture(t.TEXTURE_2D, ie), t.uniform1i(s, 1), t.activeTexture(t.TEXTURE2), t.bindTexture(t.TEXTURE_2D, ce[le]), t.uniform1i(o, 2), t.drawArrays(t.TRIANGLES, 0, 6);
	}
	async function we(n) {
		if (ve = n, _e = null, n) {
			_e = Il();
			try {
				_e = await Pl(n, e.width, e.height);
			} catch (e) {
				Jl.error("Error processing background image, falling back to black background:", e);
			}
			t.activeTexture(t.TEXTURE0), t.bindTexture(t.TEXTURE_2D, f), t.texImage2D(t.TEXTURE_2D, 0, t.RGBA, t.RGBA, t.UNSIGNED_BYTE, _e);
		}
	}
	function Te(e) {
		n = e ? Math.max(1, Math.floor(e / 4)) : null, we(null);
	}
	function Ee(e) {
		Se = e;
	}
	function De(n) {
		if (ce.length === 0) return;
		xe();
		let r = [he, ge[ue]], i = [me, ce[ue]];
		Vl(t, n, e.width, e.height, 8, ne, re, ae, r, i), le = ue, ue = 1 - ue;
	}
	function Oe() {
		t.deleteProgram(i), t.deleteProgram(d), t.deleteProgram(ne), t.deleteTexture(f), t.deleteTexture(ie), t.deleteTexture(me), t.deleteFramebuffer(he);
		for (let e of oe) t.deleteTexture(e);
		for (let e of se) t.deleteFramebuffer(e);
		for (let e of ce) t.deleteTexture(e);
		for (let e of ge) t.deleteFramebuffer(e);
		t.deleteBuffer(ae), pe && (t.deleteTexture(pe.texture), t.deleteFramebuffer(pe.framebuffer), t.deleteProgram(pe.program)), _e &&= (_e instanceof ImageBitmap && _e.close(), null), ve = null, oe = [], se = [], ce = [];
	}
	return {
		renderFrame: Ce,
		updateMask: De,
		setBackgroundImage: we,
		setBlurRadius: Te,
		setBackgroundDisabled: Ee,
		cleanup: Oe
	};
}, Xl = class {
	constructor() {
		this.isDisabled = !1;
	}
	async init({ outputCanvas: e, inputElement: t }) {
		if (!(t instanceof HTMLVideoElement)) throw TypeError("Video transformer needs a HTMLVideoElement as input");
		this.transformer = new TransformStream({ transform: (e, t) => this.transform(e, t) }), this.canvas = e || null, e && (this.gl = Yl(this.canvas || wl(t.videoWidth, t.videoHeight))), this.inputVideo = t, this.isDisabled = !1;
	}
	async restart({ outputCanvas: e, inputElement: t }) {
		var n;
		this.canvas = e || null, (n = this.gl) == null || n.cleanup(), this.gl = Yl(this.canvas || wl(t.videoWidth, t.videoHeight)), this.inputVideo = t, this.isDisabled = !1;
	}
	async destroy() {
		var e;
		this.isDisabled = !0, this.canvas = void 0, (e = this.gl) == null || e.cleanup(), this.gl = void 0;
	}
}, Zl = class extends Xl {
	constructor(e) {
		super(), this.backgroundImageAndPath = null, this.segmentationTimeMs = 0, this.isFirstFrame = !0, this.log = ml("livekit-processor-wrapper"), this.options = e, this.update(e);
	}
	static get isSupported() {
		return typeof OffscreenCanvas < "u" && typeof VideoFrame < "u" && typeof createImageBitmap < "u" && !!document.createElement("canvas").getContext("webgl2");
	}
	async init({ outputCanvas: e, inputElement: t }) {
		var n, r;
		await super.init({
			outputCanvas: e,
			inputElement: t
		});
		let i = await es.forVisionTasks(this.options.assetPaths?.tasksVisionFileSet ?? `https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@${El["@mediapipe/tasks-vision"]}/wasm`);
		this.imageSegmenter = await $.createFromOptions(i, {
			baseOptions: {
				modelAssetPath: this.options.assetPaths?.modelAssetPath ?? "https://storage.googleapis.com/mediapipe-models/image_segmenter/selfie_segmenter/float16/latest/selfie_segmenter.tflite",
				delegate: "GPU",
				...this.options.segmenterOptions
			},
			canvas: this.canvas,
			runningMode: "VIDEO",
			outputCategoryMask: !0,
			outputConfidenceMasks: !1
		}), this.options?.imagePath && await this.loadAndSetBackground(this.options.imagePath).catch((e) => this.log.error("Error while loading processor background image: ", e)), typeof this.options.blurRadius == "number" && ((n = this.gl) == null || n.setBlurRadius(this.options.blurRadius)), (r = this.gl) == null || r.setBackgroundDisabled(this.options.backgroundDisabled ?? !1);
	}
	async destroy(e) {
		await super.destroy(), await this.imageSegmenter?.close(), this.backgroundImageAndPath = null, e?.willProcessorRestart || (this.isFirstFrame = !0);
	}
	async loadAndSetBackground(e) {
		var t;
		if (!this.backgroundImageAndPath || this.backgroundImageAndPath?.path !== e) {
			let t = new Image();
			await new Promise((n, r) => {
				t.crossOrigin = "Anonymous", t.onload = () => n(t), t.onerror = (e) => r(e), t.src = e;
			});
			let n = await createImageBitmap(t);
			this.backgroundImageAndPath = {
				imageData: n,
				path: e
			};
		}
		(t = this.gl) == null || t.setBackgroundImage(this.backgroundImageAndPath.imageData);
	}
	async transform(e, t) {
		var n, r;
		let i = !1;
		try {
			if (!(e instanceof VideoFrame) || e.codedWidth === 0 || e.codedHeight === 0) {
				this.log.debug("empty frame detected, ignoring");
				return;
			}
			let a = this.isDisabled ?? this.options.backgroundDisabled ?? !1;
			if (typeof this.options.blurRadius != "number" && typeof this.options.imagePath != "string" && (a = !0), a) {
				t.enqueue(e), i = !0;
				return;
			}
			let o = Date.now();
			if (!this.canvas) throw TypeError("Canvas needs to be initialized first");
			this.canvas.width = e.displayWidth, this.canvas.height = e.displayHeight, this.isFirstFrame && (t.enqueue(e.clone()), this.inputVideo && await new Promise((e) => {
				this.inputVideo.requestVideoFrameCallback((t, n) => {
					let r = n.expectedDisplayTime - n.presentationTime;
					setTimeout(e, r);
				});
			})), this.isFirstFrame = !1;
			let s = performance.now(), c = new Promise((t, n) => {
				var r;
				try {
					let n = performance.now();
					(r = this.imageSegmenter) == null || r.segmentForVideo(e, n, (e) => {
						this.segmentationTimeMs = performance.now() - n, this.segmentationResults = e, this.updateMask(e.categoryMask), e.close(), t();
					});
				} catch (e) {
					n(e);
				}
			});
			if (this.drawFrame(e), this.canvas && this.canvas.width > 0 && this.canvas.height > 0) {
				let i = new VideoFrame(this.canvas, { timestamp: e.timestamp || o });
				t.enqueue(i);
				let a = performance.now() - s, c = {
					processingTimeMs: this.segmentationTimeMs + a,
					segmentationTimeMs: this.segmentationTimeMs,
					filterTimeMs: a
				};
				(r = (n = this.options).onFrameProcessed) == null || r.call(n, c);
			} else t.enqueue(e);
			await c;
		} catch (e) {
			this.log.error("Error while processing frame: ", e);
		} finally {
			i || e.close();
		}
	}
	async update(e) {
		var t, n, r;
		this.options = {
			...this.options,
			...e
		}, (t = this.gl) == null || t.setBlurRadius(e.blurRadius ?? null), e.imagePath ? await this.loadAndSetBackground(e.imagePath) : (n = this.gl) == null || n.setBackgroundImage(null), (r = this.gl) == null || r.setBackgroundDisabled(e.backgroundDisabled ?? !1);
	}
	async drawFrame(e) {
		var t;
		this.gl && ((t = this.gl) == null || t.renderFrame(e));
	}
	async updateMask(e) {
		var t;
		e && ((t = this.gl) == null || t.updateMask(e.getAsWebGLTexture()));
	}
}, Ql = 0, $l = 10, eu = class {
	constructor(e = {}) {
		this.name = "gain-audio-processor";
		let t = e.gainValue ?? 1;
		this.gainValue = Math.max(Ql, Math.min($l, t));
	}
	static get isSupported() {
		return typeof AudioContext < "u" && typeof GainNode < "u" && typeof MediaStreamAudioSourceNode < "u" && typeof MediaStreamAudioDestinationNode < "u";
	}
	async init(e) {
		let { track: t, audioContext: n } = e;
		this.sourceNode = n.createMediaStreamSource(new MediaStream([t])), this.gainNode = n.createGain(), this.gainNode.gain.value = this.gainValue, this.destinationNode = n.createMediaStreamDestination(), this.sourceNode.connect(this.gainNode), this.gainNode.connect(this.destinationNode), this.processedTrack = this.destinationNode.stream.getAudioTracks()[0];
	}
	async restart(e) {
		await this.destroy(), await this.init(e);
	}
	async destroy() {
		var e, t, n, r;
		(e = this.sourceNode) == null || e.disconnect(), (t = this.gainNode) == null || t.disconnect(), (n = this.destinationNode) == null || n.disconnect(), (r = this.processedTrack) == null || r.stop(), this.sourceNode = void 0, this.gainNode = void 0, this.destinationNode = void 0, this.processedTrack = void 0;
	}
	setGain(e) {
		Number.isFinite(e) && (this.gainValue = Math.max(Ql, Math.min($l, e)), this.gainNode && (this.gainNode.gain.value = this.gainValue));
	}
	getGain() {
		return this.gainValue;
	}
	async onPublish(e) {
		console.debug(`[${this.name}] onPublish \u2014 room: ${e.name}`);
	}
	async onUnpublish() {
		console.debug(`[${this.name}] onUnpublish`);
	}
}, tu = 10, nu = () => Zl.isSupported && Tl.isSupported, ru = () => Zl.isSupported && Tl.hasModernApiSupport, iu = class extends Tl {
	get mode() {
		let e = this.transformer.options;
		return e.backgroundDisabled ? "disabled" : typeof e.imagePath == "string" && e.blurRadius === void 0 ? "virtual-background" : e.imagePath === void 0 ? "background-blur" : "legacy";
	}
	async switchTo(e) {
		switch (e.mode) {
			case "background-blur":
				await this.updateTransformerOptions({
					imagePath: void 0,
					blurRadius: e.blurRadius ?? tu,
					backgroundDisabled: !1
				});
				break;
			case "virtual-background":
				await this.updateTransformerOptions({
					imagePath: e.imagePath,
					blurRadius: void 0,
					backgroundDisabled: !1
				});
				break;
			case "disabled":
				await this.updateTransformerOptions({
					imagePath: void 0,
					backgroundDisabled: !0
				});
				break;
		}
	}
}, au = (e, t = "background-processor") => {
	let n = Zl.isSupported, r = Tl.isSupported;
	if (!n) throw Error("Background transformer is not supported in this browser");
	if (!r) throw Error("Neither MediaStreamTrackProcessor nor canvas.captureStream() fallback is supported in this browser");
	let i, a;
	switch (e.mode) {
		case "background-blur": {
			let { mode: t, blurRadius: n = tu, segmenterOptions: r, assetPaths: o, onFrameProcessed: s, ...c } = e;
			a = c, i = new Zl({
				blurRadius: n,
				segmenterOptions: r,
				assetPaths: o,
				onFrameProcessed: s
			});
			break;
		}
		case "virtual-background": {
			let { mode: t, imagePath: n, segmenterOptions: r, assetPaths: o, onFrameProcessed: s, ...c } = e;
			a = c, i = new Zl({
				imagePath: n,
				segmenterOptions: r,
				assetPaths: o,
				onFrameProcessed: s
			});
			break;
		}
		case "disabled": {
			let { segmenterOptions: t, assetPaths: n, onFrameProcessed: r, ...o } = e;
			a = o, i = new Zl({
				segmenterOptions: t,
				assetPaths: n,
				onFrameProcessed: r
			});
			break;
		}
		default: {
			let { blurRadius: t, imagePath: n, segmenterOptions: r, assetPaths: o, onFrameProcessed: s, ...c } = e;
			a = c, i = new Zl({
				blurRadius: t,
				imagePath: n,
				segmenterOptions: r,
				assetPaths: o,
				onFrameProcessed: s
			});
			break;
		}
	}
	return new iu(i, t, a);
}, ou = (e = tu, t, n, r) => au({
	blurRadius: e,
	segmenterOptions: t,
	onFrameProcessed: n,
	...r
}, "background-blur"), su = (e, t, n, r) => au({
	imagePath: e,
	segmenterOptions: t,
	onFrameProcessed: n,
	...r
}, "virtual-background");
//#endregion
export { ou as BackgroundBlur, au as BackgroundProcessor, iu as BackgroundProcessorWrapper, Zl as BackgroundTransformer, eu as GainAudioProcessor, ul as LogLevel, dl as LoggerNames, Tl as ProcessorWrapper, Xl as VideoTransformer, su as VirtualBackground, ml as getLogger, gl as setLogExtension, hl as setLogLevel, nu as supportsBackgroundProcessors, ru as supportsModernBackgroundProcessors };

//# sourceMappingURL=video-background-B_8_In0u.js.map